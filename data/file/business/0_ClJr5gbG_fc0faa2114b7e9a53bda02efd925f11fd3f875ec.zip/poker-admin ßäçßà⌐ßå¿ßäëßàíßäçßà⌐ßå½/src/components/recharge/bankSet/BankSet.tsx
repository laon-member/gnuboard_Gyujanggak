import { TableRowWrapper } from "components/common";
import React from "react";
import { FaPen } from "react-icons/fa";
import { TNewBankSet, TRechargeBankSet } from "stores/recharge/types";

interface Props {
  bankSet: TRechargeBankSet;
  edit: TNewBankSet;
}

function BankSet({ bankSet, edit }: Props) {
  return (
    <TableRowWrapper>
      <td>{bankSet.id}</td>
      <td>{bankSet.bank_name}</td>
      <td>{bankSet.bank_account}</td>
      <td>{bankSet.bank_number}</td>
      <td>{bankSet.is_active ? "SHOW" : "HIDE"}</td>
      <td className="icon" onClick={() => edit.onToggle(bankSet)}>
        <FaPen />
      </td>
    </TableRowWrapper>
  );
}

export default BankSet;
