﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DepositAccountContent : MonoBehaviour
{
    public DepositManager Main;

    public int ID = 0;

    // Start is called before the first frame update
    void Start()
    {
        //this.transform.GetChild(0).GetComponent<Button>().onClick.AddListener(OnClickEvent);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //void OnClickEvent()
    //{
    //    FindObjectOfType<DepositManager>().OnClickBtn_AccountArrow();
    //}

    public void SetInfo(string str, int id)
    {
        GetComponent<Text>().text = str;
        ID = id;
    }

    public void OnClickBtn_Account()
    {
        Main.OnClickBtn_AccountArrow();

        Main.SetAccount(this.GetComponent<Text>().text, ID);
    }

    public void SetMain(DepositManager main)
    {
        Main = main;
    }
}
