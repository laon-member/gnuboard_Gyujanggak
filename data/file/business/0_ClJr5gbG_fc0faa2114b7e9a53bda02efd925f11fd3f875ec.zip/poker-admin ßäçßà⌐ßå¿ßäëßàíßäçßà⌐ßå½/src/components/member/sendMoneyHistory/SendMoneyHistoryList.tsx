import NoDataBox from "components/common/NoDataBox";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import React from "react";
import { FaSearch } from "react-icons/fa";
import {
  TSMHistoryForms,
  TSMHistoryPage,
  TSMHistorySearch,
} from "stores/member/types";
import { Button, Input } from "styles/atom";
import SendMoneyHistory from "./SendMoneyHistory";

interface Props {
  sendMoneyHistoryPage: TSMHistoryPage;
  forms: TSMHistoryForms;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
}

const SendMoneyHistoryList = ({
  sendMoneyHistoryPage,
  forms,
  onSearch,
}: Props) => {
  const { search } = forms;
  const { onChange } = search;
  const {
    sender,
    receiver,
    start_date,
    end_date,
  } = search.inputs as TSMHistorySearch;
  return (
    <>
      <SearchWrapper>
        <SearchForm className="search" onSubmit={onSearch}>
          <Input
            className="id"
            placeholder="Sender ID"
            name="sender"
            value={sender}
            onChange={onChange}
          />
          <Input
            className="id"
            placeholder="Receive ID"
            name="receiver"
            value={receiver}
            onChange={onChange}
          />
          <Input
            type="date"
            name="start_date"
            value={start_date}
            onChange={onChange}
            className="date"
          />
          <Input
            type="date"
            name="end_date"
            value={end_date}
            onChange={onChange}
            className="date"
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>Sender ID</th>
            <th>Receiver ID</th>
            <th>Amount</th>
            <th>Agent</th>
            <th>Time</th>
          </tr>
        </thead>
        <tbody>
          {sendMoneyHistoryPage.paging.total_page
            ? sendMoneyHistoryPage.logs.map((log, idx) => (
                <SendMoneyHistory
                  key={idx}
                  log={log}
                  idx={
                    idx +
                    1 +
                    (sendMoneyHistoryPage.paging.current_page - 1) * 30
                  }
                />
              ))
            : null}
        </tbody>
      </Table>
      {sendMoneyHistoryPage.paging.total_page ? (
        <PageNationContainer
          paging={sendMoneyHistoryPage.paging}
          onSearch={onSearch}
          searchForm={forms.search}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
};

export default SendMoneyHistoryList;
