import { AxiosResponse } from "axios";
import { EditBoxType } from "components/member/memberlist/types";
import RollingList from "components/notice/rolling/RollingList";
import { useInputs } from "lib/hooks";
import { inject, observer } from "mobx-react";
import React, { useEffect, useState } from "react";
import RootStore from "stores";
import {
  AddRollingType,
  RollingPage,
  RollingSearchType,
  RollingType,
  UseInput,
} from "stores/notice/types";
import { WarningBoxType } from "stores/recharge/types";

interface Props {
  getRollingList: (payload: RollingSearchType) => void;
  rollingPage: RollingPage;
  addRolling: (payload: AddRollingType) => AxiosResponse<any>;
  deleteRollingToggle: (id: number) => void;
  getDeleteRollingList: RollingType[];
  deleteRolling: (payload: RollingType[]) => AxiosResponse<any>;
  deleteAllRollingToggle: () => void;
  rolling: RollingType;
  setRolling: (payload: RollingType) => void;
}

function RollingListContainer({
  getRollingList,
  rollingPage,
  addRolling,
  deleteRollingToggle,
  getDeleteRollingList,
  deleteRolling,
  deleteAllRollingToggle,
  rolling,
  setRolling,
}: Props) {
  const [newToggle, setNewToggle] = useState(false);
  const onRollingSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (forms.new.inputs.duration % 100 > 0) {
      return forms.new.setInputs({
        ...forms.new.inputs,
        validateInterval: true,
      });
    }

    try {
      const res = await addRolling(forms.new.inputs);
      if (res.data.result === 1) {
      } else if (res.data.result === 0) {
        alert("Failed to add rolling message, Try again");
      }
    } catch (error) {
      alert("There is a problem with the server");
    } finally {
      forms.new.init();
      forms.search.init();
      await getRollingList(forms.search.inputs);
      setNewToggle(false);
      setEditToggle(false);
    }
  };
  // new 키워드가 존재하기 때문에 언더바 붙임
  const _new: EditBoxType = {
    toggle: newToggle,
    onToggle: () => setNewToggle(!newToggle),
    onSubmit: onRollingSubmit,
  };

  const [editToggle, setEditToggle] = useState(false);

  const edit: EditBoxType = {
    toggle: editToggle,
    onToggle: (payload: RollingType) => {
      setRolling(payload);
      setEditToggle(!editToggle);
      forms.new.init();
    },
    onSubmit: onRollingSubmit,
    check: deleteRollingToggle,
  };

  const [deleteToggle, setDeleteToggle] = useState(false);
  const onDeleteSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      const res = await deleteRolling(getDeleteRollingList);
      if (res.data.result === 1) {
        alert("Successed to delete the messages");
        getRollingList(forms.search.inputs);
        return setDeleteToggle(false);
      } else if (res.data.result === 0) {
        alert("Failed to delete the messages");
        return setDeleteToggle(false);
      }
    } catch (error) {
      console.error(error);
      alert("There is a problem with the server");
      return setDeleteToggle(false);
    }
  };
  const _delete: WarningBoxType = {
    toggle: deleteToggle,
    onToggle: () => setDeleteToggle(!deleteToggle),
    onSubmit: onDeleteSubmit,
  };

  const forms: {
    search: UseInput;
    new: UseInput;
  } = {
    search: useInputs({
      content: "",
      start_date: "",
      end_date: "",
      position: "",
      page: 1,
      validateInterval: false,
    } as RollingSearchType),
    new: useInputs({
      content: "",
      start_date: "",
      end_date: "",
      duration: "",
      position: "",
      validateInterval: false,
    } as AddRollingType),
  };

  useEffect(() => {
    (async () => {
      await getRollingList(forms.search.inputs);
    })();
  }, []);

  const onSearch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    getRollingList(forms.search.inputs);
  };

  return (
    <RollingList
      onSearch={onSearch}
      _new={_new}
      edit={edit}
      _delete={_delete}
      rollingPage={rollingPage}
      forms={forms}
      deleteAllRollingToggle={deleteAllRollingToggle}
      rolling={rolling}
    />
  );
}

export default inject(({ noticeStore }: RootStore) => ({
  getRollingList: noticeStore.getRollingList,
  rollingPage: noticeStore.rollingPage,
  addRolling: noticeStore.addRolling,
  deleteRollingToggle: noticeStore.deleteRollingToggle,
  getDeleteRollingList: noticeStore.getDeleteRollingList,
  deleteRolling: noticeStore.deleteRolling,
  deleteAllRollingToggle: noticeStore.deleteAllRollingToggle,
  rolling: noticeStore.rolling,
  setRolling: noticeStore.setRolling,
}))(observer(RollingListContainer));
