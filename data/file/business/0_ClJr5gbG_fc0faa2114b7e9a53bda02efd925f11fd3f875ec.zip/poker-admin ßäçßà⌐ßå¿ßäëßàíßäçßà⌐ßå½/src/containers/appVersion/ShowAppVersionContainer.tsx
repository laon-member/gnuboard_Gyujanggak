import ShowAppVersion from "components/appVersion/ShowAppVersion";
import { inject, observer } from "mobx-react";
import React, { useEffect } from "react";
import RootStore from "stores";

interface Props {
  getAppVersion: () => void;
  appVersion: string;
}

function ShowAppVersionContainer({ getAppVersion, appVersion }: Props) {
  useEffect(() => {
    (async () => {
      await getAppVersion();
    })();
  }, []);
  return <ShowAppVersion appVersion={appVersion} />;
}

export default inject(({ adminStore }: RootStore) => ({
  getAppVersion: adminStore.getAppVersion,
  appVersion: adminStore.appVersion,
}))(observer(ShowAppVersionContainer));
