import GameLogListContainer from "containers/distributor/member/GameLogListContainer";
import MemberListContainer from "containers/distributor/member/MemberListContainer";
import RechargeListContainer from "containers/distributor/member/RechargeListContainer";
import SendMoneyHistoryListContainer from "containers/distributor/member/SendMoneyHistoryListContainer";
import SendMoneyListContainer from "containers/distributor/member/SendMoneyListContainer";
import WithdrawListContainer from "containers/distributor/member/WithdrawListContainer";
import { ContainerWrapper, SubNavContainer } from "pages/member/MemberPage";
import React from "react";
import { NavLink, Route, Switch } from "react-router-dom";

function AgentMemberPage() {
  return (
    <>
      <SubNavContainer>
        <li>
          <NavLink exact to="/agent/member" activeClassName="active">
            MemberList
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/agent/member/game" activeClassName="active">
            GameLog
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/agent/member/recharge" activeClassName="active">
            Recharge
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/agent/member/withdraw" activeClassName="active">
            Withdraw
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/agent/member/sendMoney" activeClassName="active">
            SendMoney
          </NavLink>
        </li>
        <li>
          <NavLink
            exact
            to="/agent/member/moneyHistory"
            activeClassName="active"
          >
            SendMoneyHistory
          </NavLink>
        </li>
      </SubNavContainer>
      <ContainerWrapper>
        <Switch>
          <Route exact path="/agent/member" component={MemberListContainer} />
          <Route
            exact
            path="/agent/member/game"
            component={GameLogListContainer}
          />
          <Route
            exact
            path="/agent/member/recharge"
            component={RechargeListContainer}
          />
          <Route
            exact
            path="/agent/member/withdraw"
            component={WithdrawListContainer}
          />
          <Route
            exact
            path="/agent/member/sendMoney"
            component={SendMoneyListContainer}
          />
          <Route
            exact
            path="/agent/member/moneyHistory"
            component={SendMoneyHistoryListContainer}
          />
        </Switch>
      </ContainerWrapper>
    </>
  );
}

export default AgentMemberPage;
