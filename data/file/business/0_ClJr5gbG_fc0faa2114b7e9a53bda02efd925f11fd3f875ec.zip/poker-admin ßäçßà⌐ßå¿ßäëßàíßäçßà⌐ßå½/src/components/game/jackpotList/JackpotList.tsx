import NoDataBox from "components/common/NoDataBox";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import { Invalid } from "components/login/Login";
import { EditBoxType } from "components/member/memberlist/types";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import JackpotEditBoxContainer from "containers/game/JackpotEditBoxContainer";
import comma from "lib/comma";
import React from "react";
import { FaSearch } from "react-icons/fa";
import {
  JackpotInfo,
  JackpotPage,
  PolicyType,
  SearchJackpotType,
} from "stores/jackpot/types";
import { GMFormType } from "stores/message/types";
import { UseInput } from "stores/notice/types";
import styled from "styled-components";
import { Button, Input } from "styles/atom";
import Jackpot from "./Jackpot";
import Policy from "./Policy";

interface Props {
  jackpot: EditBoxType;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
  jackpotInfo: JackpotInfo;
  policyInfo: PolicyType[];
  jackpotPage: JackpotPage;
  searchForm: GMFormType;
  policyForm: UseInput;
}

function JackpotList({
  jackpot,
  onSearch,
  jackpotInfo,
  policyInfo,
  jackpotPage,
  searchForm: { inputs, onChange },
  policyForm,
}: Props) {
  if (!jackpotInfo) return <div>Could not get jackpot information.</div>;
  const {
    jackpot_amount,
    today_send,
    limit_amount,
  } = jackpotInfo as JackpotInfo;
  const { id, start_date, end_date } = inputs as SearchJackpotType;
  return (
    <>
      {jackpot.toggle && (
        <JackpotEditBoxContainer
          type={jackpot}
          policyForm={policyForm}
          jackpotInfo={jackpotInfo}
          policyInfo={policyInfo}
        />
      )}
      <JackpotTitle>
        <div>
          <h3>Jackpot Amount : </h3>
          <span>{!jackpot_amount ? "0" : comma(jackpot_amount)}</span>
        </div>
        <div>
          <h3>Today send : </h3>
          <span>{!today_send ? "0" : comma(today_send)}</span>
        </div>
        <div>
          <h3>Limit : </h3>
          <span>{!limit_amount ? "0" : limit_amount}</span>
        </div>
        <Button onClick={jackpot.onToggle}>Edit</Button>
      </JackpotTitle>
      <JackpotInfoTable>
        <thead>
          <tr>
            <th>ROOM TYPE</th>
            <th>CONSUME</th>
            <th>GUARANTEE</th>
          </tr>
        </thead>
        <tbody>
          {policyInfo.map((policy, index) => (
            <Policy key={policy.level.key} room={index + 1} policy={policy} />
          ))}
        </tbody>
      </JackpotInfoTable>
      <SearchWrapper>
        <SearchForm className="search" onSubmit={onSearch}>
          <Input
            name="id"
            value={id}
            onChange={onChange}
            placeholder="ID"
            className="id"
          />
          <Input
            type="date"
            name="start_date"
            value={start_date}
            onChange={onChange}
            className="date"
          />
          <Input
            type="date"
            name="end_date"
            value={end_date}
            onChange={onChange}
            className="date"
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>Winner</th>
            <th>Amount</th>
            <th>WinTime</th>
            <th>AdminName</th>
            <th>Note</th>
          </tr>
        </thead>
        <tbody>
          {jackpotPage.paging.total_page
            ? jackpotPage.jackpot.map((jackpot) => (
                <Jackpot key={jackpot.id} jackpot={jackpot} />
              ))
            : null}
        </tbody>
      </Table>
      {jackpotPage.paging.total_page ? (
        <PageNationContainer
          paging={jackpotPage.paging}
          onSearch={onSearch}
          searchForm={{ inputs, onChange }}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
}

const JackpotInfoTable = styled.table`
  border-collapse: collapse;

  & th,
  td {
    width: 200px;
    border: 1px solid #d7e0dd;
  }

  & th {
    background: #555;
    color: #fff;
    padding: 0.825rem 0;
  }
`;

const JackpotTitle = styled.div`
  display: flex;
  align-items: center;
  padding: 2rem 0;
  font-size: 1.5rem;

  div {
    display: flex;
    align-items: center;
  }
  div + div {
    margin-left: 1rem;
  }

  h3 {
    font-size: 1rem;
    font-weight: bold;
    display: inline-block;
  }
  span {
    color: #007fdb;
  }

  h3 + span {
    margin-left: 1rem;
  }

  button {
    margin-left: 1rem;
  }
`;

export default JackpotList;
