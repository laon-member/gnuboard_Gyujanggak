/* eslint-disable no-restricted-globals */
import React, { useState } from "react";
import styled from "styled-components";
import { DepositType } from "stores/deposit/types";
import BanksetItem from "../Bankset/item/BanksetItem";
import useInputs from "lib/hooks/useInputs";
import Table from "components/common/Table";
import { DialogContainer } from "containers/common/dialog";
import { Input, Button } from "styles/atom";
import del from "assets/icons/del.png";

interface Props {
  deposit: DepositType;
  depositList: DepositType[];
  onCreateBankSet: (
    addBankName: string,
    addAccountHolder: string,
    addAccountNumber: string
  ) => void;
  onSearch: (name?: string, account?: string) => void;
  onActiveToggle: (id: number) => void;
  activeDepositList: number[];
  onRemoveDeposit: (id: number[]) => void;
}

function Bankset({
  depositList,
  onCreateBankSet,
  onSearch,
  onActiveToggle,
  activeDepositList,
  onRemoveDeposit,
}: Props) {
  const { inputs, onChange, init } = useInputs({
    addBankName: "",
    addAccountHolder: "",
    addAccountNumber: "",
    account: "",
    name: "",
  });
  const {
    addBankName,
    addAccountHolder,
    addAccountNumber,
    account,
    name,
  } = inputs;
  const [createToggle, setCreateToggle] = useState(false);
  const [removeToggle, setRemoveToggle] = useState(false);

  const onToggle = (type: string) => {
    switch (type) {
      case "create":
        return setCreateToggle(!createToggle);
      case "remove":
        return setRemoveToggle(!removeToggle);
      default:
        break;
    }
  };

  const onSave = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (
      addBankName === "" ||
      addAccountHolder === "" ||
      addAccountNumber === ""
    )
      return alert("type to inputs");
    onCreateBankSet(addBankName, addAccountHolder, addAccountNumber);
    init();
  };

  const onRemove = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (activeDepositList.length === 0) {
      alert("Select bank set.");
      onToggle("remove");
      return;
    }
    onRemoveDeposit(activeDepositList);
  };

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onSearch(name, account);
  };

  return (
    <>
      <>
        {createToggle && (
          <DialogContainer
            title="CREATE BANK SET"
            onToggle={() => onToggle("create")}
            onSubmit={onSave}
          >
            <InputWrapper>
              <label>BANK NAME</label>
              <Input
                name="addBankName"
                value={addBankName}
                onChange={onChange}
                placeholder="type bank name"
              />
            </InputWrapper>
            <InputWrapper>
              <label>ACCOUNT HODLER</label>
              <Input
                name="addAccountHolder"
                value={addAccountHolder}
                onChange={onChange}
                placeholder="type account holder"
              />
            </InputWrapper>
            <InputWrapper>
              <label>ACCOUNT NUMBER</label>
              <Input
                name="addAccountNumber"
                value={addAccountNumber}
                onChange={onChange}
                placeholder="type account number"
              />
            </InputWrapper>
          </DialogContainer>
        )}
        {removeToggle && (
          <DialogContainer
            title="REMOVE BANK SET"
            onToggle={() => onToggle("remove")}
            onSubmit={onRemove}
          >
            <p>
              Are you sure you want to delete a total of{" "}
              {activeDepositList.length} bank account?
            </p>
          </DialogContainer>
        )}
        <SearchWrapper>
          <Button onClick={() => onToggle("create")}>CREATE</Button>
          <Button secondary onClick={() => onToggle("remove")}>
            <img src={del} alt="del" />
          </Button>
          <SearchForm onSubmit={onSubmit} className="search">
            <Input
              name="name"
              placeholder="bank name"
              className="ordernumber"
              value={name}
              onChange={onChange}
            />
            <Input
              name="account"
              placeholder="account"
              className="mobile"
              value={account}
              onChange={onChange}
            />
            <Button type="submit">SEARCH</Button>
          </SearchForm>
        </SearchWrapper>
        <Table>
          <thead>
            <tr>
              <th>No.</th>
              <th>Bank name</th>
              <th>Account Holder</th>
              <th>Account number</th>
            </tr>
          </thead>
          <tbody>
            {depositList.map((data, idx) => (
              <BanksetItem
                key={idx}
                data={data}
                onActiveToggle={onActiveToggle}
              />
            ))}
          </tbody>
        </Table>
      </>
    </>
  );
}

export const SearchForm = styled.form`
  display: flex;
  align-items: center;

  & > * {
    margin-right: 1rem;
  }
`;

export const SearchWrapper = styled.div`
  display: flex;
  align-items: center;
  margin: 1rem 0;

  & button {
    height: 2.5rem;
    margin-right: 1rem;
  }
`;

export const InputWrapper = styled.div`
  display: flex;
  align-items: center;
  label {
    flex: 2;
    padding: 1rem;
    text-align: right;
  }
  & > *:not(label) {
    flex: 3;
  }
`;

export default Bankset;
