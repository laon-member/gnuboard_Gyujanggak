import NoDataBox from "components/common/NoDataBox";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import React from "react";
import { FaSearch } from "react-icons/fa";
import { Finance, TFinanceForms } from "stores/member/types";
import { PagingType } from "stores/message/types";
import { Button, Input } from "styles/atom";
import { FinanceLog } from ".";
import NoteBox from "../block/NoteBox";
import { NoteType } from "../memberlist/types";

interface Props {
  note: NoteType;
  financeList: Finance[];
  finance: Finance;
  financePage: PagingType;
  forms: TFinanceForms;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
}

const FinanceLogList = ({
  note,
  financeList,
  finance,
  financePage,
  forms,
  onSearch,
}: Props) => {
  const { onChange } = forms.search;

  return (
    <>
      {note.toggle && (
        <NoteBox content={finance.note!} onToggle={note.onToggle} />
      )}
      <SearchWrapper>
        <SearchForm onSubmit={onSearch}>
          <Input type="text" placeholder="ID" name="id" onChange={onChange} />
          <Input
            type="text"
            placeholder="NickName"
            name="name"
            onChange={onChange}
          />
          <Input type="date" name="start_date" onChange={onChange} />
          <Input type="date" name="end_date" onChange={onChange} />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>Ninkname</th>
            <th>Type</th>
            <th>Gold</th>
            <th>AdminName</th>
            <th>HandleTime</th>
            <th>Note</th>
          </tr>
        </thead>
        <tbody>
          {financePage.total_page
            ? financeList.map((log) => (
                <FinanceLog key={log.id} note={note} log={log} />
              ))
            : null}
        </tbody>
      </Table>
      {financePage.total_page ? (
        <PageNationContainer
          paging={financePage}
          onSearch={onSearch}
          searchForm={forms.search}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
};

export default FinanceLogList;
