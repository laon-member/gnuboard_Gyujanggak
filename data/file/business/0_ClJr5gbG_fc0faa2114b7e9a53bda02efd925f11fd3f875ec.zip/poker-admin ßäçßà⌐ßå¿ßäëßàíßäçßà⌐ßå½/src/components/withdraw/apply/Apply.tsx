import { TableRowWrapper } from "components/common";
import { OptButtonsWrapper } from "components/recharge/applyList/Apply";
import { CancleType } from "components/recharge/applyList/types";
import comma from "lib/comma";
import React from "react";
import { WarningBoxType } from "stores/recharge/types";
import { WithdrawApplyType } from "stores/withdraw/types";
import { Button } from "styles/atom";

interface Props {
  apply: WithdrawApplyType;
  ok: WarningBoxType;
  reserve: WarningBoxType;
  cancle: CancleType;
}

function Apply({ apply, ok, reserve, cancle }: Props) {
  return (
    <TableRowWrapper>
      <td>{apply.id}</td>
      <td>{apply.username}</td>
      <td>{apply.agent}</td>
      <td>{apply.phone}</td>
      <td>{apply.name}</td> {/* name: bankAccount */}
      <td>{apply.bank}</td> {/* bank: bankName */}
      <td>{apply.number}</td>
      <td>{apply.created_at}</td>
      <td>{comma(apply.amount)}</td>
      <OptButtonsWrapper>
        <Button
          bgColor="#70C44D"
          color="white"
          onClick={apply.status === 5 ? () => ok.onToggle(apply) : undefined}
        >
          OK
        </Button>
        {apply.status === 5 ? (
          <Button bgColor="gary" color="black" disabled>
            RESERVED
          </Button>
        ) : (
          <Button
            bgColor="#FFC124"
            color="white"
            onClick={() => reserve.onToggle(apply)}
          >
            RESERVE
          </Button>
        )}
        <Button
          bgColor="#E44849"
          color="white"
          onClick={
            apply.status === 5 ? () => cancle.onToggle(apply) : undefined
          }
        >
          CANCEL
        </Button>
      </OptButtonsWrapper>
    </TableRowWrapper>
  );
}

export default Apply;
