import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import Member from "./Member";
import { OverFlowWrapper } from "components/member/memberlist/MemberList";
import React from "react";
import { FaSearch } from "react-icons/fa";
import {
  TMemberListForms,
  TMemberListPage,
  TMemberListSearch,
} from "stores/distributor/member/types";
import { Button, Input, Select } from "styles/atom";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import NoDataBox from "components/common/NoDataBox";

interface Props {
  memberListPage: TMemberListPage;
  forms: TMemberListForms;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
}

function MemberList({ memberListPage, forms, onSearch }: Props) {
  const { search } = forms;
  const { onChange } = search;
  const {
    username,
    nickname,
    date_type,
    start_date,
    end_date,
  } = search.inputs as TMemberListSearch;
  return (
    <>
      <SearchWrapper>
        <SearchForm onSubmit={onSearch}>
          <Input
            type="text"
            placeholder="ID"
            name="username"
            value={username}
            onChange={onChange}
          />
          <Input
            type="text"
            placeholder="NickName"
            name="nickname"
            value={nickname}
            onChange={onChange}
          />
          <Select name="date_type" value={date_type} onChange={onChange}>
            <option value="" disabled selected>
              Select Date Type
            </option>
            <option value="REGISTER">Register</option>
            <option value="LAST_LOGIN">LastLogin</option>
          </Select>
          <Input
            type="date"
            name="start_date"
            value={start_date}
            onChange={onChange}
          />
          <Input
            type="date"
            name="end_date"
            value={end_date}
            onChange={onChange}
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <OverFlowWrapper>
        <Table>
          <thead>
            <tr>
              <th>No.</th>
              <th>UserNumber</th>
              <th>Room</th>
              <th>ID</th>
              <th>NickName</th>
              <th>Agent</th>
              <th>Mobile</th>
              <th>
                {/* <FaSortUp onClick={() => console.log("asc")} /> */}
                {"  "} Gold{"  "}
                {/* <FaSortDown onClick={() => console.log("desc")} /> */}
              </th>
              <th>RegisterTime</th>
              <th>LastLogin</th>
              <th>BankAccount</th>
              <th>BankName</th>
              <th>CardNumber</th>
            </tr>
          </thead>
          <tbody>
            {memberListPage.paging.total_page
              ? memberListPage.users.map((member, idx) => (
                  <Member
                    idx={
                      idx + 1 + (memberListPage.paging.current_page - 1) * 30
                    }
                    key={member.id}
                    member={member}
                  />
                ))
              : null}
          </tbody>
        </Table>
      </OverFlowWrapper>
      {memberListPage.paging.total_page ? (
        <PageNationContainer
          paging={memberListPage.paging}
          searchForm={forms.search}
          onSearch={onSearch}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
}

export default MemberList;
