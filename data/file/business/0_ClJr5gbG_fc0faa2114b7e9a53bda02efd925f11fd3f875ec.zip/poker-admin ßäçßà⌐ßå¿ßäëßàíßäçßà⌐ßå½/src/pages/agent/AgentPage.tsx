import React from "react";

import { Route, NavLink, Switch } from "react-router-dom";
import { ContainerWrapper, SubNavContainer } from "pages/member/MemberPage";
import AgentListContainer from "containers/agent/AgentListContainer";
import AddAgentMoneyHistoryContainer from "containers/agent/AddAgentMoneyHistoryContainer";

function AgentPage() {
  return (
    <>
      <SubNavContainer>
        <li>
          <NavLink exact to="/admin/agent" activeClassName="active">
            AgentList
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/admin/agent/money" activeClassName="active">
            AddAgentMoneyHistory
          </NavLink>
        </li>
      </SubNavContainer>
      <ContainerWrapper>
        <Switch>
          <Route exact path="/admin/agent" component={AgentListContainer} />
          <Route
            exact
            path="/admin/agent/money"
            component={AddAgentMoneyHistoryContainer}
          />
        </Switch>
      </ContainerWrapper>
    </>
  );
}

export default AgentPage;
