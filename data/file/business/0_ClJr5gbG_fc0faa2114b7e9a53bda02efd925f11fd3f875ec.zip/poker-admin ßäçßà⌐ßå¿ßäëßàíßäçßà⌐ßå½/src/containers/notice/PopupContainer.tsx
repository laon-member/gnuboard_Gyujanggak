import { AxiosResponse } from "axios";
import Popup from "components/notice/popup/Popup";
import { useInputs } from "lib/hooks";
import { inject, observer } from "mobx-react";
import React, { useEffect } from "react";
import RootStore from "stores";
import { PopUpFormType, TPopUp, UseInput } from "stores/notice/types";

interface Props {
  createPopUp: (inputs: PopUpFormType) => AxiosResponse<any>;
  getPopUp: () => void;
  popUp: TPopUp;
}

function PopupContainer({ createPopUp, getPopUp, popUp }: Props) {
  const { inputs, onChange, setInputs } = useInputs({
    title: "",
    content: "",
  } as PopUpFormType);

  useEffect(() => {
    (async () => {
      await getPopUp();
    })();
  }, []);

  const onSend = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      const res = await createPopUp(inputs);
      if (res.status === 200) {
        alert("Successed to save popup message");
      } else return alert("failed to send message, try again");
    } catch (error) {
      return alert("There is a problem with the server");
    }
  };
  return (
    <Popup
      onSend={onSend}
      sendForm={{ inputs, onChange, setInputs } as UseInput}
      popUp={popUp}
    />
  );
}

export default inject(({ noticeStore }: RootStore) => ({
  createPopUp: noticeStore.createPopUp,
  getPopUp: noticeStore.getPopUp,
  popUp: noticeStore.popUp,
}))(observer(PopupContainer));
