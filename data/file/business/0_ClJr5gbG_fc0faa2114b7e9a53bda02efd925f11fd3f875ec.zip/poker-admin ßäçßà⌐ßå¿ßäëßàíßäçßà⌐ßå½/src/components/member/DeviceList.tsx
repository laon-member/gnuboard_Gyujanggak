import React from "react";

const DeviceList = () => {
  return (
    <>
      <h1>device list</h1>
    </>
  );
};

export default DeviceList;
