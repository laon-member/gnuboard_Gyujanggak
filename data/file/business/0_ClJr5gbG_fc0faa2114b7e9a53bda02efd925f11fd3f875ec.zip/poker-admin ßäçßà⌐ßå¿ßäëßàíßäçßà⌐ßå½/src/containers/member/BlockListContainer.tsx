import BlockList from "components/member/block/BlockList";
import { NoteType } from "components/member/memberlist/types";
import { useInputs } from "lib/hooks";
import { inject, observer, useObserver } from "mobx-react";
import React, { useEffect, useState } from "react";
import {
  MemberAmount,
  MemberSearch,
  MemberType,
  TBlock,
  TBlockForms,
  TEditMember,
} from "stores/member/types";
import { PagingType } from "stores/message/types";

interface Props {
  getBlockList: (blockSearch: MemberSearch) => void;
  getMember: (id: number) => void;
  updateMember: (modifyMember: MemberType) => void;
  updateMemberEdit: (modifyMemberAmount: MemberAmount) => void;
  blockList: TBlock[];
  member: MemberType;
  blockPage: PagingType;
}

const BlockListContainer = ({
  getBlockList,
  blockList,
  getMember,
  updateMember,
  updateMemberEdit,
  member,
  blockPage,
}: Props) => {
  const forms = {
    search: useInputs({
      id: "",
      name: "",
      start_date: "",
      end_date: "",
      page: 1,
    } as MemberSearch),
    edit: useInputs({
      id: 0,
      bank: "",
      bankName: "",
      bankNumber: "",
      phone: "",
      password: "",
      check_password: "",
    } as TEditMember),
  } as TBlockForms;
  const [editToggle, setEditToggle] = useState(false);
  const [infoToggle, setInfoToggle] = useState(false);
  const [noteToggle, setNoteToggle] = useState(false);

  useEffect(() => {
    (async () => {
      await getBlockList(forms.search.inputs);
    })();
  }, []);

  const note: NoteType = {
    toggle: noteToggle,
    onToggle: () => setNoteToggle(!noteToggle),
  };

  const onEditToggle = () => {
    setEditToggle(!editToggle);
  };
  const onInfoToggle = () => {
    setInfoToggle(!infoToggle);
  };

  const onEditSubmit = async (
    e: React.FormEvent<HTMLFormElement>,
    modifyMemberAmount?: MemberAmount
  ) => {
    e.preventDefault();
    const { amount, option } = modifyMemberAmount as MemberAmount;
    if (amount) {
      if (option) {
        if (option !== "INCREASE" && option !== "DECREASE") {
          alert("Please select an option.");
          return;
        }
      } else {
        alert("Please select an option.");
        return;
      }
    }
    await updateMemberEdit(modifyMemberAmount!);
    await setEditToggle(false);
    await getBlockList(forms.search.inputs);
  };
  const onInfoSubmit = async (
    e: React.FormEvent<HTMLFormElement>,
    modifyMember?: MemberType
  ) => {
    e.preventDefault();
    await updateMember(modifyMember!);
    await setInfoToggle(false);
    await getBlockList(forms.search.inputs);
  };

  const onSearch = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    await getBlockList(forms.search.inputs);
  };

  return useObserver(() => (
    <BlockList
      editToggle={editToggle}
      infoToggle={infoToggle}
      onEditToggle={onEditToggle}
      onInfoToggle={onInfoToggle}
      onEditSubmit={onEditSubmit}
      onInfoSubmit={onInfoSubmit}
      blockList={blockList}
      getMember={getMember}
      member={member}
      getBlocks={getBlockList}
      note={note}
      forms={forms}
      onSearch={onSearch}
      blockPage={blockPage}
    />
  ));
};
export default inject(({ memberStore }) => ({
  getBlockList: memberStore.getBlockList,
  updateMember: memberStore.updateMember,
  updateMemberEdit: memberStore.updateMemberEdit,
  blockList: memberStore.blockList,
  getMember: memberStore.getBlock,
  member: memberStore.member,
  blockPage: memberStore.blockPage,
}))(observer(BlockListContainer));
