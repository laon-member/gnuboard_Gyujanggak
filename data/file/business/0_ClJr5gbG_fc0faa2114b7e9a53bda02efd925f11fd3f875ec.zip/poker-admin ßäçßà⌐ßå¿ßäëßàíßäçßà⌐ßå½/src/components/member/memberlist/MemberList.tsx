import React from "react";
import { FaSearch } from "react-icons/fa";

import { Button, Input } from "styles/atom";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import Member from "./Member";
import ChangeBox from "./ChangeBox";
import EditBoxContainer from "containers/common/dialog/EditBoxContainer";
import {
  MemberAmount,
  MemberSearch,
  MemberType,
  TMemberForms,
} from "stores/member/types";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import { PagingType } from "stores/message/types";
import styled from "styles/theme-components";
import NoDataBox from "components/common/NoDataBox";
import { TAgent } from "stores/user/types";

interface Props {
  infoToggle: boolean;
  onInfoToggle: () => void;
  onInfoSubmit: (
    e: React.FormEvent<HTMLFormElement>,
    modifyMember?: MemberType
  ) => void;
  editToggle: boolean;
  onEditToggle: () => void;
  onEditSubmit: (
    e: React.FormEvent<HTMLFormElement>,
    memberAmount: MemberAmount
  ) => void;
  memberList: MemberType[];
  getMembers: (memberSearch: MemberSearch) => void;
  forms: TMemberForms;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
  getMember: (id: number) => void;
  member?: MemberType;
  memberAmount: MemberAmount;
  memberPage: PagingType;
}

const MemberList = ({
  infoToggle,
  onInfoToggle,
  onInfoSubmit,
  editToggle,
  onEditToggle,
  onEditSubmit,
  memberList,
  onSearch,
  getMember,
  forms,
  member,
  memberAmount,
  memberPage,
}: Props) => {
  const { search } = forms;
  const { onChange } = search;

  const { id, name, start_date, end_date } = forms.search
    .inputs as MemberSearch;
  return (
    <>
      {editToggle && (
        <EditBoxContainer
          onEditToggle={onEditToggle}
          onEditSubmit={onEditSubmit}
          member={member}
          memberAmount={memberAmount}
        />
      )}
      {infoToggle && (
        <ChangeBox
          onInfoToggle={onInfoToggle}
          onInfoSubmit={onInfoSubmit}
          member={member}
          form={forms.edit}
        />
      )}
      <SearchWrapper>
        <SearchForm onSubmit={onSearch}>
          <Input
            type="text"
            placeholder="ID"
            name="id"
            value={id}
            onChange={onChange}
          />
          <Input
            type="text"
            placeholder="NickName"
            name="name"
            value={name}
            onChange={onChange}
          />
          <Input
            type="date"
            name="start_date"
            value={start_date}
            onChange={onChange}
          />
          <Input
            type="date"
            name="end_date"
            value={end_date}
            onChange={onChange}
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <OverFlowWrapper>
        <Table>
          <thead>
            <tr>
              <th>No.</th>
              <th>UserNumber</th>
              <th>Room</th>
              <th>ID</th>
              <th>NickName</th>
              <th>Agent</th>
              <th>Mobile</th>
              <th>
                {/* <FaSortUp onClick={() => console.log("asc")} /> */}
                {"  "} Gold{"  "}
                {/* <FaSortDown onClick={() => console.log("desc")} /> */}
              </th>
              <th>RegisterTime</th>
              <th>LastLogin</th>
              <th>BankAccount</th>
              <th>BankName</th>
              <th>CardNumber</th>
              <th>RechargeSum</th>
              <th>WithdrawSum</th>
              <th>SendMoney</th>
              <th>ReceiveMoney</th>
              <th>Otp</th>
              <th>ChangeInfo</th>
            </tr>
          </thead>
          <tbody>
            {memberPage.total_page
              ? memberList.map((member, idx) => (
                  <Member
                    idx={idx}
                    paging={memberPage}
                    key={member.id}
                    member={member}
                    onInfoToggle={() => onInfoToggle()}
                    getMember={getMember}
                    onEditToggle={onEditToggle}
                  />
                ))
              : null}
          </tbody>
        </Table>
      </OverFlowWrapper>
      {memberPage.total_page ? (
        <PageNationContainer
          paging={memberPage}
          searchForm={forms.search}
          onSearch={onSearch}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
};

export const OverFlowWrapper = styled.div`
  overflow-x: scroll;
`;

export default MemberList;
