import React from "react";
import styled from "styled-components";

const ApplyOptionApprove = () => {
  return (
    <Wrap>
      <div className="title">
        <h2>OK</h2>
      </div>

      <div className="amount">
        <div>
          <p>ID</p>
          <p>홍길동</p>
        </div>
        <div>
          <p>Amount</p>
          <p>90,000</p>
        </div>
        <div className="charge">
          <span>충전하시겠습니까?</span>
        </div>
      </div>

      <div className="button">
        <button>확인</button>
        <button>취소</button>
      </div>
    </Wrap>
  );
};

const Wrap = styled.div`
  width: 550px;
  height: 400px;

  background: #fff;

  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);

  & > .title {
    width: 100%;
    height: 68px;

    text-align: center;
    line-height: 68px;

    border-bottom: 1px solid #ddd;

    & > h2 {
      font-weight: normal;
      font-size: 18px;
      color: #333;
    }
  }

  & > .amount {
    width: 100%;
    height: 249px;

    text-align: center;

    padding-top: 60px;
    & > div {
      width: 158px;
      margin: 0 auto;
      overflow: hidden;
      margin-bottom: 10px;
      & > p {
        float: left;
      }
      & > p:nth-child(1) {
        width: 70px;
        height: 25px;

        font-size: 16px;
        color: #333;
        text-align: left;
      }

      & > p:nth-child(2) {
        width: 88px;
        height: 25px;

        font-size: 16px;
        color: #333;
        text-align: right;
      }
    }

    & > .charge {
      width: 100%;
      text-align: cneter;

      margin-top: 52px;

      & > span {
        font-size: 14px;
        color: #888;
      }
    }
  }

  & > .button {
    width: 100%;
    height: 82px;

    text-align: center;
    line-height: 70px;

    & > button:nth-child(1) {
      width: 195px;
      height: 40px;
      background: #007fdb;
      border: none;
      color: #fff;
    }
    & > button:nth-child(2) {
      width: 195px;
      height: 40px;
      background: #ddd;
      border: none;
      color: #333;
      margin-left: 20px;
    }
  }
`;

export default ApplyOptionApprove;
