﻿using System.Collections;
using System.Net;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using Photon.Pun;
using Photon.Realtime;

using LitJson;
using Leguar.TotalJSON;

public class LobbyManager : MonoBehaviourPunCallbacks
{
    [System.Serializable]
    public struct SPreferences
    {
        public Image[] GameSound;
        public Image[] BGM;

        public Sprite[] Spr;
    }
    public SPreferences Prefernces;

    public Button[] Arr_JoinLobbyBtn;

    //Profile
    public Image ProfileImg;
    public Text UserName;
    public Text UserNumber;
    public Text UserMoney;

    public Notic notic;

    public Transform JackpotParent;
    public JackPot PFJackpot;
    JackPot Jackpot;

    int BatMoney = 0;

    public GameObject PopUp_Preference;

    public GameObject Loading;

    public SoundManager Sound;

    DataBaseManager DBMgr;

    public Guidance PopUp_Guid;
    public Guidance_Logout PopUp_Quit;

    public MailDetail PopUpNotice;

    public Text Test_Region;

    void Start()
    {
        if(DBMgr == null)
        {
            DBMgr = FindObjectOfType<DataBaseManager>();
            Sound = FindObjectOfType<SoundManager>();
        }

        if (PhotonNetwork.IsConnected)
        {   
            PhotonNetwork.JoinLobby();

            LocalPlayerInfo.Instance.InRoom = false;

            foreach (var item in Arr_JoinLobbyBtn)
            {
                item.interactable = false;
            }

            DBMgr.StartSendLogined();

            // db 연동
            SendLocation();

            Co_SetProfile();

            SetAccount();

            // 공지
            SetPopupNotice();
            SetRollingNotice();

            // 잭팟 생성
            Jackpot = GameObject.Instantiate(PFJackpot, JackpotParent);
            Jackpot.SetBtnActive(true);

            if(PlayerPrefs.GetInt("ReflashRoom") == 1)
            {
                Loading.SetActive(true);
            }
        }
        else
        {
            //PhotonNetwork.ConnectUsingSettings();
            Loading.SetActive(true);
            SceneManager.LoadScene("LogIn");
        }
    }

    void SendLocation()
    {
        JSON data = new JSON();
        data.Add("type", "LOBBY");

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.SendMyLocation, data.CreateString(), "PATCH", PlayerPrefs.GetString("Token"), (result) => {
            JsonData resp = JsonMapper.ToObject(result);

            if ((int)resp["result"] == 1)
            {

            }
        }));
    }

    public override void OnConnected()
    {
        foreach (var item in Arr_JoinLobbyBtn)
        {
            item.interactable = true;
        }

        if(LocalPlayerInfo.Instance.QuitWait)
        {
            FindObjectOfType<Guidance_Logout>().SetText("Đã được đăng nhập ở máy khác. xin vui lòng di chuyển đến trang wed đăng nhập"); // 번역 : 다른 기기에서 로그인 하였습니다. 로그인 화면으로 돌아갑니다.
        }
    }

    void SetPopupNotice()
    {
        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetNotics + "/POPUP", "", "Post", "", (result) =>
        {
            JsonData resp = JsonMapper.ToObject(result);

            if ((int)resp["result"] == 1)
            {
                string title = "";
                if (resp["data"].Count > 0)
                {
                    LocalPlayerInfo.Instance.PopUpNotic = (string)resp["data"]["notice"]["content"];
                    title = (string)resp["data"]["notice"]["title"];

                    if (!LocalPlayerInfo.Instance.ShowPopUpNotice && title.Length > 0 && LocalPlayerInfo.Instance.PopUpNotic.Length > 0)
                    {
                        PopUpNotice.SetTitle(title);
                        PopUpNotice.SetContent(LocalPlayerInfo.Instance.PopUpNotic);

                        PopUpNotice.gameObject.SetActive(true);
                        LocalPlayerInfo.Instance.ShowPopUpNotice = true;
                    }
                }
            }
        }));
    }

    void SetRollingNotice() // 수정
    {
        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetNotics + "/LOBBY", "", "Post", "", (result) =>
        {
            JsonData resp = JsonMapper.ToObject(result);

            if ((int)resp["result"] == 1)
            {
                if (resp["data"].Count != 0)
                {
                    LocalPlayerInfo.Instance.RollingNotic = (string)resp["data"]["notice"]["content"];
                    float interval = float.Parse(resp["data"]["notice"]["duration"].ToString());

                    StartCoroutine("RepeatNotic", interval);
                }
            }
        }));
    }

    void Co_SetProfile()
    {
        if (!LocalPlayerInfo.Instance.SetProfile)
        {
            StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetUserInfo, "", "Post", PlayerPrefs.GetString("Token"), (result) =>
            {
                if (result == "NetworkError" || result == "Not Found")
                {
                    return;
                }
                JsonData resp = JsonMapper.ToObject(result);

                ExitGames.Client.Photon.Hashtable playerInfo = new ExitGames.Client.Photon.Hashtable();

                playerInfo.Add("UserID", (string)resp["data"]["user"]["username"]);
                playerInfo.Add("UserNumber", (int)resp["data"]["user"]["id"]);
                playerInfo.Add("UserMoney", long.Parse(resp["data"]["user"]["amount"].ToString()));

                playerInfo.Add("ProfileImageName", (string)resp["data"]["user"]["profile_img"]);
                playerInfo.Add("UserGender", (int)resp["data"]["user"]["gender"]);

                playerInfo.Add("BattingMoney", 0);
                playerInfo.Add("IsDealer", false);
                playerInfo.Add("IsDie", false);
                playerInfo.Add("IsWatch", false);

                LocalPlayerInfo.Instance.SetInfo(playerInfo);

                PhotonNetwork.LocalPlayer.SetCustomProperties(playerInfo);

            //Set Profile
            ProfileImg.sprite = Resources.Load<Sprite>("Sprites/InGameProfiles/" + LocalPlayerInfo.Instance.ProfileImgFilePath);
            // 데이터 베이스에서 유저 아이디 받아오기
            UserName.text = LocalPlayerInfo.Instance.PlayerName;
            // 데이터 베이스에서 유저 고유 번호 받아오기
            UserNumber.text = GetPlayerCP("UserNumber").ToString();
            // 데이터 베이스에서 유저 보유 금액 받아오기
            if (long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()) <= 0)
                {
                    UserMoney.text = "0";
                }
                else
                {
                    UserMoney.text = CStringFormat.Instance.FormatToInt(long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()));
                }

                LocalPlayerInfo.Instance.SetProfile = true;
            }));
        }
        else
        {
            StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetUserInfo, "", "Post", PlayerPrefs.GetString("Token"), (result) =>
            {
                if (result == "NetworkError" || result == "Not Found")
                {
                    return;
                }
                JsonData resp = JsonMapper.ToObject(result);

                PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"] = long.Parse(resp["data"]["user"]["amount"].ToString());

                LocalPlayerInfo.Instance.PlayerMoney = long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString());
                //Set Profile
                ProfileImg.sprite = Resources.Load<Sprite>("Sprites/InGameProfiles/" + LocalPlayerInfo.Instance.ProfileImgFilePath);
                // 데이터 베이스에서 유저 아이디 받아오기
                UserName.text = LocalPlayerInfo.Instance.PlayerName;
                // 데이터 베이스에서 유저 고유 번호 받아오기
                UserNumber.text = GetPlayerCP("UserNumber").ToString();
                // 데이터 베이스에서 유저 보유 금액 받아오기
                if (long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()) <= 0)
                {
                    UserMoney.text = "0";
                }
                else
                {
                    UserMoney.text = CStringFormat.Instance.FormatToInt(long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()));
                }
            }));
        }
    }

    void SetAccount()
    {
        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetProfileInfo, "", "Post", PlayerPrefs.GetString("Token"), (result_num) => {

            JsonData resp_num = JsonMapper.ToObject(result_num);

            if (resp_num["data"].Count != 0)
            {
                LocalPlayerInfo.Instance.PlayerAccount = (string)resp_num["data"]["Info"]["number"];
            }
            else
            {
                LocalPlayerInfo.Instance.PlayerAccount = "000-00-000000";
            }
        }));
    }

    public override void OnJoinedLobby()
    {
        foreach (var item in Arr_JoinLobbyBtn)
        {
            item.interactable = true;
        }

        if (!LocalPlayerInfo.Instance.SendPlayerCount)
        {
            LocalPlayerInfo.Instance.SendPlayerCount = true;

            JSON data = new JSON();
            data.Add("players", PhotonNetwork.CountOfPlayers);
            data.Add("playing_players", PhotonNetwork.CountOfPlayersInRooms);
            data.Add("room_count", PhotonNetwork.CountOfRooms);

            StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.SendPlayerCount, data.CreateString(), "Post", PlayerPrefs.GetString("Token"), (result) =>
            {
                JsonData resp = JsonMapper.ToObject(result);
            }));
        }
    }

    IEnumerator RepeatNotic(float interval)
    {
        WaitForSeconds wfsTime = CWFS.WFS(interval);

        while (true)
        {
            notic.SetRollingNoticText();
            notic.gameObject.SetActive(true);

            yield return wfsTime;
        }
    }

    public override void OnConnectedToMaster()
    {
        if (PlayerPrefs.GetInt("ReflashRoom") == 1)
        {
            OnClickBtn_JoinRoom(PlayerPrefs.GetInt("RoomSelect"));
        }
    }

    void Update()
    {
        if (Application.platform == RuntimePlatform.Android)
        {
            if (Input.GetKey(KeyCode.Escape))
            {
                PopUp_Quit.gameObject.SetActive(true);
            }
        }
    }

    object GetPlayerCP(string key)
    {
        return PhotonNetwork.LocalPlayer.CustomProperties[key];
    }

    #region JOIN_ROOM

    public void OnClickBtn_JoinRoom(int batMoney)
    {
        if(long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()) >= batMoney * 10)
        {
            //광클방지
            for (int i = 0; i < Arr_JoinLobbyBtn.Length; i++)
            {
                Arr_JoinLobbyBtn[i].interactable = false;
            }

            BatMoney = batMoney;

            //마스터 서버에 연결중이라면
            if (PhotonNetwork.IsConnected)
            {
                SetLocalPlayerCP(LocalPlayerInfo.Instance.GetInfo());

                // 랜덤 룸 입장
                ExitGames.Client.Photon.Hashtable roomProperties = new ExitGames.Client.Photon.Hashtable() {
                    { "BatMoney", batMoney }
                };

                //Loading.SetActive(true);

                PhotonNetwork.JoinRandomRoom(roomProperties, 6);
            }
        }
        else
        {
            PopUp_Guid.SetText("Tiền dư của bạn không đủ"); //번역 :  금액이 부족합니다. o
        }
    }

    public void OnClickBtn_SetLevel(int level)
    {
        LocalPlayerInfo.Instance.RoomLevel = level;
    }

    public override void OnJoinRandomFailed(short returnCode, string message)
    {
        CreateRoom();
    }

    void CreateRoom()
    {
        //룸 접속 실행
        RoomOptions roomOptions = new RoomOptions();
        roomOptions.CustomRoomProperties = new ExitGames.Client.Photon.Hashtable { { "BatMoney", BatMoney }};
        roomOptions.CustomRoomPropertiesForLobby = new string[] { "BatMoney" };
        roomOptions.IsVisible = true;
        roomOptions.IsOpen = true;
        roomOptions.MaxPlayers = 6;
        roomOptions.CleanupCacheOnLeave = true;
        
        PhotonNetwork.CreateRoom(null, roomOptions, null);
    }
     
    public override void OnJoinedRoom()
    {
        if (PhotonNetwork.IsMasterClient)
        {
            Sound.SetBGMSound(SoundFileList.BGM.GAME);
            Sound.StartSound_Effect(SoundFileList.EFFECT.door_in);

            PhotonNetwork.LoadLevel("GamePlay");
        }
    }

    void SetLocalPlayerCP(ExitGames.Client.Photon.Hashtable cp)
    {
        PhotonNetwork.LocalPlayer.CustomProperties["UserID"] = cp["UserID"];
        PhotonNetwork.LocalPlayer.CustomProperties["UserNickName"] = cp["UserNickName"];
        PhotonNetwork.LocalPlayer.CustomProperties["UserNumber"] = cp["UserNumber"];
        PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"] = cp["UserMoney"];
        PhotonNetwork.LocalPlayer.CustomProperties["UserGender"] = cp["UserGender"];
        PhotonNetwork.LocalPlayer.CustomProperties["ProfileImageName"] = cp["ProfileImageName"];
        PhotonNetwork.LocalPlayer.CustomProperties["IsDealer"] = cp["IsDealer"];
    }

    #endregion

    // UI 버튼 관련

    public void OnClickBtn_NextUI(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }

    public void OnClickBtn_Preferences(bool active)
    {
        PopUp_Preference.SetActive(active);

        if("0" == PlayerPrefs.GetString("GameSound"))
        {
            Prefernces.GameSound[0].sprite = Prefernces.Spr[0];
            Prefernces.GameSound[1].sprite = Prefernces.Spr[1];
        }
        else
        {
            Prefernces.GameSound[1].sprite = Prefernces.Spr[0];
            Prefernces.GameSound[0].sprite = Prefernces.Spr[1];
        }

        if ("0" == PlayerPrefs.GetString("BGM"))
        {
            Prefernces.BGM[0].sprite = Prefernces.Spr[0];
            Prefernces.BGM[1].sprite = Prefernces.Spr[1];
        }
        else
        {
            Prefernces.BGM[1].sprite = Prefernces.Spr[0];
            Prefernces.BGM[0].sprite = Prefernces.Spr[1];
        }
    }

    public void OnClickBtn_Preference_Check(bool type)
    {
        if(type) // 닫기
        {
            PopUp_Preference.SetActive(false);
        }
        else
        {
            StopCoroutine("RepeatNotic");
            Destroy(GameObject.FindObjectOfType<JackPot>().transform.parent.parent.gameObject);
            PlayerPrefs.SetInt("AutoLogin", 0);

            PhotonNetwork.Disconnect();
        }
    }

    public void OnClickBtn_GameSound(bool result)
    {
        if(result) // 소리 켜기
        {
            Prefernces.GameSound[0].sprite = Prefernces.Spr[0];
            Prefernces.GameSound[1].sprite = Prefernces.Spr[1];

            PlayerPrefs.SetString("GameSound", "0");
        }
        else // 소리 끄기
        {
            Prefernces.GameSound[1].sprite = Prefernces.Spr[0];
            Prefernces.GameSound[0].sprite = Prefernces.Spr[1];

            PlayerPrefs.SetString("GameSound", "1");
        }
    }

    public void OnClickBtn_BGM(bool result)
    {
        if (result) // 소리 켜기
        {
            Prefernces.BGM[0].sprite = Prefernces.Spr[0];
            Prefernces.BGM[1].sprite = Prefernces.Spr[1];

            PlayerPrefs.SetString("BGM", "0");
            if (!Sound.BGM.isPlaying)
            {
                Sound.SetBGMSound(SoundFileList.BGM.MAIN);
            }
        }
        else // 소리 끄기
        {
            Prefernces.BGM[1].sprite = Prefernces.Spr[0];
            Prefernces.BGM[0].sprite = Prefernces.Spr[1];

            PlayerPrefs.SetString("BGM", "1");
            if(Sound.BGM.isPlaying)
            {
                Sound.BGM.Stop();
            }
        }
    }

    public void OnClickBtn_ClickSound()
    {
        Sound.StartSound_Effect(SoundFileList.EFFECT.btn_click);
    }

    public override void OnDisconnected(DisconnectCause cause)
    {
        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.Logout, "", "Post", PlayerPrefs.GetString("Token"), (result) => { 
        }));

        SceneManager.LoadScene("LogIn");
    }
}
