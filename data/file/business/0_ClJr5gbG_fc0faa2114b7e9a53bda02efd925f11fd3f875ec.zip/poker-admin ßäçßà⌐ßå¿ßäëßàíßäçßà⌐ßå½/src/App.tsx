import React from "react";
import { Switch, withRouter, RouteComponentProps } from "react-router";
import { BrowserRouter as Router, Route } from "react-router-dom";
import { withCookies, ReactCookieProps } from "react-cookie";

import LoginPage from "pages/login/LoginPage";
import PageRouter from "Router/PageRouter";

interface Props extends RouteComponentProps, ReactCookieProps {}

class App extends React.Component<Props> {
  render() {
    return (
      <Router>
        <Switch>
          <Route exact path="/login" component={LoginPage} />
          <Route path="/" component={PageRouter} />
        </Switch>
      </Router>
    );
  }
}

export default withCookies(withRouter(App));
