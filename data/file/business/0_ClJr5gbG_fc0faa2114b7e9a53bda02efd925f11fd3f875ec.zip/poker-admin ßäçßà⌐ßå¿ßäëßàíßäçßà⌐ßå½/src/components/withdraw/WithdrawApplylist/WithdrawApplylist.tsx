/* eslint-disable no-restricted-globals */
import React, { useState } from "react";
import SearchIcon from "assets/icons/search.png";
import { WithdrawTypeBackup } from "stores/withdraw/types";
import WithApplistItem from "./item";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import { Button, Input } from "styles/atom";

interface Props {
  withdraw: WithdrawTypeBackup;
  withdrawList: WithdrawTypeBackup[];
  updateComplete: (id: number) => void;
  updateReject: (id: number) => void;
  onSearch: (
    id?: string,
    phone?: string,
    startDate?: string,
    endDate?: string
  ) => void;
  onActiveToggle: (id: number) => void;
}

function WithdrawApplylist({
  withdraw,
  withdrawList,
  updateComplete,
  updateReject,
  onSearch,
  onActiveToggle,
}: Props) {
  const [inputs, setInputs] = useState({
    id: "",
    phone: "",
    startDate: "",
    endDate: "",
  });
  const { id, phone, startDate, endDate } = inputs;

  const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setInputs({
      ...inputs,
      [name]: value,
    });
  };

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onSearch(id, phone, startDate, endDate);
  };

  return (
    <>
      <SearchWrapper>
        <SearchForm className="search" onSubmit={onSubmit}>
          <Input
            name="id"
            value={id}
            onChange={onChange}
            placeholder="ID"
            className="id"
          />
          <Input
            name="phone"
            value={phone}
            onChange={onChange}
            placeholder="Mobile"
            className="mobile"
          />
          <Input
            name="startDate"
            value={startDate}
            onChange={onChange}
            type="date"
            className="date"
          />
          <span> ~ </span>
          <Input
            type="date"
            name="endDate"
            value={endDate}
            onChange={onChange}
            className="date"
          />
          <Button type="submit">
            <img src={SearchIcon} alt="검색" />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>ID</th>
            <th>Phone number</th>
            <th>Bank name</th>
            <th>Account Holder</th>
            <th>Account number</th>
            <th>Application time</th>
            <th>Charge amount</th>
            <th>Opt</th>
          </tr>
        </thead>
        <tbody>
          {withdrawList.map((data, idx) => (
            <WithApplistItem
              key={idx}
              data={data}
              updateComplete={updateComplete}
              updateReject={updateReject}
              onActiveToggle={onActiveToggle}
            />
          ))}
        </tbody>
      </Table>
    </>
  );
}

export default WithdrawApplylist;
