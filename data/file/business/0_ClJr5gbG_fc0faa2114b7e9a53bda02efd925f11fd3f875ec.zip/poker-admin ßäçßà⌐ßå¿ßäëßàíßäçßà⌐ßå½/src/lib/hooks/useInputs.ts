import { useState } from "react";

const useInputs = (initialState: any) => {
  const [inputs, setInputs] = useState<any>(initialState);

  const onChange = (e: any) => {
    const { name, value } = e.target;
    if (name === "page" || name === "bene_rate" || name === "add_money") {
      setInputs({
        ...inputs,
        [name]: parseInt(value, 10),
      });
    } else {
      setInputs({
        ...inputs,
        [name]: value,
      });
    }
  };

  const init = () => {
    setInputs(initialState);
  };

  return { inputs, setInputs, onChange, init };
};

export default useInputs;
