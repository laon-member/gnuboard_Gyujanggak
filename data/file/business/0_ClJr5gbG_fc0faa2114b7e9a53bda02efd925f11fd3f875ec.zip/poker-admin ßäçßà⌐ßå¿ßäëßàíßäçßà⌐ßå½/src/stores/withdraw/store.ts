import { observable, flow, computed, action } from "mobx";

import BaseStore from "stores/BaseStore";
import RootStore from "stores";

import {
  TWithdrawApplyPage,
  TWithdrawLog,
  TWithdrawLogPage,
  WithdrawApplyType,
  WithdrawTypeBackup,
} from "./types";
import WithdrawService from "services/withdraw/WithdrawService";
import { PagingType } from "stores/message/types";
import {
  CancleWithdrawApplyType,
  PassWithdrawApplyType,
  SearchWithdrawApplyType,
  SearchWithdrawLogType,
} from "services/withdraw/types";
class WithdrawStore extends BaseStore {
  root: RootStore;

  constructor(root: RootStore) {
    super();
    this.root = root;
  }

  // 추가 및 수정 API
  @observable
  withdrawApplyListPage = {
    paging: {} as PagingType,
    withdraw: [] as WithdrawApplyType[],
  } as TWithdrawApplyPage;

  @observable
  withdrawLogListPage = {
    paging: {} as PagingType,
    withdraw: [] as TWithdrawLog[],
  } as TWithdrawLogPage;

  @observable
  apply = {} as WithdrawApplyType;

  @action
  getWithdrawApplyListPage = async (payload: SearchWithdrawApplyType) => {
    try {
      const res = await WithdrawService.getWithdrawApplyList(payload);
      if (res.data.result) {
        this.withdrawApplyListPage = res.data.data;
      } else {
        return alert("Field error");
      }
    } catch (error) {
      console.error(error);
      alert("There is a problem with the server");
      throw error;
    }
  };

  @action
  getWithdrawLogListPage = async (payload: SearchWithdrawLogType) => {
    try {
      const res = await WithdrawService.getWithdrawLogList(payload);
      if (res.data.result) {
        this.withdrawLogListPage = res.data.data;
      } else {
        return alert("Field error");
      }
    } catch (error) {
      console.error(error);
      return alert("There is a problem with the server");
    }
  };

  @action
  setApply = (payload: WithdrawApplyType) => {
    this.apply = payload;
  };

  @action
  passWithdrawApply = async (payload: PassWithdrawApplyType) => {
    return await WithdrawService.passWithdrawApply(payload);
  };

  @action
  cancleWithdrawApply = async (payload: CancleWithdrawApplyType) => {
    return await WithdrawService.cancleWithdrawApply({
      id: this.apply.id,
      message: payload.message,
    } as CancleWithdrawApplyType);
  };

  @action
  reserveApply = async () => {
    return await WithdrawService.reserveApply(this.apply.id);
  };

  // 기존 API
  @observable
  private _isLoggedIn = false;

  @observable
  private _userType?: number;

  @observable
  private _withdrawList: WithdrawTypeBackup[] = [];
  @observable
  private _withdraw?: WithdrawTypeBackup;

  @observable
  private _activeWithdrawList: WithdrawTypeBackup[] = [];

  @computed
  get IsLoggedIn() {
    return this._isLoggedIn;
  }

  @computed
  get UserType() {
    return this._userType;
  }
  //2020-07-18(토)
  @computed
  get WithdrawList() {
    return this._withdrawList;
  }
  //2020-07-18(토)
  @computed
  get Withdraw() {
    return this._withdraw;
  }

  @action
  public onActive(id: number) {
    this._withdrawList = this._withdrawList.map((user) =>
      user.id === id ? { ...user, active: !user.active } : user
    );
  }

  @action
  public logout() {
    this._isLoggedIn = false;
    this._userType = undefined;
  }

  GetWithRechargeList = flow(function* (
    this: WithdrawStore,
    id?: string,
    phone?: string,
    status?: string,
    startDate?: string,
    endDate?: string
  ) {
    this._init("GET_WITHDRAW_RECHARGE_LIST");
    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ withdraw: WithdrawTypeBackup[] }>;
      } = yield WithdrawService.GetWithRechargeListAPI(
        id,
        phone,
        status,
        startDate,
        endDate
      );
      const { withdraw } = res.data;
      this._withdrawList = withdraw;
      this._success["GET_WITHDRAW_RECHARGE_LIST"] = true;
    } catch (e) {
      this._failure["GET_WITHDRAW_RECHARGE_LIST"] = [true, e];
    } finally {
      this._pending["GET_WITHDRAW_RECHARGE_LIST"] = false;
    }
  });
  GetWithdrawList = flow(function* (
    this: WithdrawStore,
    id?: string,
    phone?: string,
    startDate?: string,
    endDate?: string
  ) {
    this._init("GET_WITHDRAW_LIST");
    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ withdraw: WithdrawTypeBackup[] }>;
      } = yield WithdrawService.GetWithdrawListAPI(
        id,
        phone,
        startDate,
        endDate
      );
      const { withdraw } = res.data;
      this._withdrawList = withdraw;
      this._success["GET_WITHDRAW_LIST"] = true;
    } catch (e) {
      this._failure["GET_WITHDRAW_LIST"] = [true, e];
    } finally {
      this._pending["GET_WITHDRAW_LIST"] = false;
    }
  });
  PutWithdrawComplete = flow(function* (this: WithdrawStore, id: number) {
    this._init("PUT_WITHDRAW_COMPLETE");

    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ complete: WithdrawTypeBackup }>;
      } = yield WithdrawService.PutWithdrawCompleteAPI(id);
      const { complete } = res.data;
      this._withdraw = complete;
      this._success["PUT_WITHDRAW_COMPLETE"] = true;
    } catch (e) {
      this._failure["PUT_WITHDRAW_COMPLETE"] = [true, e];
    } finally {
      this._pending["PUT_WITHDRAW_COMPLETE"] = false;
    }
  });
  PutWithdrawReject = flow(function* (this: WithdrawStore, id: number) {
    this._init("PUT_WITHDRAW_REJECT");

    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ cancel: WithdrawTypeBackup }>;
      } = yield WithdrawService.PutWithdrawRejectAPI(id);
      const { cancel } = res.data;
      this._withdraw = cancel;
      this._success["PUT_WITHDRAW_REJECT"] = true;
    } catch (e) {
      this._failure["PUT_WITHDRAW_REJECT"] = [true, e];
    } finally {
      this._pending["PUT_WITHDRAW_REJECT"] = false;
    }
  });
}

export default WithdrawStore;
