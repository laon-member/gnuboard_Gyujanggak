import EditMessage from "components/message/editMessage/EditMessage";
import { useInputs } from "lib/hooks";
import { inject, observer } from "mobx-react";
import React from "react";
import { SearchUserType, UserType } from "stores/message/types";

interface Props {
  searchUser: (payload: SearchUserType) => void;
  userList: UserType[];
  setUser: (id: number) => void;
  user: UserType;
  initUserList: () => void;
  initUser: () => void;
  sendMessage: (inputs: SearchUserType) => void;
}

const EditMessageContainer = ({
  searchUser,
  userList,
  setUser,
  user,
  initUserList,
  initUser,
  sendMessage,
}: Props) => {
  const { inputs, onChange, setInputs, init } = useInputs({
    title: "",
    content: "",
    type: "1",
    username: !user ? "" : user.username,
  } as SearchUserType);
  const onSearch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (inputs.type === "1") return;
    searchUser(inputs);
  };

  const onSend = () => {
    try {
      sendMessage(inputs);
      init();
    } catch (error) {
      return alert("There is a problem with the server");
    }
  };
  return (
    <EditMessage
      onSearch={onSearch}
      onSend={onSend}
      userList={userList}
      searchForm={{ inputs, onChange, setInputs, init }}
      setUser={setUser}
      user={user}
      initUserList={initUserList}
      initUser={initUser}
    />
  );
};

export default inject(({ messageStore }) => ({
  searchUser: messageStore.searchUser,
  userList: messageStore.userList,
  setUser: messageStore.setUser,
  user: messageStore.user,
  initUserList: messageStore.initUserList,
  initUser: messageStore.initUser,
  sendMessage: messageStore.sendMessage,
}))(observer(EditMessageContainer));
