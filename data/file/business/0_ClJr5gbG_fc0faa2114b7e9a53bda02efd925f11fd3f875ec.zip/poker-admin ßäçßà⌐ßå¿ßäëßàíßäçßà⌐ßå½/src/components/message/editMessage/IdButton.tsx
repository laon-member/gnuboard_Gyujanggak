import React from "react";
import { FaPlus } from "react-icons/fa";
import styled from "styles/theme-components";

interface Props {
  user: any;
  setUser: (id: number) => void;
}

function IdButton({ user, setUser }: Props) {
  return (
    <Wrapper onClick={() => setUser(user.id)}>
      {user.username} <FaPlus />
    </Wrapper>
  );
}

const Wrapper = styled.span`
  display: inline-block;
  padding: 0.5rem 1rem;
  background-color: #64b399;
  color: #fff;
  border-radius: 20px;
`;

export default IdButton;
