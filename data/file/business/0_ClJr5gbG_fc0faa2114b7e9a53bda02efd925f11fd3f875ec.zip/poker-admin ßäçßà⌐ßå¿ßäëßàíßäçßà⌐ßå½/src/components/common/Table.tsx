import React from "react";
import styled from "styles/theme-components";

type TableProps = {
  children: any;
};

const Table = ({ children }: TableProps) => {
  return <StyledTable>{children}</StyledTable>;
};

const StyledTable = styled.table`
  width: 100%;
  font-size: 1rem;

  & th,
  td {
    padding: 1rem;
    border: 1px solid #d7e0dd;
  }

  & tr {
    height: 3.125rem;
    text-align: center;
  }

  & th {
    background: #e6ecef;
    color: #000;
    font-weight: bold;
    word-break: keep-all;
  }

  & tr:nth-child(2n) {
    background-color: #fffdfa;
  }

  .blue {
    color: #86b2ff;
    cursor: pointer;
  }

  .overflow {
    max-width: 400px;
    overflow-x: auto;
  }
`;

export default Table;
