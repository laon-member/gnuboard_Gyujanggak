import { AxiosResponse } from "axios";
import RoomList from "components/game/roomList/RoomList";
import { useInputs } from "lib/hooks";
import { inject, observer } from "mobx-react";
import React, { useEffect, useState } from "react";
import {
  TRoom,
  TRoomDelete,
  TRoomListForms,
  TRoomListPage,
  TRoomListSearch,
} from "services/game/types";
import RootStore from "stores";

interface Props {
  roomListPage: TRoomListPage;
  getRoomListPage: (payload: TRoomListSearch) => void;
  setRoom: (payload: TRoom) => void;
  room: TRoom;
  deleteRoom: () => AxiosResponse;
}

const RoomListContainer = ({
  roomListPage,
  getRoomListPage,
  setRoom,
  deleteRoom,
}: Props) => {
  const [deleteToggle, setDeleteToggle] = useState(false);
  const forms = {
    search: useInputs({
      room_type: "",
      username: "",
      nickname: "",
      page: 1,
    } as TRoomListSearch),
  } as TRoomListForms;

  const _delete = ({
    toggle: deleteToggle,
    onToggle: (payload: TRoom) => {
      if (!deleteToggle) setRoom(payload);
      setDeleteToggle(!deleteToggle);
    },
    onSubmit: async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();

      try {
        const res = await deleteRoom();
        if (!res.data.result) {
          alert("Faild to delete room");
        }
      } catch (error) {
        alert("There is a problem with the server");
      } finally {
        setDeleteToggle(false);
        forms.search.init();
        await getRoomListPage(forms.search.inputs);
      }
    },
  } as unknown) as TRoomDelete;

  useEffect(() => {
    (async () => {
      await getRoomListPage(forms.search.inputs);
    })();
  }, []);

  const onSearch = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    await getRoomListPage(forms.search.inputs);
  };

  return (
    <RoomList
      roomListPage={roomListPage}
      forms={forms}
      onSearch={onSearch}
      _delete={_delete}
    />
  );
};

export default inject(({ gameStore }: RootStore) => ({
  roomListPage: gameStore.roomListPage,
  getRoomListPage: gameStore.getRoomListPage,
  setRoom: gameStore.setRoom,
  room: gameStore.room,
  deleteRoom: gameStore.deleteRoom,
}))(observer(RoomListContainer));
