import { PagingType } from "stores/message/types";
import { UseInput } from "stores/notice/types";
import { StringLiteral } from "typescript";

export type TSearchRechargeApply = {
  username: string;
  phone: string;
  page: number;
};

export type TRechargeApply = {
  id: number;
  username: string;
  agent: string;
  amount: number;
  phone: string;
  bankAccount: string;
  bankName: string;
  bankNumber: string;
  applyTime: string;
  acceptBank: string;
  accepyBankNumber: string;
  status: number;
};

export type TRechargeApplyPage = {
  paging: PagingType;
  content: TRechargeApply[];
};

export type TRechargeForms = {
  search: UseInput;
  cancle: UseInput;
};

export type TPassRechargeApply = {
  id: number;
};

export type TCancleRechRgeApply = {
  id: number;
  message: string;
};

export type TSearchRechargeLog = {
  username: string;
  phone: string;
  page: number;
};

export type TRechargeLog = {
  id: number;
  username: string;
  agent: string;
  amount: number;
  phone: string;
  bankAccount: string;
  bankName: string;
  bankNumber: string;
  applyTime: string;
  adminName?: any;
  handleTime: string;
  status: string;
};

export type TRechargeLogPage = {
  paging: PagingType;
  recharge: TRechargeLog[];
};

export type TSearchRechargeBankSet = {
  bank_name: string;
  bank_account: string;
  bank_number: string;
  page: number;
};

export type TRechargeBankSet = {
  id: number;
  bank_name: string;
  bank_account: string;
  bank_number: string;
  created_at: string;
  is_active: number;
};

export type TRechargeBankSetPage = {
  paging: PagingType;
  accounts: TRechargeBankSet[];
};

export type TBankSetForm = {
  search: UseInput;
  new: UseInput;
  edit: UseInput;
};

export type TNewBankSetForm = {
  bank_name: string;
  bank_account: string;
  bank_number: string;
  is_active: number;
};

export type TEditBankSetForm = {
  bank_name: string;
  bank_account: string;
  bank_number: string;
  is_active: number;
};

export type TNewBankSet = {
  toggle: boolean;
  onToggle: (payload?: any) => void;
  onSubmit: (e?: React.FormEvent<HTMLFormElement> | any) => void;
};

export type WarningBoxType = {
  toggle: boolean;
  onToggle: (payload?: any) => void;
  // eslint-disable-next-line prettier/prettier
  onSubmit: (payload?: any) => void;
  check?: (id: number) => void;
};
