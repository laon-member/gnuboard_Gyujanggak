import React from "react";
import { Route, Switch, NavLink } from "react-router-dom";
import { SubNavContainer, ContainerWrapper } from "pages/member/MemberPage";
import PersonMessageContainer from "containers/message/PersonMessageContainer";
import GlobalMessageContainer from "containers/message/GlobalMessageContainer";
import EditMessageContainer from "containers/message/EditMessageContainer";

function MessagePage() {
  return (
    <>
      <SubNavContainer>
        <li>
          <NavLink exact to="/admin/message" activeClassName="active">
            PersonMessage
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/admin/message/global" activeClassName="active">
            GlobalMessage
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/admin/message/edit" activeClassName="active">
            EditMessage
          </NavLink>
        </li>
      </SubNavContainer>
      <ContainerWrapper>
        <Switch>
          <Route
            exact
            path="/admin/message"
            component={PersonMessageContainer}
          />
          <Route
            exact
            path="/admin/message/global"
            component={GlobalMessageContainer}
          />
          <Route
            exact
            path="/admin/message/edit"
            component={EditMessageContainer}
          />
        </Switch>
      </ContainerWrapper>
    </>
  );
}

export default MessagePage;
