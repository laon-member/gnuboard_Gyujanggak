﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class JackpotContent : MonoBehaviour
{
    public Text No;
    public Image Profile;
    public Text ID;
    public Text Amount;
    public Text Time;

    /// <summary>
    /// 0 = No
    /// 1 = Prifile
    /// 2 = ID
    /// 3 = Amount
    /// 4 = Time
    /// </summary>
    /// <param name="info"></param>
    public void SetInfo(string[] info)
    {
        No.text = info[0];
        Profile.sprite = Resources.Load<Sprite>("Sprites/InGameProfiles/" + info[1]);
        ID.text = info[2];
        Amount.text = info[3];
        Time.text = info[4];
    }
}
