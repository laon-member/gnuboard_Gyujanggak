export function formatDate(date: string) {
  if (new Date(date) === null) {
    return "date error";
  }
  const _date = new Date(date);
  const year = _date.getFullYear();
  let month: number | string = _date.getMonth() + 1;
  month = month >= 10 ? month : "0" + month;
  let day: number | string = _date.getDate();
  day = day >= 10 ? day : "0" + day;
  return `${year}-${month}-${day}`;
}
