﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using LitJson;

public class Notic : MonoBehaviour
{
    public Text NoticTxt;

    public float MoveSpeed = 1.0f;

    bool IsMove = false;

    int Count = 0;

    public RectTransform BGRect;
    public RectTransform TxtRect;

    DataBaseManager DBMgr;

    // Start is called before the first frame update
    void Start()
    {
        if(DBMgr == null)
        {
            DBMgr = FindObjectOfType<DataBaseManager>();

            //SetRollingNoticText();
        }
    }

    private void OnEnable()
    {
        IsMove = true;
    }


    private void OnDisable()
    {
        Count = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if (IsMove)
        {
            if (Count < 3)
            {
                NoticTxt.transform.localPosition = new Vector2(NoticTxt.transform.localPosition.x - MoveSpeed * Time.deltaTime, NoticTxt.transform.localPosition.y);

                if (NoticTxt.transform.localPosition.x <= ((BGRect.rect.width / 2) + (TxtRect.rect.width / 2) + 50.0f) * -1)
                {
                    NoticTxt.transform.localPosition = new Vector2((BGRect.rect.width / 2) + (TxtRect.rect.width / 2) + 50.0f, NoticTxt.transform.localPosition.y);

                    Count++;
                }
            }
            else
            {
                IsMove = false;
            }
        }
        else
        {
            this.gameObject.SetActive(false);
        }
    }

    public void SetRollingNoticText()
    {
        NoticTxt.text = LocalPlayerInfo.Instance.RollingNotic;
    }
}
