import { createGlobalStyle } from "styled-components";
import reset from "styled-reset";

const GlobalStyle = createGlobalStyle`
/* @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;500&display=swap'); */
${reset}

/* font-family: 'Noto Sans KR', sans-serif; */

body {
  margin: 0;
  padding: 0;
  font-family: "Noto Sans KR", sans-serif;
  font-size: 16px;
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

a {
  color: inherit;
  text-decoration: none;
}
ul {
  list-style: none;
}
img {
  border: none;
}
table {
  border-collapse: collapse;

  th, td {
    text-align: center;
    vertical-align: middle;
  }

  td span {
    font-size: .75rem;
    padding: .25rem;
    background: #ccc;
    border-radius: 10px;
    cursor: pointer;
  }
}

button {
  outline: none;
  cursor: pointer;
}

p {
  text-align: center;
  font-size: 1.25rem;
}

input {
  outline: none;
}

textarea {
  resize: none;
  outline: none;
}
`;

export default GlobalStyle;
