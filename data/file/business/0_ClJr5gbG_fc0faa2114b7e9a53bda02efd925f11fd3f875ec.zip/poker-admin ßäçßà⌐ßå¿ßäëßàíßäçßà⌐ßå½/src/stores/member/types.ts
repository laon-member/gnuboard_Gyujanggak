import { PagingType } from "stores/message/types";
import { UseInput } from "stores/notice/types";

export type MemberType = {
  id: number;
  username: string;
  name: string;
  phone: string;
  agent: string;
  amount: number;
  created_at: string;
  last_login: string;
  bank: string;
  bankName: string;
  bankNumber: string;
  block_note: string;
  platform: string;
  status: number;
  location: string;
  blocked: number;
  deposit: number;
  withdraw: number;
  send_money?: number;
  receive_money?: number;
};

export type TBlock = {
  id: number;
  username: string;
  name: string;
  phone: string;
  agent?: string;
  amount: number;
  created_at: string;
  last_login: string;
  bank: string;
  bankName: string;
  bankNumber: string;
  block_note: string;
  platform: string;
  status: number;
  location: string;
  blocked: number;
  deposit: number;
  withdraw?: any;
};

export type TEditMember = {
  id: number;
  bank: string;
  bankName: string;
  bankNumber: string;
  phone: string;
  password: string;
  check_password: string;
};

export interface MemberSearch {
  id?: string;
  name?: string;
  start_date?: string;
  end_date?: string;
  page: number;
}

export type TMemberForms = {
  search: UseInput;
  edit: UseInput;
};

export interface MemberAmount {
  id: number;
  amount?: number;
  type?: string;
  option?: string;
  block?: boolean;
  finance_note?: string;
  deblock_note?: string;
}

export interface Finance {
  id: number;
  username: string;
  type: string;
  amount: string;
  adminName?: string;
  note?: string;
  handleTime: string;
}

export type TGameLogSearch = {
  username: string;
  nickname: string;
  round: string;
  start_date: string;
  end_date: string;
  page: number;
};

export type TGameLog = {
  id: number;
  name: string;
  username: string;
  room_type: number;
  bet_amount: number;
  mode: string;
  my_card: string;
  game_time: string;
  base_amount: number;
  result_amount: number;
  round: number;
};

export type TGameLogPage = {
  paging: PagingType;
  logs: TGameLog[];
};

export type TGameLogForms = {
  search: UseInput;
};

export type TBlockForms = {
  search: UseInput;
  edit: UseInput;
};

export type TFinanceForms = {
  search: UseInput;
};

export type TEditBlock = {
  id: number;
  amount: number;
  option: string;
  finance_note: string;
  block: boolean;
  deblock_note: string;
};

export interface TSMHistory {
  sender: string;
  receiver: string;
  amount: string;
  agnet?: string;
  created_at: string;
}

export interface TSMHistoryPage {
  paging: PagingType;
  logs: TSMHistory[];
}

export interface TSMHistorySearch {
  sender: string;
  receiver: string;
  start_date: string;
  end_date: string;
  page: number;
}

export interface TSMHistoryForms {
  search: UseInput;
}
