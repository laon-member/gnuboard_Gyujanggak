import FinanceLogList from "components/member/financeLog/FinanceLogList";
import { NoteType } from "components/member/memberlist/types";
import { useInputs } from "lib/hooks";
import { inject, observer, useObserver } from "mobx-react";
import React, { useEffect, useState } from "react";
import { Finance, MemberSearch, TFinanceForms } from "stores/member/types";
import { PagingType } from "stores/message/types";

interface Props {
  financeList: Finance[];
  getFinanceList: (financeSearch: MemberSearch) => void;
  getFinance: (id: number) => void;
  finance: Finance;
  financePage: PagingType;
}

const FinanceLogContainer = ({
  getFinanceList,
  financeList,
  getFinance,
  finance,
  financePage,
}: Props) => {
  const forms = {
    search: useInputs({
      id: "",
      name: "",
      start_date: "",
      end_date: "",
      page: 1,
    }),
  } as TFinanceForms;
  const [noteToggle, setNoteToggle] = useState(false);

  useEffect(() => {
    (async () => {
      await getFinanceList(forms.search.inputs);
    })();
  }, []);

  const note: NoteType = {
    toggle: noteToggle,
    onToggle: (id) => setFinanceToggle(id!),
  };

  const setFinanceToggle = (id: number) => {
    getFinance(id);
    setNoteToggle(!noteToggle);
  };

  const onSearch = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    await getFinanceList(forms.search.inputs);
  };

  return useObserver(() => (
    <FinanceLogList
      note={note}
      financeList={financeList}
      finance={finance}
      financePage={financePage}
      forms={forms}
      onSearch={onSearch}
    />
  ));
};

export default inject(({ memberStore }) => ({
  financeList: memberStore.financeList,
  getFinanceList: memberStore.getFinanceList,
  getFinance: memberStore.getFinance,
  finance: memberStore.finance,
  financePage: memberStore.financePage,
}))(observer(FinanceLogContainer));
