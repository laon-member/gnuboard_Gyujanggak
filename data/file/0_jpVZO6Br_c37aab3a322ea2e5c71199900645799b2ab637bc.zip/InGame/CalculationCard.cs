﻿using DG.Tweening;
using Photon.Pun;
using Photon.Realtime;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CalculationCard
{
    private static CalculationCard instance = null;

    private CalculationCard() { }

    public static CalculationCard Instance
    {
        get
        {
            if (instance == null)
            {
                instance = new CalculationCard();
            }
            return instance;
        }
    }

    // 다 초기화 해야댐
    string[][] Cards;
    
    // 족보 판단
    public CardGenealogy.GenealogyType GetGenealogyType(string[] playerCard)
    {
        Cards = new string[3][];

        // 배열로 받은 카드 나누기
        for (int i = 0; i < playerCard.Length; i++)
        {
            string[] info = playerCard[i].Split('/');
            for (int j = 0; j < info.Length; j++)
            {
                Cards[i] = info;
            }
        }

        Array.Sort(Cards, new CardComparer(1));

        // 트리플
        if(int.Parse(Cards[0][1]) == int.Parse(Cards[1][1]) && int.Parse(Cards[1][1]) == int.Parse(Cards[2][1]))
        {
            return CardGenealogy.GenealogyType.Triple;
        }
        // 스트레이트
        else if (int.Parse(Cards[0][1]) + 1 == int.Parse(Cards[1][1]) && int.Parse(Cards[1][1]) + 1 == int.Parse(Cards[2][1]) ||  // 통상적인 스트레이트 A23... 등등
            int.Parse(Cards[0][1]) == 1 && int.Parse(Cards[1][1]) == 12 && int.Parse(Cards[2][1]) == 13) // A 가 껴있는 스트레이트 AKQ
        {
            return CardGenealogy.GenealogyType.Straight;
        }

        bool pair = false;

        if (int.Parse(Cards[0][1]) == int.Parse(Cards[1][1]) && int.Parse(Cards[0][1]) > 10) // 원페어
        {
            pair = true;
        }
        else if (int.Parse(Cards[0][1]) == int.Parse(Cards[2][1]) && int.Parse(Cards[0][1]) > 10)
        {
            pair = true;
        }
        else if(int.Parse(Cards[1][1]) == int.Parse(Cards[2][1]) && int.Parse(Cards[1][1]) > 10)
        {
            pair = true;
        }
        //else // 끗
        //{
        //    return CardGenealogy.GenealogyType.Basic;
        //}

        if(pair)
        {
            if (int.Parse(Cards[0][1]) >= 10 && int.Parse(Cards[1][1]) >= 10 && int.Parse(Cards[2][1]) >= 10)
            {
                return CardGenealogy.GenealogyType.Pair;
            }
            else
            {
                return CardGenealogy.GenealogyType.Basic;
            }
        }
        else
        {
            return CardGenealogy.GenealogyType.Basic;
        }
    }

    public CardInfo.CARDPATTERN GetTopCardPattern()
    {
        int[] cardNum = new int[3];

        for (int i = 0; i < Cards.Length; i++)
        {
            cardNum[i] = int.Parse(Cards[i][0]);
        }

        Array.Sort(cardNum);

        return (CardInfo.CARDPATTERN)cardNum[0];
    }

    public int GetTopPatternNumber()
    {
        int[] patterns = new int[Cards.Length];

        int result = 0;

        for (int i = 0; i < Cards.Length; i++)
        {
            patterns[i] = int.Parse(Cards[i][0]);
        }
        Array.Sort(patterns);

        List<int> samePattern = new List<int>();

        foreach (var pattern in patterns)
        {
            if(patterns[0] == pattern)
            {
                samePattern.Add(pattern);
            }
        }

        if(samePattern.Count > 1)
        {
            int[] nums = new int[samePattern.Count];

            for (int i = 0; i < nums.Length; i++)
            {
                for (int j = 0; j < Cards.Length; j++)
                {
                    if(samePattern[0] == int.Parse(Cards[j][0]))
                    {
                        nums[i] = int.Parse(Cards[j][1]);
                    }
                }
            }
            Array.Sort(nums);

            if(nums[0] == 1)
            {
                result = 1;
            }
            else
            {
                result = nums[nums.Length - 1];
            }
        }
        else
        {
            foreach (var num in Cards)
            {
                if(samePattern[0] == int.Parse(num[0]))
                {
                    result = int.Parse(num[1]);
                    break;
                }
            }
        }

        return result;
    }

    public int GetTopCardNumber()
    {
        int[] cardNum = new int[3];

        for (int i = 0; i < Cards.Length; i++)
        {
            cardNum[i] = int.Parse(Cards[i][1]);
        }

        Array.Sort(cardNum);

        if(cardNum[0] == 1 || cardNum[1] == 1 || cardNum[2] == 1) 
        {
            return 1;
        }
        else
        {
            return cardNum[2];
        }
    }

    public int GetStraightTopCardNum()
    {
        int[] cardNum = new int[3];

        for (int i = 0; i < Cards.Length; i++)
        {
            cardNum[i] = int.Parse(Cards[i][1]);
        }

        Array.Sort(cardNum);

        return cardNum[2];
    }

    public int GetPairNumber()
    {
        int[] cardNum = new int[3];

        int pairNum = 0;

        for (int i = 0; i < Cards.Length; i++)
        {
            cardNum[i] = int.Parse(Cards[i][1]);
        }

        if(cardNum[0] == cardNum[1] || cardNum[0] == cardNum[2])
        {
            pairNum = cardNum[0];
        }
        else if(cardNum[1] == cardNum[2])
        {
            pairNum = cardNum[1];
        }

        return pairNum;
    }

    public int GetPairOtherNumber(int pairNum)
    {
        for (int i = 0; i < Cards.Length; i++)
        {
            if(int.Parse(Cards[i][1]) != pairNum)
            {
                return int.Parse(Cards[i][1]);
            }
        }
        return 0;
    }

    public int GetSumNumber()
    {
        int sumNum = 0;

        for (int i = 0; i < Cards.Length; i++)
        {
            int num = int.Parse(Cards[i][1]);
            if(num >= 10)
            {
                num = 10;
            }

            sumNum = sumNum + num;
        }

        return sumNum % 10;
    }

    public int GetStraightNums()
    {
        Array.Sort(Cards, new CardComparer(1));

        return int.Parse(Cards[2][1]);
    }

    public void ClearLists()
    {
        //Triple_Players.Clear();
        //Straight_Players.Clear();
        //Pair_Players.Clear();
        //Basic_Players.Clear();
    }

    // 최종 승자 판단 후 누구인지 알려준다
    public CardGenealogy GetWinner(List<CardGenealogy> players)
    {
        List<CardGenealogy> triple_Players = new List<CardGenealogy>();
        List<CardGenealogy> straight_Players = new List<CardGenealogy>();
        List<CardGenealogy> pair_Players = new List<CardGenealogy>();
        List<CardGenealogy> basic_Players = new List<CardGenealogy>();

        for (int i = 0; i < players.Count; i++) // 플레이어 패 분류
        {
            if (players[i] != null)
            {
                if (players[i].GeneType != CardGenealogy.GenealogyType.Default)
                {
                    switch (players[i].GeneType)
                    {
                        case CardGenealogy.GenealogyType.Triple:
                            {
                                triple_Players.Add(players[i]);
                            }
                            break;
                        case CardGenealogy.GenealogyType.Straight:
                            {
                                straight_Players.Add(players[i]);
                            }
                            break;
                        case CardGenealogy.GenealogyType.Pair:
                            {
                                pair_Players.Add(players[i]);
                            }
                            break;
                        case CardGenealogy.GenealogyType.Basic:
                            {
                                basic_Players.Add(players[i]);
                            }
                            break;
                        default:
                            break;
                    }
                }
            }
        }

        if(triple_Players.Count > 1)
        {
            return GetWinner_Triple(triple_Players);
        }
        else if(triple_Players.Count == 1)
        {
            return triple_Players[0];
        }

        if(straight_Players.Count > 1)
        {
            return GetWinner_Straight(straight_Players);
        }
        else if(straight_Players.Count == 1)
        {
            return straight_Players[0];
        }

        if (pair_Players.Count > 1)
        {
            return GetWinner_Pair(pair_Players);
        }
        else if (pair_Players.Count == 1)
        {
            return pair_Players[0];
        }

        if (basic_Players.Count > 1)
        {
            return GetWinner_Basic(basic_Players);
        }
        else if (basic_Players.Count == 1)
        {
            return basic_Players[0];
        }

        return null;
    }

    CardGenealogy GetWinner_Triple(List<CardGenealogy> triplePlayers)
    {
        CardGenealogy winner = null;

        int[] topNum = new int[triplePlayers.Count];

        for (int i = 0; i < triplePlayers.Count; i++)
        {
            topNum[i] = triplePlayers[i].TopCardNumber;
        }

        Array.Sort(topNum);

        for (int i = 0; i < triplePlayers.Count; i++)
        {
            if(topNum[topNum.Length - 1] == triplePlayers[i].TopCardNumber)
            {
                winner = triplePlayers[i];
                break;
            }
        }

        return winner;
    }

    CardGenealogy GetWinner_Straight(List<CardGenealogy> straightPlayers)
    {
        CardGenealogy winner = null;
        List<CardGenealogy> sameNum = new List<CardGenealogy>();
        Dictionary<CardGenealogy, int> dic_players = new Dictionary<CardGenealogy, int>();
        int[] topNums = new int[straightPlayers.Count];
        int[] lastNums = new int[straightPlayers.Count];

        for (int i = 0; i < topNums.Length; i++)
        {
            topNums[i] = straightPlayers[i].TopCardNumber;
            lastNums[i] = straightPlayers[i].StraightLastNumber;
            dic_players.Add(straightPlayers[i], straightPlayers[i].TopCardNumber);
        }

        Array.Sort(topNums);
        Array.Reverse(lastNums); // 역순으로 정렬

        // 가장 높은 수의 카드와 동일한 숫자가 있나 판단
        foreach (var player in dic_players)
        {
            if(topNums[topNums.Length - 1] == player.Value)
            {
                sameNum.Add(player.Key);
            }
        }

        // 동일한 카드가 있으면 무늬 비교
        if (sameNum.Count > 1)
        {
            int[] patterns = new int[sameNum.Count];
            for (int i = 0; i < patterns.Length; i++)
            {
                patterns[i] = (int)sameNum[i].TopCardPattern;
            }
            Array.Sort(patterns);

            List<CardGenealogy> samePattern = new List<CardGenealogy>();

            // 가장 높은 무늬 카드가 같은 카드가 있나 체크

            foreach (var player in dic_players)
            {
                if (patterns[0] == (int)player.Key.TopCardPattern)
                {
                    samePattern.Add(player.Key);
                }
            }

            // 같은 무늬를 가진 플레이어가 있으면
            if (samePattern.Count > 1)
            {
                for (int i = 0; i < samePattern.Count; i++)
                {
                    if (samePattern[i].TopPatternNumber == 1)
                    {
                        return samePattern[i];
                    }
                }

                int[] topNumberCard = new int[samePattern.Count];

                for (int i = 0; i < topNumberCard.Length; i++)
                {
                    topNumberCard[i] = samePattern[i].TopPatternNumber;
                }
                Array.Sort(topNumberCard);

                // 같은 무늬의 카드중 높은 숫자 판단
                foreach (var player in samePattern)
                {
                    if (player.TopPatternNumber == topNumberCard[topNumberCard.Length - 1])
                    {
                        return player;
                    }
                }
            }
            else // 같은 무늬를 가진 플레이어가 없으면
            {
                return samePattern[0];
            }
        }
        else // 같은 숫자를 가진 플레이어가 없으면
        {
            return sameNum[0];
        }

        return winner;
    }


    CardGenealogy GetWinner_Pair(List<CardGenealogy> pairPlayers)
    {
        // 페어인 카드숫자 비교 -> 같은 카드가 있으면 -> 마지막 숫자 비교 -> 같으면 -> 무늬비교 -> 무늬 카드의 숫자 비교
        CardGenealogy winner = null;
        List<CardGenealogy> sameNum = new List<CardGenealogy>();
        Dictionary<CardGenealogy, int> dic_players = new Dictionary<CardGenealogy, int>();

        int[] topNums = new int[pairPlayers.Count];

        for (int i = 0; i < topNums.Length; i++)
        {
            topNums[i] = pairPlayers[i].PairNumber;
            dic_players.Add(pairPlayers[i], pairPlayers[i].PairNumber);
        }

        Array.Reverse(topNums); // 역순으로 정렬

        // 가장 높은 수의 카드와 동일한 숫자가 있나 판단
        foreach (var player in dic_players)
        {
            if (topNums[0] == player.Value)
            {
                sameNum.Add(player.Key);
            }
        }

        if (sameNum.Count > 1) // 가장 높은 수의 카드를 가진 사람이 2명 이상일 때
        {
            // 3번째 카드를 체크하여 더 높은 사람이 승리
            int[] lastNums = new int[sameNum.Count];
            for (int i = 0; i < lastNums.Length; i++)
            {
                lastNums[i] = sameNum[i].PairOtherNumber;
            }
            Array.Reverse(lastNums);

            // 가장 높은 페어가 아닌 숫자가 같은 카드가 있나 체크
            List<CardGenealogy> players = new List<CardGenealogy>();

            foreach (var player in dic_players)
            {
                if(lastNums[0] == player.Key.PairOtherNumber)
                {
                    players.Add(player.Key);
                }
            }
            // 동일한 카드가 있으면 무늬 비교
            if (players.Count > 1)
            {
                int[] patterns = new int[players.Count];
                for (int i = 0; i < patterns.Length; i++)
                {
                    patterns[i] = (int)players[i].TopCardPattern;
                }
                Array.Sort(patterns);

                List<CardGenealogy> samePattern = new List<CardGenealogy>();

                // 가장 높은 무늬 카드가 같은 카드가 있나 체크
                foreach (var player in dic_players)
                {
                    if(patterns[0] == (int)player.Key.TopCardPattern)
                    {
                        samePattern.Add(player.Key);
                    }
                }

                // 같은 무늬를 가진 플레이어가 있으면
                if (samePattern.Count > 1)
                {
                    int[] topNumberCard = new int[samePattern.Count];

                    for (int i = 0; i < topNumberCard.Length; i++)
                    {
                        topNumberCard[i] = samePattern[i].TopPatternNumber;
                    }
                    Array.Sort(topNumberCard);

                    foreach (var player in samePattern)
                    {
                        if (player.TopPatternNumber == topNumberCard[topNumberCard.Length - 1])
                        {
                            return player;
                        }
                    }
                }
                else // 같은 무늬를 가진 플레이어가 없으면
                {
                    return samePattern[0];
                }
            }
            else
            {
                return players[0];
            }
        }
        else
        {
            return sameNum[0];
        }

        return winner;
    }

    CardGenealogy GetWinner_Basic(List<CardGenealogy> basicPlayers)
    {
        CardGenealogy winner = null;
        List<CardGenealogy> sameNum = new List<CardGenealogy>();

        int[] topNums = new int[basicPlayers.Count];

        Dictionary<CardGenealogy, int> dic_topNums = new Dictionary<CardGenealogy, int>();

        for (int i = 0; i < topNums.Length; i++)
        {
            topNums[i] = basicPlayers[i].SumCardNumber;
            dic_topNums.Add(basicPlayers[i], basicPlayers[i].SumCardNumber);
        }

        Array.Sort(topNums); // 역순으로 정렬

        // 가장 높은 수의 카드와 동일한 숫자가 있나 판단
        foreach (var player in dic_topNums)
        {
            if (topNums[topNums.Length - 1] == player.Value)
            {
                sameNum.Add(player.Key);
            }
        }

        if (sameNum.Count > 1) // 가장 높은 수의 카드를 가진 사람이 2명 이상일 때
        {
            // 동일한 카드가 있으면 무늬 비교
            int[] patterns = new int[sameNum.Count];
            for (int i = 0; i < patterns.Length; i++)
            {
                patterns[i] = (int)sameNum[i].TopCardPattern;
            }
            Array.Sort(patterns);

            List<CardGenealogy> samePattern = new List<CardGenealogy>();

            // 가장 높은 무늬 카드가 같은 카드가 있나 체크
            foreach (var player in dic_topNums)
            {
                if (patterns[0] == (int)player.Key.TopCardPattern)
                {
                    samePattern.Add(player.Key);
                }
            }

            // 같은 무늬를 가진 플레이어가 있으면
            if (samePattern.Count > 1)
            {
                for (int i = 0; i < samePattern.Count; i++)
                {
                    if (samePattern[i].TopPatternNumber == 1)
                    {
                        return samePattern[i];
                    }
                }

                int[] topNumberCard = new int[samePattern.Count];

                for (int i = 0; i < topNumberCard.Length; i++)
                {
                    topNumberCard[i] = samePattern[i].TopPatternNumber;
                }
                Array.Sort(topNumberCard);

                foreach (var player in samePattern) // 같은 무늬 카드중 가장 높은수를 가진 플레이어가 승리
                {
                    if (player.TopPatternNumber == topNumberCard[topNumberCard.Length -1])
                    {
                        return player;
                    }
                }
            }
            else // 같은 무늬를 가진 플레이어가 없으면
            {
                return samePattern[0];
            }

        }
        else // 같은 카드를 가진 플레이어가 없을때
        {
            return sameNum[0];
        }

        return winner;
    }
}
