import { action, computed, observable } from "mobx";
import UserService from "services/user/UserService";
import RootStore from "stores";
import BaseStore from "stores/BaseStore";
import { PagingType } from "stores/message/types";
import {
  Finance,
  MemberSearch,
  MemberType,
  TEditBlock,
  TEditMember,
  TGameLog,
  TGameLogPage,
  TGameLogSearch,
  TSMHistory,
  TSMHistoryPage,
  TSMHistorySearch,
} from "./types";

class MemberStore extends BaseStore {
  root: RootStore;

  constructor(root: RootStore) {
    super();
    this.root = root;
  }

  @observable
  memberPage = {} as PagingType;

  @observable
  blockPage = {} as PagingType;

  @observable
  financePage = {} as PagingType;

  @observable
  private _member?: MemberType;

  @observable
  private _memberList: MemberType[] = [];

  @observable
  private _blockList: MemberType[] = [];

  @observable
  private _financeList: Finance[] = [];

  @observable
  private _finance!: Finance;

  @observable
  gameLogPage = {
    paging: {} as PagingType,
    logs: [] as TGameLog[],
  } as TGameLogPage;

  @observable
  sendMoneyHistoryPage = {
    paging: {} as PagingType,
    logs: [] as TSMHistory[],
  } as TSMHistoryPage;

  @computed
  get memberList() {
    return this._memberList;
  }

  @computed
  get member() {
    return this._member;
  }

  @computed
  get blockList() {
    return this._blockList;
  }

  @computed
  get financeList() {
    return this._financeList;
  }

  @computed
  get finance() {
    return this._finance;
  }

  @action
  getMember = (id: number) => {
    return this.memberList.map((member) => {
      if (member.id === id) {
        this._member = member;
      }
    });
  };

  @action
  getBlock = (id: number) => {
    this.blockList.map((member) => {
      if (member.id === id) {
        this._member = member;
      }
    });
  };

  @action
  getFinance = (id: number) => {
    this.financeList.map((log) => {
      if (log.id === id) {
        this._finance = log;
      }
    });
  };

  @action
  setMemberList(users: MemberType[]) {
    this._memberList = users;
  }

  @action
  getMemberList = async (memberSearch: MemberSearch) => {
    this._init("GET_MEMBER_LIST");

    try {
      const res = await UserService.GetUserListAPI(memberSearch);
      const { users } = res.data.data;
      this.memberPage = res.data.data.paging;
      this._memberList = users;
      this._success["GET_MEMBER_LIST"] = true;
    } catch (e) {
      this._failure["GET_MEMBER_LIST"] = [true, e];
    } finally {
      this._pending["GET_MEMBER_LIST"] = false;
    }
  };

  @action
  updateMember = async (modifyMember: TEditMember) => {
    this._init("UPDATE_MEMBER");

    try {
      this._success["UPDATE_MEMBER"] = true;
      await UserService.PutUpdateOneUserAPI(modifyMember);
    } catch (e) {
      this._failure["UPDATE_MEMBER"] = [true, e];
      throw e;
    } finally {
      this._pending["UPDATE_MEMBER"] = false;
    }
  };

  @action
  updateMemberEdit = async (modifyMemberAmount: TEditBlock) => {
    this._init("UPDATE_MEMBER_AMOUNT");

    await UserService.PatchUserAmount(modifyMemberAmount);

    try {
      this._success["UPDATE_MEMBER_AMOUNT"] = true;
    } catch (e) {
      this._failure["UPDATE_MEMBER_AMOUNT"] = [true, e];
    } finally {
      this._pending["UPDATE_MEMBER_AMOUNT"] = false;
    }
  };

  @action
  getBlockList = async (blockSearch: MemberSearch) => {
    this._init("GET_BLOCK_LIST");

    const res = await UserService.GetBlockUserListAPI(blockSearch);
    this._blockList = res.data.data.users;
    this.blockPage = res.data.data.paging;

    try {
      this._success["GET_BLOCK_LIST"] = true;
    } catch (e) {
      this._failure["GET_BLOCK_LIST"] = [true, e];
    } finally {
      this._pending["GET_BLOCK_LIST"] = false;
    }
  };

  @action
  getFinanceList = async (financeSearch: MemberSearch) => {
    this._init("GET_FINANCE_LIST");

    const res = await UserService.GetFinanceListAPI(financeSearch);
    this._financeList = res.data.data.logs;
    this.financePage = res.data.data.paging;

    try {
      this._success["GET_FINANCE_LIST"] = true;
    } catch (e) {
      this._failure["GET_FINANCE_LIST"] = [true, e];
    } finally {
      this._pending["GET_FINANCE_LIST"] = false;
    }
  };

  @action
  getGameLogPage = async (payload: TGameLogSearch) => {
    try {
      const res = await UserService.getGameLogPage(payload);
      if (res.data.result) {
        this.gameLogPage = res.data.data;
      } else {
        alert("Field error");
      }
    } catch (error) {
      alert("There is a problem with the server");
    }
  };

  @action
  getSendMoneyHistoryPage = async (payload: TSMHistorySearch) => {
    try {
      const res = await UserService.getSMHistoryPage(payload);
      if (res.data.result) {
        this.sendMoneyHistoryPage = res.data.data;
      } else {
        alert("Field error");
      }
    } catch (error) {
      alert("There is a problem with the server");
    }
  }
}
export default MemberStore;
