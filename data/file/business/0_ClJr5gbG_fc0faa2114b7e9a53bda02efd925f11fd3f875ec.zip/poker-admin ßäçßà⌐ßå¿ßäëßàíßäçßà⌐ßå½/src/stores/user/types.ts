// export type UserType = {
//   id: number;
//   username: string;
//   password: string;
//   amount: number;
//   profile_img: string;
//   name: string;
//   phone: string;
//   gender: number;
//   status: number;
//   created_at: Date;
//   updated_at?: Date;
// };
export type UserType = {
  id: number;
  userName: string;
  name: string;
  phone: string;
  amount: number;
  created_at: Date;
  bank: string;
  bankName: string;
  bankNumber: string;
  deposit: number;
  withdraw: number;
  password: string;
  active?: boolean | undefined;
};

export type Playing = {
  online: number;
  lobby: number;
  lv1: number;
  lv2: number;
  lv3: number;
  lv4: number;
  lv5: number;
  lv6: number;
  withdraw_count: number;
  deposit_count: number;
};

export type Admin = null | {
  id: string;
  role: string;
};

export type TAgent = null | {
  id: string;
  role: string;
}

export interface TAgentLogin {
  id: string;
  password: string;
}