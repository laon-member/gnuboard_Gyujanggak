import React, { useEffect } from "react";
import SendMoneyHistoryList from "components/member/sendMoneyHistory/SendMoneyHistoryList";
import { inject, observer } from "mobx-react";
import RootStore from "stores";
import {
  TSMHistoryForms,
  TSMHistoryPage,
  TSMHistorySearch,
} from "stores/member/types";
import { useInputs } from "lib/hooks";

interface Props {
  getSendMoneyHistoryPage: (payload: TSMHistorySearch) => void;
  sendMoneyHistoryPage: TSMHistoryPage;
}

const SendMoneyHistoryContainer = ({
  getSendMoneyHistoryPage,
  sendMoneyHistoryPage,
}: Props) => {
  const forms = {
    search: useInputs({
      sender: "",
      receiver: "",
      start_date: "",
      end_date: "",
      page: 1,
    } as TSMHistorySearch),
  } as TSMHistoryForms;

  useEffect(() => {
    (async () => {
      await getSendMoneyHistoryPage(forms.search.inputs);
    })();
  }, []);

  const onSearch = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    getSendMoneyHistoryPage(forms.search.inputs);
  };
  return (
    <SendMoneyHistoryList
      sendMoneyHistoryPage={sendMoneyHistoryPage}
      forms={forms}
      onSearch={onSearch}
    />
  );
};

export default inject(({ memberStore }: RootStore) => ({
  getSendMoneyHistoryPage: memberStore.getSendMoneyHistoryPage,
  sendMoneyHistoryPage: memberStore.sendMoneyHistoryPage,
}))(observer(SendMoneyHistoryContainer));
