﻿using DG.Tweening;
using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using LitJson;
using Leguar.TotalJSON;
using Photon.Realtime;

public class DepositManager : MonoBehaviourPunCallbacks
{
    // TopButton
    public UnityEngine.UI.Image Btn_Charge;
    public UnityEngine.UI.Image Btn_History;

    public Sprite[] Spr_TopBtn;
    
    public GameObject[] Pages;

    int BtnState = 0;

    public RectTransform ArrowScroll;
    public GameObject ArrowContent;
    public Text AccountTxt;

    public InputField Input_ChargeAmount;

    public Transform ArrowImg;

    bool IsMore;

    public DepositAccountContent PFAccount;

    public GameObject PopUp_Guidance;
    
    public GameObject PFContent;
    public Transform ContentParent;

    public GameObject X_Btn;

    DataBaseManager DBMgr;
    List<DepositContent> List_Contents = new List<DepositContent>();

    public Guidance NoticGuidance;

    int SelectAccountID;

    public GameObject ClickPanel;

    List<DepositAccountContent> List_Accounts = new List<DepositAccountContent>();

    // Start is called before the first frame update
    void Start()
    {
        if(DBMgr == null)
        {
            DBMgr = FindObjectOfType<DataBaseManager>();
        }

        CreateAccountContent();
    }

    private void Update()
    {
        if(Input_ChargeAmount != null)
        {
            if(Input_ChargeAmount.text != "0" && Input_ChargeAmount.text.Length > 0)
            {
                if(!X_Btn.activeInHierarchy)
                {
                    X_Btn.SetActive(true);
                }
            }
            else
            {
                if(X_Btn.activeInHierarchy)
                {
                    X_Btn.SetActive(false);
                }
            }
        }
    }

    public void OnClickBtn_X_Btn()
    {
        Input_ChargeAmount.text = "0";
    }

    // DB 에서 계좌 정보 받아서 넣기
    void CreateAccountContent()
    {
        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetCompanyAccount, "", "Post", PlayerPrefs.GetString("Token"), (result) => {

            JsonData resp = JsonMapper.ToObject(result);
            
            if((int)resp["result"] == 1)
            {
                int count = resp["data"]["bank"].Count;
                for (int i = 0; i < count; i++)
                {
                    //DepositAccountContent account = GameObject.Instantiate(PFAccount, ArrowContent.transform);

                    //account.transform.localPosition = new Vector2(301.5f, 0);
                    //account.SetMain(this);

                    //account.SetInfo((string)resp["data"]["bank"][i]["number"], (int)resp["data"]["bank"][i]["id"]);

                    if (i == 0)
                    {
                        AccountTxt.text = (string)resp["data"]["bank"][0]["number"];
                        SelectAccountID = (int)resp["data"]["bank"][0]["id"];
                    }

                    if (AccountTxt.text != (string)resp["data"]["bank"][i]["number"])
                    {
                        DepositAccountContent account = GameObject.Instantiate(PFAccount, ArrowContent.transform);

                        account.transform.localPosition = new Vector2(301.5f, 0);
                        account.SetMain(this);

                        account.SetInfo((string)resp["data"]["bank"][i]["number"], (int)resp["data"]["bank"][i]["id"]);

                        List_Accounts.Add(account);
                    }
                }
            }
        }));
    }

    void SetAccount()
    {
        for (int i = 0; i < List_Accounts.Count; i++)
        {
            Destroy(List_Accounts[i].gameObject);
        }

        List_Accounts.Clear();

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetCompanyAccount, "", "Post", PlayerPrefs.GetString("Token"), (result) => {

            JsonData resp = JsonMapper.ToObject(result);
            if ((int)resp["result"] == 1)
            {
                int count = resp["data"]["bank"].Count;
                for (int i = 0; i < count; i++)
                {
                    if (AccountTxt.text != (string)resp["data"]["bank"][i]["number"])
                    {
                        DepositAccountContent account = GameObject.Instantiate(PFAccount, ArrowContent.transform);

                        account.transform.localPosition = new Vector2(301.5f, 0);
                        account.SetMain(this);

                        account.SetInfo((string)resp["data"]["bank"][i]["number"], (int)resp["data"]["bank"][i]["id"]);

                        List_Accounts.Add(account);
                    }
                }
            }
        }));
    }

    void CreateHistoryContent()
    {
        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetDepositHistory, "", "Post", PlayerPrefs.GetString("Token"), (result) => {

            JsonData resp = JsonMapper.ToObject(result);

            if ((int)resp["result"] == 1)
            {
                int count = resp["data"]["deposit"].Count;

                for (int i = 0; i < count; i++)
                {
                    DepositContent content = GameObject.Instantiate(PFContent, ContentParent).GetComponent<DepositContent>();

                    // DB에서 정보 받아서 세팅
                    string[] info = new string[6];
                    info[0] = (i + 1).ToString();
                    info[1] = LocalPlayerInfo.Instance.PlayerAccount;
                    info[2] = (string)resp["data"]["deposit"][i]["number"];

                    info[3] = CStringFormat.Instance.FormatToInt(long.Parse(resp["data"]["deposit"][i]["amount"].ToString()));

                    string date_buffer = (string)resp["data"]["deposit"][i]["created_at"];
                    string date = "";

                    for (int j = 0; j < 10; j++ )
                    {
                        date += date_buffer[j].ToString();
                    }

                    info[4] = date;

                    string status = "";
                    if((int)resp["data"]["deposit"][i]["status"] == 0 || (int)resp["data"]["deposit"][i]["status"] == 5)
                    {
                        status = "Chờ nạp tiền"; // 번역 : 입금 대기 o
                    }
                    else if ((int)resp["data"]["deposit"][i]["status"] == 1)
                    {
                        status = "Hoàn thành \r\nrnạp tiền"; // 번역 : 입금 완료 o
                    }
                    else if ((int)resp["data"]["deposit"][i]["status"] == 2)
                    {
                        status = "Hủy nạp tiền"; // 번역 :  입금 취소 o
                    }
                    info[5] = status;

                    content.SetTexts(info);
                    List_Contents.Add(content);
                }
            }
        }));
    }

    public override void OnDisconnected(DisconnectCause cause)
    {
        SceneManager.LoadScene("LogIn");
    }

    void ClearHistory()
    {
        for (int i = 0; i < ContentParent.childCount; i++)
        {
            Destroy(ContentParent.GetChild(i).gameObject);
        }

        List_Contents.Clear();
    }

    public void OnClickBtn_Leave()
    {
        SceneManager.LoadScene("Lobby");
    }

    /// <summary>
    /// 0 = charge, 1 = history
    /// </summary>
    /// <param name="type"></param>
    public void OnClickBtn_TopBtn(int type)
    {
        if (type == 0 && BtnState == 1)
        {
            BtnState = type;

            Btn_Charge.sprite = Spr_TopBtn[0];
            Btn_History.sprite = Spr_TopBtn[1];

            Btn_Charge.GetComponent<RectTransform>().sizeDelta = new Vector2(389, 112);
            Btn_History.GetComponent<RectTransform>().sizeDelta = new Vector2(319, 84);

            Pages[0].SetActive(true);
            Pages[1].SetActive(false);

            ClearHistory();

            Input_ChargeAmount.text = "0";
        }
        else if(type == 1 && BtnState == 0)
        {
            BtnState = type;

            Btn_Charge.sprite = Spr_TopBtn[1];
            Btn_History.sprite = Spr_TopBtn[0];

            Btn_Charge.GetComponent<RectTransform>().sizeDelta = new Vector2(319, 84);
            Btn_History.GetComponent<RectTransform>().sizeDelta = new Vector2(389, 112);

            Pages[0].SetActive(false);
            Pages[1].SetActive(true);

            CreateHistoryContent();
        }
    }

    public void OnClickBtn_Recharge()
    {
        if (GetIntMoney(Input_ChargeAmount.text) > 0 && Input_ChargeAmount.text.Length > 0)
        {
            //PopUp_Guidance.SetActive(true);
            PopUp_Guidance.GetComponent<Guidance>().SetText("Bạn có muốn nạp vào?");
        }
    }

    public void OnClickBtn_RechargeOK(bool result)
    {
        if (result)
        {
            // 충전
            JSON jsonData = new JSON();
            jsonData.Add("account_id", SelectAccountID.ToString());
            jsonData.Add("amount", GetIntMoney(Input_ChargeAmount.text).ToString());
            jsonData.Add("status", "0");

            StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.AddDeposit, jsonData.CreateString(), "Post", PlayerPrefs.GetString("Token"), (coresult) =>
            {
                JsonData resp = JsonMapper.ToObject(coresult);

                Debug.LogFormat("<color=red>{0}</color>", (int)resp["result"]);

                if ((int)resp["result"] == 1)
                {
                    NoticGuidance.SetText("Hoàn thành đăng kí"); //번역 : 신청 완료 o
                }
            }));
        }
        else
        {
            // 취소
        }

        PopUp_Guidance.SetActive(false);
    }

    public void SetAccount(string accountNum, int id)
    {
        AccountTxt.text = accountNum;

        SelectAccountID = id;
    }

    public void OnClickBtn_Chip(int money)
    {
        if(Input_ChargeAmount.text.Length == 0)
        {
            Input_ChargeAmount.text = "0";
        }
        if(Input_ChargeAmount.text != "0")
        {
            Input_ChargeAmount.text = string.Format("{0:#,###}", GetIntMoney(Input_ChargeAmount.text) + money);
        }
        else
        {
            Input_ChargeAmount.text = string.Format("{0:#,###}", (long.Parse(Input_ChargeAmount.text) + money));
        }
    }

    public long GetIntMoney(string str)
    {
        long money = 0;

        if (str.Length > 0)
        {
            if (str != "0")
            {
                string[] buffer = str.Split(',');
                string buffer_money = "";
                foreach (var item in buffer)
                {
                    buffer_money += item;
                }

                money = long.Parse(buffer_money);
            }
        }
        return money;
    }

    public void OnClickBtn_AccountArrow()
    {
        if(!IsMore)
        {
            ArrowScroll.GetComponent<ScrollRect>().enabled = true;

            ActiveArrowScroll(true);

            ArrowScroll.DOSizeDelta(new Vector2(ArrowScroll.sizeDelta.x, 475.0f), 0.15f);

            Color color = ArrowScroll.GetComponent<Image>().color;
            color.a = 1.0f;

            ArrowScroll.GetComponent<Image>().DOColor(color, 0.15f);

            ArrowImg.transform.DORotate(new Vector3(0, 0, 180), 0.00001f);
        }
        else
        {
            SetAccount();

            ArrowScroll.GetComponent<ScrollRect>().enabled = false;
            
            ArrowScroll.DOSizeDelta(new Vector2(ArrowScroll.sizeDelta.x, 20.0f), 0.15f).OnComplete(()=> ActiveArrowScroll(false));

            Color color = ArrowScroll.GetComponent<Image>().color;
            color.a = 0.0f;

            ArrowScroll.GetComponent<Image>().DOColor(color, 0.15f);

            ArrowImg.transform.DORotate(new Vector3(0, 0, 0), 0.00001f);

            ClickPanel.SetActive(false);
        }

        IsMore = !IsMore;
    }

    void ActiveArrowScroll(bool active)
    {
        if(active)
        {
            ArrowScroll.gameObject.SetActive(true);
            ClickPanel.SetActive(true);
        }
        else
        {
            ArrowScroll.gameObject.SetActive(false); 
        }
    }

    public void OnClickBtn_ClickPanel()
    {
        if(ArrowScroll.gameObject.activeInHierarchy)
        {
            ClickPanel.SetActive(false);
            OnClickBtn_AccountArrow();
        }
    }

    public void OnValueChange_ChargeAmount()
    {
        string formatTxt = string.Format("{0:#,###}", GetIntMoney(Input_ChargeAmount.text));
        Input_ChargeAmount.text = formatTxt;
    }

    public void OnClickBtn_ClickSound()
    {
        FindObjectOfType<SoundManager>().StartSound_Effect(SoundFileList.EFFECT.btn_click);
    }
}
