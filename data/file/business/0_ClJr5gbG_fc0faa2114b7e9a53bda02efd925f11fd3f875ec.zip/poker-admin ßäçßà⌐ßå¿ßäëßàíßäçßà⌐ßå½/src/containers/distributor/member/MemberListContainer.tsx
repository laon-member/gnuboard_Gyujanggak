import MemberList from "components/distributor/member/memberList/MemberList";
import { useInputs } from "lib/hooks";
import { inject, observer } from "mobx-react";
import React, { useEffect } from "react";
import RootStore from "stores";
import {
  TMemberListForms,
  TMemberListPage,
  TMemberListSearch,
} from "stores/distributor/member/types";

interface Props {
  memberListPage: TMemberListPage;
  getMemberListPage: (payload: TMemberListSearch) => void;
}

function MemberListContainer({ memberListPage, getMemberListPage }: Props) {
  const forms = {
    search: useInputs({
      username: "",
      nickname: "",
      date_type: "",
      start_date: "",
      end_date: "",
      page: 1,
    } as TMemberListSearch),
  } as TMemberListForms;

  useEffect(() => {
    (async () => {
      getMemberListPage(forms.search.inputs);
    })();
  }, []);

  const onSearch = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    await getMemberListPage(forms.search.inputs);
  };

  return (
    <MemberList
      memberListPage={memberListPage}
      forms={forms}
      onSearch={onSearch}
    />
  );
}

export default inject(({ agentMemberStore }: RootStore) => ({
  memberListPage: agentMemberStore.memberListPage,
  getMemberListPage: agentMemberStore.getMemberListPage,
}))(observer(MemberListContainer));
