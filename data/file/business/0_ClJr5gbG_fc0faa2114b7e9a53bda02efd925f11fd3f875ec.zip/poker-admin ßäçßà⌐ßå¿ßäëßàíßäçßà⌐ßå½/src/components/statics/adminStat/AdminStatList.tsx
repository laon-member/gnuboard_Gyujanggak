import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import React from "react";
import { FaSearch } from "react-icons/fa";
import {
  TAdminStatForms,
  TAdminStatPage,
  TAdminStatSearch,
} from "stores/statistics/types";
import { Button, Input } from "styles/atom";
import { AdminStat } from ".";

interface Props {
  adminStatPage: TAdminStatPage;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
  forms: TAdminStatForms;
}

const AdminStatList = ({ adminStatPage, onSearch, forms }: Props) => {
  const { search } = forms;
  const { onChange } = search;
  const { start_date, end_date } = search.inputs as TAdminStatSearch;
  return (
    <>
      <SearchWrapper>
        <SearchForm onSubmit={onSearch}>
          <Input
            type="date"
            name="start_date"
            value={start_date}
            onChange={onChange}
          />
          <Input
            type="date"
            name="end_date"
            value={end_date}
            onChange={onChange}
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>Date</th>
            <th>MemberRecharge</th>
            <th>PlayersGoldSum</th>
            <th>MemberWithdraw</th>
            <th>AdminIncrease</th>
            <th>AdminDecrease</th>
            <th>TotalPoundage</th>
            <th>AgentPoundage</th>
            <th>NetProfit</th>
            <th>NewMember</th>
          </tr>
        </thead>
        <tbody>
          {adminStatPage.notices.map((adminStat, index) => (
            <AdminStat key={index} adminStat={adminStat} />
          ))}
        </tbody>
      </Table>
      <PageNationContainer
        paging={adminStatPage.paging}
        searchForm={forms.search}
        onSearch={onSearch}
      />
    </>
  );
};

export default AdminStatList;
