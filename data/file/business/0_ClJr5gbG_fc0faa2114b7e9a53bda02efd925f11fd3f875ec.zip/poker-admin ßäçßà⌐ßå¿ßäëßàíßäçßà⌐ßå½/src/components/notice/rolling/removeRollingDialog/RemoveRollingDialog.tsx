import React from "react";
import { DialogContainer } from "containers/common/dialog";

interface Props {
  title: string;
  onToggle: () => void;
  onRemove: (list: number[]) => void;
  activeList: number[];
}

const RemoveRollingDialog = ({
  title,
  onToggle,
  onRemove,
  activeList,
}: Props) => {
  const onSave = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onRemove(activeList);
  };
  return (
    <DialogContainer
      title={title}
      confirmText="REMOVE"
      onToggle={onToggle}
      onSubmit={onSave}
    >
      <p>
        Are you sure you want to delete a total of {activeList.length} messages?
      </p>
    </DialogContainer>
  );
};

export default RemoveRollingDialog;
