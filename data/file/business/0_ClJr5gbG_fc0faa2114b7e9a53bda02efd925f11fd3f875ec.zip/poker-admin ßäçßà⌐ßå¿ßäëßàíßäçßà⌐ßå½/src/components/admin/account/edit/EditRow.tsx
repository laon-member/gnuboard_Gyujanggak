import React from "react";
import { AdminType } from "stores/admin/types";
import { useInputs } from "lib/hooks";
import styled from "styled-components";
import { Button, Input } from "styles/atom";
import TableRowWrapper from "components/common/TableRowWrapper";

interface Props {
  admin: AdminType;
  onEditAccout: (id: string, password: string) => void;
  onDelete: (id: string) => void;
}

const EditRow = ({ admin, onDelete, onEditAccout }: Props) => {
  const { inputs, onChange } = useInputs({
    password: "",
    passwordCheck: "",
  });
  const { password, passwordCheck } = inputs;

  const onSubmit = (id: string, password: string) => {
    if (password === "" || passwordCheck === "")
      return alert("Don't empty input");
    if (password !== passwordCheck) return alert("The password is not same");
    onEditAccout(id, password);
  };

  return (
    <TableRowWrapper>
      <td>{admin.id}</td>
      <td>{admin.username}</td>
      <td>
        <Input
          type="password"
          name="password"
          value={password}
          onChange={onChange}
          placeholder="enter password"
        />
      </td>
      <td>
        <Input
          type="password"
          name="passwordCheck"
          value={passwordCheck}
          onChange={onChange}
          placeholder="enter password again"
        />
      </td>
      <td>
        <OptionWrapper>
          <Button onClick={() => onSubmit(admin.username, password)}>
            EDIT
          </Button>
          <Button secondary onClick={() => onDelete(admin.id)}>
            DEL
          </Button>
        </OptionWrapper>
      </td>
    </TableRowWrapper>
  );
};

export const OptionWrapper = styled.div`
  & > button + button {
    margin-left: 0.5rem;
  }
`;

export default EditRow;
