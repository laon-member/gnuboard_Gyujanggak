import TableRowWrapper from "components/common/TableRowWrapper";
import React from "react";
import { FaBook, FaEdit, FaPen } from "react-icons/fa";
import { TBlock } from "stores/member/types";
import { NoteType } from "../memberlist/types";

interface Props {
  block: TBlock;
  note: NoteType;
  onEditToggle: () => void;
  onInfoToggle: () => void;
  getMember: (id: number) => void;
}

function Block({ block, note, onEditToggle, onInfoToggle, getMember }: Props) {
  const onToggleNote = () => {
    note.onToggle();
    getMember(block.id);
  };

  const onToggleEdit = () => {
    onEditToggle();
    getMember(block.id);
  };

  const onToggleInfo = () => {
    onInfoToggle();
    getMember(block.id);
  };

  return (
    <TableRowWrapper>
      <td>{block.id}</td>
      <td>{block.username}</td>
      <td>{block.name}</td>
      <td>{block.agent}</td>
      <td>{block.phone}</td>
      <td>{block.amount}</td>
      <td>{block.created_at}</td>
      <td>{block.last_login}</td>
      <td>{block.bankName}</td>
      <td>{block.bank}</td>
      <td>{block.bankNumber}</td>
      <td>{block.deposit}</td>
      <td>{block.withdraw}</td>
      <td className="icon" onClick={onToggleNote}>
        <FaBook />
      </td>
      <td className="icon" onClick={onToggleEdit}>
        <FaPen />
      </td>
      <td className="icon" onClick={onToggleInfo}>
        <FaEdit />
      </td>
    </TableRowWrapper>
  );
}

export default Block;
