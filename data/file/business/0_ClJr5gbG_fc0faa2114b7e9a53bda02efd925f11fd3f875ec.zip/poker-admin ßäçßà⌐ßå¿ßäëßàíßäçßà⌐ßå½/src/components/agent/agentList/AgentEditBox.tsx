import { InputWrapper } from "components/deposit/Bankset/Bankset";
import { Invalid } from "components/login/Login";
import { RadioWrapper } from "components/member/memberlist/EditBox";
import { DialogContainer } from "containers/common/dialog";
import React, { useEffect, useState } from "react";
import { EditBoxType, TAgent, TAgentEdit } from "stores/agent/types";
import { UseInput } from "stores/notice/types";
import { Input } from "styles/atom";

interface Props {
  edit: EditBoxType;
  editForm: UseInput;
  agent: TAgent;
}

function AgentEditBox({ edit, editForm, agent }: Props) {
  const {
    username,
    password,
    passwordCheck,
    mobile,
    agent_code,
    bank_account,
    bank_name,
    card_number,
    bene_rate,
    add_money,
  } = editForm!.inputs as TAgentEdit;
  const { onChange } = editForm;
  const [passwordConfirm, setPasswordConfirm] = useState(false);

  const passwordCheckHandler = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPasswordConfirm(password !== e.target.value);
    editForm!.setInputs({
      ...editForm!.inputs,
      passwordCheck: e.target.value,
    });
  };

  useEffect(() => {
    editForm.setInputs({
      ...editForm.inputs,
      ...agent,
      add_money: "",
    });
  }, []);
  return (
    <DialogContainer
      title="Agent Edit Box"
      confirmText="SAVE"
      onToggle={edit!.onToggle}
      onSubmit={edit!.onSubmit}
    >
      <InputWrapper>
        <label>ID</label>
        <Input placeholder="ID" name="username" value={username} disabled />
      </InputWrapper>
      <InputWrapper>
        <label>Password</label>
        <Input
          type="password"
          placeholder="Password"
          name="password"
          value={password}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>PasswordCheck</label>
        <Input
          type="password"
          placeholder="passwordCheck"
          value={passwordCheck}
          onChange={(e) => passwordCheckHandler(e)}
        />
      </InputWrapper>
      {passwordConfirm && (
        <InputWrapper>
          <label></label>
          <Invalid>The password is different.</Invalid>
        </InputWrapper>
      )}
      <InputWrapper>
        <label>Mobile</label>
        <Input
          placeholder="Mobile"
          name="mobile"
          value={mobile}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>AgentCode</label>
        <Input
          placeholder="AgentCode"
          name="agent_code"
          value={agent_code}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>BankAccount</label>
        <Input
          placeholder="BankAccount"
          name="bank_account"
          value={bank_account}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>BankName</label>
        <Input
          placeholder="BankName"
          name="bank_name"
          value={bank_name}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>CardNumber</label>
        <Input
          placeholder="CardNumber"
          name="card_number"
          value={card_number}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>BeneRate</label>
        <Input
          type="number"
          placeholder="BeneRate"
          name="bene_rate"
          value={bene_rate}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Amount</label>
        <Input
          type="number"
          placeholder="Amount"
          disabled
          name="amount"
          defaultValue={agent.agent_amount}
          onChange={onChange}
        />
      </InputWrapper>
      <RadioWrapper>
        <label>Operation</label>
        <div>
          <input
            type="radio"
            name="operation"
            value="INCREASE"
            onChange={editForm?.onChange}
          />{" "}
          <span>INCREASE</span>
          <input
            type="radio"
            name="operation"
            value="DECREASE"
            onChange={editForm?.onChange}
          />{" "}
          <span>DECREASE</span>
        </div>
      </RadioWrapper>
      <InputWrapper>
        <label>AddMoney</label>
        <Input
          type="number"
          placeholder="AddMoney"
          name="add_money"
          value={add_money}
          onChange={onChange}
        />
      </InputWrapper>
    </DialogContainer>
  );
}

export default AgentEditBox;
