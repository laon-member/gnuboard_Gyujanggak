import { PagingType } from "stores/message/types";
import { UseInput } from "stores/notice/types";

export type WithdrawApplyType = {
  id: number;
  username: string;
  agent: string;
  phone: string;
  bank: string;
  name: string;
  number: string;
  amount: number;
  created_at: string;
  status: number;
};

export type TWithdrawApplyPage = {
  paging: PagingType;
  withdraw: WithdrawApplyType[];
};

export type TWithdrawLog = {
  orderNumber: number;
  username: string;
  agent: string;
  phone: string;
  amount: number;
  bankAccount: string;
  bankName: string;
  bankNumber: string;
  applyTime: string;
  handleTime: string;
  adminName: string;
  status: number;
};

export type TWithdrawLogForm = {
  search: UseInput;
};

export type TWithdrawLogPage = {
  paging: PagingType;
  withdraw: TWithdrawLog[];
};

export type User = {
  id: number;
  username: string;
  name: string;
  phone: string;
  birth: Date;
  sex: string;
  created_at: Date;
  updated_at?: Date;
};

export type Account = {
  id: string;
  dl: number;
  cp: number;
  created_at: Date;
  updated_at?: Date;
};

export type WithdrawTypeBackup = {
  id: number;
  username: string;
  phone: string;
  bank: string;
  name: string;
  number: string;
  amount: number;
  created_at: Date;
  check_at: Date;
  status: number;
  user_id: number;
  active?: boolean | undefined;
};

export type PremiumType = {
  idx: number;
  updated_at: Date;
  content: string;
};
