export default function (number?: number): string {
  if (!number) return "0";

  if (number < 0) {
    number = Math.abs(number);
    const arr = (number + "").split("");
    if (arr.length === 3) {
      arr.unshift("-");
      return arr.join("");
    }
    for (let i = arr.length - 3; i >= 0; i -= 3) {
      if (i === 0) {
        arr.unshift("-");
        return arr.join("");
      }
      arr.splice(i, 0, ",");
    }
    arr.unshift("-");
    return arr.join("");
  } else {
    const arr = (number + "").split("");
    if (arr.length === 3) return arr.join("");
    for (let i = arr.length - 3; i >= 0; i -= 3) {
      if (i === 0) return arr.join("");
      arr.splice(i, 0, ",");
    }
    return arr.join("");
  }
}
