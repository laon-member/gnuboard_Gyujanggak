import client from "lib/client";
import {
  SearchGMType,
  SearchPMType,
  SearchUserType,
  UserType,
} from "stores/message/types";

class MessageService {
  public getPMList = async (payload: SearchPMType) => {
    return await client.get(
      `/api/admin/messages/personal?username=${payload.username}&start_date=${payload.start_date}&end_date=${payload.end_date}&sender=${payload.sender}&page=${payload.page - 1}`
    );
  };

  public getGMList = async (payload: SearchGMType) => {
    return await client.get(
      `/api/admin/messages/global?sender&start_date=${payload.start_date}&end_date=${payload.end_date}&page=${payload.page - 1}`
    );
  };

  public searchUserList = async (payload: SearchUserType) => {
    return await client.get(
      `/api/admin/notice/message/users?type=username&value=${payload.username}`
    );
  };

  public sendMessage = async (inputs: SearchUserType, user: UserType) => {
    return await client.post(`/api/admin/messages`, {
      title: inputs.title,
      content: inputs.content,
      type: Number(inputs.type), // TODO: 11/10 주명돈 수정 - 해당 타입 number 타입으로 요청해야함으로 DTO에 type 형변환이 필요합니다. 현재는 string 으로 되어있습니다.
      username: inputs.type === "0" ? user.username : "",
    });
  };
}

export default new MessageService();
