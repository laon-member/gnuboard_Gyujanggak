import React from "react";
import { WithdrawTypeBackup } from "stores/withdraw/types";
import TableRowWrapper from "components/common/TableRowWrapper";
import comma from "lib/comma";
interface Props {
  data: WithdrawTypeBackup;
  onActiveToggle: (id: number) => void;
}

function WithRechargelistItem({ data, onActiveToggle }: Props) {
  const getStatus = () => {
    if (data.status === 1) {
      return "Success";
    } else if (data.status === 2) {
      return "Cancle";
    }
  };
  return (
    <TableRowWrapper>
      <td>{data.id}</td>
      <td>{data.username}</td>
      <td>{data.phone}</td>
      <td>{data.bank}</td>
      <td>{data.name}</td>
      <td>{data.number}</td>
      <td>{comma(data.amount)}</td>
      <td>{data.created_at.toString().slice(0, 16).replace("T", " ")}</td>
      <td>
        {data.check_at &&
          new Date(data.check_at).toISOString().slice(0, 16).replace("T", " ")}
      </td>
      <td>{getStatus()}</td>
    </TableRowWrapper>
  );
}

export default WithRechargelistItem;
