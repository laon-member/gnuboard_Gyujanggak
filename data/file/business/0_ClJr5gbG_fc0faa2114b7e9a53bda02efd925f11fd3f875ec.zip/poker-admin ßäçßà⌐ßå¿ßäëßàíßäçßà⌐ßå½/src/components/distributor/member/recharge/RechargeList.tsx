import React from "react";

function RechargeList() {
  return <h1>recharge c</h1>;
}

export default RechargeList;
