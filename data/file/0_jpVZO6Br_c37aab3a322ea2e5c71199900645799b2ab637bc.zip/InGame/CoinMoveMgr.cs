﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinMoveMgr : MonoBehaviour
{
    private void OnDisable()
    {
        //FindObjectOfType<SoundManager>().StartSound_Effect(SoundFileList.EFFECT.poker_chip);
        //Destroy(this.gameObject);
    }
}
