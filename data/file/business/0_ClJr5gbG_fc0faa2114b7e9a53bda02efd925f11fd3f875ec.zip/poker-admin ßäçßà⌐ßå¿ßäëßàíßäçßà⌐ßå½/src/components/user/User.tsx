/* eslint-disable no-restricted-globals */
import React from "react";

import { UserType } from "stores/user/types";
import SearchIcon from "assets/icons/search.png";
import useInputs from "lib/hooks/useInputs";
import Table from "components/common/Table";
import UserItem from "./item";
import { Select, Input, Button } from "styles/atom";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";

interface Props {
  user: UserType;
  userList: UserType[];
  search: (type: string, inputValue: string, dateType: string) => void;
  oneUser: (id: number) => void;
  update: (
    id: number,
    bank: string,
    bankName: string,
    bankNumber: string,
    phone: string
  ) => void;
  onActiveToggle: (id: number) => void;
}

const User = ({
  user,
  userList,
  search,
  oneUser,
  update,
  onActiveToggle,
}: Props) => {
  const { inputs, onChange } = useInputs({
    searchType: "",
    searchValue: "",
    date: "",
  });
  const { searchType, searchValue, date } = inputs;

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    search(searchType, searchValue, date);
  };

  return (
    <>
      <SearchWrapper>
        <SearchForm onSubmit={onSubmit}>
          <Select
            name="searchType"
            value={searchType}
            onChange={onChange}
            className="select"
          >
            <option>선택</option>
            <option value="id">No.</option>
            <option value="username">ID</option>
            <option value="name">Nick name</option>
            <option value="phone">Phone number</option>
            <option value="amount">Holding amount</option>
            <option value="bank">Bank name</option>
            <option value="bankName">Account Holder</option>
            <option value="bankNumber">Account number</option>
          </Select>
          <Input
            name="searchValue"
            value={searchValue}
            onChange={onChange}
            type="text"
            placeholder="입력하세요"
            className="search"
          />
          <Input
            name="date"
            value={date}
            onChange={onChange}
            type="date"
            placeholder="날짜"
            className="textdate"
          />
          <Button type="submit">
            <img src={SearchIcon} alt="search" />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>ID</th>
            <th>Nick name</th>
            <th>Phone number</th>
            <th>Holding amount</th>
            <th>Sign up date</th>
            <th>Bank name</th>
            <th>Account Holder</th>
            <th>Account number</th>
            <th>deposit</th>
            <th>withdraw</th>
          </tr>
        </thead>
        <tbody>
          {userList.map((data, idx) => (
            <UserItem key={idx} data={data} onActiveToggle={onActiveToggle} />
          ))}
        </tbody>
      </Table>
    </>
  );
};

export default User;
