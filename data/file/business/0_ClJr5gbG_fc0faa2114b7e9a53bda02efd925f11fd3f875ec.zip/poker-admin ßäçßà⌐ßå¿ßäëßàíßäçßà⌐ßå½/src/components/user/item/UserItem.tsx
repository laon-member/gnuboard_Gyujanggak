import React from "react";

import { UserType } from "stores/user/types";
import TableRowWrapper from "components/common/TableRowWrapper";
import comma from "lib/comma";

type Props = {
  data: UserType;
  onActiveToggle: (id: number) => void;
};
const UserItem = ({ data, onActiveToggle }: Props) => {
  console.dir(data);
  return (
    <TableRowWrapper>
      <td>{data.id}</td>
      <td>{data.userName}</td>
      <td>{data.name}</td>
      <td>{data.phone}</td>
      <td>{comma(data.amount)}</td>
      <td>{data.created_at.toString().slice(0, 16).replace("T", " ")}</td>
      <td>{data.bank}</td>
      <td>{data.bankName}</td>
      <td>{data.bankNumber}</td>
      <td>{comma(data.deposit)}</td>
      <td>{comma(data.withdraw)}</td>
    </TableRowWrapper>
  );
};

export default UserItem;
