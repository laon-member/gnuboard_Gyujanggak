import qs from "query-string";

import client from "lib/client";
import {
  MemberSearch,
  TEditBlock,
  TEditMember,
  TGameLogSearch,
  TSMHistorySearch,
} from "stores/member/types";
import { TAgentLogin } from "stores/user/types";

class UserService {
  public LoginAPI(id: string, password: string) {
    return client.post(`/api/admin/users/login`, {
      username: id,
      password,
    });
  }

  public GetUserListAPI(memberSearch: MemberSearch) {
    return client.get(`/api/admin/users/me`, {
      params: {
        username: memberSearch.id,
        nickname: memberSearch.name,
        state_date: memberSearch.start_date,
        end_date: memberSearch.end_date,
        date_type: "REGISTER",
        page: memberSearch.page - 1,
      },
    });
  }

  public GetBlockUserListAPI(blockSearch: MemberSearch) {
    const { id, name, start_date, end_date, page } = blockSearch;
    return client.get(`/api/admin/users/block`, {
      params: {
        username: id,
        nickname: name,
        start_date,
        end_date,
        page: page - 1,
      },
    });
  }

  public GetFinanceListAPI(financeSearch: MemberSearch) {
    const { id, name, start_date, end_date, page } = financeSearch;
    return client.get("/api/admin/users/finance", {
      params: {
        username: id,
        nickname: name,
        start_date,
        end_date,
        page: page - 1,
      },
    });
  }

  public PutUpdateOneUserAPI(modifyMember: TEditMember) {
    const {
      id,
      bank,
      bankName,
      bankNumber,
      phone,
      password,
      check_password,
    } = modifyMember;
    return client.put(`/api/admin/users/update-user`, {
      id,
      bank,
      bankName,
      bankNumber,
      phone,
      password,
      check_password,
    });
  }

  public GetSearchUserListAPI(
    type?: string,
    inputValue?: string,
    dateType?: string
  ) {
    return client.get(`/api/admin/users/search`, {
      params: {
        type: type,
        inputValue: inputValue,
        dateType: dateType,
      },
    });
  }

  public GetOneUserAPI(id: number) {
    return client.get(`/api/admin/users/one-user`, {
      params: { id: id },
    });
  }

  public PatchUserAmount(modifyMemberAmount: TEditBlock) {
    const {
      amount,
      id,
      block,
      deblock_note,
      finance_note,
      option,
    } = modifyMemberAmount;
    return client.patch(`/api/admin/users/amount/${id}`, {
      amount: Number(amount),
      option,
      block,
      finance_note,
      deblock_note,
    });
  }

  public PutUserPointAPI(idx: number, point: number) {
    return client.put(
      `/api/users/user-update-point`,
      qs.stringify({ idx: idx, point: point })
    );
  }

  public PutUserLevelAPI(idx: number, type: number) {
    return client.put(
      `/api/users/user-update-type`,
      qs.stringify({ idx, type })
    );
  }

  public PutRecoAPI(idx: number, id: string, recoCode: string) {
    return client.put(
      `/api/users/reco-update`,
      qs.stringify({ idx, id, recoCode })
    );
  }

  public GetRecoNoneAPI() {
    return client.get(`/api/users/reco-none-user`);
  }

  public GetPremium() {
    return client.get(`/api/admin/select-premium`);
  }

  public PostPremium(idx: number, content: string) {
    return client.put(
      `/api/admin/update-premium`,
      qs.stringify({ idx, content })
    );
  }

  public GetRewardUser(idx: number) {
    return client.get(`/api/users/get-reword-user`, { params: { idx: idx } });
  }

  public playingInfo() {
    return client.get(`/api/admin/users/playing`);
  }

  public getGameLogPage(payload: TGameLogSearch) {
    return client.get(
      `/api/admin/users/game?username=${payload.username}&nickname=${payload.nickname
      }&round=${payload.round}&start_date=${payload.start_date}&end_date=${payload.end_date
      }&page=${payload.page - 1}`
    );
  }

  public getSMHistoryPage = (payload: TSMHistorySearch) => {
    const { sender, receiver, start_date, end_date, page } = payload;
    return client.get(
      `/api/admin/users/gold?sender=${sender}&receiver=${receiver}&start_date=${start_date}&end_date=${end_date}&page=${page - 1
      }`
    );
  };

  public agentLogin = (payload: TAgentLogin) => {
    return client.post(`/api/agent/login`, {
      username: payload.id,
      password: payload.password,
    });
  };
}
export default new UserService();
