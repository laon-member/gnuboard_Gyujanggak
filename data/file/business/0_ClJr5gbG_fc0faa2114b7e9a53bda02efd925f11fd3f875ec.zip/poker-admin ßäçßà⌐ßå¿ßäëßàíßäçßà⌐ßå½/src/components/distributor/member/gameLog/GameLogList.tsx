import React from "react";

function GameLogList() {
  return <h1>game c</h1>;
}

export default GameLogList;
