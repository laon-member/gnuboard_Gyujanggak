import WarningBox from "components/recharge/applyList/WarningBox";
import React from "react";
import { WarningBoxType } from "stores/recharge/types";

interface Props {
  content: string;
  type: WarningBoxType;
}

function WarningBoxContainer({ content, type }: Props) {
  return (
    <WarningBox
      content={content}
      onToggle={type.onToggle}
      onSubmit={type.onSubmit}
    />
  );
}

export default WarningBoxContainer;
