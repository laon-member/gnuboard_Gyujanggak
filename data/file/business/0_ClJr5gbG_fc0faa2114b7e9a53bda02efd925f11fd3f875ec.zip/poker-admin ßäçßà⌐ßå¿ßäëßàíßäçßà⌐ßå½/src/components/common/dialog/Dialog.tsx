import React from "react";
import styled from "styled-components";

type DialogProps = {
  title: string;
  children: any;
};

const Dialog = ({ title, children }: DialogProps) => {
  return (
    <DarkBackground>
      <DialogBlock>
        <h3>{title}</h3>
        {children}
      </DialogBlock>
    </DarkBackground>
  );
};

const DarkBackground = styled.div`
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.5);
`;

const DialogBlock = styled.div`
  width: 800px;
  background: white;
  border-radius: 2px;
  border-radius: 10px;
  h3 {
    border-radius: 10px 10px 0 0;
    background-color: #3F3F3F;
    color: #fff;
    padding: 1rem 0;
    text-align: center;
    font-size: 1.5rem;
    border-bottom: 2px solid #ddd;
  }
`;

export default Dialog;
