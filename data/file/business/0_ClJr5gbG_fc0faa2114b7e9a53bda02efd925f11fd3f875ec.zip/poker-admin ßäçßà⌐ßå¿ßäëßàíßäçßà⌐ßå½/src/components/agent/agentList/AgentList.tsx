import NoDataBox from "components/common/NoDataBox";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import { OverFlowWrapper } from "components/member/memberlist/MemberList";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import React from "react";
import { FaPlus, FaSearch } from "react-icons/fa";
import {
  CreateBoxType,
  EditBoxType,
  TAgent,
  TAgentListPage,
  TAgentListPageForms,
  TAgentListPageSearch,
} from "stores/agent/types";
import { Button, Input } from "styles/atom";
import Agent from "./Agent";
import AgentBox from "./AgentBox";
import AgentEditBox from "./AgentEditBox";

interface Props {
  forms: TAgentListPageForms;
  agentListPage: TAgentListPage;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
  create: CreateBoxType;
  edit: EditBoxType;
  agent?: TAgent;
}

function AgentList({
  forms,
  agentListPage,
  onSearch,
  create,
  edit,
  agent,
}: Props) {
  const { search } = forms;
  const { onChange } = search;
  const {
    username,
    agent_code,
    start_date,
    end_date,
  } = search.inputs as TAgentListPageSearch;
  return (
    <>
      {create.toggle && <AgentBox create={create} createForm={forms.create} />}
      {edit.toggle && (
        <AgentEditBox edit={edit} editForm={forms.edit} agent={agent!} />
      )}
      <SearchWrapper>
        <Button onClick={create.onToggle}>
          Create <FaPlus />
        </Button>
        <SearchForm className="search" onSubmit={onSearch}>
          <Input
            placeholder="ID"
            name="username"
            value={username}
            onChange={onChange}
          />
          <Input
            placeholder="AgentCode"
            name="agent_code"
            value={agent_code}
            onChange={onChange}
          />
          <Input
            type="date"
            name="start_date"
            value={start_date}
            onChange={onChange}
            className="date"
          />
          <Input
            type="date"
            name="end_date"
            value={end_date}
            onChange={onChange}
            className="date"
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <OverFlowWrapper>
        <Table>
          <thead>
            <tr>
              <th>No.</th>
              <th>ID</th>
              <th>AgentCode</th>
              <th>Mobile</th>
              <th>BeneRate</th>
              <th>BankAccount</th>
              <th>BankName</th>
              <th>CardNumber</th>
              <th>RegisterTime</th>
              <th>MemberSum</th>
              <th>AgentAmount</th>
              <th>RemainAmount</th>
              <th>WithdrawSum</th>
              <th>Opt</th>
            </tr>
          </thead>
          <tbody>
            {agentListPage.paging.total_page
              ? agentListPage.list.map((agent, idx) => (
                  <Agent
                    key={agent.agent_id}
                    idx={idx}
                    paging={agentListPage.paging}
                    agent={agent}
                    edit={edit}
                  />
                ))
              : null}
          </tbody>
        </Table>
      </OverFlowWrapper>
      {agentListPage.paging.total_page ? (
        <PageNationContainer
          paging={agentListPage.paging}
          searchForm={forms.search}
          onSearch={onSearch}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
}

export default AgentList;
