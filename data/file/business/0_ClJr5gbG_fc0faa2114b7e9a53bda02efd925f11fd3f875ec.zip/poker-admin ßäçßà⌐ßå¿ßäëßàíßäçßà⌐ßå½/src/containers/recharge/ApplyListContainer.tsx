import { AxiosResponse } from "axios";
import ApplyList from "components/recharge/applyList/ApplyList";
import { CancleType } from "components/recharge/applyList/types";
import { useInputs } from "lib/hooks";
import { inject, observer } from "mobx-react";
import React, { useEffect, useState } from "react";
import RootStore from "stores";
import {
  TCancleRechRgeApply,
  TRechargeApply,
  TRechargeApplyPage,
  TRechargeForms,
  TSearchRechargeApply,
  WarningBoxType,
} from "stores/recharge/types";

interface Props {
  rechargeApplyPage: TRechargeApplyPage;
  getRechargeApplyPage: (payload: TSearchRechargeApply) => void;
  passRechargeApply: () => AxiosResponse;
  setApply: (payload: TRechargeApply) => void;
  cancleRechargeApply: (payload: TCancleRechRgeApply) => AxiosResponse;
  reserveApply: () => AxiosResponse;
  apply: TRechargeApply;
}

const ApplyListContainer = ({
  rechargeApplyPage,
  getRechargeApplyPage,
  passRechargeApply,
  setApply,
  cancleRechargeApply,
  reserveApply,
}: Props) => {
  const [okToggle, setOkToggle] = useState(false);
  const [reserveToggle, setReserveToggle] = useState(false);
  const [cancleToggle, setCancleToggle] = useState(false);
  const forms = {
    search: useInputs({
      username: "",
      phone: "",
      page: 1,
    } as TSearchRechargeApply),
    cancle: useInputs({
      id: 0,
      message: "",
    } as TCancleRechRgeApply),
  } as TRechargeForms;

  useEffect(() => {
    (async () => {
      await getRechargeApplyPage(forms.search.inputs);
    })();
  }, []);

  const onOkSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      await passRechargeApply();
    } catch (error) {
      return alert("There is a problem with the server");
    } finally {
      forms.search.init();
      getRechargeApplyPage(forms.search.inputs);
      setOkToggle(false);
    }
  };
  const ok: WarningBoxType = {
    toggle: okToggle,
    onToggle: (payload: TRechargeApply) => {
      if (!okToggle) setApply(payload);
      setOkToggle(!okToggle);
    },
    onSubmit: onOkSubmit,
  };

  const onReserveSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    try {
      await reserveApply();
    } catch (error) {
      return alert("There is a problem with the server");
    } finally {
      await getRechargeApplyPage(forms.search.inputs);
      setReserveToggle(false);
    }
  };
  const reserve: WarningBoxType = {
    toggle: reserveToggle,
    onToggle: (payload: TRechargeApply) => {
      setApply(payload);
      setReserveToggle(!reserveToggle);
    },
    onSubmit: onReserveSubmit,
  };

  const onCancleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    try {
      await cancleRechargeApply(forms.cancle.inputs);
    } catch (error) {
      alert("There is a problem with the server");
    } finally {
      forms.cancle.init();
      getRechargeApplyPage(forms.search.inputs);
      setCancleToggle(false);
    }
  };

  const cancle: CancleType = {
    toggle: cancleToggle,
    onToggle: (payload: TRechargeApply) => {
      if (!cancleToggle) setApply(payload);
      setCancleToggle(!cancleToggle);
    },
    onSubmit: onCancleSubmit,
  };

  const onSearch = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    await getRechargeApplyPage(forms.search.inputs);
  };

  return (
    <>
      <ApplyList
        ok={ok}
        reserve={reserve}
        cancle={cancle}
        rechargeApplyPage={rechargeApplyPage}
        onSearch={onSearch}
        forms={forms}
      />
    </>
  );
};

export default inject(({ rechargeStore }: RootStore) => ({
  rechargeApplyPage: rechargeStore.rechargeApplyPage,
  getRechargeApplyPage: rechargeStore.getRechargeApplyPage,
  passRechargeApply: rechargeStore.passRechargeApply,
  setApply: rechargeStore.setApply,
  cancleRechargeApply: rechargeStore.cancleRechargeApply,
  reserveApply: rechargeStore.reserveApply,
  apply: rechargeStore.apply,
}))(observer(ApplyListContainer));
