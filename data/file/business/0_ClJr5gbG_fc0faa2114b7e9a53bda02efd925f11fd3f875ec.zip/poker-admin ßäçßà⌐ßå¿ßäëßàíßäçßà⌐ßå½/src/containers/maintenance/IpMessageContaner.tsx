import React from "react";

const IpMessageContaner = () => {
  return (
    <>
      <h1>ipMessageContainer</h1>
    </>
  );
};

export default IpMessageContaner;
