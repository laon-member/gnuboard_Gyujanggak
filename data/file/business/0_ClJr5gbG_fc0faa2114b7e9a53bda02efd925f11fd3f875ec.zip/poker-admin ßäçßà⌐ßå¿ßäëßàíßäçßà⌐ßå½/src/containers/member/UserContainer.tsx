import React from "react";
import { inject, observer } from "mobx-react";

import User from "components/user/User";

import userStore from "stores/user";

interface Props {
  userStore: userStore;
}

@inject("userStore")
@observer
class UserContainer extends React.Component<Props> {
  private userStore = this.props.userStore as userStore;

  async componentDidMount() {
    // await this.userStore.GetUserList();
  }

  oneUser = async (id: number) => {
    await this.userStore.GetOneUser(id);
  };

  search = async (type: string, inputValue: string, dateType: string) => {
    if (type === null || type === "") type = "username";
    await this.userStore.GetSearchUserList(type, inputValue, dateType);
  };

  update = async () => {
    // await this.userStore.PutUpdateOneUser(
    //   id,
    //   bank,
    //   bankName,
    //   bankNumber,
    //   phone
    // );
  };

  onActiveToggle = async (id: number) => {
    await this.userStore.Active(id);
    // await console.log(this.userStore);
  };

  render() {
    return (
      <User
        //user 하나 만들어주고 , store 에서 get ,set 만들어주고
        user={this.userStore.User!}
        userList={this.userStore.UserList}
        search={this.search}
        oneUser={this.oneUser}
        update={this.update}
        onActiveToggle={this.onActiveToggle}
      />
    );
  }
}

export default UserContainer;
