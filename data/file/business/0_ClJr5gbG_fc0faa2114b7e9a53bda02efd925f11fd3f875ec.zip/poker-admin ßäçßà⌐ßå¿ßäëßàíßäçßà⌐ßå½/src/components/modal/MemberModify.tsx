import React, { useState, useEffect } from "react";
import styled from "styled-components";
import { UserType } from "stores/user/types";
interface Props extends UserType {
  update: (
    id: number,
    bank: string,
    bankName: string,
    bankNumber: string,
    phone: string
  ) => void;
  setModal: (e: boolean) => void;
}
function MemberModify({
  id,
  userName,
  name,
  bank,
  bankName,
  bankNumber,
  phone,
  update,
  setModal,
}: Props) {
  // const [username, setUsername] = useState('');
  //리액트를 사용하여 해당 돔에 직접 접근해야할때 useRef 를 사용할 수 있다

  const [state, setState] = useState({
    username: "",
    name: "",
    bank: "",
    bankname: "",
    banknumber: "",
    phone: "",
    password: "",
  });
  const updateModal = () => {
    setState(state);
    update(id, state.bank, state.bankname, state.banknumber, state.phone);
  };
  // const onChangePasswordChk = (e: any) => {
  //   //비밀번호를 입력할때마다 password 를 검증하는 함수
  //   setPasswordError(e.target.value !== firstPw);
  // };
  //검증로직
  //1.비밀번호와 비밀번호체크가 다를경우를 검증한다,
  useEffect(() => {
    setState({
      ...state,
      username: userName,
      name: name,
      bank: bank,
      bankname: bankName,
      banknumber: bankNumber,
      phone: phone,
    });
  }, [userName, name, bank, bankName, bankNumber, phone, state]);

  return (
    <Wrap>
      <div className="title">
        <h2>Edit하기</h2>
      </div>

      <div>
        <ul>
          <li>
            <p>ID</p>
            <p>
              <input
                type="text"
                placeholder="ID"
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  e.preventDefault();
                  setState({
                    ...state,
                    username: e.target.value,
                  });
                }}
                value={state.username || ""}
                readOnly
              />
            </p>
          </li>
          <li>
            <p>Nick name</p>
            <p>
              <input
                type="text"
                placeholder="길동이"
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  e.preventDefault();

                  setState({
                    ...state,
                    name: e.target.value,
                  });
                }}
                value={state.name || ""}
                readOnly
              />
            </p>
          </li>
          <li>
            <p>Bank name</p>
            <p>
              <input
                type="text"
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  e.preventDefault();
                  setState({
                    ...state,
                    bank: e.target.value,
                  });
                }}
                value={state.bank || ""}
              />
            </p>
          </li>
          <li>
            <p>Account Holder</p>
            <p>
              <input
                type="text"
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  e.preventDefault();
                  setState({
                    ...state,
                    bankname: e.target.value,
                  });
                }}
                value={state.bankname || ""}
              />
            </p>
          </li>
          <li>
            <p>Account number</p>
            <p>
              <input
                type="text"
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  e.preventDefault();
                  setState({
                    ...state,
                    banknumber: e.target.value,
                  });
                }}
                value={state.banknumber || ""}
              />
            </p>
          </li>
          <li>
            <p>Phone number</p>
            <p>
              <input
                type="text"
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  e.preventDefault();
                  setState({
                    ...state,
                    phone: e.target.value,
                  });
                }}
                value={state.phone || ""}
              />
            </p>
          </li>
          <li>
            <p>비밀번호</p>
            <p>
              <input type="text" />
            </p>
          </li>
          <li>
            <p>비밀번호 확인</p>
            <p>
              <input type="text" />
            </p>
          </li>
        </ul>
      </div>

      <div className="button" onClick={() => setModal(false)}>
        <button onClick={() => updateModal()}>저장</button>
        <button
          onClick={() => {
            setModal(false);
          }}
        >
          취소
        </button>
      </div>
    </Wrap>
  );
}

const Wrap = styled.div`
  width: 100%;
  height: 100%;

  & > .title {
    width: 100%;
    height: 68px;

    text-align: center;
    line-height: 68px;

    border-bottom: 1px solid #ddd;

    & > h2 {
      font-weight: normal;
      font-size: 18px;
      color: #333;
    }
  }

  & > div {
    width: 100%;

    & > ul {
      width: 90%;
      margin: 40px auto 40px;

      & > li {
        width: 100%;
        height: 60px;
        overflow: hidden;
        & > p {
          float: left;
        }
        & > p:nth-child(1) {
          width: 120px;
          margin-left: 60px;
          line-height: 60px;
          font-size: 14px;
          color: #333;
        }
        & > p:nth-child(2) {
          line-height: 60px;
          & > input {
            width: 260px;
            height: 30px;
            padding: 5px 12px;
            border: 1px solid #ccc;
            border-radius: 7px;
            font-size: 14px;
            color: #333;
          }
        }
      }
      & > li:nth-child(1) {
        & > p {
          & > input {
            background: #eee;
            ::placeholder {
              color: #999;
            }
          }
        }
      }
      & > li:nth-child(2) {
        & > p {
          & > input {
            background: #eee;
            ::placeholder {
              color: #999;
            }
          }
        }
      }
    }
  }
  & > .button {
    width: 100%;
    height: 82px;

    text-align: center;
    line-height: 70px;

    & > button :nth-child(1) {
      width: 195px;
      height: 40px;
      background: #007fdb;
      border: none;
      color: #fff;
    }
    & > button:nth-child(2) {
      width: 195px;
      height: 40px;
      background: #ddd;
      border: none;
      color: #333;
      margin-left: 20px;
    }
  }
`;
export default MemberModify;
