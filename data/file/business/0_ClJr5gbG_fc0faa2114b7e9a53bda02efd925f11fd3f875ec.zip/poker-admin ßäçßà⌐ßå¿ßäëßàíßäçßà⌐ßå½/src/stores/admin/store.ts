import { observable, computed, action, flow } from "mobx";
import RootStore from "stores";
import BaseStore from "stores/BaseStore";
import AdminService from "services/admin/AdminService";
import { AdminType, DepositAndWithdrawInfo } from "./types";
import { EditAdminType, NewAdminType } from "components/adminSet/AdminBox";

class AdminStore extends BaseStore {
  root: RootStore;

  constructor(root: RootStore) {
    super();
    this.root = root;
  }

  @observable
  private id: undefined | string = undefined;

  @observable
  private _adminList: AdminType[] = [];

  @observable
  private _activeAdminList: AdminType[] = [];

  @observable
  private _depoeitAndWithdrawInfo = {} as DepositAndWithdrawInfo;

  @observable
  appVersion = "";

  @computed
  get adminId() {
    return this.id;
  }

  @computed
  get GetAdminList() {
    return this._adminList;
  }

  @computed
  get GetActiveAdminList() {
    return this._adminList
      .filter((admin) => admin.active)
      .map((admin) => admin.id);
  }

  @computed
  get depoeitAndWithdrawInfo() {
    return this._depoeitAndWithdrawInfo;
  }

  @action
  public onActiveToggle(id: string) {
    this._adminList = this._adminList.map((admin) =>
      admin.id === id ? { ...admin, active: !admin.active } : admin
    );
  }

  SetAdminlist = flow(function* (this: AdminStore) {
    try {
      const res = yield AdminService.admins();
      this._adminList = res.data.data.admin;
    } catch (error) {
      throw error;
    }
  });

  createAccount = flow(function* (
    this: AdminStore,
    id: string,
    password: string
  ) {
    try {
      yield AdminService.createAccount(id, password);
    } catch (error) {
      throw error;
    }
  });

  editAccout = flow(function* (this: AdminStore, id: string, password: string) {
    try {
      yield AdminService.editAccout(id, password);
    } catch (error) {
      throw error;
    }
  });

  deleteAccount = flow(function* (this: AdminStore, id: number) {
    try {
      yield AdminService.deleteAccount(id);
    } catch (error) {
      throw error;
    }
  });

  @action
  depositAndWithdraw = async () => {
    const res = await AdminService.depositAndWithdraw();
    this._depoeitAndWithdrawInfo = res.data.data.user;
  };

  // 추가기능 정의
  @observable
  adminList: AdminType[] = [];

  @observable
  admin?: AdminType;

  @action
  getAdminList = async () => {
    try {
      const res = await AdminService.getAdminList();
      this.adminList = res.data.data.admin;
    } catch (error) {
      throw error;
    }
  };

  @action
  setAdmin = (id: string) => {
    this.admin = this.adminList.find((admin) => admin.id === id);
  };

  @action
  addAdmin = async (payload: NewAdminType) => {
    return await AdminService.addAdmin(payload);
  };

  @action
  pathAdmin = async (payload: EditAdminType) => {
    return await AdminService.patchAdmin(payload);
  };

  @action
  deleteAdmin = async (id: string) => {
    return await AdminService.deleteAdmin(id);
  };

  @action
  getAppVersion = async () => {
    try {
      const res = await AdminService.getAppVersion();
      if (res.data.result) {
        this.appVersion = res.data.data.version.version;
      } else {
        console.log(res.data.data);
        alert("There is a problem with the server");
      }
    } catch (error) {
      alert("There is a problem with the server");
    }
  };
}

export default AdminStore;
