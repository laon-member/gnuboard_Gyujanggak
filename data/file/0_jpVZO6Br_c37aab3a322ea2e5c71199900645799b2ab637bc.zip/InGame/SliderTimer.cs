﻿using DG.Tweening.Plugins.Options;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
public class SliderTimer : MonoBehaviour
{
    public Image Timer;

    public Image Second_Hand;
    private void OnEnable()
    {
        
    }

    public void StartBattingTimer()
    {
        Timer.fillAmount = 1.0f;
        Timer.color = Color.HSVToRGB(0.4f, 1.0f, 1.0f);
        Timer.DOColor(Color.yellow, 4.0f).OnComplete(() => Timer.DOColor(Color.red, 2.0f).OnComplete(() => Timer.DOColor(Color.red, 1.0f)));
        Timer.transform.DOScaleX(0.0f, 8.0f).SetEase(Ease.Unset);

        Second_Hand.transform.DORotate(new Vector3(0, 0, -360), 5.0f, RotateMode.FastBeyond360).SetEase(Ease.Unset);
    }

    public void StartCardTimer()
    {
        Timer.fillAmount = 1.0f;
        Timer.color = Color.HSVToRGB(0.4f, 1.0f, 1.0f);
        Timer.DOColor(Color.yellow, 6.0f).OnComplete(() => Timer.DOColor(Color.red, 4.0f).OnComplete(() => Timer.DOColor(Color.red, 1.0f)));
        Timer.transform.DOScaleX(0.0f, 14.0f).SetEase(Ease.Unset);

        Second_Hand.transform.DORotate(new Vector3(0, 0, -360), 10.0f, RotateMode.FastBeyond360).SetEase(Ease.Unset);
    }

    private void OnDisable()
    {
        Timer.DOKill();
        Timer.transform.DOKill();

        Second_Hand.transform.DOKill();
        Second_Hand.transform.localRotation = Quaternion.Euler(Vector3.zero);

        //Timer.fillAmount = 1.0f;
        Timer.transform.localScale = Vector3.one;
        Timer.color = Color.HSVToRGB(0.4f, 1.0f, 1.0f);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
