import React, { Component } from "react";
import AdminAccount from "components/admin/account/AdminAccount";
import { RouteComponentProps, withRouter, Redirect } from "react-router-dom";
import { inject, observer } from "mobx-react";
import AdminStore from "stores/admin";
import userStore from "stores/user";

interface Props extends RouteComponentProps {
  adminStore: AdminStore;
  useStore: userStore;
}

@inject("adminStore")
@inject("userStore")
@observer
class AdminAccountContainer extends Component<Props> {
  private adminStore = this.props.adminStore as AdminStore;
  private userStore = this.props.useStore as userStore;

  async componentDidMount() {
    await this.adminStore.SetAdminlist();
  }

  onCreateAccount = async (id: string, password: string) => {
    try {
      await this.adminStore.createAccount(id, password);
      this.props.history.go(0);
    } catch (error) {
      alert(`${id} already exists.`);
    }
  };

  onEditAccout = async (id: string, password: string) => {
    try {
      await this.adminStore.editAccout(id, password);
      alert("Success to edited");
      this.props.history.go(0);
    } catch (error) {
      alert("sorry, something is wrong");
    }
  };

  onDeleteAccount = async (id: number) => {
    try {
      await this.adminStore.deleteAccount(id);
      this.props.history.go(0);
    } catch (error) {}
  };

  render() {
    if (JSON.parse(localStorage.getItem("userInfo")!).role !== "SUPER_ADMIN") {
      alert("You don't have permission.");
      return <Redirect to="/member" />;
    }
    if (!this.adminStore.GetAdminList) return <h1>loading ...</h1>;
    return (
      <AdminAccount
        adminList={this.adminStore.GetAdminList}
        onCreateAccount={this.onCreateAccount}
        // adminId={this.userStore.admin}
        onEditAccout={this.onEditAccout}
        onDeleteAccount={this.onDeleteAccount}
      />
    );
  }
}

export default withRouter(AdminAccountContainer);
