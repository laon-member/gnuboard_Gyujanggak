import React from "react";
import { PolicyType } from "stores/jackpot/types";
import styled from "styled-components";

interface Props {
  policy: PolicyType;
  room: number;
}

function Policy({ policy, room }: Props) {
  return (
    <Wrap>
      <td>Lv.{room}</td>
      <td>{policy.consume.value}</td>
      <td>{policy.guarantee.value}</td>
    </Wrap>
  );
}

const Wrap = styled.tr`
  width: 100%;
  height: 50px;
`;

export default Policy;
