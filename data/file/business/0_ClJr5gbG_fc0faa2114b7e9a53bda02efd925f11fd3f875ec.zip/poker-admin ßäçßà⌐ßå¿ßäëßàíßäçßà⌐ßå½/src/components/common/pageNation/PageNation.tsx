import React from "react";
import { TWithdrawFormType } from "services/withdraw/types";
import { GMFormType, PagingType, PMFormTYpe } from "stores/message/types";
import styled from "styled-components";
import { Button, Input } from "styles/atom";

interface Props {
  onPageNation?: () => void;
  paging: PagingType;
  searchForm: PMFormTYpe | GMFormType | TWithdrawFormType;
  onSearch?: (e: React.FormEvent<HTMLFormElement>) => void;
}

function PageNation({
  paging,
  searchForm: { inputs, onChange },
  onSearch,
}: Props) {
  return (
    <PageNationContainer>
      <PageNationWrapper onSubmit={onSearch}>
        <Input
          type="number"
          value={inputs.page}
          name="page"
          onChange={onChange}
          className="current"
        />
        /<span>{paging.total_page}</span>
        <Button color="#fff" bgColor="#70c7bf" type="submit">
          GO
        </Button>
      </PageNationWrapper>
    </PageNationContainer>
  );
}

const PageNationContainer = styled.div`
  display: flex;
  justify-content: center;
`;

const PageNationWrapper = styled.form`
  display: flex;
  align-items: center;
  padding: 2rem;

  svg {
    cursor: pointer;
  }

  .current {
    width: 100px;
    margin: 0 1rem;
    text-align: center;
  }

  input,
  span {
    margin: 1rem;
  }

  input {
    width: 50px;
  }
`;

export default PageNation;
