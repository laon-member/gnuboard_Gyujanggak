export type AdminType = {
  id: string;
  username: string;
  role: string;
  created_at: string;
  updated_at: string;
  active?: boolean | undefined;
};

export type DepositAndWithdrawInfo = {
  holding_amount: number;
  deposit: number;
  withdraw: number;
};
