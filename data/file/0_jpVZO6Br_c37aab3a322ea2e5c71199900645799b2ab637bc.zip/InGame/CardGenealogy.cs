﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CardGenealogy : MonoBehaviour
{
    public enum GenealogyType { Triple, Straight, Pair, Basic, Default };

    // 카드 족보 관련
    public string[] Cards;
    [Space]
    public GenealogyType GeneType;
    public CardInfo.CARDPATTERN TopCardPattern;
    public int StraightLastNumber;
    public int TopCardNumber;
    public int SumCardNumber;
    public int PairNumber;
    public int TopPatternNumber;
    public int PairOtherNumber;

    public void SetGenealogy(string[] cardsFileName)
    {
        Cards = cardsFileName;

        // 카드 정보에 족보 세팅
        GeneType = CalculationCard.Instance.GetGenealogyType(cardsFileName);

        if (GeneType != GenealogyType.Straight)
        {
            TopCardNumber = CalculationCard.Instance.GetTopCardNumber();
        }

        if (GeneType != GenealogyType.Triple)
        {
            TopCardPattern = CalculationCard.Instance.GetTopCardPattern();
            TopPatternNumber = CalculationCard.Instance.GetTopPatternNumber();
        }
        
        if (GeneType == GenealogyType.Pair)
        {
            PairNumber = CalculationCard.Instance.GetPairNumber();
            PairOtherNumber = CalculationCard.Instance.GetPairOtherNumber(PairNumber);
        }
        else if (GeneType == GenealogyType.Basic)
        {
            SumCardNumber = CalculationCard.Instance.GetSumNumber();
        }
        else if(GeneType == GenealogyType.Straight)
        {
            StraightLastNumber = CalculationCard.Instance.GetStraightNums();
            TopCardNumber = CalculationCard.Instance.GetStraightTopCardNum();
        }
    }

    public void Clear()
    {
        GeneType = GenealogyType.Default;
        TopCardPattern = CardInfo.CARDPATTERN.Default;
        StraightLastNumber = 0;
        TopCardNumber = 0;
        SumCardNumber = 0;
        PairNumber = 0;
        TopPatternNumber = 0;
        PairOtherNumber = 0;
    }
}
