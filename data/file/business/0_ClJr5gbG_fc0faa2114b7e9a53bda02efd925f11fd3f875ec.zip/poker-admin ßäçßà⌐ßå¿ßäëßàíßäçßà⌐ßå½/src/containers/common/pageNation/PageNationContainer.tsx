import PageNation from "components/common/pageNation/PageNation";
import React from "react";
import { TWithdrawFormType } from "services/withdraw/types";
import { GMFormType, PagingType, PMFormTYpe } from "stores/message/types";

interface Props {
  onPageNation?: () => void;
  paging?: PagingType;
  searchForm?: PMFormTYpe | GMFormType | TWithdrawFormType;
  onSearch?: (e: React.FormEvent<HTMLFormElement>) => void;
}

function PageNationContainer({
  onPageNation,
  paging,
  searchForm,
  onSearch,
}: Props) {
  if (!searchForm?.inputs) return <div></div>;
  return (
    <PageNation
      onPageNation={onPageNation}
      paging={paging!}
      searchForm={searchForm!}
      onSearch={onSearch}
    />
  );
}

export default PageNationContainer;
