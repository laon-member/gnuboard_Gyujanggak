import { AxiosResponse } from "axios";
import { EditAdminType, NewAdminType } from "components/adminSet/AdminBox";
import AdminSetList from "components/adminSet/AdminSetList";
import { EditBoxType } from "components/member/memberlist/types";
import { inject, observer } from "mobx-react";
import React, { useEffect, useState } from "react";
import RootStore from "stores";
import { AdminType } from "stores/admin/types";
import { WarningBoxType } from "stores/recharge/types";

interface Props {
  getAdminList: () => void;
  adminList: AdminType[];
  addAdmin: (payload: NewAdminType) => AxiosResponse<any>;
  admin: AdminType;
  setAdmin: (id: string) => void;
  patchAdmin: (payload: EditAdminType) => AxiosResponse<any>;
  deleteAdmin: (id: string) => AxiosResponse<any>;
}

function AdminSetListContainer({
  getAdminList,
  adminList,
  addAdmin,
  admin,
  setAdmin,
  patchAdmin,
  deleteAdmin,
}: Props) {
  const [newToggle, setNewToggle] = useState(false);
  const [editToggle, setEditToggle] = useState(false);
  const [deleteToggle, setDeleteToggle] = useState(false);

  useEffect(() => {
    getAdminList();
  }, [getAdminList, newToggle, editToggle, deleteToggle]);

  const onNewSubmit = async (payload: NewAdminType) => {
    try {
      const res: AxiosResponse<any> = await addAdmin(payload);
      if (res.status === 200) {
        alert("successed to create admin");
        return setNewToggle(false);
      }
    } catch (error) {
      alert("There is a problem with the server or the user already exists.");
    }
  };
  const _new: EditBoxType = {
    toggle: newToggle,
    onToggle: () => setNewToggle(!newToggle),
    onSubmit: onNewSubmit,
  };

  const onEditSubmit = async (payload: EditAdminType) => {
    try {
      const res = await patchAdmin(payload);
      if (res.status === 200) {
        alert("successed to edit admin password");
        return setEditToggle(false);
      }
    } catch (error) {
      alert("There is a problem with the server");
    }
  };
  const edit: EditBoxType = {
    toggle: editToggle,
    onToggle: () => setEditToggle(!editToggle),
    onSubmit: onEditSubmit,
  };

  const onDeleteSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      const res = await deleteAdmin(admin.id);
      if (res.status === 200) {
        alert("successed to delete admin account");
        return setDeleteToggle(false);
      }
    } catch (error) {
      alert("There is a problem with the server");
      throw error;
    }
  };
  const _delete: WarningBoxType = {
    toggle: deleteToggle,
    onToggle: () => setDeleteToggle(!deleteToggle),
    onSubmit: onDeleteSubmit,
  };

  return (
    <AdminSetList
      _new={_new}
      edit={edit}
      _delete={_delete}
      adminList={adminList}
      admin={admin!}
      setAdmin={setAdmin}
    />
  );
}

export default inject(({ adminStore }: RootStore) => ({
  getAdminList: adminStore.getAdminList,
  adminList: adminStore.adminList,
  addAdmin: adminStore.addAdmin,
  admin: adminStore.admin,
  setAdmin: adminStore.setAdmin,
  patchAdmin: adminStore.pathAdmin,
  deleteAdmin: adminStore.deleteAdmin,
}))(observer(AdminSetListContainer));
