﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CardComparer : IComparer
{
    int keyIndex;
    // 생성자
    // 2차원 배열에서 비교를 수행할 열의 인덱스를 sortKey로 받아와 ketIndex에 저장.
    public CardComparer(int sortKey)
    {
        keyIndex = sortKey;
    }
    // IComparer 를 상속하는 클래스는 Compare 메소드를 정의해야 한다.
    // keyindex에 해당하는 열을 뽑아 그 기준으로 비교 연산을 수행.
    public int Compare(object x, object y)
    {
        IComparable cX = (IComparable)((Array)x).GetValue(keyIndex);
        IComparable cY = (IComparable)((Array)y).GetValue(keyIndex);

        return cX.CompareTo(cY);
    }
}
