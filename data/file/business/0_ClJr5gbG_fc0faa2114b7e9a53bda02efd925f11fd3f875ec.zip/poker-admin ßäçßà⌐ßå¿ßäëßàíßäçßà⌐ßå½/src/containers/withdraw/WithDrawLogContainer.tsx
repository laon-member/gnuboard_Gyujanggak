import WithdrawLogList from "components/withdraw/withdrawLog/WithdrawLogList";
import { useInputs } from "lib/hooks";
import { inject, observer } from "mobx-react";
import React, { useEffect } from "react";
import { SearchWithdrawLogType } from "services/withdraw/types";
import RootStore from "stores";
import { TWithdrawLogForm, TWithdrawLogPage } from "stores/withdraw/types";

interface Props {
  getWithdrawLogListPage: (payload: SearchWithdrawLogType) => void;
  withdrawLogListPage: TWithdrawLogPage;
}

const WithDrawLogContainer = ({
  getWithdrawLogListPage,
  withdrawLogListPage,
}: Props) => {
  const forms = {
    search: useInputs({
      username: "",
      phone: "",
      orderNumber: "",
      page: 1,
    } as SearchWithdrawLogType),
  } as TWithdrawLogForm;

  useEffect(() => {
    (async () => {
      await getWithdrawLogListPage(forms.search.inputs);
    })();
  }, []);

  const onSearch = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    await getWithdrawLogListPage(forms.search.inputs);
  };

  return (
    <WithdrawLogList
      withdrawLogListPage={withdrawLogListPage}
      onSearch={onSearch}
      forms={forms}
    />
  );
};

export default inject(({ withdrawStore }: RootStore) => ({
  getWithdrawLogListPage: withdrawStore.getWithdrawLogListPage,
  withdrawLogListPage: withdrawStore.withdrawLogListPage,
}))(observer(WithDrawLogContainer));
