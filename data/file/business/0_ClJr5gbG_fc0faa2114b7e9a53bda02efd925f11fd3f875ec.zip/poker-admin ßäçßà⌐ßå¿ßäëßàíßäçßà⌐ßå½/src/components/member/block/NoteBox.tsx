import { DialogContainer } from "containers/common/dialog";
import React from "react";

interface Props {
  content?: string;
  onToggle: () => void;
  note?: boolean;
}

function NoteBox({ onToggle, content }: Props) {
  return (
    <DialogContainer title="Note Box" onToggle={onToggle} note>
      <p>{content}</p>
    </DialogContainer>
  );
}

export default NoteBox;
