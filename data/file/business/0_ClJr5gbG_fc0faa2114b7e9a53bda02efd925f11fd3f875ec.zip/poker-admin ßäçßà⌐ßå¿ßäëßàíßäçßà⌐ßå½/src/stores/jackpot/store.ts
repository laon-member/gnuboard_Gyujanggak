import BaseStore from "stores/BaseStore";
import RootStore from "stores";
import { action, observable } from "mobx";
import {
  JackpotInfo,
  JackpotPage,
  JackpotType,
  PolicyType,
  SearchJackpotType,
  TPutPolicy,
} from "./types";
import JackpotService from "services/jackpot/JackpotService";
import { PagingType } from "stores/message/types";

class JackpotStore extends BaseStore {
  root: RootStore;

  constructor(root: RootStore) {
    super();
    this.root = root;
  }

  @observable
  jackpotInfo: JackpotInfo = {} as JackpotInfo;

  @observable
  policyInfo: PolicyType[] = [];

  @observable
  jackpotPage: JackpotPage = {
    paging: {} as PagingType,
    jackpot: [] as JackpotType[],
  } as JackpotPage;

  @action
  getJackpotInfo = async () => {
    try {
      const res = await JackpotService.getJackpotInfo();
      this.jackpotInfo = res.data.data.jackpot;
    } catch (error) {
      alert("There is a problem with the server");
      throw error;
    }
  };

  @action
  getPolicyInfo = async () => {
    try {
      const res = await JackpotService.getPolicyInfo();
      this.policyInfo = res.data.data.policy;
    } catch (error) {
      alert("There is a problem with the server");
      throw error;
    }
  };

  @action
  getJackpotList = async (payload: SearchJackpotType) => {
    try {
      const res = await JackpotService.getJackpotList(payload);
      if (res.data.result === 1) {
        this.jackpotPage = res.data.data;
      }
    } catch (error) {
      alert("There is a problem with the server");
      throw error;
    }
  };

  @action
  putPolicy = async (payload: TPutPolicy) => {
    return await JackpotService.putPolicy(payload);
  };
}

export default JackpotStore;
