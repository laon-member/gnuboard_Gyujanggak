import { PagingType } from "stores/message/types";
import { UseInput } from "stores/notice/types";

export type TAgent = {
  agent_id: number;
  username: string;
  agent_code: string;
  mobile: string;
  bene_rate: number;
  bank_account: string;
  bank_name: string;
  card_number: string;
  created_at: string;
  member_sum: number;
  agent_amount: number;
  remain_amount: number;
  withdraw_sum: number;
};

export type TAgentListPage = {
  paging: PagingType;
  list: TAgent[];
};

export type TAgentListPageSearch = {
  username: string;
  agent_code: string;
  start_date: string;
  end_date: string;
  page: number;
};

export type TAgentCreate = {
  username: string;
  mobile: string;
  password: string;
  passwordCheck: string;
  agent_code: string;
  bank_account: string;
  bank_name: string;
  card_number: string;
  bene_rate: number | string;
  add_money: number | string;
};

export type TAgentListPageForms = {
  search: UseInput;
  create: UseInput;
  edit: UseInput;
};

export type CreateBoxType = {
  toggle: boolean;
  onToggle: () => void;
  onSubmit: (e: React.FormEvent<HTMLFormElement>) => void;
};

export type EditBoxType = {
  toggle: boolean;
  onToggle: (payload?: TAgent) => void;
  onSubmit: (e: React.FormEvent<HTMLFormElement>, payload: TAgent) => void;
};

export interface TAgentEdit extends TAgent {
  password: string;
  passwordCheck: string;
  operation: string;
  add_money: number | string;
}

export interface TAgentMoneyHistorySearch {
  username: string;
  agent_code: string;
  start_date: string;
  end_date: string;
  page: number;
}

export interface TAgentMoneyHistory {
  admin_account: string;
  agent_account: string;
  agent_code: string;
  amount: string;
  created_at: string;
}

export interface TAgentMoneyHistoryPage {
  paging: PagingType;
  list: TAgentMoneyHistory[];
}

export interface TAgentMoneyHistoryForms {
  search: UseInput;
}

export interface TAgentInfo {
  agent_id: number;
  username: string;
  mobile: string;
  agent_code: string;
  bank_account: string;
  bank_name: string;
  card_number: string;
  bene_rate: number;
  amount: number;
  created_at: string;
  role: string;
  member_sum: number;
  ramain_amount: number;
  withdraw_sum?: number;
}
