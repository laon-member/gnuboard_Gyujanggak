import React, { useCallback } from "react";
import styled from "styled-components";
import { createPortal } from "react-dom";
import CloseImg from "assets/icons/close.png";

interface Props {
  onClose?: () => void;
}

const Modal: React.FC<Props> = ({ onClose, children }) => {
  const ROOT = document.getElementById("modals");

  const onClickClose = useCallback(
    (e: React.MouseEvent<HTMLButtonElement>) => {
      e.preventDefault();

      if (!onClose) return;

      onClose();
    },
    [onClose]
  );

  return createPortal(
    <Wrap>
      <Content>
        <Foot>
          <Close onClick={onClickClose}>
            <img src={CloseImg} alt="x" />
          </Close>
        </Foot>
        {children}
      </Content>
    </Wrap>,
    ROOT!
  );
};

const Wrap = styled.div`
  width: 100vw;
  height: 100vh;
  position: fixed;
  left: 0;
  top: 0;
  background: rgba(0, 0, 0, 0.9);
`;

const Content = styled.div`
  width: 550px;
  height: 710px;

  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);

  overflow: auto;
  background: #fff;
`;

const Foot = styled.div`
  height: 60px + 20px;
  padding: 10px;
  position: absolute;
  right: 14px;
  top: 9px;
`;

const Close = styled.button`
  border: none;
  background: transparent;
  & > img {
    width: 30px;
    height: 30px;
  }
`;

export default Modal;
