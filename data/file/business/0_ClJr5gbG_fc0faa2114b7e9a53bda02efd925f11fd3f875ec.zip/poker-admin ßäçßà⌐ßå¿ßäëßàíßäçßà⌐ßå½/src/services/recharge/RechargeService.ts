import client from "lib/client";
import {
  TCancleRechRgeApply,
  TNewBankSetForm,
  TRechargeApply,
  TRechargeBankSet,
  TSearchRechargeApply,
  TSearchRechargeBankSet,
  TSearchRechargeLog,
} from "stores/recharge/types";

class RechargeService {
  public getRechargeApplyPage = async (payload: TSearchRechargeApply) => {
    return await client.get(
      `/api/admin/deposit/applyinfo?username=${payload.username}&phone=${payload.phone}&page=${payload.page - 1}`
    );
  };

  public passRechargeApply = async (payload: TRechargeApply) => {
    return await client.put(`/api/admin/deposit/approval`, {
      id: payload.id,
    });
  };

  public cancleRechargeApply = async (payload: TCancleRechRgeApply) => {
    return await client.put(`/api/admin/deposit/reject`, {
      id: payload.id,
      message: payload,
    });
  };

  public getRechargeLogPage = async (payload: TSearchRechargeLog) => {
    return await client.get(
      `/api/admin/deposit/rechargeinfo?username=${payload.username}&phone=${payload.phone}&page=${payload.page - 1}`
    );
  };

  public getBankSetPage = async (payload: TSearchRechargeBankSet) => {
    return await client.get(
      `/api/admin/deposit/my-account?bank_name=${payload.bank_name}&bank_account=${payload.bank_account}&bank_number=${payload.bank_number}&page=${payload.page - 1}`
    );
  };

  public createBankSet = async (payload: TNewBankSetForm) => {
    return await client.post("/api/admin/deposit/new-account", {
      bank_name: payload.bank_name,
      bank_account: payload.bank_account,
      bank_number: payload.bank_number,
      is_active: payload.is_active,
    });
  };

  public modifyBankSet = async (payload: TRechargeBankSet) => {
    return await client.put(`/api/admin/deposit/my-account/${payload.id}`, {
      bank_name: payload.bank_name,
      bank_account: payload.bank_account,
      bank_number: payload.bank_number,
      is_active: payload.is_active,
    });
  };

  public reserveApply = async (payload: TRechargeApply) => {
    return await client.patch(`/api/admin/deposit/${payload.id}/reserve`);
  };
}

export default new RechargeService();
