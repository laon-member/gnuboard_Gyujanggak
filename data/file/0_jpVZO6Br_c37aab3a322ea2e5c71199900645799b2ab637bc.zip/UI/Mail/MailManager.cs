﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using LitJson;
using Leguar.TotalJSON;

using Photon.Realtime;
using Photon.Pun;

public class MailManager : MonoBehaviourPunCallbacks
{
    public List<MailContent> Contents = new List<MailContent>();

    public Image ProfileImg;

    public Text NewMailTxt;
    public Text TotalMailTxt;

    public MailContent PFMailObj;
    public Transform MailParent;

    public MailDetail Detail;

    DataBaseManager DBMgr;

    // Start is called before the first frame update
    void Start()
    {
        if(DBMgr == null)
        {
            DBMgr = FindObjectOfType<DataBaseManager>();
        }

        CreateMail();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void CreateMail()
    {
        ProfileImg.sprite = Resources.Load<Sprite>("Sprites/Profiles/" + LocalPlayerInfo.Instance.ProfileImgFilePath);

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetMailList, "", "Post", PlayerPrefs.GetString("Token"), (result) => {
            
            JsonData resp = JsonMapper.ToObject(result);

            if((int)resp["result"] == 1)
            {
                int totalMailCount = resp["data"]["mail"].Count;

                TotalMailTxt.text = totalMailCount.ToString();

                int newCount = 0;

                for (int i = 0; i < totalMailCount; i++)
                {
                    bool isNew = false;

                    MailContent mail = GameObject.Instantiate(PFMailObj, MailParent);

                    // DB에서 정보 받아서 메일 생성
                    string[] info = new string[4];
                    info[0] = (string)resp["data"]["mail"][i]["title"];
                    info[1] = "Admin";

                    string day_buffer = (string)resp["data"]["mail"][i]["created_at"];
                    string day = "";

                    for (int j = 0; j < 10; j++)
                    {
                        day += day_buffer[j];
                    }

                    info[2] = day;

                    string time_buffer = (string)resp["data"]["mail"][i]["created_at"];
                    string time = "";

                    for (int ii = 11; ii < 16; ii++)
                    {
                        time += time_buffer[ii];
                    }

                    info[3] = time;

                    if((int)resp["data"]["mail"][i]["is_read"] == 0)
                    {
                        isNew = true;
                    }
                    else
                    {
                        isNew = false;
                    }
                    
                    if (isNew)
                    {
                        newCount++;
                    }

                    mail.SetMailInfo(info, isNew, (int)resp["data"]["mail"][i]["mail_id"]);
                    mail.SetObj_Detail(Detail, this, (string)resp["data"]["mail"][i]["content"]);
                    Contents.Add(mail);
                }

                NewMailTxt.text = newCount.ToString();
            }
        }));
    }

    public void ReadMail(int mail_id)
    {
        JSON jsonData = new JSON();
        jsonData.Add("mail_id", mail_id.ToString());

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.ReadMail, jsonData.CreateString(), "Patch", PlayerPrefs.GetString("Token"), (result) => {

            JsonData resp = JsonMapper.ToObject(result);

            Debug.LogFormat("<color=red>{0}</color>", (int)resp["result"]);
        }));
    }

    public void DeleteMail(int mail_id)
    {
        JSON jsonData = new JSON();
        jsonData.Add("mail_id", mail_id.ToString());

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.DeleteMail, jsonData.CreateString(), "Delete", PlayerPrefs.GetString("Token"), (result) => {

            JsonData resp = JsonMapper.ToObject(result);

            Debug.LogFormat("<color=red>{0}</color>", (int)resp["result"]);
        }));
    }

    public void RemoveContentList(GameObject content)
    {
        for (int i = 0; i < Contents.Count; i++)
        {
            if(Contents[i].gameObject == content)
            {
                Contents.RemoveAt(i);
                TotalMailTxt.text = (int.Parse(TotalMailTxt.text) - 1).ToString();
                break;
            }
        }
    }

    public void OnClickBtn_DeleteAll()
    {
        for (int i = 0; i < Contents.Count; i++)
        {
            Destroy(Contents[i].gameObject);
        }

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.DeleteAllMail, "", "Delete", PlayerPrefs.GetString("Token"), (result) => {

            JsonData resp = JsonMapper.ToObject(result);

            Debug.LogFormat("<color=red>{0}</color>", (int)resp["result"]);
        }));

        NewMailTxt.text = "0";
        TotalMailTxt.text = "0";

        Contents.Clear();
    }

    

    public void OnClickBtn_Leave()
    {
        SceneManager.LoadScene("Lobby");
    }

    public override void OnDisconnected(DisconnectCause cause)
    {
        SceneManager.LoadScene("LogIn");
    }

    public void SumNewMailNumber(int num)
    {
        NewMailTxt.text = (int.Parse(NewMailTxt.text) - num).ToString();
    }
    public void OnClickBtn_ClickSound()
    {
        FindObjectOfType<SoundManager>().StartSound_Effect(SoundFileList.EFFECT.btn_click);
    }
}
