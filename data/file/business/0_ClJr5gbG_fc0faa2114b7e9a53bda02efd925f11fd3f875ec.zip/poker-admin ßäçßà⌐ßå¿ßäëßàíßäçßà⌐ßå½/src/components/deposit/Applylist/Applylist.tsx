/* eslint-disable no-restricted-globals */
import React from "react";
import SearchIcon from "assets/icons/search.png";
import { DepositType } from "stores/deposit/types";
import ApplistItem from "../Applylist/item/ApplistItem";
import useInputs from "lib/hooks/useInputs";
import Table from "components/common/Table";
import { Select, Input, Button } from "styles/atom";
import { SearchWrapper, SearchForm } from "../Bankset/Bankset";

interface Props {
  deposit: DepositType;
  depositList: DepositType[];
  updateApproval: (id: number) => void;
  updateReject: (id: number) => void;
  search: (type: string, inputValue: string, dateType: string) => void;
  onActiveToggle: (id: number) => void;
}

function Applylist({
  deposit,
  depositList,
  updateApproval,
  updateReject,
  search,
  onActiveToggle,
}: Props) {
  const { inputs, onChange } = useInputs({
    searchType: "",
    searchValue: "",
    date: "",
  });
  const { searchType, searchValue, date } = inputs;

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    search(searchType, searchValue, date);
  };

  return (
    <>
      <SearchWrapper>
        <SearchForm onSubmit={onSubmit} className="selectbox">
          <Input
            type="text"
            name="searchValue"
            value={searchValue}
            onChange={onChange}
            placeholder="ID"
            className="searchtext"
          />
          <Input
            type="date"
            name="date"
            value={date}
            onChange={onChange}
            placeholder="날짜"
            className="textdate"
          />
          <Button type="submit">
            <img src={SearchIcon} alt="검색" />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>ID</th>
            <th>Phone number</th>
            <th>Bank name</th>
            <th>Account Holder</th>
            <th>Account number</th>
            <th>Charge amount</th>
            <th>Application time</th>
            <th>Opt</th>
          </tr>
        </thead>
        <tbody>
          {depositList.map((data, idx) => (
            <ApplistItem
              key={idx}
              data={data}
              {...deposit}
              updateApproval={updateApproval}
              updateReject={updateReject}
              onActiveToggle={onActiveToggle}
            />
          ))}
        </tbody>
      </Table>
    </>
  );
}

export default Applylist;
