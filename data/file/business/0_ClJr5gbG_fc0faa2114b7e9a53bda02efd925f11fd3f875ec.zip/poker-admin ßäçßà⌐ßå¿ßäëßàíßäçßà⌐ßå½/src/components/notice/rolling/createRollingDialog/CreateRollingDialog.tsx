import React from "react";
import { DialogContainer } from "containers/common/dialog";
import { useInputs } from "lib/hooks";
import { InputWrapper } from "components/deposit/Bankset/Bankset";
import { TextArea } from "styles/atom/TextArea";

interface Props {
  title: string;
  onToggle: () => void;
  onRemove?: any;
  onCreateRolling: (adminName: string, content: string) => void;
  activeList: any;
}

const CreateRollingDialog = ({ title, onToggle, onCreateRolling }: Props) => {
  const { inputs, onChange, init } = useInputs({
    adminName: "admin",
    content: "",
  });
  const { adminName, content } = inputs;

  const onSave = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onCreateRolling(adminName, content);
    init();
  };
  return (
    <DialogContainer
      title={title}
      confirmText="생성"
      onToggle={onToggle}
      onSubmit={onSave}
    >
      <InputWrapper>
        <label>CONTENT</label>
        <TextArea name="content" value={content} onChange={onChange} />
      </InputWrapper>
    </DialogContainer>
  );
};

export default CreateRollingDialog;
