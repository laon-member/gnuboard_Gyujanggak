import React from "react";
import styled from "styled-components";

const JackpotBox = () => {
  return (
    <Wrap>
      <div className="title">
        <h2>Jackpot Limit Box</h2>
      </div>

      <div>
        <ul>
          <li>
            <p>Limit Value</p>
            <p>
              <input type="text" />
            </p>
          </li>
          <li>
            <p>Lv.1 Consume</p>
            <p>
              <input type="text" placeholder="80,000" />
            </p>
          </li>
          <li>
            <p>Lv.1 Guarantee</p>
            <p>
              <input type="text" placeholder="80,000" />
            </p>
          </li>
          <li>
            <p>Lv.2 Consume</p>
            <p>
              <input type="text" placeholder="80,000" />
            </p>
          </li>
          <li>
            <p>Lv.2 Guarantee</p>
            <p>
              <input type="text" placeholder="80,000" />
            </p>
          </li>
          <li>
            <p>Lv.3 Consume</p>
            <p>
              <input type="text" placeholder="80,000" />
            </p>
          </li>
          <li>
            {" "}
            <p>Lv.3 Guarantee</p>
            <p>
              <input type="text" placeholder="80,000" />
            </p>
          </li>
          <li>
            {" "}
            <p>Lv.4 Consume</p>
            <p>
              <input type="text" placeholder="80,000" />
            </p>
          </li>
          <li>
            {" "}
            <p>Lv.4 Guarantee</p>
            <p>
              <input type="text" placeholder="80,000" />
            </p>
          </li>
          <li>
            {" "}
            <p>Lv.5 Consume</p>
            <p>
              <input type="text" placeholder="80,000" />
            </p>
          </li>
          <li>
            {" "}
            <p>Lv.5 Guarantee</p>
            <p>
              <input type="text" placeholder="80,000" />
            </p>
          </li>
          <li>
            {" "}
            <p>Lv.6 Consume</p>
            <p>
              <input type="text" placeholder="80,000" />
            </p>
          </li>
          <li>
            {" "}
            <p>Lv.6 Guarantee</p>
            <p>
              <input type="text" placeholder="80,000" />
            </p>
          </li>
        </ul>
      </div>

      <div className="button">
        <button>저장</button>
        <button>취소</button>
      </div>
    </Wrap>
  );
};
const Wrap = styled.div`
  width: 550px;
  height: 710px;
  overflow: auto;

  background: #fff;

  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);

  & > .title {
    width: 100%;
    height: 68px;

    text-align: center;
    line-height: 68px;

    border-bottom: 1px solid #ddd;

    & > h2 {
      font-weight: normal;
      font-size: 18px;
      color: #333;
    }
  }

  & > div {
    width: 100%;

    & > ul {
      width: 90%;
      margin: 40px auto 40px;

      & > li {
        width: 100%;
        height: 60px;
        overflow: hidden;
        & > p {
          float: left;
        }
        & > p:nth-child(1) {
          width: 120px;
          margin-left: 60px;
          line-height: 60px;
          font-size: 14px;
          color: #333;
        }
        & > p:nth-child(2) {
          line-height: 60px;
          & > input {
            width: 260px;
            height: 30px;
            padding: 5px 12px;
            border: 1px solid #ccc;
            border-radius: 7px;
            font-size: 14px;
            color: #333;
            ::placeholder {
              color: #ccc;
            }
          }
        }
      }
    }
  }
  & > .button {
    width: 100%;
    height: 82px;

    text-align: center;
    line-height: 70px;

    & > button:nth-child(1) {
      width: 195px;
      height: 40px;
      background: #007fdb;
      border: none;
      color: #fff;
    }
    & > button:nth-child(2) {
      width: 195px;
      height: 40px;
      background: #ddd;
      border: none;
      color: #333;
      margin-left: 20px;
    }
  }
`;
export default JackpotBox;
