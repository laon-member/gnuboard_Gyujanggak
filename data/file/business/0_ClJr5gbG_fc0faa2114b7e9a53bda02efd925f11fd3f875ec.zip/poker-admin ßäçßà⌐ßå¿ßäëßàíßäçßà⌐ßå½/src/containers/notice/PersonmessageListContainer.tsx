import React from "react";
import { inject, observer } from "mobx-react";

import NoticeStore from "stores/notice";
import Porsonmessage from "components/notice/Porsonmessage";
import { withRouter, RouteComponentProps } from "react-router-dom";

interface Props extends RouteComponentProps {
  noticeStore?: NoticeStore;
}

@inject("noticeStore")
@observer
class PersonmessageContainer extends React.Component<Props> {
  private NoticeStore = this.props.noticeStore! as NoticeStore;

  async componentDidMount() {
    await this.NoticeStore.GetPeronmsgList();
  }

  onSearch = async (nickname?: string, date?: string) => {
    await this.NoticeStore.GetPeronmsgList(nickname, date);
  };

  onActiveToggle = async (id: number) => {
    await this.NoticeStore.activeToggle(id);
  };

  onRemove = async (list: number[]) => {
    try {
      await this.NoticeStore.RemovePersonList(list);
      return this.props.history.go(0);
    } catch (error) {
      throw error;
    }
  };

  render() {
    return (
      <Porsonmessage
        noticeList={this.NoticeStore.NoticeList}
        onActiveToggle={this.onActiveToggle}
        activeList={this.NoticeStore.activeUsers}
        onRemove={this.onRemove}
        onSearch={this.onSearch}
      />
    );
  }
}

export default withRouter(PersonmessageContainer);
