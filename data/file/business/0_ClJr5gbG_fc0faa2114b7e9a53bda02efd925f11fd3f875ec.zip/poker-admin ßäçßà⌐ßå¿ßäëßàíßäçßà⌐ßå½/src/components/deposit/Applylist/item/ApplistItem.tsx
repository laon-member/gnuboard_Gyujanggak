import React from "react";
import { DepositType } from "stores/deposit/types";
import TableRowWrapper from "components/common/TableRowWrapper";
import comma from "lib/comma";
import { Button } from "styles/atom";
import { OptionWrapper } from "components/admin/account/edit/EditRow";

interface Props extends DepositType {
  data: DepositType;
  updateApproval: (id: number) => void;
  updateReject: (id: number) => void;
  onActiveToggle: (id: number) => void;
}

function ApplistItem({
  data,
  updateApproval,
  updateReject,
  onActiveToggle,
}: Props) {
  const approval = (id: number) => {
    alert("Accepted to request.");
    updateApproval(id);
  };
  const reject = (id: number) => {
    updateReject(id);
    alert("Declined to request.");
  };

  return (
    <TableRowWrapper>
      <td>{data.id}</td>
      <td>{data.userName}</td>
      <td>{data.phone}</td>
      <td>{data.bank}</td>
      <td>{data.name}</td>
      <td>{data.number}</td>
      <td>{comma(data.amount)}</td>
      <td>
        {data.created_at &&
          data.created_at.toString().slice(0, 16).replace("T", " ")}
      </td>
      <td>
        <OptionWrapper>
          <Button onClick={() => approval(data.id)}>OK</Button>
          <Button secondary onClick={() => reject(data.id)}>
            NO
          </Button>
        </OptionWrapper>
      </td>
    </TableRowWrapper>
  );
}

export default ApplistItem;
