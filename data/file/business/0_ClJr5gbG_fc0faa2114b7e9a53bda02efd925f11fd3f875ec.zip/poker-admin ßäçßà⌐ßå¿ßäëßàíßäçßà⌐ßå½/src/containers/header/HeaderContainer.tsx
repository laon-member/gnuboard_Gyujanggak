import React, { useEffect } from "react";
import { inject, observer } from "mobx-react";
import Header from "components/common/header/Header";
import { Redirect, RouteComponentProps, withRouter } from "react-router-dom";
import RootStore from "stores";
import { Admin, Playing, TAgent } from "stores/user/types";
import { DepositAndWithdrawInfo } from "stores/admin/types";
import { TRechargeApplyPage } from "stores/recharge/types";
import { TWithdrawApplyPage } from "stores/withdraw/types";
import { useStores } from "lib/hooks";
import AgentHeader from "components/common/header/AgentHeader";
import { TAgentInfo } from "stores/agent/types";

interface Props extends RouteComponentProps {
  playing?: () => void;
  depositAndWithdraw?: () => void;
  admin?: Admin;
  agent?: TAgent;
  getPlaying?: Playing;
  depoeitAndWithdrawInfo?: DepositAndWithdrawInfo;
  rechargeApplyPage?: TRechargeApplyPage;
  withdrawApplyPage?: TWithdrawApplyPage;
  userInit?: () => void;
  getAgentInfo?: () => void;
  agentInfo?: TAgentInfo;
}

const HeaderContainer = ({
  playing,
  depositAndWithdraw,
  admin,
  getPlaying,
  depoeitAndWithdrawInfo,
  history,
  rechargeApplyPage,
  withdrawApplyPage,
  agent,
  userInit,
  getAgentInfo,
  agentInfo,
}: Props) => {
  useEffect(() => {
    (async () => {
      playing!();
      depositAndWithdraw!();
      getAgentInfo!();
    })();

    setInterval(async () => {
      playing!();
      depositAndWithdraw!();
    }, 60000);
  }, [rechargeApplyPage, withdrawApplyPage]);

  const onLogout = () => {
    localStorage.removeItem("userInfo");
    history.push("/login");
    userInit!();
  };

  if (!getPlaying) return <h1>Loading...</h1>;
  if (agent)
    return (
      <AgentHeader agent={agent} onLogout={onLogout} agentInfo={agentInfo!} />
    );
  if (admin) {
    return (
      <Header
        onLogout={onLogout}
        adminId={admin!.id}
        playing={getPlaying}
        role={admin!.role}
        depositWithdrawInfo={depoeitAndWithdrawInfo!}
      />
    );
  }

  return <Redirect to="/login" />;
};

export default inject(
  ({
    userStore,
    adminStore,
    rechargeStore,
    withdrawStore,
    agentStore,
  }: RootStore) => ({
    playing: userStore.playing,
    depositAndWithdraw: adminStore.depositAndWithdraw,
    admin: userStore.admin,
    getPlaying: userStore.getPlaying,
    depoeitAndWithdrawInfo: adminStore.depoeitAndWithdrawInfo,
    rechargeApplyPage: rechargeStore.rechargeApplyPage,
    withdrawApplyPage: withdrawStore.withdrawApplyListPage,
    agent: userStore.agent,
    userInit: userStore.userInit,
    getAgentInfo: agentStore.getAgentInfo,
    agentInfo: agentStore.agentInfo,
  })
)(observer(withRouter(HeaderContainer)));
