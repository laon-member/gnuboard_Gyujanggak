import { observable, flow, computed, action } from "mobx";

import BaseStore from "stores/BaseStore";
import RootStore from "stores";

import { DepositType } from "./types";
import DepositService from "services/deposit/DepositService";

class DepositStore extends BaseStore {
  root: RootStore;

  constructor(root: RootStore) {
    super();
    this.root = root;
  }

  // 2020-07-16 목  depositList
  @observable
  private _depositList: DepositType[] = [];
  // 2020-07-17 금  deposit
  @observable
  private _deposit?: DepositType;
  // 2020-07-16 목  depositList

  @action
  public onActiveToggle(id: number) {
    this._depositList = this._depositList.map((user) =>
      user.id === id ? { ...user, active: !user.active } : user
    );
  }

  @computed
  get ActiveDepositList() {
    return this._depositList.filter((v) => v.active).map((v) => v.id);
  }

  @computed
  get DepositList() {
    return this._depositList;
  }
  // 2020-07-17 금  deposit
  @computed
  get Deposit() {
    return this._deposit;
  }

  GetSearchList = flow(function* (
    this: DepositStore,
    type?: string,
    inputValue?: string,
    dateType?: string
  ) {
    this._init("GET_SEARCH_LIST");
    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ search: DepositType[] }>;
      } = yield DepositService.GetSearchListAPI(type, inputValue, dateType);
      const { search } = res.data;
      this._depositList = search;

      this._success["GET_SEARCH_LIST"] = true;
    } catch (e) {
      this._failure["GET_SEARCH_LIST"] = [true, e];
    } finally {
      this._pending["GET_SEARCH_LIST"] = false;
    }
  });

  PostAccount = flow(function* (
    this: DepositStore,
    addBankName: string,
    addAccountHolder: string,
    addAccountNumber: string
  ) {
    this._init("POST_ACCOUNT");

    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ newAccount: DepositType }>;
      } = yield DepositService.PostAccountAPI(
        addBankName,
        addAccountHolder,
        addAccountNumber
      );
      const { newAccount } = res.data;
      this._deposit = newAccount;
      this._success["GET_RANKSET_LIST"] = true;
    } catch (e) {
      this._failure["GET_RANKSET_LIST"] = [true, e];
    } finally {
      this._pending["GET_RANKSET_LIST"] = false;
    }
  });

  RemoveDepositList = flow(function* (this: DepositStore, id: number[]) {
    try {
      yield DepositService.removeDepositList(id);
    } catch (error) {
      throw error;
    }
  });

  GetRanksetList = flow(function* (
    this: DepositStore,
    name?: string,
    account?: string
  ) {
    this._init("GET_RANKSET_LIST");
    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ myAccount: DepositType[] }>;
      } = yield DepositService.GetRanksetListAPI(name, account);
      const { myAccount } = res.data;
      this._depositList = myAccount;
      this._success["GET_RANKSET_LIST"] = true;
    } catch (e) {
      this._failure["GET_RANKSET_LIST"] = [true, e];
    } finally {
      this._pending["GET_RANKSET_LIST"] = false;
    }
  });

  GetRechargeList = flow(function* (
    this: DepositStore,
    id?: string,
    phone?: string,
    status?: string,
    startDate?: string,
    endDate?: string
  ) {
    this._init("GET_RECHARGE_LIST");

    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ recharge: DepositType[] }>;
      } = yield DepositService.GetRechargeListAPI(
        id,
        phone,
        status,
        startDate,
        endDate
      );
      const { recharge } = res.data;
      this._depositList = recharge;
      this._success["GET_RECHARGE_LIST"] = true;
    } catch (e) {
      this._failure["GET_RECHARGE_LIST"] = [true, e];
    } finally {
      this._pending["GET_RECHARGE_LIST"] = false;
    }
  });

  GetDepositList = flow(function* (
    this: DepositStore,
    searchType?: string,
    searchValue?: string,
    date?: string
  ) {
    this._init("GET_DEPOSIT_LIST");

    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ user: DepositType[] }>;
      } = yield DepositService.GetDepositListAPI();
      const { user } = res.data;
      this._depositList = user;
      this._success["GET_DEPOSIT_LIST"] = true;
    } catch (e) {
      this._failure["GET_DEPOSIT_LIST"] = [true, e];
    } finally {
      this._pending["GET_DEPOSIT_LIST"] = false;
    }
  });
  PutUpdateApproval = flow(function* (this: DepositStore, id: number) {
    this._init("PUT_UPDATE_APPROVAL");

    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ update: DepositType }>;
      } = yield DepositService.PutUpdateApprovalAPI(id);
      const { update } = res.data;
      this._deposit = update;
      this._success["PUT_UPDATE_APPROVAL"] = true;
    } catch (e) {
      this._failure["PUT_UPDATE_APPROVAL"] = [true, e];
    } finally {
      this._pending["PUT_UPDATE_APPROVAL"] = false;
    }
  });
  PutupdateReject = flow(function* (this: DepositStore, id: number) {
    this._init("PUT_UPDATE_REJECT");

    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ update: DepositType }>;
      } = yield DepositService.PutupdateRejectAPI(id);
      const { update } = res.data;
      this._deposit = update;
      this._success["PUT_UPDATE_REJECT"] = true;
    } catch (e) {
      this._failure["PUT_UPDATE_REJECT"] = [true, e];
    } finally {
      this._pending["PUT_UPDATE_REJECT"] = false;
    }
  });
}
export default DepositStore;
