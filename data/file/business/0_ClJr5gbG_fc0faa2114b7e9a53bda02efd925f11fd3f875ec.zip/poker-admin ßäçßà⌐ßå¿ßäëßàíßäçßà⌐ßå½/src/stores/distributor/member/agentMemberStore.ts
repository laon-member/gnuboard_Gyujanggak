import { action, observable } from "mobx";
import agentMemberService from "services/distributor/member/agentMemberService";
import RootStore from "stores";
import { PagingType } from "stores/message/types";
import { TMember, TMemberListPage, TMemberListSearch } from "./types";

export default class AgentMemberStore {
  root: RootStore;

  constructor(root: RootStore) {
    this.root = root;
  }

  @observable
  memberListPage = {
    paging: {} as PagingType,
    users: [] as TMember[],
  } as TMemberListPage;

  @action
  getMemberListPage = async (payload: TMemberListSearch) => {
    try {
      const res = await agentMemberService.getMemberListPage(payload);
      if (res.data.result) {
        this.memberListPage = res.data.data;
      } else {
        alert("Field error");
      }
    } catch (error) {
      alert("There is a problem with the server");
    }
  };
}
