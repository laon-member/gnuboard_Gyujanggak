import React, { useMemo } from "react";
import { createPortal } from "react-dom";

interface Props {
  id: string;
}

const Portal: React.FC<Props> = ({ id, children }) => {
  const ROOT = useMemo(() => document.getElementById(id), [id]);

  return createPortal(children, ROOT!);
};

export default Portal;
