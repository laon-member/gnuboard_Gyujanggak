﻿using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CardInfo : MonoBehaviour
{
    public enum CARDPATTERN { DIAMOND, HEART, CLOVER, SPACE, Default };
    
    /// <summary>
    /// Space = 0, Clover = 1, Diamond = 2, Heard = 3
    /// A = 1 ~ K = 13
    /// </summary>
    public CARDPATTERN CardPattern;

    public Image Img;
    public Sprite BackImg;

    string Pattern;

    public int Num;

    public string CardFileName;

    bool IsRot = true;

    private void Update()
    {
        if(IsRot)
        {
            //this.transform.Rotate(Vector3.forward, 16.0f);
        }
    }

    public void SetCardInfo(int pattern, int num, bool isMine, bool swapImg = true)
    {
        switch ((CARDPATTERN)pattern)
        {
            case CARDPATTERN.SPACE:
                {
                    Pattern = "s";
                }
                break;
            case CARDPATTERN.HEART:
                {
                    Pattern = "h";
                }
                break;
            case CARDPATTERN.DIAMOND:
                {
                    Pattern = "d";
                }
                break;
            case CARDPATTERN.CLOVER:
                {
                    Pattern = "c";
                }
                break;
        }

        CardPattern = (CARDPATTERN)pattern;
        Num = num;
        CardFileName = "Sprites/Cards/" + Pattern + "_" + num;

        if (swapImg)
        {
            //Img.sprite = Resources.Load<Sprite>("Sprites/Cards/" + Pattern + "_" + num);

            //GetComponent<Outline>().enabled = true;

            if (isMine)
            {
                FlipAniCard();
            }
            else
            {
                Img.sprite = Resources.Load<Sprite>(CardFileName);
            }
        }
    }

    public void FlipAniCard()
    {
        StartCoroutine("Co_FlipAni");
    }

    IEnumerator Co_FlipAni()
    {
        this.transform.DORotate(new Vector3(0, 90, 0), 0.25f);
        yield return CWFS.WFS(0.25f);
        Img.sprite = Resources.Load<Sprite>(CardFileName);
        this.transform.DORotate(new Vector3(0, 0, 0), 0.25f);
    }

    public void FlipCard()
    {
        //FlipAniCard();
        Img.sprite = Resources.Load<Sprite>(CardFileName);
    }

    public void StopRot()
    {
        IsRot = false;
        this.transform.DORotate(new Vector3(0, 0, 0), 0.0f);
    }

    public void ClearInfo()
    {
        Img.sprite = BackImg;

        CardFileName = "";
        CardPattern = CARDPATTERN.Default;
        Num = 0;
        IsRot = true;

        this.transform.localPosition = Vector3.zero;
    }
}
