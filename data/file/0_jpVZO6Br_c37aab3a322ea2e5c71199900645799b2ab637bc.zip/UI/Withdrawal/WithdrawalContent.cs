﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WithdrawalContent : MonoBehaviour
{
    public Text No;
    public Text AccountNumber;
    public Text Remittance;
    public Text Charge;
    public Text Time;
    public Text State;

    /// <summary>
    /// 0 = No, 1 = Account, 2 = Remittance, 3 = Charge, 4 = Time, 5 = State
    /// </summary>
    /// <param name="info"></param>
    public void SetTexts(string[] info)
    {
        No.text = info[0];
        AccountNumber.text = info[1];
        Remittance.text = info[2];
        Charge.text = info[3];
        Time.text = info[4];
        State.text = info[5];
    }
}
