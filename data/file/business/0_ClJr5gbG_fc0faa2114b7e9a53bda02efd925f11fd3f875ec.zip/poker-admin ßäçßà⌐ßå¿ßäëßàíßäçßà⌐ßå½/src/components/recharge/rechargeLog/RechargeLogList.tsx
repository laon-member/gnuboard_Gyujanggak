import NoDataBox from "components/common/NoDataBox";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import React from "react";
import { FaSearch } from "react-icons/fa";
import {
  TRechargeForms,
  TRechargeLogPage,
  TSearchRechargeLog,
} from "stores/recharge/types";
import { Button, Input } from "styles/atom";
import RechargeLog from "./RechargeLog";

interface Props {
  rechargeLogPage: TRechargeLogPage;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
  forms: TRechargeForms;
}

function RechargeLogList({ rechargeLogPage, onSearch, forms }: Props) {
  const { search } = forms;
  const { onChange } = search;
  const { username, phone } = search.inputs as TSearchRechargeLog;
  return (
    <>
      <SearchWrapper>
        <SearchForm onSubmit={onSearch}>
          <Input
            placeholder="ID"
            name="username"
            value={username}
            onChange={onChange}
          />
          <Input
            placeholder="Mobile"
            name="phone"
            value={phone}
            onChange={onChange}
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>ID</th>
            <th>Agent</th>
            <th>Mobile</th>
            <th>Amount</th>
            <th>BankAccount</th>
            <th>BankName</th>
            <th>CardNumber</th>
            <th>ApplyTime</th>
            <th>AdminName</th>
            <th>HandleTime</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {rechargeLogPage.paging.total_page
            ? rechargeLogPage.recharge.map((log) => (
                <RechargeLog key={log.id} log={log} />
              ))
            : null}
        </tbody>
      </Table>
      {rechargeLogPage.paging.total_page ? (
        <PageNationContainer
          paging={rechargeLogPage.paging}
          onSearch={onSearch}
          searchForm={forms.search}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
}

export default RechargeLogList;
