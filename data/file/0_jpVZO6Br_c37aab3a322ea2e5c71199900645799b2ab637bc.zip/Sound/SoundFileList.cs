﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundFileList
{
    public enum BGM
    {
        MAIN,
        GAME
    }

    public enum EFFECT
    {
        btn_click,
        card_distribution,
        card_flip,
        door_in,
        door_out,
        jackpot,
        lose,
        victory,
        playerturn,
        poker_chip,
        card_open,
        card_timer
    }
}
