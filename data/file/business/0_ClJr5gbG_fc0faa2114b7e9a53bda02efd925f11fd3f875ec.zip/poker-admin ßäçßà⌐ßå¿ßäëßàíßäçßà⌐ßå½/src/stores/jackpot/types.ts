import { PagingType } from "stores/message/types";

export type User = {
  id: number;
  username: string;
  name: string;
  phone: string;
  birth: Date;
  sex: string;
  created_at: Date;
  updated_at?: Date;
};

export type Account = {
  id: string;
  dl: number;
  cp: number;
  created_at: Date;
  updated_at?: Date;
};

export type JackpotInfo = {
  jackpot_amount: number;
  today_send: number;
  limit_amount: number;
};

export type JackpotType = {
  id: number;
  username: string;
  amount: number;
  created_at: string;
  admin_name: string;
  note: string;
};
export type PolicyTypeBackUp = {
  consume: Map;
  guarantee: Map;
  level: Map;
};

export type PremiumType = {
  idx: number;
  updated_at: Date;
  content: string;
};

export type Map = {
  key: string;
  value: string;
};

export type PolicyDetail = {
  key: string;
  value: number;
};

export type PolicyType = {
  consume: PolicyDetail;
  guarantee: PolicyDetail;
  level: PolicyDetail;
};

export type JackpotPage = {
  paging: PagingType;
  jackpot: JackpotType[];
};

export type SearchJackpotType = {
  id: string;
  start_date: string;
  end_date: string;
  page: number;
};

export type TPutPolicy = {
  limit_amount?: string;
  level_1_consume?: string;
  level_1_guarantee?: string;
  level_1_headcount?: string;
  level_2_consume?: string;
  level_2_guarantee?: string;
  level_2_headcount?: string;
  level_3_consume?: string;
  level_3_guarantee?: string;
  level_3_headcount?: string;
  level_4_consume?: string;
  level_4_guarantee?: string;
  level_4_headcount?: string;
  level_5_consume?: string;
  level_5_guarantee?: string;
  level_5_headcount?: string;
  level_6_consume?: string;
  level_6_guarantee?: string;
  level_6_headcount?: string;
};
