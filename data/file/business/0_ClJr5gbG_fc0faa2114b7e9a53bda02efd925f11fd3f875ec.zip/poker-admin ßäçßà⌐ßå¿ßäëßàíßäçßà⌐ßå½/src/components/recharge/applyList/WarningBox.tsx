import { DialogContainer } from "containers/common/dialog";
import React from "react";
import { AiFillWarning } from "react-icons/ai";
import styled from "styled-components";

interface Props {
  content: string;
  onToggle: () => void;
  onSubmit: (e: React.FormEvent<HTMLFormElement>) => void;
}

function WarningBox({ content, onToggle, onSubmit }: Props) {
  return (
    <DialogContainer
      title="Warning"
      confirmText="OK"
      onToggle={onToggle}
      onSubmit={onSubmit}
    >
      <SvgWrapper>
        <AiFillWarning size={48} color="#FFC639" />
      </SvgWrapper>
      <ContentWrapper>{content}</ContentWrapper>
    </DialogContainer>
  );
}

export const SvgWrapper = styled.div`
  text-align: center;
`;

export const ContentWrapper = styled.p`
  padding: 1rem;
`;

export default WarningBox;
