import { EditBoxType } from "components/member/memberlist/types";
import RollNoticeBox from "components/notice/rolling/RollNoticeBox";
import React from "react";
import { RollingType, UseInput } from "stores/notice/types";

interface Props {
  rolling?: RollingType;
  _new?: EditBoxType;
  edit?: EditBoxType;
  useInputs?: UseInput;
  form?: UseInput;
}

function RollNoticeBoxContainer({ rolling, _new, edit, form }: Props) {
  return (
    <RollNoticeBox rolling={rolling} _new={_new} edit={edit} form={form!} />
  );
}

export default RollNoticeBoxContainer;
