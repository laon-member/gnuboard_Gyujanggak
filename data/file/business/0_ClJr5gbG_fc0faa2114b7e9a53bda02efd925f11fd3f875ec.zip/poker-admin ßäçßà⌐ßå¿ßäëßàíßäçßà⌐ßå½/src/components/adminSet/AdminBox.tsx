import { InputWrapper } from "components/deposit/Bankset/Bankset";
import { Invalid } from "components/login/Login";
import { EditBoxType } from "components/member/memberlist/types";
import { DialogContainer } from "containers/common/dialog";
import { useInputs } from "lib/hooks";
import React, { useState } from "react";
import { AdminType } from "stores/admin/types";
import { Input } from "styles/atom";

interface Props {
  _new?: EditBoxType;
  admin?: AdminType;
  edit?: EditBoxType;
}

export type NewAdminType = {
  username: string;
  password: string;
};
export type EditAdminType = {
  id: string;
  password: string;
};

function AdminBox({ _new, admin, edit }: Props) {
  const { inputs, onChange } = useInputs({
    username: "",
    password: "",
  });
  const { username, password } = inputs;

  const [passwordCheck, setPasswordCheck] = useState("");
  const passwordCheckHandler = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPasswordCheck(e.target.value);
    setPasswordConfirm(password !== e.target.value);
  };

  const onNewSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (passwordConfirm) return;
    if (password === "" || passwordCheck === "") return;

    _new?.onSubmit({
      username,
      password,
    } as NewAdminType);
  };

  const [passwordConfirm, setPasswordConfirm] = useState(false);

  const onEditSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (passwordConfirm) return;
    if (password === "" || passwordCheck === "") return;

    edit!.onSubmit({
      id: admin?.id,
      password: password,
    });
  };

  return admin ? (
    <DialogContainer
      title="Edit Admin Box"
      confirmText="SAVE"
      onToggle={edit!.onToggle}
      onSubmit={onEditSubmit}
    >
      <InputWrapper>
        <label>ID</label>
        <Input value={admin.username} disabled />
      </InputWrapper>
      <InputWrapper>
        <label>Password</label>
        <Input
          type="password"
          placeholder="Password"
          name="password"
          value={password}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>PasswordCheck</label>
        <Input
          type="password"
          placeholder="PasswordCheck"
          value={passwordCheck}
          onChange={passwordCheckHandler}
        />
      </InputWrapper>
      {passwordConfirm && (
        <InputWrapper>
          <label></label>
          <Invalid>The password is different.</Invalid>
        </InputWrapper>
      )}
    </DialogContainer>
  ) : (
    <DialogContainer
      title="Admin Box"
      confirmText="SAVE"
      onToggle={_new!.onToggle}
      onSubmit={onNewSubmit}
    >
      <InputWrapper>
        <label>ID</label>
        <Input
          placeholder="ID"
          name="username"
          value={username}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Password</label>
        <Input
          type="password"
          placeholder="Password"
          name="password"
          value={password}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>PasswordCheck</label>
        <Input
          type="password"
          placeholder="PasswordCheck"
          value={passwordCheck}
          onChange={passwordCheckHandler}
        />
      </InputWrapper>
      {passwordConfirm && (
        <InputWrapper>
          <label></label>
          <Invalid>The password is different.</Invalid>
        </InputWrapper>
      )}
    </DialogContainer>
  );
}

export default AdminBox;
