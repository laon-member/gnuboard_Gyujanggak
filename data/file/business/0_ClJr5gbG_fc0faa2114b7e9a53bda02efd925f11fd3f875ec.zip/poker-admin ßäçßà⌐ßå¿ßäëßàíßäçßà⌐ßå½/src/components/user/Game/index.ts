export { default } from "./Game";
