﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

using DG.Tweening;
using Photon.Pun;
using Photon.Realtime;
using LitJson;
using Leguar.TotalJSON;
using DG.Tweening.Plugins;
using JetBrains.Annotations;

public class GameMgr : MonoBehaviourPunCallbacks
{
    [System.Serializable]
    public struct SPopUp
    {
        public GameObject CardExpansion;
        public GameObject Batting;
        public GameObject EmoticonChat;
        public GameObject Preferences;

        public Image[] GameSound;
        public Image[] BGM;

        public Sprite[] Btn_Spr;

        public Transform UI;
    }
    [Space]
    public SPopUp PopUp;

    [System.Serializable]
    public struct SBtns
    {
        public GameObject MoreBtn;
        public GameObject LeaveBtn;
        public GameObject ResetBtn;

        public GameObject Preference;
        public GameObject EmoticonChat;

        public Text CallTxt;
    }
    [Space]
    public SBtns Btns;
    public bool IsMoreBtns = false;
    [Space]
    public CardInfo PFCard;

    public bool IsPlaying = false;
    public bool IsAutoPlaying = false;
    public bool LeaveReservation = false;

    public Button[] RaceBtns;

    public Transform EmoticonContent;

    public Transform CardDeckPos;

    public Transform TimerBG;

    RoomPosition RoomPos;

    Color Timer_Color;

    // 배팅 관련
    public long BattingMoney; // 게임 판돈
    public long TotalBattingMoney;

    public bool[] IsPlayerTurns = new bool[6];
    public bool IsResultWait = false;

    //int PlayerTotalBattingMoney;
    public long PrevPlayerTotalBattingMoney;
    int PrevActorNum;

    int PrevChipCount;


    long PrevBattingMoney = 0;
    long PaymentMoney = 0;

    public bool IsBatting;

    bool[] CheckDiePlayer = new bool[6];

    public Text BattingTimer;

    int RaceCount = 0;
    int CallCount = 0;
    int TurnCount = 0;
    int DieCount = 0;

    // 이전 플레잉어가 체크했는지 확인용
    bool IsCheck = false;

    float JackPotMoney = 1; // 잭팟 추가 금액 퍼센트
    float Commission = 4; // 회사 지분 퍼센트

    //레이스 관련
    bool IsRace;
    int StartPlayerCount;

    //잭팟
    public Transform JackpotParrent;
    public JackPot PFJackpot;

    public GameObject StartBtn;

    // 카드 덱
    int[,] Arr_CardDeck = new int[4, 13];
    // 카드 덱에서 카드를 줄때 중복으로 준게있나 체크
    bool[,] Arr_CheckCardDeck = new bool[4, 13];
    // 호스트에게 받은 카드 정보를 저장
    string[] CardsFileName;

    public Dictionary<int, bool> Dic_CheckCard = new Dictionary<int, bool>();

    public SoundManager Sound;

    // DB 관련
    DataBaseManager DBMgr;

    long RetainedAmount;
    long CurrnetAmount;

    bool IsWinner;

    long DividendMoney = 0;

    // emoticon
    public GameObject[] Emote_Page;
    public GameObject[] Emote_Tap;
    public Text[] Emote_Txt;

    // JackPot
    public GameObject PFJackPotAni;
    GameObject JackpotAni;

    // coin
    public GameObject PFCoin;
    public List<GameObject> Coin_List = new List<GameObject>();
    public Transform ChipParent;

    // Total Money 
    public Text TotalBattingMoney_Txt;
    public Text CallMoney;

    public GameObject PlayMoney_Panel;

    public Text HalfPayMoney;
    public Text FullPayMoney;

    public bool IsPossibilityDestroy = false;

    bool IsJudgWinner = false;

    string RoomNumber = "";

    // 롤링 공지
    public Notic Notice;

    // 카드 중복 생성
    bool IsCreateCard = false;

    // object pool
    GameObject[] CoinPool;
    public Transform CoinPoolBasket;

    CardInfo[] CardPool;
    public Transform CardPoolBasket;

    // 로딩 화면
    public GameObject Loading;

    // Start is called before the first frame update
    void Start()
    {
        if (Sound == null)
        {
            Sound = FindObjectOfType<SoundManager>();
            DBMgr = FindObjectOfType<DataBaseManager>();
            Timer_Color = BattingTimer.color;
        }

        LocalPlayerInfo.Instance.InRoom = true;

        RoomPos = this.gameObject.GetComponent<RoomPosition>();

        SetRollingNotice();

        SendLocation();

        CreatePool();

        JackPot jackpot = GameObject.Instantiate(PFJackpot, JackpotParrent);

        jackpot.SetBtnActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if(Time.frameCount % 30 == 0)
        {
            //System.GC.Collect();
        }

        if (Application.platform == RuntimePlatform.Android)
        {
            if (Input.GetKey(KeyCode.Escape))
            {
                RoomPos.Android_BackBtn();
            }
        }
    }

    void CreatePool()
    {
        CoinPool = new GameObject[300];

        for (int i = 0; i < CoinPool.Length; i++)
        {
            GameObject obj = Instantiate(PFCoin, CoinPoolBasket);

            CoinPool[i] = obj;
            CoinPool[i].SetActive(false);
        }

        CardPool = new CardInfo[18];

        for (int i = 0; i < CardPool.Length; i++)
        {
            CardInfo obj = Instantiate(PFCard, CardPoolBasket).GetComponent<CardInfo>();

            CardPool[i] = obj;
            CardPool[i].gameObject.SetActive(false);
        }

        Loading.SetActive(false);
    }

    GameObject GetCoinPool()
    {
        GameObject obj = null;

        for (int i = 0; i < CoinPool.Length; i++)
        {
            if(!CoinPool[i].activeSelf)
            {
                CoinPool[i].SetActive(true);
                obj = CoinPool[i];
                break;
            }
        }

        if(obj == null)
        {
            for (int i = 0; i < CoinPool.Length / 2; i++)
            {
                CoinPool[i].SetActive(false);
            }

            obj = GetCoinPool();
        }

        return obj;
    }

    CardInfo GetCardPool()
    {
        CardInfo obj = null;

        for (int i = 0; i < CardPool.Length; i++)
        {
            if (!CardPool[i].gameObject.activeSelf)
            {
                CardPool[i].gameObject.SetActive(true);
                obj = CardPool[i];
                break;
            }
        }

        if (obj == null)
        {
            for (int i = 0; i < CardPool.Length / 2; i++)
            {
                CardPool[i].gameObject.SetActive(false);
            }

            obj = GetCardPool();
        }

        return obj;
    }

    public void ClearCard(CardInfo card)
    {
        card.transform.SetParent(CardPoolBasket);
        card.gameObject.SetActive(false);
        card.ClearInfo();
    }

    void SetRollingNotice() // 수정
    {
        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetNotics + "/GAME", "", "Post", "", (result) =>
        {
            JsonData resp = JsonMapper.ToObject(result);

            if ((int)resp["result"] == 1)
            {
                if (resp["data"].Count != 0)
                {
                    LocalPlayerInfo.Instance.RollingNotic = (string)resp["data"]["notice"]["content"];

                    float interval = float.Parse(resp["data"]["notice"]["duration"].ToString());

                    StartCoroutine("RepeatNotic", interval);
                }
            }
        }));
    }

    IEnumerator RepeatNotic(float interval)
    {
        WaitForSeconds wfsTime = CWFS.WFS(interval);

        while (true)
        {
            Notice.SetRollingNoticText();
            Notice.gameObject.SetActive(true);

            yield return wfsTime;
        }
    }

    void SendLocation()
    {
        JSON data = new JSON();
        data.Add("type", "LEVEL" + LocalPlayerInfo.Instance.RoomLevel.ToString());

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.SendMyLocation, data.CreateString(), "PATCH", PlayerPrefs.GetString("Token"), (result) => {
            
        }));
    }

    void PayMoney(long money)
    {
        JSON data = new JSON();
        data.Add("amount", money);

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.SetUserMoney, data.CreateString(), "Put", PlayerPrefs.GetString("Token"), (result) => {

            JsonData resp = JsonMapper.ToObject(result);

            if ((int)resp["result"] == 1)
            {
                
            }
        }));
    }

    public void OnClickBtn_GameStart()
    {
        ResetGame();
        StartBtn.GetComponent<Button>().interactable = false;
        StartBtn.SetActive(false);

        GameStart();
    }

    public void StopCo_GameStart()
    {
        StopCoroutine("Co_GameStart");
    }

    IEnumerator Co_GameStart()
    {
        yield return CWFS.WFS(2.0f);

        OnClickBtn_GameStart();
    }

    [PunRPC] // 모두 호출
    void GameEnd()
    {
        StartCoroutine("Co_GameEnd");
    }

    IEnumerator Co_GameEnd()
    {
        Coin_List.Clear();

        //Room Pos Clear
        RoomPos.Dic_PausePlayerBattingMoney.Clear();
        RoomPos.List_WatchPlayers.Clear();

        CurrnetAmount = long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString());

        long amountLost = (RetainedAmount - CurrnetAmount) * -1;

        JSON jsonData = new JSON();
        jsonData.Add("level", LocalPlayerInfo.Instance.RoomLevel.ToString());
        jsonData.Add("price", amountLost.ToString());

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.EndHistory, jsonData.CreateString(), "Post", PlayerPrefs.GetString("Token"), (result) => {
            JsonData resp = JsonMapper.ToObject(result);

            if ((int)resp["result"] == 1)
            {
                
            }
        }));

        float time = 2.0f;

        if (!IsWinner)
        {
            StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetRaffle, "", "Post", PlayerPrefs.GetString("Token"), (result) =>
            {
                JsonData resp = JsonMapper.ToObject(result);

                if ((int)resp["result"] == 1)
                {
                    // 잭팟 당첨?
                    if (resp["data"].Count != 0)
                    {
                        JackpotPrize(long.Parse(resp["data"]["account"]["amount"].ToString()));
                        time = 5.0f;
                    }
                }
            }));
        }

        string mode = IsWinner ? "WIN" : "LOSE";

        JSON jsonData_ = new JSON();
        jsonData_.Add("base_amount", amountLost);
        jsonData_.Add("result_amount", CurrnetAmount);

        jsonData_.Add("mode", mode);

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.SendUser_End + RoomNumber, jsonData_.CreateString(), "PATCH", PlayerPrefs.GetString("Token"), (result) =>
        {
            
        }));

        if (PhotonNetwork.IsMasterClient)
        {
            JSON jsonData_r = new JSON();
            jsonData_r.Add("bet_amount", TotalBattingMoney);
            
            StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.SendRoom_End + RoomNumber, jsonData_r.CreateString(), "PATCH", PlayerPrefs.GetString("Token"), (result) =>
            {
                
            }));
        }

        yield return CWFS.WFS(time);

        photonView.RPC("ResetGame", RpcTarget.All, null);

        if (long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()) <= long.Parse(PhotonNetwork.CurrentRoom.CustomProperties["BatMoney"].ToString()))
        {
            RoomPos.OnClickBtn_LeaveRoom();
        }

        yield return CWFS.WFS(0.25f);

        if (LeaveReservation)
        {
            RoomPos.OnClickBtn_LeaveRoom();
        }

        yield return CWFS.WFS(0.5f);

        if (PhotonNetwork.IsMasterClient)
        {
            if (PhotonNetwork.CurrentRoom.PlayerCount > 1)
            {
                if (IsAutoPlaying)
                {
                    StartCoroutine("Co_GameStart");
                }
            }
        }
    }

    public void JackpotPrize(long prizeMoney)
    {
        JSON j_jackpot = new JSON();
        j_jackpot.Add("amount", prizeMoney);

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.JackPotPlus, j_jackpot.CreateString(), "Post", PlayerPrefs.GetString("Token"), (result) => {
            
            JsonData resp = JsonMapper.ToObject(result);

            if ((int)resp["result"] == 1)
            {
                // 잭팟 당첨?
                if (resp["data"].Count != 0)
                {
                    PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"] = long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()) + prizeMoney;
                    photonView.RPC("SetWinnerMoneyTxt", RpcTarget.All, PhotonNetwork.LocalPlayer.ActorNumber, prizeMoney);
                    photonView.RPC("ShowJackpotAnimation", RpcTarget.All, LocalPlayerInfo.Instance.PlayerName, prizeMoney);
                }
            }
        }));
    }

    [PunRPC] // 모두 호출
    void ShowJackpotAnimation(string name, long money)
    {
        GameObject jackpotAni = GameObject.Instantiate(PFJackPotAni, PopUp.UI);

        JackPotPrizeAni jack = jackpotAni.GetComponent<JackPotPrizeAni>();
        jack.SetUserName(name);

        string format_money = CStringFormat.Instance.FormatToInt(money);

        jack.SetPrizeMoney(format_money);

        JackpotAni = jackpotAni;
    }

    public void AutoStart()
    {
        StopCoroutine("Co_AutoStart");
        StartCoroutine("Co_AutoStart");
    }

    public void Stop_AutoStart()
    {
        StopCoroutine("Co_AutoStart");
    }

    IEnumerator Co_AutoStart()
    {
        yield return CWFS.WFS(1.5f);

        if ((bool)PhotonNetwork.LocalPlayer.CustomProperties["IsDealer"])
        {
            if (PhotonNetwork.CurrentRoom.PlayerCount > 1)
            {
                StartCoroutine("Co_GameStart");
            }
        }
    }

    [PunRPC]
    void ResetGame()
    {
        IsPlaying = false;
        IsCreateCard = false;
        IsResultWait = false;

        RoomNumber = "";

        RaceCount = 0;
        TurnCount = 0;
        CallCount = 0;
        DieCount = 0;

        IsRace = false;

        BattingMoney = 0;
        PrevBattingMoney = 0;
        PaymentMoney = 0;
        StartPlayerCount = 0;

        PrevPlayerTotalBattingMoney = 0;

        DividendMoney = 0;

        IsCheck = false;
        TurnCount = 0;

        TotalBattingMoney_Txt.text = "0";
        CallMoney.text = "0";

        CheckDiePlayer = new bool[6];

        IsPossibilityDestroy = false;
        IsJudgWinner = false;

        Dic_CheckCard.Clear();

        for (int i = 0; i < this.transform.childCount; i++)
        {
            Destroy(this.transform.GetChild(i));
        }

        foreach (KeyValuePair<int, Player> player in PhotonNetwork.CurrentRoom.Players)
        {
            for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
            {
                if ((bool)player.Value.CustomProperties["IsWatch"])
                {
                    if (RoomPos.Arr_Players[i] != null)
                    {
                        if (player.Value.ActorNumber == RoomPos.Arr_Players[i].Info.ActorNumber)
                        {
                            player.Value.CustomProperties["IsWatch"] = false;
                            RoomPos.Arr_Players[i].SetWatchImg(false);
                        }
                    }
                }
            }
        }

        Color color = RaceBtns[0].GetComponentInChildren<Text>().color;
        color.a = 1.0f;

        RaceBtns[0].GetComponentInChildren<Text>().color = color;
        RaceBtns[0].interactable = true;

        RaceBtns[1].GetComponentInChildren<Text>().text = "ĐẦY"; // 번역 : FULL

        TotalBattingMoney = 0;
        
        for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
        {
            if (RoomPos.Arr_Players[i] != null)
            {
                RoomPos.Arr_Players[i].Clear();
            }
        }
    }

    // 카드 덱 변수 생성
    void CreateCardDeck()
    {
        Arr_CardDeck = new int[4, 13];
        Arr_CheckCardDeck = new bool[4, 13];

        for (int i = 0; i < Arr_CardDeck.GetLength(0); i++)
        {
            for (int j = 0; j < Arr_CardDeck.GetLength(1); j++)
            {
                Arr_CardDeck[i, j] = j + 1;
                Arr_CheckCardDeck[i, j] = false;
            }
        }
    }

    void GameStart()
    {
        photonView.RPC("SetStartPlayerCount", RpcTarget.All);

        StopCoroutine("Co_GameStart");
        StopCoroutine("Co_AutoStart");

        photonView.RPC("SetStartGameInfo", RpcTarget.MasterClient);

        photonView.RPC("RPC_CreateCard", RpcTarget.All);
    }

    [PunRPC]
    void SetStartGameInfo()
    {
        long roomBattingMoney = long.Parse(PhotonNetwork.CurrentRoom.CustomProperties["BatMoney"].ToString());

        JSON data = new JSON();
        data.Add("room_type", LocalPlayerInfo.Instance.RoomLevel.ToString());

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.SendRoomLevel, data.CreateString(), "Post", "", (result) => {

            JsonData resp = JsonMapper.ToObject(result);

            if ((int)resp["result"] == 1)
            {
                RoomNumber = resp["data"]["room_id"].ToString();
                

                photonView.RPC("SendBase_Amount", RpcTarget.All, RoomNumber);
            }
        }));

        if (PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            CreateCardDeck();
        }
    }
    [PunRPC]
    void SendBase_Amount(string roomNumber)
    {
        RoomNumber = roomNumber;

        JSON data = new JSON();
        data.Add("base_amount", long.Parse(PhotonNetwork.CurrentRoom.CustomProperties["BatMoney"].ToString()));

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.SendRoomBattingMoney + RoomNumber, data.CreateString(), "POST", PlayerPrefs.GetString("Token"), (result) =>
        {
            
        }));
    }

    [PunRPC]
    void SetStartPlayerCount()
    {
        StartPlayerCount = PhotonNetwork.CurrentRoom.PlayerCount;

        for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
        {
            if(RoomPos.Arr_Players[i] != null)
            {
                RoomPos.Arr_Players[i].Clear();
            }
        }

        IsAutoPlaying = true;
        IsPlaying = true;
    }
    [PunRPC]
    void RPC_CreateCard()
    {
        CardDeckPos.gameObject.SetActive(true);

        RetainedAmount = long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString());
        
        // 마스터 클라이언트면 유저들에게 카드 정보를 준다.
        if (PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            List<Player> players = new List<Player>();

            foreach (KeyValuePair<int, Player> item in PhotonNetwork.CurrentRoom.Players)
            {
                players.Add(item.Value);
            }

            for (int i = 0; i < players.Count; i++)
            {
                string[] cards = new string[3];

                for (int j = 0; j < 3; j++)
                {
                    int pattern = Random.Range(0, Arr_CardDeck.GetLength(0));
                    int num = Random.Range(0, Arr_CardDeck.GetLength(1));

                    // 카드 정보 주기

                    if (Arr_CheckCardDeck[pattern, num])
                    {
                        j--;
                    }
                    else
                    {
                        Arr_CheckCardDeck[pattern, num] = true;

                        cards[j] = pattern.ToString() + "/" + (num + 1).ToString();
                    }
                }

                // 족보 테스트 고정값 박아주기
                if(i == 0)
                {
                    cards[0] = "0/11";
                    cards[1] = "2/11";
                    cards[2] = "2/10";
                }
                else if(i == 1)
                {
                    cards[0] = "3/11";
                    cards[1] = "1/11";
                    cards[2] = "2/12";
                }

                photonView.RPC("SetCardsOtherPlayer", RpcTarget.All, players[i], cards);
                photonView.RPC("StartCo_CreateCard", players[i], cards);
            }
        }

        PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"] = long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()) - long.Parse(PhotonNetwork.CurrentRoom.CustomProperties["BatMoney"].ToString());

        photonView.RPC("SetTotalBattingMoney", RpcTarget.All, PhotonNetwork.LocalPlayer.ActorNumber, long.Parse(PhotonNetwork.CurrentRoom.CustomProperties["BatMoney"].ToString()));

        PayMoney(-long.Parse(PhotonNetwork.CurrentRoom.CustomProperties["BatMoney"].ToString()));

        for (int i = 0; i < PhotonNetwork.CurrentRoom.PlayerCount; i++)
        {
            TotalBattingMoney += long.Parse(PhotonNetwork.CurrentRoom.CustomProperties["BatMoney"].ToString());
        }

        TotalBattingMoney_Txt.text = CStringFormat.Instance.FormatToInt(TotalBattingMoney);
        

        for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
        {
            if (RoomPos.Arr_Players[i] != null)
            {
                RoomPos.Arr_Players[i].SetBattingMoneyText(long.Parse(PhotonNetwork.CurrentRoom.CustomProperties["BatMoney"].ToString()));
            }
        }

        if (long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()) <= 0)
        {
            photonView.RPC("PlayerAllIn", RpcTarget.All, PhotonNetwork.LocalPlayer.ActorNumber);

            Color color = RaceBtns[0].GetComponentInChildren<Text>().color;
            color.a = 0.3f;
            foreach (var item in RaceBtns)
            {
                item.GetComponentInChildren<Text>().color = color;
                item.interactable = false;
            }
            Btns.CallTxt.text = "GỌI"; // 번역 : CALL
        }
        else
        {
            Color color = RaceBtns[0].GetComponentInChildren<Text>().color;
            color.a = 1.0f;
            RaceBtns[2].GetComponentInChildren<Text>().color = color;
            RaceBtns[2].interactable = true;
        }

        RaceCount = 0;

        for (int i = 0; i < CheckDiePlayer.Length; i++)
        {
            CheckDiePlayer[i] = false;
        }
    }

    [PunRPC]
    void SetCardsOtherPlayer(Player player, string[] cards)
    {
        for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
        {
            if (RoomPos.Arr_Players[i] != null)
            {
                if (player.ActorNumber == RoomPos.Arr_Players[i].Info.ActorNumber)
                {
                    RoomPos.Arr_Players[i].CardsFileName = cards;
                    break;
                }
            }
        }
    }


    [PunRPC]
    void StartCo_CreateCard(string[] cards)
    {
        CardsFileName = cards;
        StopCoroutine("CreateCard");
        StartCoroutine("CreateCard");

    }
    // 카드 생성
    IEnumerator CreateCard()
    {
        if (!IsCreateCard)
        {
            Player curDealer = PhotonNetwork.MasterClient;
            int dealerIdx = 0;

            int count = 0;
            // 딜러 찾기
            bool searchDealer = false;
            foreach (KeyValuePair<int, Player> item in PhotonNetwork.CurrentRoom.Players)
            {
                if ((bool)item.Value.CustomProperties["IsDealer"])
                {
                    curDealer = item.Value;
                    searchDealer = true;
                    for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
                    {
                        if (RoomPos.Arr_Players[i] != null)
                        {
                            if (item.Value.ActorNumber == RoomPos.Arr_Players[i].Info.ActorNumber)
                            {
                                RoomPos.Arr_Players[i].SetDealerImg(true);
                                break;
                            }
                        }
                    }
                    break;
                }
            }
            // 딜러가 없으면 호스트를 딜러로
            if (!searchDealer)
            {
                curDealer.CustomProperties["IsDealer"] = true;

                for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
                {
                    if (RoomPos.Arr_Players[i] != null)
                    {
                        if (curDealer.ActorNumber == RoomPos.Arr_Players[i].Info.ActorNumber)
                        {
                            RoomPos.Arr_Players[i].SetDealerImg(true);
                            break;
                        }
                    }
                }
            }
            // 딜러의 인덱스 찾기
            for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
            {
                if (RoomPos.Arr_Players[i] != null)
                {
                    if (RoomPos.Arr_Players[i].Info.ActorNumber == curDealer.ActorNumber)
                    {
                        dealerIdx = i;
                    }
                }
            }

            for (int i = 0; i < 3; i++)
            {
                int idx = 0;

                if (dealerIdx + 1 >= RoomPos.Arr_Players.Length - 1)
                {
                    idx = 0;
                }
                else
                {
                    idx = dealerIdx + 1;
                }
                count = 0;

                WaitForSeconds wfsTime = CWFS.WFS(0.5f);

                while (true)
                {
                    if (RoomPos.Arr_Players[idx] != null)
                    {
                        if (!RoomPos.JudgeWatchingPlayer(RoomPos.Arr_Players[idx].Info.ActorNumber))
                        {
                            if (!RoomPos.Arr_Players[idx].IsWatch)
                            {
                                // 카드 생성
                                //CardInfo card = Instantiate(PFCard, CardDeckPos);
                                CardInfo card = GetCardPool();
                                card.transform.SetParent(CardDeckPos);

                                card.transform.localPosition = Vector3.zero;
                                card.transform.localScale = Vector3.one;

                                RoomPos.Arr_Players[idx].SetCardPos(card, idx, CardsFileName);
                                count++;

                                Sound.StartSound_Effect(SoundFileList.EFFECT.card_distribution);

                                yield return wfsTime;
                            }
                        }
                    }

                    if (idx >= RoomPos.Arr_Players.Length - 1)
                    {
                        idx = 0;
                    }
                    else
                    {
                        idx++;
                    }

                    if (count >= StartPlayerCount /*- RoomPos.GetWatchingPlayerCount()*/)
                    {
                        break;
                    }
                }
            }

            for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
            {
                if (RoomPos.Arr_Players[i] != null)
                {
                    if (!RoomPos.JudgeWatchingPlayer(RoomPos.Arr_Players[i].Info.ActorNumber))
                    {
                        RoomPos.Arr_Players[i].SetSliderTimer(true, false); // 카드 확인 타이머
                    }
                }
            }

            string temp = RoomPos.MyProfile.CardsFileName[0];
            string card_0 = "";
            if (temp.Length == 3)
            {
                card_0 = temp[0] + "_" + temp[2];
            }
            else
            {
                card_0 = temp[0] + "_" + temp[2] + temp[3];
            }

            temp = RoomPos.MyProfile.CardsFileName[1];
            string card_1 = "";
            if (temp.Length == 3)
            {
                card_1 = temp[0] + "_" + temp[2];
            }
            else
            {
                card_1 = temp[0] + "_" + temp[2] + temp[3];
            }

            temp = RoomPos.MyProfile.CardsFileName[2];
            string card_2 = "";
            if (temp.Length == 3)
            {
                card_2 = temp[0] + "_" + temp[2];
            }
            else
            {
                card_2 = temp[0] + "_" + temp[2] + temp[3];
            }

            string cardName = card_0 + "," + card_1 + "," + card_2;

            JSON data = new JSON();
            data.Add("my_card", cardName);

            StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.SendCardInfo + RoomNumber, data.CreateString(), "PATCH", PlayerPrefs.GetString("Token"), (result) =>
            {

            }));

            IsPossibilityDestroy = true;

            // 패 확인 팝업 실행
            RoomPos.MyProfile.StartCo_Expansion();

            IsCreateCard = !IsCreateCard;
        }
    }

    // 패 확인 완료
    public void CompleteCardCheck()
    {
        CardDeckPos.gameObject.SetActive(false);

        photonView.RPC("CompleteCardCheckAllPlayer", RpcTarget.MasterClient, PhotonNetwork.LocalPlayer.ActorNumber);
        photonView.RPC("CompleteCardCheckSliderTimer", RpcTarget.All, PhotonNetwork.LocalPlayer.ActorNumber);
    }
    public void SetWatchPlayerImg()
    {
        photonView.RPC("SetWatchPlayer", RpcTarget.All);
    }
    [PunRPC]
    void SetWatchPlayer()
    {
        for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
        {
            if (RoomPos.Arr_Players[i] != null)
            {
                if (RoomPos.JudgeWatchingPlayer(RoomPos.Arr_Players[i].Info.ActorNumber))
                {
                    RoomPos.Arr_Players[i].SetWatchImg(true);
                }
            }
        }
    }
    public void SetCardInfoPrevPlayers(Player player, string[] cards)
    {
        photonView.RPC("RPC_SetCardInfoPrevPlayers", player, cards);
    }

    [PunRPC]
    void RPC_SetCardInfoPrevPlayers(string[] cards)
    {
        for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
        {
            if (RoomPos.Arr_Players[i] != null)
            {
                if (PhotonNetwork.LocalPlayer.ActorNumber != RoomPos.Arr_Players[i].Info.ActorNumber)
                {
                    RoomPos.Arr_Players[i].CardsFileName = cards;

                    int cardDir = 0;

                    if (i >= 3)
                    {
                        cardDir = 1;
                    }
                    else
                    {
                        cardDir = 0;
                    }

                    for (int j = 0; j < 3; j++)
                    {
                        CardInfo card = Instantiate(GetComponent<GameMgr>().PFCard, RoomPos.Arr_Players[i].CardPos[cardDir]);
                        card.transform.localPosition = Vector3.zero;
                        card.transform.localScale = Vector3.one;

                        RoomPos.Arr_Players[i].SetCardPos(card, i, cards);
                        RoomPos.Arr_Players[i].SetGenealogy(cards);
                    }
                }
            }
        }
    }

    [PunRPC]
    void CompleteCardCheckSliderTimer(int actorNum)
    {
        for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
        {
            if (RoomPos.Arr_Players[i] != null)
            {
                if (RoomPos.Arr_Players[i].Info.ActorNumber == actorNum)
                {
                    RoomPos.Arr_Players[i].SetSliderTimer(false);
                    break;
                }
            }
        }
    }
    [PunRPC]
    void CompleteCardCheckAllPlayer(int actorNum)
    {
        bool result = false;

        if (!Dic_CheckCard.ContainsKey(actorNum))
        {
            Dic_CheckCard.Add(actorNum, true);
        }
        else
        {
            Dic_CheckCard[actorNum] = true;
        }

        if (Dic_CheckCard.Count == PhotonNetwork.CurrentRoom.PlayerCount - RoomPos.GetWatchingPlayerCount())
        {
            result = true;
        }

        if (result) // 모두 확인했으면 딜러 플레이어 다음 차례부터 배팅을 시작한다
        {
            // 배팅을 시작할 플레이어 찾기
            FindStartPlayer();
        }
    }

    public void FindStartPlayer()
    {
        List<Player> players = new List<Player>();

        foreach (KeyValuePair<int, Player> item in PhotonNetwork.CurrentRoom.Players)
        {
            players.Add(item.Value);
        }

        for (int i = 0; i < players.Count; i++)
        {
            if ((bool)players[i].CustomProperties["IsDealer"])
            {
                photonView.RPC("StartBatting", players[i], long.Parse(PhotonNetwork.CurrentRoom.CustomProperties["BatMoney"].ToString()), 0, PrevPlayerTotalBattingMoney, false, IsCheck);
                photonView.RPC("SetSliderTimer", RpcTarget.All, RoomPos.SeatPlayerPK[i], true);
                break;
            }
        }
    }

    [PunRPC] // 카드 오픈
    public void OpenPlayerCard(bool open)
    {
        StartCoroutine("Co_CardOpen", open);
    }

    IEnumerator Co_CardOpen(bool open)
    {
        yield return CWFS.WFS(1.5f);

        IsBatting = false;

        Sound.StartSound_Effect(SoundFileList.EFFECT.card_flip);

        WaitForSeconds wfsTime = CWFS.WFS(0.5f);

        // 살아있는 플레이어 패만 오픈
        for (int i = 0; i < RoomPos.SeatPlayerPK.Length; i++)
        {
            for (int j = 0; j < RoomPos.Arr_Players.Length; j++)
            {
                if (!CheckDiePlayer[i]) // 죽은 플레이어가 아니고
                {
                    if (RoomPos.Arr_Players[j] != null) // 비어 있지않고
                    {
                        if (RoomPos.SeatPlayerPK[i] == RoomPos.Arr_Players[j].Info.ActorNumber)
                        {
                            if (!RoomPos.JudgeWatchingPlayer(RoomPos.Arr_Players[j].Info.ActorNumber)) // 관전 플레이어가 아니면
                            {
                                if (RoomPos.Arr_Players[j].Info.ActorNumber != PhotonNetwork.LocalPlayer.ActorNumber) // 나자신이 아니면
                                {
                                    RoomPos.Arr_Players[j].OpenCard(open);
                                    yield return wfsTime;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        yield return CWFS.WFS(0.3f);
        if (PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            JudgmentWinner();
            photonView.RPC("SetResultWait", RpcTarget.All, true);
        }
    }

    #region Batting

    [PunRPC] // 배팅 시작
    void StartBatting(long payMoney, int prevActorNum, long prevTotalBattingMoney, bool isLastPlayer, bool isCheck)
    {
        Sound.StartSound_Effect(SoundFileList.EFFECT.playerturn);

        PrevBattingMoney = payMoney;
        PrevActorNum = prevActorNum;
        PrevPlayerTotalBattingMoney = prevTotalBattingMoney;

        if (!(bool)PhotonNetwork.LocalPlayer.CustomProperties["IsDealer"])
        {
            Btns.CallTxt.text = "GỌI"; // 번역 : CALL
        }
        else
        {
            TurnCount++;

            if ((bool)PhotonNetwork.LocalPlayer.CustomProperties["IsDealer"] && TurnCount <= 1)
            {
                if (!RoomPos.MyProfile.Info.IsAllin)
                {
                    Btns.CallTxt.text = "KIỂM TRA"; // 번역 : CHECK
                }
            }
            else
            {
                Btns.CallTxt.text = "GỌI"; // 번역 : CALL
            }
        }

        if (PrevBattingMoney == 0 && !isCheck && !IsRace)
        {
            Btns.CallTxt.text = "KIỂM TRA"; // 번역 : CHECK
        }

        Color color = RaceBtns[0].GetComponentInChildren<Text>().color;

        if (long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()) <= 0) // 올인 상태면 콜만 가능하게
        {
            color.a = 0.3f;
            foreach (var item in RaceBtns)
            {
                item.GetComponentInChildren<Text>().color = color;
                item.interactable = false;
            }
            RaceBtns[1].GetComponentInChildren<Text>().text = "ĐẦY"; // 번역 : FULL
        }
        else
        {
            if (isLastPlayer) // 마지막 플레이어면 콜만 가능하게
            {
                color.a = 0.3f;
                for (int i = 0; i < 2; i++)
                {
                    RaceBtns[i].GetComponentInChildren<Text>().color = color;
                    RaceBtns[i].interactable = false;
                }
                RaceBtns[1].GetComponentInChildren<Text>().text = "ĐẦY"; // 번역 : FULL

                HalfPayMoney.transform.parent.gameObject.SetActive(false);
                FullPayMoney.transform.parent.gameObject.SetActive(false);
            }
            else
            {
                // HALF, FULL 배팅금 보다 보유금이 낮으면 FULL 버튼 ALLIN 버튼으로 변경
                // 배팅시 금액 보이는칸 안보이게
                long half_money = PrevBattingMoney + (TotalBattingMoney / 2);
                long full_money = PrevBattingMoney + TotalBattingMoney;

                if (long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()) < half_money)
                {
                    color.a = 0.3f;

                    RaceBtns[0].interactable = false;
                    RaceBtns[0].GetComponentInChildren<Text>().color = color;

                    RaceBtns[1].GetComponentInChildren<Text>().text = "ALLIN";
                    HalfPayMoney.transform.parent.gameObject.SetActive(false);
                    FullPayMoney.transform.parent.gameObject.SetActive(false);
                }
                else if (long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()) < full_money)
                {
                    color.a = 0.3f;

                    //RaceBtns[0].interactable = false;
                    //RaceBtns[0].GetComponentInChildren<Text>().color = color;

                    RaceBtns[1].GetComponentInChildren<Text>().text = "ALLIN";

                    HalfPayMoney.transform.parent.gameObject.SetActive(true);
                    FullPayMoney.transform.parent.gameObject.SetActive(false);
                }
                else
                {
                    color.a = 1.0f;
                    for (int i = 0; i < 2; i++)
                    {
                        if (!RaceBtns[i].interactable)
                        {
                            RaceBtns[i].GetComponentInChildren<Text>().color = color;
                            RaceBtns[i].interactable = true;
                        }
                    }
                    RaceBtns[1].GetComponentInChildren<Text>().text = "ĐẦY"; // 번역 : FULL

                    HalfPayMoney.transform.parent.gameObject.SetActive(true);
                    FullPayMoney.transform.parent.gameObject.SetActive(true);
                }
            }
        }

        // 배팅 팝업시 스케일값 초기화 세팅값 설정
        for (int i = 0; i < PopUp.Batting.transform.GetChild(1).childCount; i++)
        {
            PopUp.Batting.transform.GetChild(1).GetChild(i).localScale = Vector3.one;
        }

        // 배팅할 금액 보여주기
        if (RaceBtns[0].transform.GetChild(0).GetComponent<Text>().text == "MỘT NỬA") // Half 버튼 일때만
        {
            HalfPayMoney.text = CStringFormat.Instance.FormatToInt(PrevBattingMoney + (TotalBattingMoney / 2));
        }
        if (RaceBtns[1].transform.GetChild(0).GetComponent<Text>().text == "ĐẦY") // Full 버튼 일때만
        {
            FullPayMoney.GetComponent<Text>().text = CStringFormat.Instance.FormatToInt(PrevBattingMoney + TotalBattingMoney);
        }

        if (Btns.CallTxt.text == "GỌI") // CALL 일 때만
        {
            if(PrevPlayerTotalBattingMoney - BattingMoney > 0)
            {
                CallMoney.text = CStringFormat.Instance.FormatToInt(PrevPlayerTotalBattingMoney - BattingMoney);
            }
            else
            {
                CallMoney.text = "0";
            }
        }
        photonView.RPC("SetIsTurn", RpcTarget.All, PhotonNetwork.LocalPlayer.ActorNumber);
        PopUp.Batting.SetActive(true);

        StopCoroutine("Co_BattingTimer");
        StartCoroutine("Co_BattingTimer");
    }
    IEnumerator Co_BattingTimer()
    {
        int timelimit = 5;
        BattingTimer.color = Timer_Color;
        BattingTimer.text = timelimit.ToString();

        WaitForSeconds wfs_long = CWFS.WFS(0.25f);
        WaitForSeconds wfs_short = CWFS.WFS(0.125f);

        // 타이머
        for (int i = timelimit - 1; i >= 0; i--)
        {
            if (i >= 3)
            {
                yield return wfs_long;
                TimerBG.transform.DOScale(1.2f, 0.25f);
                yield return wfs_long;
                TimerBG.transform.DOScale(1.0f, 0.25f);
                yield return wfs_long;
                TimerBG.transform.DOScale(1.2f, 0.25f);
                yield return wfs_long;
                TimerBG.transform.DOScale(1.0f, 0.25f);
            }
            else if (i < 3)
            {
                BattingTimer.color = Color.red;
                yield return wfs_short;
                TimerBG.transform.DOScale(1.2f, 0.125f);
                yield return wfs_short;
                TimerBG.transform.DOScale(1.0f, 0.125f);
                yield return wfs_short;
                TimerBG.transform.DOScale(1.2f, 0.125f);
                yield return wfs_short;
                TimerBG.transform.DOScale(1.0f, 0.125f);
                yield return wfs_short;
                TimerBG.transform.DOScale(1.2f, 0.125f);
                yield return wfs_short;
                TimerBG.transform.DOScale(1.0f, 0.125f);
                yield return wfs_short;
                TimerBG.transform.DOScale(1.2f, 0.125f);
                yield return wfs_short;
                TimerBG.transform.DOScale(1.0f, 0.125f);
            }
            BattingTimer.text = i.ToString();
        }

        if (RoomPos.MyProfile.Info.IsAllin)
        {
            OnClickBtn_Batting(0);
        }
        else
        {
            OnClickBtn_Batting(3); // 시간제한
        }
    }

    public void CallJudgmentRace(int actorNum, long totalBattingMoney)
    {
        photonView.RPC("JudgmentRace", RpcTarget.MasterClient, 3, (long)0, actorNum, totalBattingMoney, true, true);
        //photonView.RPC("LeavePlayer_DieCount", RpcTarget.All);
    }

    [PunRPC]
    void LeavePlayer_DieCount()
    {
        DieCount++;
    }

    [PunRPC] // 호스트만 호출
    void JudgmentRace(int type, long payMoney, int prevActorNum, long prevTotalMoney, bool isCheck, bool isLeft) // 이전 플레이어가 냈던 머니
    {
        bool lastPlayer = false;
        int leftCount = 0;

        if (type == 0 || type == 4) // call, check
        {
            CallCount++;
        }
        else if (type == 3) // die
        {
            if (!isLeft)
            {
                DieCount++;
                photonView.RPC("SetRaceDieCount", RpcTarget.All, DieCount);
                
                if (DieCount >= PhotonNetwork.CurrentRoom.PlayerCount - (1 + RoomPos.GetWatchingPlayerCount())) // 1명 빼고 모두 죽었을 때
                {
                    photonView.RPC("OpenPlayerCard", RpcTarget.All, false);
                    photonView.RPC("SetSliderTimer", RpcTarget.All, prevActorNum, false);
                    return;
                }
            }
            else
            {
                leftCount = 1;
            }
        }
        else // race (half, full)
        {
            CallCount = 0;
            IsRace = true;
            photonView.RPC("SetRaceIsRace", RpcTarget.All, IsRace);

            photonView.RPC("SetPrevPlayerIsCheck", RpcTarget.All, true);
        }

        bool endRace = false;
        if (IsRace == true)
        {
            if (CallCount + DieCount >= PhotonNetwork.CurrentRoom.PlayerCount - leftCount - (1 + RoomPos.GetWatchingPlayerCount())) // 레이스 시작한 사람 제외
            {
                endRace = true;
            }
        }
        else
        {
            if (CallCount + DieCount >= PhotonNetwork.CurrentRoom.PlayerCount - leftCount - RoomPos.GetWatchingPlayerCount())
            {
                endRace = true;
            }
        }

        if (endRace)
        {
            photonView.RPC("OpenPlayerCard", RpcTarget.All, true);
            photonView.RPC("SetSliderTimer", RpcTarget.All, prevActorNum, false);
        }
        else
        {
            // 현재 내위치 찾기
            int myIdx = 0;
            for (int i = 0; i < RoomPos.SeatPlayerPK.Length; i++)
            {
                if (RoomPos.SeatPlayerPK[i] > 0)
                {
                    if (RoomPos.SeatPlayerPK[i] == prevActorNum)
                    {
                        myIdx = i;
                        break;
                    }
                }
            }

            int myPos = 0;

            if (myIdx != RoomPos.SeatPlayerPK.Length - 1)
            {
                myPos = myIdx;
            }

            int count = 0;
            // 다음 플레이어 찾아서 배팅 턴 실행
            for (int i = myPos; i < RoomPos.SeatPlayerPK.Length; i++)
            {
                if (!CheckDiePlayer[i])
                {
                    if (RoomPos.SeatPlayerPK[i] > 0)
                    {
                        if (RoomPos.SeatPlayerPK[i] != prevActorNum)
                        {
                            if (!RoomPos.JudgeWatchingPlayer(RoomPos.SeatPlayerPK[i]))
                            {
                                if (!(bool)RoomPos.GetPlayer(RoomPos.SeatPlayerPK[i]).CustomProperties["IsDie"])
                                {
                                    photonView.RPC("SetIsTurn", RpcTarget.All, RoomPos.SeatPlayerPK[i]);
                                    photonView.RPC("StartBatting", RoomPos.GetPlayer(RoomPos.SeatPlayerPK[i]), payMoney, prevActorNum, prevTotalMoney, lastPlayer, isCheck);
                                    photonView.RPC("SetSliderTimer", RpcTarget.All, RoomPos.SeatPlayerPK[i], true);
                                    break;
                                }
                            }
                        }
                    }
                }

                if (i >= RoomPos.SeatPlayerPK.Length - 1)
                {
                    i = -1;
                }

                count++;
                if (count >= 6)
                {
                    break;
                }
            }
        }
    }

    [PunRPC]
    void SetIsTurn(int actorNum)
    {
        for (int i = 0; i < IsPlayerTurns.Length; i++)
        {
            IsPlayerTurns[i] = false;
        }

        for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
        {
            if (RoomPos.Arr_Players[i] != null)
            {
                if (RoomPos.Arr_Players[i].Info.ActorNumber == actorNum)
                {
                    IsPlayerTurns[i] = true;
                    break;
                }
            }
        }
    }

    [PunRPC]
    void SetRaceTurnCount(int count)
    {
        RaceCount = count;
    }

    [PunRPC]
    void SetRaceDieCount(int count)
    {
        DieCount = count;
    }

    [PunRPC]
    void SetRaceIsRace(bool r)
    {
        IsRace = r;
    }
        
    [PunRPC]
    void DisPlayBattingMoney(int actorNum, long money)
    {
        for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
        {
            if (RoomPos.Arr_Players[i] != null)
            {
                if (RoomPos.Arr_Players[i].Info.ActorNumber == actorNum)
                {
                    RoomPos.Arr_Players[i].SetBattingMoneyText(money);
                    break;
                }
            }
        }
    }
    [PunRPC] // 모두 호출
    void SetPrevPlayerIsCheck(bool result)
    {
        IsCheck = result;
    }


    // 배팅 버튼 온클릭
    public void OnClickBtn_Batting(int type)
    {
        StopCoroutine("Co_BattingTimer");

        if (type != 3)
        {
            photonView.RPC("RPCSoundPlay", RpcTarget.All, SoundFileList.EFFECT.poker_chip);
        }
        else
        {
            photonView.RPC("RPCSoundPlay", RpcTarget.All, SoundFileList.EFFECT.card_flip);
        }

        int chipCount = 0;

        switch (type)
        {
            case 0: // call
                {
                    if (Btns.CallTxt.text == "GỌI") // Call 번역 : CALL
                    {
                        if (PrevPlayerTotalBattingMoney > BattingMoney)
                        {
                            PaymentMoney = PrevPlayerTotalBattingMoney - BattingMoney; // 이전 플레이어랑 금액 맞추기
                        }
                        RoomPos.MyProfile.SetBattingResultImg(0);
                        photonView.RPC("SetOtherPlayerBattingImg", RpcTarget.Others, PhotonNetwork.LocalPlayer.ActorNumber, 0);

                        chipCount = PrevChipCount;
                    }
                    else // Check
                    {
                        PaymentMoney = 0;
                        RoomPos.MyProfile.SetBattingResultImg(1);
                        photonView.RPC("SetOtherPlayerBattingImg", RpcTarget.Others, PhotonNetwork.LocalPlayer.ActorNumber, 1);
                        photonView.RPC("SetPrevPlayerIsCheck", RpcTarget.All, true);
                    }
                }
                break;
            case 1: // half
                {
                    PaymentMoney = PrevBattingMoney + (TotalBattingMoney / 2);
                    RoomPos.MyProfile.SetBattingResultImg(2);
                    photonView.RPC("SetOtherPlayerBattingImg", RpcTarget.Others, PhotonNetwork.LocalPlayer.ActorNumber, 2);

                    chipCount = Random.Range(3, 7);
                }
                break;
            case 2: // full
                {
                    PaymentMoney = PrevBattingMoney + TotalBattingMoney;

                    if (RaceBtns[1].GetComponentInChildren<Text>().text == "ĐẦY") // 번역 : FULL
                    {
                        RoomPos.MyProfile.SetBattingResultImg(3);
                        photonView.RPC("SetOtherPlayerBattingImg", RpcTarget.Others, PhotonNetwork.LocalPlayer.ActorNumber, 3);

                        chipCount = Random.Range(7, 13);
                    }
                    else // AllIn
                    {
                        RoomPos.MyProfile.SetBattingResultImg(4);
                        photonView.RPC("SetOtherPlayerBattingImg", RpcTarget.Others, PhotonNetwork.LocalPlayer.ActorNumber, 4);

                        chipCount = Random.Range(13, 19);
                    }
                }
                break;
            case 3: // die
                {
                    photonView.RPC("SetPlayerDie", RpcTarget.All, PhotonNetwork.LocalPlayer.ActorNumber);
                }
                break;
            default:
                break;
        }

        if (long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()) <= PaymentMoney)
        {
            PaymentMoney = long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString());
            
            photonView.RPC("PlayerAllIn", RpcTarget.All, PhotonNetwork.LocalPlayer.ActorNumber);
        }

        // 코인 만들기
        photonView.RPC("CreateCoin", RpcTarget.All, chipCount, PhotonNetwork.LocalPlayer.ActorNumber);

        PayMoney(-PaymentMoney);

        PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"] = long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()) - PaymentMoney;

        BattingMoney = BattingMoney + PaymentMoney;
        photonView.RPC("SetTotalBattingMoney", RpcTarget.All, PhotonNetwork.LocalPlayer.ActorNumber, BattingMoney);

        photonView.RPC("AddTotalBattingMoney", RpcTarget.All, PaymentMoney);
        photonView.RPC("DisPlayBattingMoney", RpcTarget.All, PhotonNetwork.LocalPlayer.ActorNumber, PaymentMoney);
        photonView.RPC("SetSliderTimer", RpcTarget.All, RoomPos.MyProfile.Info.ActorNumber, false);

        photonView.RPC("JudgmentRace", RpcTarget.MasterClient, type, PaymentMoney, PhotonNetwork.LocalPlayer.ActorNumber, BattingMoney, IsCheck, false);

        JSON data = new JSON();
        data.Add("base_amount", (BattingMoney + long.Parse(PhotonNetwork.CurrentRoom.CustomProperties["BatMoney"].ToString())));

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.SendBattingMoney + RoomNumber, data.CreateString(), "PATCH", PlayerPrefs.GetString("Token"), (result) =>
        {
            
        }));

        PopUp.Batting.SetActive(false);
    }

    [PunRPC]
    void SetTotalBattingMoney(int actorNum, long money)
    {
        if(RoomPos.Dic_PausePlayerBattingMoney.Count == 0)
        {
            RoomPos.Dic_PausePlayerBattingMoney.Add(actorNum, money);
        }
        else
        {
            if (RoomPos.Dic_PausePlayerBattingMoney.ContainsKey(actorNum))
            {
                RoomPos.Dic_PausePlayerBattingMoney[actorNum] = money;
            }
            else
            {
                RoomPos.Dic_PausePlayerBattingMoney.Add(actorNum, money);
            }
        }
    }

    [PunRPC]
    public void SetOtherPlayerBattingImg(int actorNum, int idx)
    {
        foreach (var item in RoomPos.Arr_Players)
        {
            if(item != null)
            {
                if(item.Info.ActorNumber == actorNum)
                {
                    item.SetBattingResultImg(idx);
                }
            }
        }
    }

    [PunRPC] // 모두 호출
    void CreateCoin(int chipCount, int playerNum)
    {
        int[] para = new int[2];
        para[0] = chipCount;
        para[1] = playerNum;

        StartCoroutine("Co_CreateCoin", para);
    }

    IEnumerator Co_CreateCoin(int[] para)
    {
        int chipCount = para[0];
        int playerNum = para[1];

        PrevChipCount = chipCount;

        // 플레이어 찾기
        CPlayer player = new CPlayer();
        for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
        {
            if(RoomPos.Arr_Players[i] != null)
            {
                if(RoomPos.Arr_Players[i].Info.ActorNumber == playerNum)
                {
                    player = RoomPos.Arr_Players[i];
                    break;
                }
            }
        }

        // 코인 생성
        for (int i = 0; i < chipCount; i++)
        {
            float posY = 0.0f;
            float posX = 0.0f;

            while (true)
            {
                posX = Random.Range(-250, -17);
                posY = Random.Range(-132, 118);

                if (Vector3.Distance(new Vector3(posX, posY), CardDeckPos.localPosition) <= 150)
                {
                    break;
                }
            }

            GameObject obj = GetCoinPool();

            obj.transform.SetParent(player.ChipPos[(int)player.Type]);
            obj.transform.localPosition = Vector3.zero;

            obj.transform.SetParent(ChipParent);
            obj.transform.localScale = Vector3.one;

            obj.transform.DOLocalJump(new Vector3(posX, posY), 100.0f, 1, 1.0f);

            Coin_List.Add(obj);
            yield return null;
        }
    }

    public void CreateAllPlayerCoin()
    {
        StartCoroutine("Co_AllPlayerCreateCoin");
    }

    IEnumerator Co_AllPlayerCreateCoin()
    {
        int chipCount = Random.Range(2, 5);

        foreach (var player in RoomPos.Arr_Players)
        {
            if(player != null)
            {
                for (int i = 0; i < chipCount; i++)
                {
                    float posY = 0.0f;
                    float posX = 0.0f;

                    while (true)
                    {
                        posX = Random.Range(-250, -17);
                        posY = Random.Range(-132, 118);

                        if (Vector3.Distance(new Vector3(posX, posY), CardDeckPos.localPosition) <= 150)
                        {
                            break;
                        }
                    }

                    GameObject obj = GetCoinPool();

                    obj.transform.SetParent(player.ChipPos[(int)player.Type]);
                    obj.transform.localPosition = Vector3.zero;

                    obj.transform.SetParent(ChipParent);
                    obj.transform.localScale = Vector3.one;

                    obj.transform.DOLocalJump(new Vector3(posX, posY), 100.0f, 1, 1.0f);

                    Coin_List.Add(obj);
                    yield return null;
                }
            }
        }

        Sound.StartSound_Effect(SoundFileList.EFFECT.poker_chip);
    }

    [PunRPC]
    void AddTotalBattingMoney(long money)
    {
        TotalBattingMoney += money;
        TotalBattingMoney_Txt.text = CStringFormat.Instance.FormatToInt(TotalBattingMoney);
    }

    [PunRPC]
    void PlayerAllIn(int actorNum)
    {
        for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
        {
            if (RoomPos.Arr_Players[i] != null)
            {
                if (RoomPos.Arr_Players[i].Info.ActorNumber == actorNum)
                {
                    RoomPos.Arr_Players[i].ActiveAllIn();
                    break;
                }
            }
        }
    }
    [PunRPC]
    public void SetPlayerDie(int actorNum)
    {
        // Dir Player color 바꾸기
        for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
        {
            if(RoomPos.Arr_Players[i] != null)
            {
                if(RoomPos.Arr_Players[i].Info.ActorNumber == actorNum)
                {
                    RoomPos.Arr_Players[i].SetDieImg();
                    break;
                }
            }
        }

        for (int i = 0; i < RoomPos.SeatPlayerPK.Length; i++)
        {
            if(RoomPos.SeatPlayerPK[i] == actorNum)
            {
                CheckDiePlayer[i] = true;
                break;
            }
        }
    }

    public void CallSetLeftDiePlayer(int actorNum)
    {
        photonView.RPC("SetLeftDiePlayer", RpcTarget.All, actorNum);
    }

    [PunRPC]
    void SetLeftDiePlayer(int actorNum)
    {
        for (int i = 0; i < RoomPos.SeatPlayerPK.Length; i++)
        {
            if(RoomPos.SeatPlayerPK[i] == actorNum)
            {
                if(CheckDiePlayer[i])
                    CheckDiePlayer[i] = false;
                break;
            }
        }
    }

    [PunRPC]
    void SetSliderTimer(int actorNum, bool result)
    {
        if (actorNum != RoomPos.MyProfile.Info.ActorNumber) // 자신이 아닐 때만
        {
            foreach (var item in RoomPos.Arr_Players)
            {
                if (item != null)
                {
                    if (item.Info.ActorNumber == actorNum)
                    {
                        item.SetSliderTimer(result); // 배팅 타이머 슬라이더
                        break;
                    }
                }
            }
        }
    }

    #endregion

    [PunRPC]
    void SetResultWait(bool result)
    {
        IsResultWait = result;
    }

    public void JudgmentWinner() // 마스터 클라이언트만 호출
    {
        if (!IsJudgWinner)
        {
            IsJudgWinner = true;

            StopCoroutine("Co_BattingTimer");
            PopUp.Batting.SetActive(false);
            PopUp.CardExpansion.SetActive(false);

            // 여기서 넣을 때 죽은 플레이어 빼고 넣어준다.
            // 죽은 플레이어 카운트 계산
            int diePlayerCount = 0;
            foreach (var diePlayer in CheckDiePlayer)
            {
                if (diePlayer)
                {
                    diePlayerCount++;
                }
            }

            CardGenealogy[] players = new CardGenealogy[PhotonNetwork.CurrentRoom.PlayerCount - diePlayerCount];

            int idx = 0;
            for (int i = 0; i < RoomPos.SeatPlayerPK.Length; i++)
            {
                for (int j = 0; j < RoomPos.Arr_Players.Length; j++)
                {
                    if (!CheckDiePlayer[i]) // 죽은 플레이어가 아니고
                    {
                        if (RoomPos.Arr_Players[j] != null) // 비어있지 않고
                        {
                            if (!RoomPos.Arr_Players[j].IsLeftPlayer) // 나간 플레이어가 아닐 때
                            {
                                if (!RoomPos.JudgeWatchingPlayer(RoomPos.Arr_Players[j].Info.ActorNumber)) // 관전 플레이어가 아닐 때
                                {
                                    if (RoomPos.SeatPlayerPK[i] == RoomPos.Arr_Players[j].Info.ActorNumber) // 해당 플레이어를 찾아
                                    {
                                        players[idx] = RoomPos.Arr_Players[j].gameObject.GetComponent<CardGenealogy>(); // 해당 플레이어를 찾아 넣어준다.
                                        idx++;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 패의 순서대로 리스트에 저장 0 = 1등
            List<CPlayer> list_winner = new List<CPlayer>();
            List<CardGenealogy> temp_players = new List<CardGenealogy>(); // 임시 저장 리스트
            List<long> list_batMoney = new List<long>();

            if (PhotonNetwork.CurrentRoom.PlayerCount - RoomPos.GetWatchingPlayerCount() <= 1)
            {
                list_winner.Add(RoomPos.MyProfile);
                list_batMoney.Add(list_winner[0].GetBattingMoney());
            }
            else
            {
                for (int i = 0; i < players.Length; i++)
                {
                    if (players[i] != null)
                    {
                        temp_players.Add(players[i]); // 플레이어들을 저장
                    }
                }

                int tempCount = temp_players.Count;

                for (int i = 0; i < tempCount; i++)
                {
                    if (CalculationCard.Instance.GetWinner(temp_players) != null)
                    {
                        list_winner.Add(CalculationCard.Instance.GetWinner(temp_players).gameObject.GetComponent<CPlayer>());
                    }
                    else if (CalculationCard.Instance.GetWinner(temp_players) == null && PhotonNetwork.CurrentRoom.PlayerCount - RoomPos.GetWatchingPlayerCount() <= 1)
                    {
                        list_winner.Add(RoomPos.MyProfile);
                    }

                    list_batMoney.Add(list_winner[i].GetBattingMoney());

                    for (int j = 0; j < temp_players.Count; j++)
                    {
                        if (temp_players[j] != null)
                        {
                            if (temp_players[j].gameObject.GetComponent<CPlayer>() != null)
                            {
                                if (list_winner[i] == temp_players[j].gameObject.GetComponent<CPlayer>())
                                {
                                    temp_players.RemoveAt(j);
                                }
                            }
                        }
                    }
                }
            }
            
            long totalMoney = 0;
            foreach (var player in list_winner)
            {
                totalMoney += player.GetBattingMoney();
            }

            if (totalMoney != TotalBattingMoney)
            {
                list_winner[0].Info.BatMoney += TotalBattingMoney - totalMoney;
            }

            //foreach (var item in RoomPos.Arr_Players)
            //{
            //    if (item != null)
            //    {
            //        if (item.Info.IsDie)
            //        {
            //            list_winner.Add(item);
            //            list_batMoney.Add(item.GetBattingMoney());
            //        }
            //    }
            //}

            CPlayer winner = list_winner[0];

            long dividend = TotalBattingMoney;

            #region 유저 배당금 분배

            long[] arr_dividend = new long[list_batMoney.Count];

            // 배당금 분배
            for (int i = 0; i < list_batMoney.Count; i++)
            {
                for (int j = i; j < list_batMoney.Count; j++)
                {
                    if (!list_winner[i].Info.IsDie)
                    {
                        if (list_batMoney[i] != 0)
                        {
                            if (list_batMoney[i] > list_batMoney[j])
                            {
                                arr_dividend[i] += list_batMoney[j];
                                list_batMoney[j] = 0;
                            }
                            else
                            {
                                arr_dividend[i] += list_batMoney[i];

                                if (i != j)
                                {
                                    list_batMoney[j] -= list_batMoney[i];
                                }
                            }
                        }
                    }
                }
            }

            #endregion

            // 플레이어 찾아서 돈 넘겨주기
            foreach (KeyValuePair<int, Player> item in PhotonNetwork.CurrentRoom.Players)
            {
                for (int i = 0; i < list_winner.Count; i++)
                {
                    if (item.Value.ActorNumber == list_winner[i].Info.ActorNumber)
                    {
                        photonView.RPC("ReceiveMoney", item.Value, arr_dividend[i]);
                    }
                }
            }

            photonView.RPC("ShowResultMoney", RpcTarget.All, list_winner[0].Info.ActorNumber, arr_dividend[0]);
            photonView.RPC("SetPlayersResult", RpcTarget.All, winner.Info.ActorNumber);

            // 서버에 잭팟 수수료 값 넘겨주기
            long jackPotMoney = (long)((TotalBattingMoney * JackPotMoney) / 100);

            JSON data = new JSON();
            data.Add("amount", jackPotMoney);

            StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.AddJackpotLog, data.CreateString(), "Post", PlayerPrefs.GetString("Token"), (result) =>
            {

            }));
        }
    }

    [PunRPC] // 모두 호출
    void ShowResultMoney(int actorNum, long money)
    {
        for (int  i = 0;  i < RoomPos.Arr_Players.Length;  i++)
        {
            if (RoomPos.Arr_Players[i] != null)
            {
                if (RoomPos.Arr_Players[i].Info.ActorNumber == actorNum)
                {
                    long receiveCompanyMoney = (long)((money * Commission) / 100);
                    long jackPotMoney = (long)(money * JackPotMoney) / 100;

                    long resultMoney = money - receiveCompanyMoney - jackPotMoney;

                    RoomPos.Arr_Players[i].ShowResultMoney(resultMoney);
                    break;
                }
            }
        }
    }

    [PunRPC] // 모두 호출
    void SetPlayersResult(int actorNum) // 배너처리, 딜러 넘기기
    {
        if(PhotonNetwork.LocalPlayer.ActorNumber == actorNum)
        {
            Sound.StartSound_Effect(SoundFileList.EFFECT.victory);
            IsWinner = true;
        }
        else
        {
            Sound.StartSound_Effect(SoundFileList.EFFECT.lose);
            IsWinner = false;
        }

        SetBanner(actorNum);
    }

    void SetBanner(int winnerNumber)
    {
        if(PhotonNetwork.CurrentRoom.PlayerCount - RoomPos.GetWatchingPlayerCount() <= 1)
        {
            if (!(bool)PhotonNetwork.LocalPlayer.CustomProperties["IsWatch"])
            {
                RoomPos.MyProfile.SetBanner(0);
                RoomPos.MyProfile.ShowBackLight();
                RoomPos.MyProfile.SetDealerImg(true);
            }
        }
        else
        {
            Transform chipEndPoint = null;

            for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
            {
                if (RoomPos.Arr_Players[i] != null)
                {
                    if (!(bool)RoomPos.GetPlayer(RoomPos.Arr_Players[i].Info.ActorNumber).CustomProperties["IsWatch"])
                    {
                        if (RoomPos.Arr_Players[i].Info.ActorNumber == winnerNumber) // 승자면
                        {
                            chipEndPoint = RoomPos.Arr_Players[i].GetChipEndPoint();

                            // 배너처리
                            RoomPos.Arr_Players[i].SetBanner(0);
                            RoomPos.Arr_Players[i].ShowBackLight();

                            RoomPos.Arr_Players[i].SetDealerImg(true);

                            for (int j = 0; j < RoomPos.SeatPlayerPK.Length; j++) // 딜러 넘기기
                            {
                                if (RoomPos.Arr_Players[i].Info.ActorNumber == RoomPos.SeatPlayerPK[j])
                                {
                                    RoomPos.GetPlayer(RoomPos.SeatPlayerPK[j]).CustomProperties["IsDealer"] = true;
                                }
                            }
                        }
                        else
                        {
                            RoomPos.Arr_Players[i].SetBanner(1);

                            RoomPos.Arr_Players[i].SetDealerImg(false);

                            for (int j = 0; j < RoomPos.SeatPlayerPK.Length; j++)
                            {
                                if (RoomPos.Arr_Players[i].Info.ActorNumber == RoomPos.SeatPlayerPK[j])
                                {
                                    RoomPos.GetPlayer(RoomPos.SeatPlayerPK[j]).CustomProperties["IsDealer"] = false;
                                }
                            }


                        }
                    }
                }
            }
        }

        if (Coin_List.Count > 1)
        {
            for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
            {
                if (RoomPos.Arr_Players[i] != null)
                {
                    if (RoomPos.Arr_Players[i].Info.ActorNumber == winnerNumber)
                    {
                        for (int j = 0; j < Coin_List.Count; j++)
                        {
                            GameObject obj = Coin_List[j];

                            obj.transform.SetParent(RoomPos.Arr_Players[i].ChipPos[(int)RoomPos.Arr_Players[i].Type].transform);
                            obj.transform.DOLocalMove(Vector3.zero, 0.8f);
                            obj.transform.DOScale(new Vector3(0.535f, 0.535f, 0.535f), 0.8f).OnComplete(()=> CoinMoveEnd(obj));
                        }
                    }
                }
            }
            StartCoroutine("CoinMoveSound");
        }

        if (PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            photonView.RPC("GameEnd", RpcTarget.All);
        }
    }

    void CoinMoveEnd(GameObject obj)
    {
        obj.transform.SetParent(CoinPoolBasket);
        obj.transform.localPosition = Vector3.zero;
        obj.SetActive(false);
    }

    IEnumerator CoinMoveSound()
    {
        WaitForSeconds wfsTime = CWFS.WFS(0.2f);
        for (int i = 0; i < 5; i++)
        {
            Sound.StartSound_Effect(SoundFileList.EFFECT.poker_chip);
            yield return wfsTime;
        }
    }

    public int[] GetPlayerGeneType()
    {
        int[] result = new int[2];

        CardGenealogy gene = RoomPos.MyProfile.GetComponent<CardGenealogy>();

        result[0] = (int)gene.GeneType;

        if (result[0] == (int)(CardGenealogy.GenealogyType.Basic))
        {
            result[1] = gene.SumCardNumber;
        }
        else if(result[0] == (int)(CardGenealogy.GenealogyType.Pair))
        {
            result[1] = gene.PairNumber;
        }
        else if (result[0] == (int)(CardGenealogy.GenealogyType.Straight))
        {
            result[1] = gene.TopCardNumber;
        }
        else if (result[0] == (int)(CardGenealogy.GenealogyType.Triple))
        {
            result[1] = gene.TopCardNumber;
        }

        return result;
    }


    [PunRPC] // 모두 호출 :: 승자에게만 돈이 들어가는게 x 
    void ReceiveMoney(long money)
    {
        long receiveCompanyMoney = (long)((money * Commission) / 100); // 본사 수수료
        long jackPotMoney = (long)(money * JackPotMoney) / 100; // 잭팟 수수료
        long agentMoeny = (long)(money * LocalPlayerInfo.Instance.Agent_Commission) / 100; // 총판 수수료

        long resultMoney = money - receiveCompanyMoney - jackPotMoney - agentMoeny;

        PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"] = long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()) + (resultMoney);

        JSON data = new JSON();
        DividendMoney = resultMoney;

        data.Add("amount", DividendMoney);
        data.Add("total_amount", money);

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.SetUserMoney, data.CreateString(), "Put", PlayerPrefs.GetString("Token"), (result) => {

            JsonData resp = JsonMapper.ToObject(result);

            if ((int)resp["result"] == 1)
            {
                
            }
        }));

        photonView.RPC("SetWinnerMoneyTxt", RpcTarget.All, PhotonNetwork.LocalPlayer.ActorNumber, resultMoney);
    }
    [PunRPC]
    void SetWinnerMoneyTxt(int actorNum, long money)
    {
        for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
        {
            if(RoomPos.Arr_Players[i] != null)
            {
                if (RoomPos.Arr_Players[i].Info.ActorNumber == actorNum)
                {
                    RoomPos.Arr_Players[i].ReceiveMoneyTxt(money);
                    break;
                }
            }
        }
    }

    [PunRPC]
    void RPCSoundPlay(SoundFileList.EFFECT sound)
    {
        Sound.StartSound_Effect(sound);
    }

    #region UIBtn
    public void OnClickBtn_MoreBtns()
    {
        if (!IsMoreBtns)
        {
            Btns.MoreBtn.GetComponent<Image>().sprite = Resources.Load<Sprite>("Sprites/in_game/up_icon");

            Color targetColor = Btns.ResetBtn.GetComponent<Image>().color;

            targetColor.a = 1.0f;

            Btns.LeaveBtn.GetComponent<Image>().color = targetColor;
            Btns.ResetBtn.GetComponent<Image>().color = targetColor;

            Btns.LeaveBtn.SetActive(true);
            Btns.ResetBtn.SetActive(true);

            Btns.LeaveBtn.transform.localPosition = new Vector3(Btns.LeaveBtn.transform.localPosition.x, 0, 0);
            Btns.ResetBtn.transform.localPosition = new Vector3(Btns.ResetBtn.transform.localPosition.x, 0, 0);

            Btns.LeaveBtn.transform.DOLocalMoveY(-108, 0.3f);
            Btns.ResetBtn.transform.DOLocalMoveY(-212f, 0.3f);

            IsMoreBtns = true;
        }
        else
        {
            Btns.MoreBtn.GetComponent<Image>().sprite = Resources.Load<Sprite>("Sprites/in_game/down");

            Btns.LeaveBtn.transform.DOLocalMoveY(0, 0.3f).OnComplete(()=> Btns.LeaveBtn.SetActive(false));
            Btns.ResetBtn.transform.DOLocalMoveY(0, 0.3f).OnComplete(()=> Btns.ResetBtn.SetActive(false));

            Color targetColor = Btns.ResetBtn.GetComponent<Image>().color;

            targetColor.a = 0.0f;

            Btns.LeaveBtn.GetComponent<Image>().DOColor(targetColor, 0.3f);
            Btns.ResetBtn.GetComponent<Image>().DOColor(targetColor, 0.3f);

            IsMoreBtns = false;
        }
    }

    public void OnClickBtn_CloseMore()
    {
        if(IsMoreBtns)
        {
            Btns.MoreBtn.GetComponent<Image>().sprite = Resources.Load<Sprite>("Sprites/in_game/down");

            Btns.LeaveBtn.transform.DOLocalMoveY(0, 0.3f).OnComplete(() => Btns.LeaveBtn.SetActive(false));
            Btns.ResetBtn.transform.DOLocalMoveY(0, 0.3f).OnComplete(() => Btns.ResetBtn.SetActive(false));

            Color targetColor = Btns.ResetBtn.GetComponent<Image>().color;

            targetColor.a = 0.0f;

            Btns.LeaveBtn.GetComponent<Image>().DOColor(targetColor, 0.3f);
            Btns.ResetBtn.GetComponent<Image>().DOColor(targetColor, 0.3f);

            IsMoreBtns = false;
        }
    }

    public void OnClickBtn_EmotChat()
    {
        if(PopUp.EmoticonChat.transform.parent.gameObject.activeInHierarchy)
        {
            PopUp.EmoticonChat.transform.DOScale(new Vector3(0,0,1), 0.15f).OnComplete(()=> PopUp.EmoticonChat.transform.parent.gameObject.SetActive(false));
        }
        else
        {
            EmoticonContent.localPosition = Vector3.zero;
            PopUp.EmoticonChat.transform.parent.gameObject.SetActive(true);

            PopUp.EmoticonChat.transform.DOScale(new Vector3(1, 1, 1), 0.15f);
        }
    }

    public void OnClickBtn_Emoticon(string info)
    {
        string[] s_info = info.Split('/');

        string name = s_info[0];
        float[] i_info = new float[3];

        i_info[0] = float.Parse(s_info[1]);
        
        RoomPos.MyProfile.ShowEmoticon(name, i_info);

        photonView.RPC("ShowEmoticon", RpcTarget.Others, name, RoomPos.MyProfile.Info.ActorNumber, i_info);
    }

    [PunRPC]
    void ShowEmoticon(string fileName, int actorNum, float[] info)
    {
        foreach (var item in RoomPos.Arr_Players)
        {
            if(item != null)
            {
                if(item.Info.ActorNumber == actorNum)
                {
                    item.ShowEmoticon(fileName, info);
                    break;
                }
            }
        }
    }

    public void OnClickBtn_Preferences()
    {
        if(PopUp.Preferences.activeInHierarchy)
        {
            PopUp.Preferences.SetActive(false);
        }
        else
        {
            PopUp.Preferences.SetActive(true);
        }

        if ("0" == PlayerPrefs.GetString("GameSound"))
        {
            PopUp.GameSound[0].sprite = PopUp.Btn_Spr[0];
            PopUp.GameSound[1].sprite = PopUp.Btn_Spr[1];
        }
        else
        {
            PopUp.GameSound[1].sprite = PopUp.Btn_Spr[0];
            PopUp.GameSound[0].sprite = PopUp.Btn_Spr[1];
        }

        if ("0" == PlayerPrefs.GetString("BGM"))
        {
            PopUp.BGM[0].sprite = PopUp.Btn_Spr[0];
            PopUp.BGM[1].sprite = PopUp.Btn_Spr[1];
        }
        else
        {
            PopUp.BGM[1].sprite = PopUp.Btn_Spr[0];
            PopUp.BGM[0].sprite = PopUp.Btn_Spr[1];
        }
    }

    public void OnClickBtn_GameSound(bool result)
    {
        if (result) // 소리 켜기
        {
            PopUp.GameSound[0].sprite = PopUp.Btn_Spr[0];
            PopUp.GameSound[1].sprite = PopUp.Btn_Spr[1];

            PlayerPrefs.SetString("GameSound", "0");
        }
        else // 소리 끄기
        {
            PopUp.GameSound[1].sprite = PopUp.Btn_Spr[0];
            PopUp.GameSound[0].sprite = PopUp.Btn_Spr[1];

            PlayerPrefs.SetString("GameSound", "1");
        }
    }

    public void OnClickBtn_BGM(bool result)
    {
        if (result) // 소리 켜기
        {
            PopUp.BGM[0].sprite = PopUp.Btn_Spr[0];
            PopUp.BGM[1].sprite = PopUp.Btn_Spr[1];
            if (!Sound.BGM.isPlaying)
            {
                // 게임 소리 여러개면 바꾸기
                Sound.BGM.Play();
            }
            PlayerPrefs.SetString("BGM", "0");
        }
        else // 소리 끄기
        {
            PopUp.BGM[1].sprite = PopUp.Btn_Spr[0];
            PopUp.BGM[0].sprite = PopUp.Btn_Spr[1];
            if (Sound.BGM.isPlaying)
            {
                Sound.BGM.Stop();
            }
            PlayerPrefs.SetString("BGM", "1");
        }
    }

    public void OnClickBtn_Emot_Tap(int tap)
    {
        if(tap == 0)
        {
            Emote_Page[0].SetActive(true);
            Emote_Page[1].SetActive(false);

            Color color = Emote_Txt[0].color;
            color.a = 0.35f;
            Emote_Txt[1].color = color;

            color.a = 1;
            Emote_Txt[0].color = color;
        }
        else if(tap == 1)
        {
            Emote_Page[1].SetActive(true);
            Emote_Page[0].SetActive(false);

            Color color = Emote_Txt[0].color;
            color.a = 0.35f;
            Emote_Txt[0].color = color;

            color.a = 1;
            Emote_Txt[1].color = color;
        }
    }

    public void OnClickBtn_ClickSound()
    {
        FindObjectOfType<SoundManager>().StartSound_Effect(SoundFileList.EFFECT.btn_click);
    }
    #endregion

}
