import React from "react";
import Layout from "./stepByComponent/Layout";

type CreateMessageProps = {
  onCreateToggle: () => void;
};

const CreateMessage = ({ onCreateToggle }: CreateMessageProps) => {
  return <Layout onCreateToggle={onCreateToggle} />;
};

export default CreateMessage;
