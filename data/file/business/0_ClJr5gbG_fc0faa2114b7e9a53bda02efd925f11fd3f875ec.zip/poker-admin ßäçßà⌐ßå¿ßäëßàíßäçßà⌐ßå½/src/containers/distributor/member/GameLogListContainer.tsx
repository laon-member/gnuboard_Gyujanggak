import GameLogList from "components/distributor/member/gameLog/GameLogList";
import React from "react";

function GameLogListContainer() {
  return <GameLogList />;
}

export default GameLogListContainer;
