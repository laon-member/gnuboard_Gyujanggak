export { default } from './PersonMsgModel';
