import { AxiosResponse } from "axios";
import BankSetList from "components/recharge/bankSet/BankSetList";
import { useInputs } from "lib/hooks";
import { inject, observer } from "mobx-react";
import React, { useEffect, useState } from "react";
import RootStore from "stores";
import {
  TBankSetForm,
  TEditBankSetForm,
  TNewBankSet,
  TNewBankSetForm,
  TRechargeBankSet,
  TRechargeBankSetPage,
  TSearchRechargeBankSet,
} from "stores/recharge/types";

interface Props {
  getRechargeBankSet: (paylaod: TSearchRechargeBankSet) => void;
  rechargeBankSetPage: TRechargeBankSetPage;
  createBankSet: (paylaod: TNewBankSet) => AxiosResponse;
  setBankSet: (payload: TRechargeBankSet) => void;
  bankSet: TRechargeBankSet;
  modifyBankSet: (payload: TRechargeBankSet) => AxiosResponse;
}

const BankSetContainer = ({
  getRechargeBankSet,
  rechargeBankSetPage,
  createBankSet,
  setBankSet,
  bankSet,
  modifyBankSet,
}: Props) => {
  const [bankToggle, setBankToggle] = useState(false);
  const [editToggle, setEditToggle] = useState(false);
  const forms = {
    search: useInputs({
      bank_name: "",
      bank_account: "",
      bank_number: "",
      page: 1,
    } as TSearchRechargeBankSet),
    new: useInputs({
      bank_name: "",
      bank_account: "",
      bank_number: "",
      is_active: 0,
    } as TNewBankSetForm),
    edit: useInputs({
      bank_name: "",
      bank_account: "",
      bank_number: "",
      is_active: 0,
    } as TEditBankSetForm),
  } as TBankSetForm;

  useEffect(() => {
    (async () => {
      await getRechargeBankSet(forms.search.inputs);
    })();
  }, []);

  const onBankSetSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    try {
      const res = await createBankSet(forms.new.inputs);
      if (!res.data.result) {
        alert("Failedd to create BankSet");
      }
    } catch (error) {
      console.error(error);
      alert("There is a problem with the server");
    } finally {
      forms.new.init();
      forms.search.init();
      getRechargeBankSet(forms.search.inputs);
      setBankToggle(false);
    }
  };
  const onSearch = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    await getRechargeBankSet(forms.search.inputs);
  };

  const _new: TNewBankSet = {
    toggle: bankToggle,
    onToggle: () => {
      setBankToggle(!bankToggle);
    },
    onSubmit: onBankSetSubmit,
  };

  const onEditSubmit = async (e: TRechargeBankSet) => {
    try {
      const res = await modifyBankSet(e);
      if (!res.data.result) {
        alert("Failed to edit the bankSet");
      }
    } catch (error) {
      alert("There is a problem with the server");
    } finally {
      setEditToggle(false);
      forms.search.init();
      await getRechargeBankSet(forms.search.inputs);
    }
  };
  const edit: TNewBankSet = {
    toggle: editToggle,
    onToggle: (payload: TRechargeBankSet) => {
      if (!editToggle) setBankSet(payload);
      setEditToggle(!editToggle);
    },
    onSubmit: onEditSubmit,
  };

  return (
    <BankSetList
      _new={_new}
      edit={edit}
      onSearch={onSearch}
      rechargeBankSetPage={rechargeBankSetPage}
      forms={forms}
      bankSet={bankSet}
    />
  );
};

export default inject(({ rechargeStore }: RootStore) => ({
  getRechargeBankSet: rechargeStore.getRechargeBankSet,
  rechargeBankSetPage: rechargeStore.rechargeBankSetPage,
  createBankSet: rechargeStore.createBankSet,
  setBankSet: rechargeStore.setBankSet,
  bankSet: rechargeStore.bankSet,
  modifyBankSet: rechargeStore.modifyBankSet,
}))(observer(BankSetContainer));
