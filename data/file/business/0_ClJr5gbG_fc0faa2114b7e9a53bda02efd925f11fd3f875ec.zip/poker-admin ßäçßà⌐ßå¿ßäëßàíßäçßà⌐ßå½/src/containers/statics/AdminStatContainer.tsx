import AdminStatList from "components/statics/adminStat/AdminStatList";
import { useInputs } from "lib/hooks";
import { inject, observer } from "mobx-react";
import React, { useEffect } from "react";
import RootStore from "stores";
import {
  TAdminStatForms,
  TAdminStatPage,
  TAdminStatSearch,
} from "stores/statistics/types";

interface Props {
  adminStatPage: TAdminStatPage;
  getAdminStatPage: (payload: TAdminStatSearch) => void;
}

const AdminStatContainer = ({ adminStatPage, getAdminStatPage }: Props) => {
  const forms = {
    search: useInputs({
      start_date: "",
      end_date: "",
      page: 1,
    } as TAdminStatSearch),
  } as TAdminStatForms;

  useEffect(() => {
    (async () => {
      await getAdminStatPage(forms.search.inputs);
    })();
  }, []);

  const onSearch = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    await getAdminStatPage(forms.search.inputs);
  };

  return (
    <AdminStatList
      adminStatPage={adminStatPage}
      onSearch={onSearch}
      forms={forms}
    />
  );
};

export default inject(({ staticStore }: RootStore) => ({
  adminStatPage: staticStore.adminStatPage,
  getAdminStatPage: staticStore.getAdminStatPage,
}))(observer(AdminStatContainer));
