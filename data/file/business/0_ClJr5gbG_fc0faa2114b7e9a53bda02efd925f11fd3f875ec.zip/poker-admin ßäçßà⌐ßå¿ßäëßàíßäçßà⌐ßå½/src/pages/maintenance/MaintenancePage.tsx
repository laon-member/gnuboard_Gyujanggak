import React from "react";

import { Route, NavLink, Switch } from "react-router-dom";
import { ContainerWrapper, SubNavContainer } from "pages/member/MemberPage";
import AdminSetListContainer from "containers/adminSet/AdminSetListContainer";
import ShowAppVersionContainer from "containers/appVersion/ShowAppVersionContainer";
// import serviceBulletinsContainer from "containers/maintenance/ServiceBulletinsContainer";
// import IpMessageContaner from "containers/maintenance/IpMessageContaner";
// import ShowServerVersionContainer from "containers/maintenance/ShowServerVersionContainer";

function MemberPage() {
  return (
    <>
      <SubNavContainer>
        {/* <li>
          <NavLink exact to="/maintenance" activeClassName="active">
            ServiceBulletins
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/maintenance/ip" activeClassName="active">
            IpMessage
          </NavLink>
        </li>
        <li>
          <NavLink
            exact
            to="/maintenance/version"
            activeClassName="active"
          >
            ShowServerVersion
          </NavLink>
        </li> */}
        <li>
          <NavLink exact to="/admin/maintenance" activeClassName="active">
            Set
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/admin/maintenance/app" activeClassName="active">
            ShowAppVersion
          </NavLink>
        </li>
      </SubNavContainer>
      <ContainerWrapper>
        <Switch>
          {/* <Route
            exact
            path="/maintenance"
            component={serviceBulletinsContainer}
          />
          <Route
            exact
            path="/maintenance/ip"
            component={IpMessageContaner}
          />
          <Route
            exact
            path="/maintenance/version"
            component={ShowServerVersionContainer}
          /> */}
          <Route
            exact
            path="/admin/maintenance"
            component={AdminSetListContainer}
          />
          <Route
            exact
            path="/admin/maintenance/app"
            component={ShowAppVersionContainer}
          />
        </Switch>
      </ContainerWrapper>
    </>
  );
}

export default MemberPage;
