﻿using Photon.Realtime;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerWait_Co : MonoBehaviour
{
    RoomPosition RoomPos;

    Player WPlayer;

    public void StartCo_PlayerWait(Player player, RoomPosition roomPos)
    {
        RoomPos = roomPos;
        WPlayer = player;

        StartCoroutine("Co_Wait");
    }

    IEnumerator Co_Wait()
    {
        WaitForSeconds wfsTime = CWFS.WFS(1.0f);
        for (int i = 1; i < 11; i++) // 나간 시간 대기
        {
            yield return wfsTime;
        }

        for (int i = 0; i < RoomPos.Arr_Players.Length; i++)
        {
            if (RoomPos.Arr_Players[i] != null)
            {
                if (RoomPos.Arr_Players[i].Info.ActorNumber == WPlayer.ActorNumber)
                {
                    RoomPos.Arr_Players[i].gameObject.SetActive(false);
                    break;
                }
            }
        }

        WPlayer.CustomProperties["IsDealer"] = false;
        WPlayer.CustomProperties["IsWatch"] = false;

        Destroy(this.gameObject);
    }

    public void StopCo_PlayerWait()
    {
        StopCoroutine("Co_Wait");
        Destroy(this.gameObject);
    }

    public Player GetPlayer()
    {
        return WPlayer;
    }
}
