import JackpotEditBox from "components/game/jackpotList/JackpotEditBox";
import { EditBoxType } from "components/member/memberlist/types";
import React from "react";
import { JackpotInfo, PolicyType } from "stores/jackpot/types";
import { UseInput } from "stores/notice/types";

interface Props {
  type: EditBoxType;
  policyForm: UseInput;
  jackpotInfo: JackpotInfo;
  policyInfo: PolicyType[];
}

function JackpotEditBoxContainer({
  type,
  policyForm,
  jackpotInfo,
  policyInfo,
}: Props) {
  return (
    <JackpotEditBox
      type={type}
      policyForm={policyForm}
      jackpotInfo={jackpotInfo}
      policyInfo={policyInfo}
    />
  );
}

export default JackpotEditBoxContainer;
