import { PagingType } from "stores/message/types";
import { UseInput } from "stores/notice/types";

export interface TMember {
  id: number;
  username: string;
  name: string;
  phone: string;
  agent: string;
  amount: number;
  created_at: string;
  last_login: string;
  bank: string;
  bankName: string;
  bankNumber: string;
  block_note?: any;
  platform: string;
  status: number;
  location: string;
};

export interface TMemberListSearch {
  username: string;
  nickname: string;
  date_type: string;
  start_date: string;
  end_date: string;
  page: number;
}

export interface TMemberListPage {
  paging: PagingType;
  users: TMember[];
}

export interface TMemberListForms {
  search: UseInput;
}