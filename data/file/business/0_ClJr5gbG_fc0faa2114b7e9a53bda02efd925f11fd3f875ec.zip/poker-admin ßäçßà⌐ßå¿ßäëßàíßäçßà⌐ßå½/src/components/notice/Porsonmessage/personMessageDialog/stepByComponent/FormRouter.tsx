import React, { Component } from "react";
import EnterMessageContainer from "./EnterMessageContainer";
import SelectUserListContainer from "./SelectUserListContainer";
import { inject, observer } from "mobx-react";
import NoticeStore from "stores/notice";

interface Props {
  noticeStore?: NoticeStore;
  step: number;
  onIncrease: () => void;
  onCreateToggle: () => void;
}

@inject("noticeStore")
@observer
class FormRouter extends Component<Props> {
  private NoticeStore = this.props.noticeStore! as NoticeStore;

  render() {
    const { step, onIncrease, onCreateToggle } = this.props;
    switch (step) {
      case 1:
        return (
          <SelectUserListContainer
            onIncrease={onIncrease}
            onCreateToggle={onCreateToggle}
          />
        );
      case 2:
        return <EnterMessageContainer onCreateToggle={onCreateToggle} />;
      default:
        return <h1>Error</h1>;
    }
  }
}

export default FormRouter;
