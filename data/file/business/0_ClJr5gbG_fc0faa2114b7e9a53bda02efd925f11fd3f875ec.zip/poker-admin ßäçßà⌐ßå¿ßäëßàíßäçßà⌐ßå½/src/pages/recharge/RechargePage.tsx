import React from "react";

import { Route, NavLink, Switch } from "react-router-dom";
import { ContainerWrapper, SubNavContainer } from "pages/member/MemberPage";
import ApplyListContainer from "containers/recharge/ApplyListContainer";
import RechargeLogContainer from "containers/recharge/RechargeLogContainer";
import BankSetContainer from "containers/recharge/BankSetContainer";

function MemberPage() {
  return (
    <>
      <SubNavContainer>
        <li>
          <NavLink exact to="/admin/recharge" activeClassName="active">
            ApplyList
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/admin/recharge/log" activeClassName="active">
            RechargeLog
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/admin/recharge/bank" activeClassName="active">
            BankSet
          </NavLink>
        </li>
      </SubNavContainer>
      <ContainerWrapper>
        <Switch>
          <Route exact path="/admin/recharge" component={ApplyListContainer} />
          <Route
            exact
            path="/admin/recharge/log"
            component={RechargeLogContainer}
          />
          <Route
            exact
            path="/admin/recharge/bank"
            component={BankSetContainer}
          />
        </Switch>
      </ContainerWrapper>
    </>
  );
}

export default MemberPage;
