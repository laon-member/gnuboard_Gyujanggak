﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class JackPotNumber : MonoBehaviour
{
    public bool StartSpin = false;
    bool IsSpin = false;

    float SpinSpeed = 10.0f;

    int TargetNum = 0;

    Transform Tr;

    // Start is called before the first frame update
    void Start()
    {
        if(Tr == null)
        {
            Tr = transform;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(StartSpin)
        {
            Tr.localPosition = new Vector2(Tr.localPosition.x, Tr.localPosition.y + SpinSpeed);

            if(Tr.localPosition.y >= 360)
            {
                Tr.localPosition = new Vector2(Tr.localPosition.x, 0);
            }
        }
        else
        {
            if (IsSpin)
            {
                Tr.localPosition = new Vector2(Tr.localPosition.x, Tr.localPosition.y + SpinSpeed * 3);
            }

            if (Tr.localPosition.y >= 370)
            {
                Tr.localPosition = new Vector2(Tr.localPosition.x, 0);
                IsSpin = false;

                FindTargetNum();
            }
        }
    }

    void FindTargetNum()
    {
        Tr.DOLocalMoveY(0 + (40 * TargetNum), 1.0f).SetEase(Ease.OutQuint);
    }

    public void StartSpinNumber(int targetNum)
    {
        StartSpin = true;
        IsSpin = true;
        TargetNum = targetNum;
    }

    public void StopSpinNumber()
    {
        StartSpin = false;
    }
}
