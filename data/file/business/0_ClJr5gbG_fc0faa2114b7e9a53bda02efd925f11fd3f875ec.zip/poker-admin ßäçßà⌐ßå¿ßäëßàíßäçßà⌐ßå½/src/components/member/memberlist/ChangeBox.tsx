import { InputWrapper } from "components/deposit/Bankset/Bankset";
import { DialogContainer } from "containers/common/dialog";
import React, { useEffect } from "react";
import { MemberType, TEditMember } from "stores/member/types";
import { UseInput } from "stores/notice/types";
import { Input } from "styles/atom";

interface Props {
  onInfoToggle: () => void;
  onInfoSubmit: (
    e: React.FormEvent<HTMLFormElement>,
    modifyMember?: MemberType
  ) => void;
  member?: MemberType;
  form: UseInput;
}

export function ChangeBox({ member, onInfoToggle, onInfoSubmit, form }: Props) {
  useEffect(() => {
    form.setInputs({
      ...member,
      password: "",
      check_password: "",
    });
  }, []);
  const { onChange } = form;
  const {
    bank,
    bankName,
    bankNumber,
    phone,
    password,
    check_password,
  } = form.inputs as TEditMember;
  return (
    <DialogContainer
      title="Change Box"
      confirmText="SAVE"
      onToggle={onInfoToggle}
      onSubmit={(e) => onInfoSubmit(e, form.inputs)}
    >
      <InputWrapper>
        <label>ID</label>
        <Input placeholder="ID" value={member!.id} disabled />
      </InputWrapper>
      <InputWrapper>
        <label>NickName</label>
        <Input placeholder="NickName" value={member!.name} disabled />
      </InputWrapper>
      <InputWrapper>
        <label>CardNumer</label>
        <Input
          placeholder="CardNumber"
          name="bankNumber"
          value={bankNumber}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>BankName</label>
        <Input
          name="bank"
          value={bank}
          onChange={onChange}
          placeholder="BankName"
        />
      </InputWrapper>
      <InputWrapper>
        <label>BankAccount</label>
        <Input
          placeholder="BankAccount"
          name="bankName"
          value={bankName}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Mobile</label>
        <Input
          placeholder="Mobile"
          name="phone"
          value={phone}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Password</label>
        <Input
          placeholder="Password"
          name="password"
          value={password}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>PasswordCheck</label>
        <Input
          placeholder="PasswordCheck"
          name="check_password"
          value={check_password}
          onChange={onChange}
        />
      </InputWrapper>
    </DialogContainer>
  );
}

export default ChangeBox;
