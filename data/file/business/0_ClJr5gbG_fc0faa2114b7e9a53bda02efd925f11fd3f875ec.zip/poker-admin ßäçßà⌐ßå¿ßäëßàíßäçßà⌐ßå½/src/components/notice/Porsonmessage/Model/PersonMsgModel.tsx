/* eslint-disable no-restricted-globals */
import React, { useState } from "react";
import Modal from "components/common/Modal";
import SendMessage from "components/modal/SendMessage";
import SendMessageDetail from "components/modal/SendMessageDetail";
interface Props {
  setChildModal: (e: boolean) => void;
}
//메세지 모달 만드는곳
function PersonMsgModel({ setChildModal }: Props) {
  // const [selected, setSelected] = useState<number>();

  const [next, setNext] = useState<boolean>(false);
  // const selectUser = (id: number) => {
  //   if (selected === id) {
  //     setSelected(undefined);
  //   } else {
  //     setSelected(id);
  //   }
  // };

  return (
    <>
      <Modal
        onClose={() => {
          setChildModal(false);
        }}
      >
        {!next ? <SendMessage setNext={setNext} /> : <SendMessageDetail />}
      </Modal>
      {/* <Wrap>
        <Modal
          onClose={() => {
            setChildModal(false);
          }}
        >
          <SendMessage setModal={setModal} />
        </Modal>

        {detailModal && (
          <Modal
            onClose={() => {
              setDetailModal(false);
            }}
          >
            <SendMessageDetail />
          </Modal>
        )}
      </Wrap> */}
    </>
  );
}

export default PersonMsgModel;
