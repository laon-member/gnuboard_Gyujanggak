import React, { useState } from "react";
import { Button } from "styles/atom";
import Table from "components/common/Table";
import { Create } from "./dialog";
import { AdminType } from "stores/admin/types";
import EditRow from "./edit/EditRow";
import { SearchWrapper } from "components/deposit/Bankset/Bankset";

interface Props {
  adminList: AdminType[];
  onCreateAccount: (id: string, password: string) => void;
  onEditAccout: (id: string, password: string) => void;
  // adminId: string;
  onDeleteAccount: (id: number) => void;
}

const AdminAccount = ({
  adminList,
  onCreateAccount,
  // adminId,
  onEditAccout,
  onDeleteAccount,
}: Props) => {
  const [createToggle, setCreateToggle] = useState(false);
  const [editToggle, setEditToggle] = useState(false);
  const [deleteToggle, setDeleteToggle] = useState(false);

  const onToggle = (type: string) => {
    switch (type) {
      case "create":
        return setCreateToggle(!createToggle);
      case "edit":
        return setEditToggle(!editToggle);
      case "delete":
        return setDeleteToggle(!deleteToggle);
      default:
        break;
    }
  };

  const onDelete = (id: string) => {
    // eslint-disable-next-line no-restricted-globals
    const isDelete = confirm("Are you sure delete to the account?");
    if (isDelete) onDeleteAccount(parseInt(id, 10));
  };
  // if (!adminList) return <h1>loading...</h1>;
  return (
    <>
      <SearchWrapper>
        <Button onClick={() => onToggle("create")}>CREATE</Button>
      </SearchWrapper>
      {createToggle && (
        <Create
          title="CREATE ADMIN ACCOUNT"
          onToggle={() => onToggle("create")}
          onCreateAccount={onCreateAccount}
        />
      )}
      {/* {editToggle && (
        <Edit
          title="EDIT ADMIN ACCOUNT"
          onToggle={() => onToggle("edit")}
          // adminId={adminId}
          onEditAccout={onEditAccout}
        />
      )} */}
      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>ID</th>
            <th>Password</th>
            <th>Password check</th>
            <th>Otp</th>
          </tr>
        </thead>
        <tbody>
          {adminList.map((admin) => (
            <EditRow
              key={admin.id}
              onDelete={onDelete}
              onEditAccout={onEditAccout}
              admin={admin}
            />
          ))}
        </tbody>
      </Table>
    </>
  );
};

export default AdminAccount;
