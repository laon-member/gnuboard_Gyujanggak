import PersonMessageList from "components/message/personMessage/PersonMessageList";
import { useInputs } from "lib/hooks";
import { inject, observer } from "mobx-react";
import React, { useEffect } from "react";
import { PM, SearchPMType } from "stores/message/types";

interface Props {
  PMList: PM;
  getPMList: (payload: SearchPMType) => void;
}

const PersonMessageListContainer = ({ getPMList, PMList }: Props) => {
  const { inputs, onChange } = useInputs({
    username: "",
    start_date: "",
    end_date: "",
    sender: "",
    page: 1,
  } as SearchPMType);

  useEffect(() => {
    getPMList(inputs);
  }, []);

  const onSearch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    getPMList(inputs);
  };

  return (
    <PersonMessageList
      PMList={PMList}
      searchForm={{ inputs, onChange }}
      onSearch={onSearch}
    />
  );
};

export default inject(({ messageStore }) => ({
  PMList: messageStore.PMList,
  getPMList: messageStore.getPMList,
}))(observer(PersonMessageListContainer));
