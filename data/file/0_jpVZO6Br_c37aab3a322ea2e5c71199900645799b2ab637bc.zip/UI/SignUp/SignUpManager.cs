﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;
using TMPro;
using LitJson;
using Leguar.TotalJSON;

public class req_signup
{
    public string uid;
}

public class SignUpManager : MonoBehaviour
{
    public InputField ReferrerField;
    public InputField IDField;
    public InputField PasswordField;
    public InputField Confirm_PasswordField;
    public InputField ContactField;
    public InputField AccountHolderField;
    public InputField NameOfBankField;
    public InputField Account_NumberField;

    [System.Serializable]
    public struct SButtons
    {
        public Image[] Pop_SelectGender;
    }
    public SButtons Btns;

    public Image ProfileImg;

    public Sprite[] BtnChoiceImg;

    // Input
    public Guidance PopUp;
    public InputField[] Fields;


    // PopUp
    [Header("PopUp")]
    public GameObject PopUp_SelectImg;

    public Transform[] SelectImgBox;

    int Gender = 0;
    string ImgFilePath;

    DataBaseManager DBMgr;

    bool SignUpResult = false;

    // Start is called before the first frame update
    void Start()
    {
        if(DBMgr == null)
        {
            DBMgr = FindObjectOfType<DataBaseManager>();
        }

        SetSprite(ProfileImg, "p_0_0");

        Gender = 0;

        //popup select img
        Btns.Pop_SelectGender[Gender].sprite = BtnChoiceImg[1];

        for (int i = 0; i < SelectImgBox[Gender].childCount; i++)
        {
            string fileName = "";

            fileName = "p_0_" + i.ToString();

            SetSprite(SelectImgBox[Gender].GetChild(i).GetComponent<Image>(), fileName);
            SelectImgBox[Gender].GetChild(i).gameObject.name = "p_" + Gender.ToString() + "_" + i.ToString();
        }

        for (int i = 0; i < SelectImgBox[Gender].childCount; i++)
        {
            if (SelectImgBox[Gender].GetChild(i).gameObject.name == "p_0_0")
            {
                SelectImgBox[Gender].GetChild(i).localScale = new Vector3(1.14f, 1.16f, 1);
                break;
            }
        }
    }

    // 팝업
    public void OnClickBtn_ProfileImg()
    {
        SelectImgBox[Gender].gameObject.SetActive(true);

        //popup select img
        Btns.Pop_SelectGender[Gender].sprite = BtnChoiceImg[1];

        for (int i = 0; i < SelectImgBox[Gender].childCount; i++)
        {
            string fileName = "";

            fileName = "p_" + LocalPlayerInfo.Instance.Gender.ToString() + "_" + i.ToString();

            SetSprite(SelectImgBox[Gender].GetChild(i).GetComponent<Image>(), fileName);
            SelectImgBox[Gender].GetChild(i).gameObject.name = "p_" + Gender.ToString() + "_" + i.ToString();
        }

        for (int i = 0; i < SelectImgBox[Gender].childCount; i++)
        {
            if (SelectImgBox[Gender].GetChild(i).gameObject.name == ProfileImg.sprite.name)
            {
                SelectImgBox[Gender].GetChild(i).localScale = new Vector3(1.14f, 1.16f, 1);
                break;
            }
        }

        PopUp_SelectImg.SetActive(true);
    }

    void SetSprite(Image img, string fileName)
    {
        img.sprite = Resources.Load<Sprite>("Sprites/Profiles/" + fileName);
    }
    public void OnClickBtn_ClickSound()
    {
        FindObjectOfType<SoundManager>().StartSound_Effect(SoundFileList.EFFECT.btn_click);
    }
    public void OnClickBtn_SelectImage()
    {
        if (EventSystem.current.currentSelectedGameObject.transform.localScale == Vector3.one)
        {
            for (int i = 0; i < SelectImgBox[Gender].childCount; i++)
            {
                SelectImgBox[Gender].GetChild(i).transform.localScale = Vector3.one;
            }

            if (Gender == 0)
            {
                for (int i = 0; i < SelectImgBox[1].childCount; i++)
                {
                    SelectImgBox[1].GetChild(i).localScale = Vector3.one;
                }
            }
            else
            {
                for (int i = 0; i < SelectImgBox[0].childCount; i++)
                {
                    SelectImgBox[0].GetChild(i).localScale = Vector3.one;
                }
            }

            ImgFilePath = EventSystem.current.currentSelectedGameObject.GetComponent<Image>().sprite.name;
            EventSystem.current.currentSelectedGameObject.transform.localScale = new Vector3(1.14f, 1.16f, 1);
        }
    }

    public void OnClickBtn_SelectGender(int gender)
    {
        if (gender == 0)
        {
            Btns.Pop_SelectGender[0].sprite = BtnChoiceImg[1];
            Btns.Pop_SelectGender[1].sprite = BtnChoiceImg[0];
            SelectImgBox[0].gameObject.SetActive(true);
            SelectImgBox[1].gameObject.SetActive(false);
        }
        else
        {
            Btns.Pop_SelectGender[0].sprite = BtnChoiceImg[0];
            Btns.Pop_SelectGender[1].sprite = BtnChoiceImg[1];
            SelectImgBox[0].gameObject.SetActive(false);
            SelectImgBox[1].gameObject.SetActive(true);
        }

        for (int i = 0; i < SelectImgBox[gender].childCount; i++) // 이미지 있는 칸
        {
            string fileName = "";

            fileName = "p_" + gender.ToString() + "_" + i.ToString();

            SetSprite(SelectImgBox[gender].GetChild(i).GetComponent<Image>(), fileName);
        }

        Gender = gender;
    }

    public void OnClickBtn_PopUpClose(bool result)
    {
        foreach (var item in Btns.Pop_SelectGender)
        {
            item.sprite = BtnChoiceImg[0];
        }

        for (int i = 0; i < SelectImgBox.Length; i++)
        {
            for (int j = 0; j < SelectImgBox[i].childCount; j++)
            {
                SelectImgBox[i].GetChild(j).localScale = Vector3.one;
            }
        }

        if (!result)
        {
            //ImgFilePath = "";
            Gender = LocalPlayerInfo.Instance.Gender;
        }
        else
        {
            LocalPlayerInfo.Instance.ProfileImgFilePath = ImgFilePath;
            LocalPlayerInfo.Instance.Gender = Gender;

            SetSprite(ProfileImg, ImgFilePath);
        }

        for (int i = 0; i < SelectImgBox.Length; i++)
        {
            SelectImgBox[i].gameObject.SetActive(false);
        }

        PopUp_SelectImg.SetActive(false);
    }

    public void OnClickBtn_OK()
    {
        // 빈칸 체크
        bool isEmpty = false;

        int idx = 0;

        for (int i = 0; i < Fields.Length; i++)
        {
            if (Fields[i].text.Length <= 0)
            {
                isEmpty = true;
                idx = i;
                break;
            }
        }

        if(isEmpty)
        {
            PopUp.SetText("Xin vui lòng nhập vào chỗ trống");
        }
        else
        {
            // 회원가입 정보 서버로 보내기
            if(Fields[1].text == Fields[2].text)
            {
                SignUp();
            }
            else
            {
                PopUp.SetText("Mật khẩu khác nhau"); // 번역 : 비밀번호가 다릅니다. o
            }
        }
    }

    void SignUp()
    {
        JSON jsonData = new JSON();
        jsonData.Add("username", Fields[0].text);
        jsonData.Add("password", Fields[1].text);
        jsonData.Add("phone", Fields[3].text);
        jsonData.Add("name", Fields[4].text);
        jsonData.Add("bank", Fields[5].text);
        jsonData.Add("number", Fields[6].text);
        jsonData.Add("profile_img", ProfileImg.sprite.name);
        jsonData.Add("account_holder", Fields[4].text);
        jsonData.Add("gender", Gender);

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.SingUp, jsonData.CreateString(), "post", "", (result) =>
        {
            if (result != "Not Found")
            {
                JsonData responeseResult = JsonMapper.ToObject(result);

                if ((int)responeseResult["result"] == 0)
                {
                    PopUp.SetText("Đã có người dùng đăng ký");
                    SignUpResult = false;
                }
                else
                {
                    PopUp.SetText("Hoàn thành gia nhập thành viên"); // 번역 : 회원가입 완료 o
                    SignUpResult = true;
                }
            }
        }));
    }

    //UI

    public void OnClickBtn_PopUp_OK()
    {
        PopUp.gameObject.SetActive(false);

        if(SignUpResult)
        {
            SceneManager.LoadScene("Login");
        }
    }

    public void OnClickBtn_Reset()
    {
        foreach (var item in Fields)
        {
            item.text = "";
        }
    }

    public void OnClickBtn_Leave()
    {
        SceneManager.LoadScene("Login");
    }
}
