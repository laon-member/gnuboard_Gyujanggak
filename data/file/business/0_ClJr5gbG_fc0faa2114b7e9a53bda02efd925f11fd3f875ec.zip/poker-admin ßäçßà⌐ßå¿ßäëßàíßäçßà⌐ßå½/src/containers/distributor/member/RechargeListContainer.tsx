import RechargeList from "components/distributor/member/recharge/RechargeList";
import React from "react";

function RechargeListContainer() {
  return <RechargeList />;
}

export default RechargeListContainer;
