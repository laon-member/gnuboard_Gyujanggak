﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Photon.Pun;
using Photon.Realtime;
using LitJson;
using Leguar.TotalJSON;
using UnityEngine.EventSystems;
using DG.Tweening;

public class LoginManager : MonoBehaviourPunCallbacks
{
    public Button ConnectBtn;

    private const string GameVersion = "0.0.6";
    private string ServerGameVersion;

    public Guidance PopUp;
    public InputField[] Fields; // 0 = id, 1 = pw

    public GameObject Loading;

    public GameObject ClickPanel;

    public GameObject[] Girls;

    public Guidance Popup_Quit;

    public GameObject Popup_VersionUpdate;

    SoundManager Sound;
    DataBaseManager DBMgr;

    bool IsActive_GameVersionUpdate = false;

    string IsAndroidPlatform = ""; // 0 = other, 1 = android

    private void Awake()
    {
        Screen.sleepTimeout = SleepTimeout.NeverSleep;

        if(Application.platform == RuntimePlatform.WebGLPlayer)
        {
            Screen.SetResolution(1980, 1080, true);
        }
        else if(Application.platform == RuntimePlatform.WindowsPlayer)
        {
            Screen.SetResolution(900, 520, false);
        }
        else
        {
            Screen.SetResolution(1980, 1080, false);
        }

        if(Application.platform == RuntimePlatform.Android)
        {
            IsAndroidPlatform = "ANDROID";
        }

        if (FindObjectsOfType<SoundManager>().Length > 1)
        {
            Destroy(FindObjectsOfType<SoundManager>()[1].gameObject);
            Destroy(FindObjectsOfType<DataBaseManager>()[1].gameObject);
        }

        if (Sound == null)
        {
            Sound = FindObjectOfType<SoundManager>();
            DBMgr = FindObjectOfType<DataBaseManager>();
        }

        // DB 서버에서 버전 받아오기
        DBMgr.Post(DataBaseLinkList.Instance.GetGameVersion, "", "Post", "", (result)=>{

            if (result == "NetworkError")
            {
                PopUp.SetText("Không thể kết nối mạng"); // 번역 : 네트워크 연결 실패 o
                return;
            }

            if (result != "Not Found")
            {
                JsonData resp = JsonMapper.ToObject(result);

                if ((int)resp["result"] == 1)
                {
                    ServerGameVersion = (string)resp["version"]["version"];

                    if (ServerGameVersion != GameVersion)
                    {
                        IsActive_GameVersionUpdate = true;
                        Popup_VersionUpdate.SetActive(true);
                    }
                }
            }
            else
            {
                PopUp.SetText("Không thể kết nối mạng");

                ConnectBtn.interactable = true;
                ClickPanel.SetActive(false);
            }

        });

        LocalPlayerInfo.Instance.ShowPopUpNotice = false;

        LocalPlayerInfo.Instance.QuitWait = false;
        LocalPlayerInfo.Instance.InRoom = false;

        int ranGirl = Random.Range(0, 2);

        Girls[ranGirl].SetActive(true);

        PhotonNetwork.LogLevel = PunLogLevel.ErrorsOnly;

        PhotonNetwork.AutomaticallySyncScene = true;
    }

    // Start is called before the first frame update
    void Start()
    {
        PhotonNetwork.KeepAliveInBackground = 0.0f;
        
        LocalPlayerInfo.Instance.SetProfile = false;
        LocalPlayerInfo.Instance.IsLogined = false;

        PlayerPrefs.SetInt("ReflashRoom", 0);

        DBMgr.StopSendLogined();

        if (PlayerPrefs.GetString("GameSound").Length == 0)
        {
            PlayerPrefs.SetString("GameSound", "0");
            PlayerPrefs.SetString("BGM", "0");

            Sound.SetBGMSound(SoundFileList.BGM.MAIN);
        }

        if(PlayerPrefs.GetInt("AutoLogin") == 1)
        {
            Fields[0].text = PlayerPrefs.GetString("UserID");
            Fields[1].text = PlayerPrefs.GetString("UserPW");

            OnClickBtn_Connect();
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.KeypadEnter) || Input.GetKeyDown(KeyCode.Return))
        {
            OnClickBtn_Connect();
        }

        if(Application.platform == RuntimePlatform.Android)
        {
            if(Input.GetKey(KeyCode.Escape) && !IsActive_GameVersionUpdate)
            {
                Popup_Quit.gameObject.SetActive(true);
            }
        }
    }

    void Connect()
    {
        //게임 버전 확인
        Loading.SetActive(true);

        PhotonNetwork.GameVersion = GameVersion;

        if (PhotonNetwork.IsConnectedAndReady)
        {
            PhotonNetwork.JoinLobby();
        }
        else
        {
            //PhotonNetwork.ConnectToRegion("kr;asia");
            PhotonNetwork.ConnectUsingSettings();
            //PhotonNetwork.ConnectToBestCloudServer();
            //PhotonNetwork.ConnectToRegion("asia");
        }
    }

    public override void OnConnectedToMaster()
    {
        //마스터 서버에 연결되었으면 입장 버튼 활성화    
        ConnectBtn.interactable = true;
        ClickPanel.SetActive(false);
        
        LocalPlayerInfo.Instance.IsLogined = true;

        //DBMgr.StartSendLogined();

        //PlayerPrefs.SetInt("AutoLogin", 1);
        PlayerPrefs.SetString("UserID", Fields[0].text);
        PlayerPrefs.SetString("UserPW", Fields[1].text);

        SceneManager.LoadScene("Lobby");
    }

    public override void OnDisconnected(DisconnectCause cause)
    {
        //마스터 서버에 연결에 실패시
        //ConnectBtn.interactable = false;

        PhotonNetwork.ConnectUsingSettings();
    }
    public void OnClickBtn_Connect()
    {
        ConnectBtn.interactable = false;
        ClickPanel.SetActive(true);

        bool login = true;

        bool idEmpty = true;
        bool pwEmpty = true;

        // id pw 체크
        // id 체크
        if (Fields[0].text.Length > 0)
        {
            idEmpty = false;
        }

        if(Fields[1].text.Length > 0)
        {
            pwEmpty = false;
        }

        if (idEmpty && pwEmpty)
        {
            PopUp.SetText("Xin vui lòng nhập vào chỗ trống"); // 번역 : 빈칸을 입력해 주세요 o

            ConnectBtn.interactable = true;
            ClickPanel.SetActive(false);
            login = false;
        }

        if (login)
        {
            Login();
        }
    }

    void Login()
    {
        //FindObjectOfType<CSocketConnect>().ConnectServer();

        JSON jsonData = new JSON();
        jsonData.Add("username", Fields[0].text);
        jsonData.Add("password", Fields[1].text);
        jsonData.Add("platform", IsAndroidPlatform);

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.Login, jsonData.CreateString(), "Post", "", (result) =>
        {
            if(result == "NetworkError")
            {
                PopUp.SetText("Không thể kết nối mạng"); // 번역 : 네트워크 연결 실패 o
                ConnectBtn.interactable = true;
                ClickPanel.SetActive(false);
                return;
            }

            if (result != "Not Found")
            {
                JsonData responeseResult = JsonMapper.ToObject(result);

                if((int)responeseResult["result"] == 1)
                {
                    if ((int)responeseResult["data"]["status"] == 0)
                    {
                        if((int)responeseResult["data"]["blocked"] == 0)
                        {
                            PlayerPrefs.SetString("Token", (string)responeseResult["data"]["access_token"]);
                            Connect();
                        }
                        else
                        {
                            PopUp.SetText("Đây là tài khoản đã bị chặn. Xin vui lòng liên hệ đến trung tâm khách hàng"); // 번역 : 차단된 계정입니다. 관리자에게 문의해주세요 연락처 010-0000-0000
                            ConnectBtn.interactable = true;
                            ClickPanel.SetActive(false);
                        }
                    }
                    else
                    {
                        PopUp.SetText("đây là tài khoản đã được đăng nhập từ trước. Xin vui lòng chờ một chút và thử lại"); // 번역 : 이미 로그인된 계정입니다. 잠시후 다시 시도 해주세요.
                        ConnectBtn.interactable = true;
                        ClickPanel.SetActive(false);
                    }
                }
                else
                {
                    PopUp.SetText("Xin vui lòng nhập ID, PW"); // 번역 : ID, PW 를 확인 해 주세요. o

                    ConnectBtn.interactable = true;
                    ClickPanel.SetActive(false);
                }
            }
            else
            {
                PopUp.SetText("Không thể kết nối mạng");

                ConnectBtn.interactable = true;
                ClickPanel.SetActive(false);
            }
        }));
    }

    //UI
    public void OnClickBtn_ClickSound()
    {
        Sound.StartSound_Effect(SoundFileList.EFFECT.btn_click);
    }
    public void OnClickBtn_PopUp_OK()
    {
        PopUp.gameObject.SetActive(false);
    }

    public void OnClickBtn_SignUp()
    {
        SceneManager.LoadScene("SignUp");
    }

    public void OnClickBtn_ForgetPassword()
    {
        SceneManager.LoadScene("FindAccount");
    }

    public void OnClickBtn_CheckAutoLogin()
    {
        if (PlayerPrefs.GetInt("AutoLogin") == 1) // 자동 로그인
        {
            PlayerPrefs.SetInt("AutoLogin", 0);

            EventSystem.current.currentSelectedGameObject.transform.GetChild(0).GetChild(0).gameObject.SetActive(false);
        }
        else
        {
            PlayerPrefs.SetInt("AutoLogin", 1);

            //Slider slider = EventSystem.current.currentSelectedGameObject.transform.GetChild(1).GetComponent<Slider>();
            //slider.transform.GetChild(1).GetChild(1).gameObject.SetActive(true);
            //slider.DOValue(1.0f, 0.25f);
            EventSystem.current.currentSelectedGameObject.transform.GetChild(0).GetChild(0).gameObject.SetActive(true);
        }

        PlayerPrefs.Save();
    }

    public void OnClickBtn_VersionUpdate()
    {
        Application.OpenURL("Http://sean.oig.kr:2113");
    }
}
