import React, { Component } from "react";
import {
  Switch,
  Route,
  RouteComponentProps,
  withRouter,
  Redirect,
} from "react-router-dom";

import {
  AgentPage,
  // AgentPage,
  GamePage,
  MaintenancePage,
  MemberPage,
  MessagePage,
  NoticePage,
  RechargePage,
  StaticsPage,
  WithdrawPage,
} from "pages";
import HeaderContainer from "containers/header";
import { inject, observer } from "mobx-react";
import userStore from "stores/user";
import AgentMemberPage from "pages/distributor/member/AgentMemberPage";
import AgentStatisticsPage from "pages/distributor/statistics/AgentStatisticsPage";

interface Props extends RouteComponentProps {
  userStore: userStore;
}

@inject("userStore")
@observer
class PageRouter extends Component<Props> {
  private userStore = this.props.userStore as userStore;
  componentDidMount() {
    if (!this.userStore.admin && localStorage.getItem("userInfo")) {
      const { id, role } = JSON.parse(localStorage.getItem("userInfo")!);
      if (role === "ADMIN" || role === "SUPER_ADMIN")
        this.userStore.setAdmin(id, role);
      if (role === "AGENT") this.userStore.setAgent(id, role);
    }
    if (!localStorage.getItem("userInfo")) {
      alert("You don't have permission. Please login");
      this.props.history.push("/login");
    }
  }
  render() {
    const { admin, agent } = this.props.userStore;
    return (
      <>
        <HeaderContainer />
        <Switch>
          <Route path="/admin/member" component={MemberPage} />
          <Route path="/admin/statistics" component={StaticsPage} />
          <Route path="/admin/recharge" component={RechargePage} />
          <Route path="/admin/withdraw" component={WithdrawPage} />
          <Route path="/admin/agent" component={AgentPage} />
          <Route path="/admin/game" component={GamePage} />
          <Route path="/admin/notice" component={NoticePage} />
          <Route path="/admin/message" component={MessagePage} />
          <Route path="/admin/maintenance" component={MaintenancePage} />
          <Route path="/agent/member" component={AgentMemberPage} />
          <Route path="/agent/statistics" component={AgentStatisticsPage} />
          {admin && <Redirect path="*" to="/admin/member" />}
          {agent && <Redirect path="*" to="/agent/member" />}
        </Switch>
      </>
    );
  }
}

export default withRouter(PageRouter);
