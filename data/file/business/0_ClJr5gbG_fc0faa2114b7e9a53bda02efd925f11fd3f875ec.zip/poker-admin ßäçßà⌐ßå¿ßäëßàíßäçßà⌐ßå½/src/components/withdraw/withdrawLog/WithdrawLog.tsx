import { TableRowWrapper } from "components/common";
import comma from "lib/comma";
import React from "react";
import { TWithdrawLog } from "stores/withdraw/types";

interface Props {
  log: TWithdrawLog;
}

function WithdrawLog({ log }: Props) {
  return (
    <TableRowWrapper>
      <td>{log.orderNumber}</td>
      <td>{log.username}</td>
      <td>{log.agent}</td>
      <td>{log.phone}</td>
      <td>{comma(log.amount)}</td>
      <td>{log.bankAccount}</td>
      <td>{log.bankName}</td>
      <td>{log.bankNumber}</td>
      <td>{log.applyTime}</td>
      <td>{log.adminName}</td>
      <td>{log.handleTime}</td>
      <td>
        {(log.status === 5 && "Reserved") ||
          (log.status === 1 && "Success") ||
          (log.status === 2 && "Cancel") ||
          (log.status === 0 && "Waiting")}
      </td>
    </TableRowWrapper>
  );
}

export default WithdrawLog;
