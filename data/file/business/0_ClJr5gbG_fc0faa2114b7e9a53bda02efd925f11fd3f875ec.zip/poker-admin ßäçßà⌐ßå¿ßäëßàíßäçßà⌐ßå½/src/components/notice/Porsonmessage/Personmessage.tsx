/* eslint-disable no-restricted-globals */
import React, { useState } from "react";
import SearchIcon from "assets/icons/search.png";
import { NoticeType } from "stores/notice/types";
import PorsonmsgItem from "./item";
import useInputs from "lib/hooks/useInputs";
import Table from "components/common/Table";
import { CreateMessage, RemoveMessage } from "./personMessageDialog";
import { Button, Input } from "styles/atom";
import { SearchWrapper, SearchForm } from "components/deposit/Bankset/Bankset";
import del from "assets/icons/del.png";

interface Props {
  noticeList: NoticeType[];
  onActiveToggle: (id: number) => void;
  activeList: number[];
  onRemove: (list: number[]) => void;
  onSearch: (nickname?: string, date?: string) => void;
}

function Personmessage({
  noticeList,
  onActiveToggle,
  activeList,
  onRemove,
  onSearch,
}: Props) {
  const { inputs, onChange } = useInputs({
    nickname: "",
    date: "",
  });
  const { nickname, date } = inputs;

  const [createToggle, setCreateToggle] = useState(false);
  const [removeToggle, setRemoveToggle] = useState(false);

  const onCreateToggle = () => {
    setCreateToggle(!createToggle);
  };
  const onRemoveToggle = () => {
    setRemoveToggle(!removeToggle);
  };

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onSearch(nickname, date);
  };

  return (
    <>
      {createToggle && <CreateMessage onCreateToggle={onCreateToggle} />}
      {removeToggle && (
        <RemoveMessage
          title="REMOVE MESSAGE"
          onToggle={onRemoveToggle}
          activeList={activeList}
          onRemove={onRemove}
        />
      )}
      <SearchWrapper>
        <Button onClick={onCreateToggle}>CREATE</Button>
        <Button secondary onClick={onRemoveToggle}>
          <img src={del} alt="del" />
        </Button>
        <SearchForm onSubmit={onSubmit} className="search">
          <Input
            name="nickname"
            value={nickname}
            onChange={onChange}
            placeholder="nickname"
            className="mobile"
          />
          <Input
            type="date"
            name="date"
            value={date}
            onChange={onChange}
            placeholder="send time"
            className="righthate"
          />
          <Button>
            <img src={SearchIcon} alt="search" />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Nickname</th>
            <th>Sender</th>
            <th>Content</th>
            <th>ReadingState</th>
            <th>SendingTime</th>
          </tr>
        </thead>
        <tbody>
          {noticeList.map((data, idx) => (
            <PorsonmsgItem
              key={idx}
              onActiveToggle={onActiveToggle}
              data={data}
            />
          ))}
        </tbody>
      </Table>
    </>
  );
}

export default Personmessage;
