import { TableRowWrapper } from "components/common/TableRowWrapper";
import comma from "lib/comma";
import React from "react";
import { TGameLog } from "stores/member/types";
import styled from "styled-components";

interface Props {
  gameLog: TGameLog;
}

function GameLog({ gameLog }: Props) {
  return (
    <TableRowWrapper>
      <td>{gameLog.id}</td>
      <td>{gameLog.username}</td>
      <td>{gameLog.name}</td>
      <td>Lv.{gameLog.room_type}</td>
      <td>{comma(gameLog.bet_amount)}</td>
      <td>{gameLog.mode}</td>
      <td>{getCard(gameLog.my_card)}</td>
      <td>{gameLog.game_time}</td>
      <td>{comma(gameLog.base_amount)}</td>
      <td>{comma(gameLog.result_amount)}</td>
      <td>{gameLog.round}</td>
    </TableRowWrapper>
  );
}

function getCard(card?: string) {
  if (!card) return "Abnormal connection termination";
  const splitCard = card.split(",");
  return splitCard.map((card, idx) => {
    if (card.substring(1, 2) === "/") {
      card = card.replace("/", "_");
    }
    return (
      <CardImage
        key={idx}
        src={require(`../../../assets/cards/${card}.png`)}
        alt=""
      />
    );
  });
}

const CardImage = styled.img`
  width: 46px;
  height: 65px;
  padding: 0.125rem;
  margin-right: 1rem;
  border: 1px solid #a1a1a1;
  border-radius: 3px;
`;

export default GameLog;
