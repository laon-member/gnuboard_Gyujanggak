import React from "react";
import Dialog from "components/common/dialog/Dialog";
import styled from "styled-components";
import { Button } from "styles/atom";

type DialogContainerProps = {
  title: string;
  confirmText: string;
  children: any;
  onToggle: () => any;
  onSubmit?: (e: any, memberAmount?: any) => any;
  note?: boolean;
};

const DialogContainer = ({
  title,
  children,
  onToggle,
  onSubmit,
  confirmText,
  note,
}: DialogContainerProps) => {
  if (note) {
    return (
      <Dialog title={title}>
        <Wrapper>
          {children}
          <ButtonGroup>
            <Button big active onClick={onToggle}>
              OK
            </Button>
          </ButtonGroup>
        </Wrapper>
      </Dialog>
    );
  } else {
    return (
      <Dialog title={title}>
        <StyledDialogForm onSubmit={onSubmit}>
          {children}
          <ButtonGroup>
            <Button half active type="submit">
              {confirmText}
            </Button>
            <Button half secondary onClick={onToggle}>
              CANCLE
            </Button>
          </ButtonGroup>
        </StyledDialogForm>
      </Dialog>
    );
  }
};

DialogContainer.defaultProps = {
  confirmText: "SAVE",
};

export const ButtonGroup = styled.div`
  width: 100%;
  margin-top: 2rem;
  display: flex;
  justify-content: flex-end;

  & button + button {
    margin-left: 1rem;
  }
`;

const StyledDialogForm = styled.form`
  margin: 0 100px;
  flex-direction: column;
  padding: 1rem;
`;

const Wrapper = styled.div`
  padding: 3rem 1rem 1rem 1rem;
`;

export default DialogContainer;
