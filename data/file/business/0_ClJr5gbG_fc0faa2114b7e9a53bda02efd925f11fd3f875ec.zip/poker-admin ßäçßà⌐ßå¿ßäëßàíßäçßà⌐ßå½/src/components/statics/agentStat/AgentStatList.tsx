import { TableRowWrapper } from "components/common";
import NoDataBox from "components/common/NoDataBox";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import comma from "lib/comma";
import React from "react";
import { FaSearch } from "react-icons/fa";
import {
  TAgentStatForms,
  TAgentStatPage,
  TAgentStatSearch,
  TAgentTotalStat,
} from "stores/statistics/types";
import { Button, Input } from "styles/atom";
import AgentStat from "./AgentStat";

interface Props {
  agentPage: TAgentStatPage;
  forms: TAgentStatForms;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
}

function AgentStatList({ agentPage, forms, onSearch }: Props) {
  const { search } = forms;
  const { onChange } = search;
  const { start_date, end_date } = search.inputs as TAgentStatSearch;
  const {
    date,
    member_number,
    ramain_amount,
    total_poundage,
    agent_withdraw,
  } = agentPage.total as TAgentTotalStat;
  return (
    <>
      <SearchWrapper>
        <SearchForm onSubmit={onSearch}>
          {/* <Input
            type="text"
            placeholder="Agent"
            name="username"
            value={username}
            onChange={onChange}
          /> */}
          <Input
            type="date"
            name="start_date"
            value={start_date}
            onChange={onChange}
          />
          <Input
            type="date"
            name="end_date"
            value={end_date}
            onChange={onChange}
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>Username</th>
            <th>Date</th>
            <th>MemberNumber</th>
            <th>RemainingAmount</th>
            <th>TotalPoundage</th>
            <th>AgentWithdraw</th>
          </tr>
        </thead>
        <tbody>
          <TableRowWrapper>
            <td>TOTAL</td>
            <td></td>
            <td>{comma(member_number)}</td>
            <td>{comma(ramain_amount)}</td>
            <td>{comma(total_poundage)}</td>
            <td>{agent_withdraw ? comma(agent_withdraw) : 0}</td>
          </TableRowWrapper>
          {agentPage.paging.total_page ? (
            agentPage.stats.map((stats) => (
              <AgentStat key={stats.agent_id} agentStat={stats} />
            ))
          ) : (
            <NoDataBox />
          )}
        </tbody>
      </Table>
      {agentPage.paging.total_page ? (
        <PageNationContainer
          paging={agentPage.paging}
          onSearch={onSearch}
          searchForm={forms.search}
        />
      ) : null}
    </>
  );
}

export default AgentStatList;
