import React, { FormEvent, useState } from "react";
import { DialogContainer } from "containers/common/dialog";
import { Input } from "styles/atom";
import { useInputs } from "lib/hooks";
import { InputWrapper } from "components/deposit/Bankset/Bankset";
import styled from "styled-components";

interface Props {
  title: string;
  onToggle: (id: string) => void;
  onCreateAccount: (id: string, password: string) => void;
}

const Craete = ({ title, onToggle, onCreateAccount }: Props) => {
  const { inputs, onChange, init } = useInputs({
    id: "",
    password: "",
    passwordCheck: "",
  });
  const { id, password, passwordCheck } = inputs;
  const [isSamePassword, setIsSamePassword] = useState(true);

  const onSave = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (id === "") return alert("please enter id");
    if (password === "") return alert("please enter password");
    if (password !== passwordCheck) return setIsSamePassword(false);
    onCreateAccount(id, password);
    init();
    setIsSamePassword(true);
  };
  return (
    <DialogContainer
      title={title}
      confirmText="CREATE"
      onToggle={() => onToggle("create")}
      onSubmit={onSave}
    >
      <InputWrapper>
        <label>ID</label>
        <Input
          name="id"
          value={id}
          onChange={onChange}
          placeholder="Enter your ID"
        />
      </InputWrapper>
      <InputWrapper>
        <label>Password</label>
        <Input
          type="password"
          name="password"
          value={password}
          onChange={onChange}
          placeholder="Enter your password"
        />
      </InputWrapper>
      <InputWrapper>
        <label>Password check</label>
        <Input
          type="password"
          name="passwordCheck"
          value={passwordCheck}
          onChange={onChange}
          placeholder="again enter your password"
        />
      </InputWrapper>
      {!isSamePassword && <ErrorMessage>The password isn't same</ErrorMessage>}
    </DialogContainer>
  );
};

export const ErrorMessage = styled.p`
  margin-top: 1rem;
  text-align: center;
  color: red;
  font-style: italic;
`;

export default Craete;
