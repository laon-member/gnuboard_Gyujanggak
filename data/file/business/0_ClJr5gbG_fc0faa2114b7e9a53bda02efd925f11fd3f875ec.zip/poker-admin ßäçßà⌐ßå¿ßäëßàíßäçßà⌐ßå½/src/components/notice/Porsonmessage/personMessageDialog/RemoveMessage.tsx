import React from "react";
import { DialogContainer } from "containers/common/dialog";

type RemoveMessageProps = {
  title: string;
  onToggle: () => void;
  activeList: number[];
  onRemove: (list: number[]) => void;
};

const RemoveMessage = ({
  title,
  onToggle,
  activeList,
  onRemove,
}: RemoveMessageProps) => {
  const onSave = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onRemove(activeList);
  };
  return (
    <DialogContainer
      title={title}
      confirmText="REMOVE"
      onToggle={onToggle}
      onSubmit={onSave}
    >
      <p>
        Are you sure you want to delete a total of {activeList.length} messages?
      </p>
    </DialogContainer>
  );
};

export default RemoveMessage;
