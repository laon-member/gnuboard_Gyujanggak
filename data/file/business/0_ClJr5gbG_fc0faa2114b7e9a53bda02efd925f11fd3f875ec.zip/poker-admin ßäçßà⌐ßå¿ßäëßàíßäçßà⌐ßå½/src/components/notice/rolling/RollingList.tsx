import NoDataBox from "components/common/NoDataBox";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import { EditBoxType } from "components/member/memberlist/types";
import { WarningBoxContainer } from "containers/common/dialog";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import RollNoticeBoxContainer from "containers/notice/rolling/RollNoticeBoxContainer";
import React from "react";
import { FaPlus, FaSearch, FaTrash } from "react-icons/fa";
import {
  RollingPage,
  RollingSearchType,
  RollingType,
  UseInput,
} from "stores/notice/types";
import { WarningBoxType } from "stores/recharge/types";
import { Button, Input, Select } from "styles/atom";
import Rolling from "./Rolling";

interface Props {
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
  _new?: EditBoxType;
  edit?: EditBoxType;
  _delete: WarningBoxType;
  rollingPage: RollingPage;
  forms: { search: UseInput; new: UseInput };
  deleteAllRollingToggle: () => void;
  rolling: RollingType;
}

function RollingList({
  onSearch,
  _new,
  edit,
  _delete,
  rollingPage,
  forms,
  deleteAllRollingToggle,
  rolling,
}: Props) {
  const { search } = forms;
  const { onChange } = search;
  const {
    content,
    start_date,
    end_date,
    position,
  } = search.inputs as RollingSearchType;
  return (
    <>
      {_new!.toggle && <RollNoticeBoxContainer _new={_new} form={forms.new} />}
      {edit!.toggle && (
        <RollNoticeBoxContainer
          edit={edit}
          rolling={rolling}
          form={forms.new}
        />
      )}
      {_delete.toggle && (
        <WarningBoxContainer
          content="Sure to delete the notice?"
          type={_delete}
        />
      )}
      <SearchWrapper>
        <Button onClick={_new!.onToggle}>
          New <FaPlus />
        </Button>
        <Button onClick={_delete.onToggle}>
          Del <FaTrash />
        </Button>
        <SearchForm className="search" onSubmit={onSearch}>
          <Input
            placeholder="Content"
            name="content"
            value={content}
            onChange={onChange}
          />
          <Select name="position" value={position} onChange={onChange}>
            <option value="" disabled selected>
              Select position
            </option>
            <option value="ALL">ALL</option>
            <option value="HALL">HALL</option>
            <option value="GAME">GAME</option>
          </Select>
          <Input
            type="date"
            name="start_date"
            value={start_date}
            onChange={onChange}
            className="date"
          />
          <Input
            type="date"
            name="end_date"
            value={end_date}
            onChange={onChange}
            className="date"
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>
              <Input type="checkbox" onClick={deleteAllRollingToggle} />
            </th>
            <th>No.</th>
            <th>AdminName</th>
            <th>TimeIntv(s)</th>
            <th>BeginTime</th>
            <th>EndTime</th>
            <th>Position</th>
            <th>Content</th>
            <th>Opt</th>
          </tr>
        </thead>
        <tbody>
          {rollingPage.paging.total_page
            ? rollingPage.notices.map((rolling) => (
                <Rolling key={rolling.id} rolling={rolling} edit={edit!} />
              ))
            : null}
        </tbody>
      </Table>
      {rollingPage.paging.total_page ? (
        <PageNationContainer
          paging={rollingPage.paging}
          searchForm={forms.search}
          onSearch={onSearch}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
}

export default RollingList;
