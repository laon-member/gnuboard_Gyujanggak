import { TableRowWrapper } from "components/common";
import comma from "lib/comma";
import React from "react";
import { TRechargeLog } from "stores/recharge/types";

interface Props {
  log: TRechargeLog;
}

function RechargeLog({ log }: Props) {
  return (
    <TableRowWrapper>
      <td>{log.id}</td>
      <td>{log.username}</td>
      <td>{log.agent}</td>
      <td>{log.phone}</td>
      <td>{comma(log.amount)}</td>
      <td>{log.bankAccount}</td>
      <td>{log.bankName}</td>
      <td>{log.bankNumber}</td>
      <td>{log.applyTime}</td>
      <td>{log.adminName}</td>
      <td>{log.handleTime}</td>
      <td>
        {(parseInt(log.status, 10) === 5 && "Reserved") ||
          (parseInt(log.status, 10) === 1 && "Success") ||
          (parseInt(log.status, 10) === 2 && "Cancel") ||
          (parseInt(log.status, 10) === 0 && "Waiting")}
      </td>
    </TableRowWrapper>
  );
}

export default RechargeLog;
