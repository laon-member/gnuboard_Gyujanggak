﻿using LitJson;
using Photon.Realtime;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using Photon.Pun;

public class JackpotHistoryManager : MonoBehaviourPunCallbacks
{
    public Transform ContentParent;
    public GameObject PFContent;

    List<JackpotContent> List_Contents = new List<JackpotContent>();

    DataBaseManager DBMgr;
    SoundManager Sound;

    // Start is called before the first frame update
    void Start()
    {
        if(DBMgr == null)
        {
            DBMgr = FindObjectOfType<DataBaseManager>();
            Sound = FindObjectOfType<SoundManager>();
        }

        CreateHistoryContent();
    }

    void CreateHistoryContent()
    {
        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetJackpotHistory, "", "Post", PlayerPrefs.GetString("Token"), (result) => {

            JsonData resp = JsonMapper.ToObject(result);

            if ((int)resp["result"] == 1)
            {
                int count = resp["data"]["history"].Count;

                for (int i = 0; i < count; i++)
                {
                    JackpotContent content = GameObject.Instantiate(PFContent, ContentParent).GetComponent<JackpotContent>();

                    // DB에서 정보 받아서 세팅
                    string[] info = new string[6];
                    info[0] = i.ToString();
                    info[1] = (string)resp["data"]["history"][i]["profile_img"];
                    info[2] = (string)resp["data"]["history"][i]["username"];

                    info[3] = CStringFormat.Instance.FormatToInt(long.Parse(resp["data"]["history"][i]["amount"].ToString()));
                    
                    string date_buffer = (string)resp["data"]["history"][i]["updated_at"];
                    string date = "";

                    for (int j = 0; j < 10; j++)
                    {
                        date += date_buffer[j].ToString();
                    }

                    info[4] = date;

                    content.SetInfo(info);
                    List_Contents.Add(content);
                }
            }
        }));
    }

    public override void OnDisconnected(DisconnectCause cause)
    {
        //FindObjectOfType<CSocketConnect>().CloseSocket();

        SceneManager.LoadScene("LogIn");
    }

    public void OnClickBtn_Back()
    {
        SceneManager.LoadScene("Lobby");
    }
}
