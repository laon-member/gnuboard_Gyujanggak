import { action, observable } from "mobx";
import gameService from "services/game/gameService";
import { TRoom, TRoomListPage, TRoomListSearch } from "services/game/types";
import RootStore from "stores";
import { PagingType } from "stores/message/types";

export default class GameStore {
  root: RootStore;
  constructor(root: RootStore) {
    this.root = root;
  }

  @observable
  roomListPage = {
    paging: {} as PagingType,
    list: [] as TRoom[],
  } as TRoomListPage;

  @observable
  room = {} as TRoom;

  @action
  getRoomListPage = async (payload: TRoomListSearch) => {
    try {
      const res = await gameService.getRoomListPage(payload);
      if (res.data.result) {
        this.roomListPage = res.data.data;
      } else {
        alert("Field error");
      }
    } catch (error) {
      alert("There is a problem with the server");
    }
  };

  @action
  setRoom = (payload: TRoom) => {
    this.room = payload;
  };

  @action
  deleteRoom = async () => {
    return await gameService.deleteRoom(this.room);
  };
}
