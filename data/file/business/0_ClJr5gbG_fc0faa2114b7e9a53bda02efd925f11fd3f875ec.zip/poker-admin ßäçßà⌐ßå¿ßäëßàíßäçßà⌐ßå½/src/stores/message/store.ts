import { action, observable } from "mobx";
import MessageService from "services/message/MessageService";
import RootStore from "stores";
import {
  GM,
  GMType,
  PagingType,
  PM,
  PMType,
  SearchGMType,
  SearchPMType,
  SearchUserType,
  UserType,
} from "./types";

class MessageStore {
  root: RootStore;

  constructor(root: RootStore) {
    this.root = root;
  }

  @observable
  PMList: PM = {
    paging: {} as PagingType,
    messages: [] as PMType[],
  } as PM;

  @observable
  GMList: GM = {
    paging: {} as PagingType,
    messages: [] as GMType[],
  } as GM;

  @observable
  userList: UserType[] = [];

  @observable
  user?: UserType;

  @action
  getPMList = async (payload: SearchPMType) => {
    try {
      const { data } = await MessageService.getPMList(payload);
      this.PMList = data.data;
    } catch (error) {
      throw error;
    }
  };

  @action
  getGMList = async (payload: SearchGMType) => {
    try {
      const { data } = await MessageService.getGMList(payload);
      this.GMList = data.data;
    } catch (error) {
      throw error;
    }
  };

  @action
  searchUser = async (payload: SearchUserType) => {
    try {
      const res = await MessageService.searchUserList(payload);
      this.userList = res.data.data.users;
    } catch (error) {
      throw error;
    }
  };

  @action
  setUser = (id: number) => {
    this.user = this.userList.find((user) => user.id === id);
  };

  @action
  initUserList = () => {
    this.userList = [] as UserType[];
  };

  @action
  initUser = () => {
    this.user = undefined;
  };

  @action
  sendMessage = async (inputs: SearchUserType) => {
    try {
      const res = await MessageService.sendMessage(inputs, this.user!);
      if (res.status === 200) {
        return alert("successed to send message");
      }
    } catch (error) {
      throw error;
    }
  };
}

export default MessageStore;
