import React from "react";
import { inject, observer } from "mobx-react";
import { RouteComponentProps, withRouter } from "react-router-dom";
import { ReactCookieProps, withCookies } from "react-cookie";

import NoticeStore from "stores/notice";
import SelectUserList from "./SelectUserList";
import { searchedUserType } from "stores/notice/types";

interface Props extends RouteComponentProps, ReactCookieProps {
  noticeStore?: NoticeStore;
  onIncrease: () => void;
  onCreateToggle: () => void;
}

@inject("noticeStore")
@observer
class SelectUserListContainer extends React.Component<Props> {
  private NoticeStore = this.props.noticeStore! as NoticeStore;

  onSearch = async (type: string, value: string) => {
    await this.NoticeStore.SearchUserAtPersonMessage(type, value);
  };

  onAddUser = async (user: searchedUserType) => {
    await this.NoticeStore.addUserListToPersonMessage(user);
  };
  onRemoveUser = async (id: number) => {
    await this.NoticeStore.removeUserListToPersonMessage(id);
  };
  onSelectAllUser = async () => {
    await this.NoticeStore.selectAllUserListToPersonMessage();
  };
  onInit = async () => {
    await this.NoticeStore.initUserListToPersonMessage();
  };

  render() {
    return (
      <SelectUserList
        userList={this.NoticeStore.searchedUserList}
        onIncrease={this.props.onIncrease}
        onCreateToggle={this.props.onCreateToggle}
        onSearch={this.onSearch}
        onAddUser={this.onAddUser}
        onRemoveUser={this.onRemoveUser}
        sendUserList={this.NoticeStore.GetUserListToPersonMessage}
        onSelectAllUser={this.onSelectAllUser}
        onInit={this.onInit}
      />
    );
  }
}

export default withCookies(withRouter(SelectUserListContainer));
