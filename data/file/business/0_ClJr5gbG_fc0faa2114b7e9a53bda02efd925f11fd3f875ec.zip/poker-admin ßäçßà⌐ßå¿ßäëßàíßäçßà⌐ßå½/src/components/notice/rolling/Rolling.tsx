import { TableRowWrapper } from "components/common";
import { EditBoxType } from "components/member/memberlist/types";
import { formatDate } from "lib/util";
import React from "react";
import { FaPen } from "react-icons/fa";
import { RollingType } from "stores/notice/types";
import { Input } from "styles/atom";

interface Props {
  rolling: RollingType;
  edit: EditBoxType;
}

function Rolling({ rolling, edit }: Props) {
  return (
    <TableRowWrapper>
      <td>
        <Input
          type="checkbox"
          checked={rolling.active}
          onChange={() => edit.check(rolling.id)}
        />
      </td>
      <td>{rolling.id}</td>
      <td>{rolling.username}</td>
      <td>{rolling.duration}</td>
      <td>{formatDate(rolling.start_date)}</td>
      <td>{formatDate(rolling.end_date)}</td>
      <td>{rolling.position}</td>
      <td className="overflow">{rolling.content}</td>
      <td className="icon" onClick={() => edit.onToggle(rolling)}>
        <FaPen />
      </td>
    </TableRowWrapper>
  );
}

export default Rolling;
