import client from "lib/client";
import {
  TAgentCreate,
  TAgentEdit,
  TAgentListPageSearch,
  TAgentMoneyHistorySearch,
} from "stores/agent/types";

class agentService {
  public getAgentListPage = async (payload: TAgentListPageSearch) => {
    const { username, start_date, end_date, agent_code, page } = payload;
    return await client.get(
      `/api/admin/agents?username=${username}&agent_code=${agent_code}&start_date=${start_date}&end_date=${end_date}&page=${page - 1
      }`
    );
  };

  public addAgent = async (payload: TAgentCreate) => {
    return await client.post("/api/admin/agents", {
      username: payload.username,
      mobile: payload.mobile,
      password: payload.password,
      agent_code: payload.agent_code,
      bank_account: payload.bank_account,
      bank_name: payload.bank_name,
      card_number: payload.card_number,
      bene_rate: payload.bene_rate,
      add_money: payload.add_money,
    });
  };

  public editAgent = async (payload: TAgentEdit) => {
    return await client.put(`/api/admin/agents/${payload.agent_id}`, {
      username: payload.username,
      password: payload.password,
      mobile: payload.mobile,
      agent_code: payload.agent_code,
      bank_account: payload.bank_account,
      bank_name: payload.bank_name,
      card_number: payload.card_number,
      bene_rate: payload.bene_rate,
      operation: payload.operation,
      add_money: payload.add_money,
    });
  };

  public getAgentMoneyHistoryPage = async (
    payload: TAgentMoneyHistorySearch
  ) => {
    const { username, agent_code, start_date, end_date, page } = payload;
    return await client.get(
      `/api/admin/agents/money-history?username=${username}&agent_code=${agent_code}&start_date=${start_date}&end_date=${end_date}&page=${page - 1
      }`
    );
  };

  public getAgentInfo = async () => {
    return await client.get("/api/agent/me");
  };
}

export default new agentService();
