import TableRowWrapper from "components/common/TableRowWrapper";
import comma from "lib/comma";
import React from "react";
import { FaAndroid, FaApple, FaEdit, FaPen } from "react-icons/fa";
import { MemberType } from "stores/member/types";
import { PagingType } from "stores/message/types";
import { TAgent } from "stores/user/types";

interface Props {
  member: MemberType;
  onInfoToggle: () => void;
  onEditToggle: () => void;
  getMember: (id: number) => void;
  idx: number;
  paging: PagingType;
}

const Member = ({
  idx,
  paging,
  member,
  onInfoToggle,
  onEditToggle,
  getMember,
}: Props) => {
  const onToggleEdit = () => {
    onEditToggle();
    getMember(member.id);
  };

  const onToggleInfo = () => {
    onInfoToggle();
    getMember(member.id);
  };
  return (
    <TableRowWrapper>
      <td>{idx + 1 + (paging.current_page - 1) * 30}</td>
      <td>{member.id}</td>
      <td>{!member.status ? "Offline" : member.location}</td>
      <td>{member.username}</td>
      <td className="blue">
        {member.platform === "IOS" ? (
          <FaApple color="silver" />
        ) : (
          <FaAndroid color="green" />
        )}
        <br />
        {member.name}
      </td>
      <td>{member.agent}</td>
      <td>{member.phone}</td>
      <td>{comma(member.amount)}</td>
      <td>{member.created_at}</td>
      <td>{member.last_login}</td>
      <td>{member.bankName}</td>
      <td>{member.bank}</td>
      <td>{member.bankNumber}</td>
      <td>{comma(member.deposit)}</td>
      <td>{comma(member.withdraw)}</td>
      <td>{member.send_money ? comma(member.send_money) : 0}</td>
      <td>{member.receive_money ? comma(member.receive_money) : 0}</td>
      <td onClick={onToggleEdit} className="icon">
        <FaPen />
      </td>
      <td onClick={onToggleInfo} className="icon">
        <FaEdit />
      </td>
    </TableRowWrapper>
  );
};

export default Member;
