import client from "lib/client";
import {
  CancleWithdrawApplyType,
  PassWithdrawApplyType,
  SearchWithdrawApplyType,
  SearchWithdrawLogType,
} from "./types";

class WithdrawService {
  public GetWithdrawListAPI(
    id?: string,
    phone?: string,
    startDate?: string,
    endDate?: string
  ) {
    return client.get(`/api/admin/withdraw/withdrawinfo`, {
      params: {
        id,
        phone,
        start_date: startDate,
        end_date: endDate,
      },
    });
  }
  public PutWithdrawCompleteAPI(id: number) {
    return client.put(`/api/admin/withdraw/complete`, {
      id: id,
    });
  }
  public PutWithdrawRejectAPI(id: number) {
    return client.put(`/api/admin/withdraw/cancel`, {
      id: id,
    });
  }
  public GetWithRechargeListAPI(
    id?: string,
    phone?: string,
    status?: string,
    startDate?: string,
    endDate?: string
  ) {
    return client.get(`/api/admin/withdraw/withrechargeinfo`, {
      params: {
        id,
        phone,
        status,
        start_date: startDate,
        end_date: endDate,
      },
    });
  }

  // 최근 작업 API
  public getWithdrawLogList = async (payload: SearchWithdrawLogType) => {
    return await client.get(
      `/api/admin/withdraw/withrechargeinfo?username=${payload.username}&phone=${payload.phone}&orderNumber=${payload.orderNumber}&page=${payload.page - 1}`
    );
  };

  public getWithdrawApplyList = async (payload: SearchWithdrawApplyType) => {
    return client.get(
      `/api/admin/withdraw/withdrawinfo?id=${payload.id}&phone=${payload.phone}&page=${payload.page - 1}`
    );
  };

  public cancleWithdrawApply = async (payload: CancleWithdrawApplyType) => {
    return client.put(`/api/admin/withdraw/cancel`, {
      id: payload.id,
      message: payload.message,
    });
  };

  public passWithdrawApply = async (payload: PassWithdrawApplyType) => {
    return client.put(`/api/admin/withdraw/complete`, {
      id: payload.id,
    });
  };

  public reserveApply = async (id: number) => {
    return client.patch(`/api/admin/withdraw/${id}/reserve`);
  };
}
export default new WithdrawService();
