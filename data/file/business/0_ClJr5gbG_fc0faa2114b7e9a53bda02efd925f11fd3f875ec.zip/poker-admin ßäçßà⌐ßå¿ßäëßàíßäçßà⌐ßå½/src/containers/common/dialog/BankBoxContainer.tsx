import BankBox from "components/recharge/bankSet/BankBox";
import React from "react";
import { UseInput } from "stores/notice/types";
import { TNewBankSet, TRechargeBankSet } from "stores/recharge/types";

interface Props {
  type: TNewBankSet;
  form: UseInput;
  bankSet?: TRechargeBankSet;
}

function BankBoxContainer({ type, form, bankSet }: Props) {
  return <BankBox type={type} form={form} bankSet={bankSet!} />;
}

export default BankBoxContainer;
