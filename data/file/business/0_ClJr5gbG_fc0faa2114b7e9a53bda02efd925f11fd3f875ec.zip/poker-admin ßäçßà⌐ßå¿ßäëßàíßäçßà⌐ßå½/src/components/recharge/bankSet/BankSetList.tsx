import NoDataBox from "components/common/NoDataBox";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import BankBoxContainer from "containers/common/dialog/BankBoxContainer";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import React from "react";
import { FaPlus, FaSearch } from "react-icons/fa";
import {
  TBankSetForm,
  TNewBankSet,
  TRechargeBankSet,
  TRechargeBankSetPage,
  TSearchRechargeBankSet,
} from "stores/recharge/types";
import { Button, Input } from "styles/atom";
import BankSet from "./BankSet";

interface Props {
  _new: TNewBankSet;
  edit: TNewBankSet;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
  rechargeBankSetPage: TRechargeBankSetPage;
  forms: TBankSetForm;
  bankSet: TRechargeBankSet;
}

function BankSetList({
  _new,
  edit,
  onSearch,
  rechargeBankSetPage,
  forms,
  bankSet,
}: Props) {
  const { search } = forms;
  const { onChange } = search;
  const {
    bank_number,
    bank_account,
    bank_name,
  } = search.inputs as TSearchRechargeBankSet;
  return (
    <>
      {_new.toggle && <BankBoxContainer type={_new} form={forms.new} />}
      {edit.toggle && (
        <BankBoxContainer type={edit} form={forms.edit} bankSet={bankSet} />
      )}
      <SearchWrapper>
        <Button onClick={_new.onToggle}>
          Create <FaPlus />
        </Button>
        <SearchForm onSubmit={onSearch}>
          <Input
            placeholder="BankName"
            name="bank_name"
            value={bank_name}
            onChange={onChange}
          />
          <Input
            placeholder="BankAccount"
            name="bank_account"
            value={bank_account}
            onChange={onChange}
          />
          <Input
            placeholder="BankCardNumber"
            name="bank_number"
            value={bank_number}
            onChange={onChange}
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>BankName</th>
            <th>BankAccount</th>
            <th>BankCardNumber</th>
            <th>SHOW / HIDE</th>
            <th>Opt</th>
          </tr>
        </thead>
        <tbody>
          {rechargeBankSetPage.paging.total_page
            ? rechargeBankSetPage.accounts.map((bankSet) => (
                <BankSet key={bankSet.id} bankSet={bankSet} edit={edit} />
              ))
            : null}
        </tbody>
      </Table>
      {rechargeBankSetPage.paging.total_page ? (
        <PageNationContainer
          paging={rechargeBankSetPage.paging}
          onSearch={onSearch}
          searchForm={forms.search}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
}

export default BankSetList;
