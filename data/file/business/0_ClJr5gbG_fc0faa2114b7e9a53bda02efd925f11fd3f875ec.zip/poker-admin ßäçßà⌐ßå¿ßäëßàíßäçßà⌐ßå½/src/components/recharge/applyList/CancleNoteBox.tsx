import { TextAreaWrapper } from "components/member/memberlist/EditBox";
import { DialogContainer } from "containers/common/dialog";
import React from "react";
import {
  CancleWithdrawApplyType,
  TWithdrawFormType,
} from "services/withdraw/types";
import { TextArea } from "styles/atom/TextArea";
import { CancleType } from "./types";

interface Props {
  type: CancleType;
  form?: TWithdrawFormType;
}

function CancleNoteBox({ type, form }: Props) {
  const { message } = form!.inputs as CancleWithdrawApplyType;
  return (
    <DialogContainer
      title="Cancle Note"
      confirmText="SAVE"
      onToggle={type.onToggle}
      onSubmit={type.onSubmit}
    >
      <TextAreaWrapper>
        <label>Content</label>
        <TextArea name="message" value={message} onChange={form!.onChange} />
      </TextAreaWrapper>
    </DialogContainer>
  );
}

export default CancleNoteBox;
