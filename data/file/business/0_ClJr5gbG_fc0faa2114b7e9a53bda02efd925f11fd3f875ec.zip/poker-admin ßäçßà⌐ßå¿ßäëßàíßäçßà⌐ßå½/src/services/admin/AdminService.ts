import { EditAdminType, NewAdminType } from "components/adminSet/AdminBox";
import client from "lib/client";

class AdminService {
  public admins() {
    return client.get("/api/admin/users");
  }
  public createAccount(id: string, password: string) {
    return client.post("/api/admin/users", {
      username: id,
      password,
    });
  }

  public editAccout(id: string, password: string) {
    return client.put("/api/admin/users", {
      id,
      new_pass: password,
    });
  }

  public deleteAccount(id: number) {
    return client.delete("/api/admin/users", {
      params: {
        id,
      },
    });
  }

  public depositAndWithdraw() {
    return client.get("/api/admin/users/amount");
  }

  public getAdminList() {
    return client.get("/api/admin/users");
  }

  public addAdmin(payload: NewAdminType) {
    return client.post("/api/admin/users", {
      username: payload.username,
      password: payload.password,
    });
  }

  public patchAdmin(payload: EditAdminType) {
    return client.patch("/api/admin/users", {
      id: payload.id,
      new_pass: payload.password,
    });
  }

  public deleteAdmin(id: string) {
    return client.delete(`/api/admin/users?id=${id}`);
  }

  public getAppVersion() {
    return client.post("/api/version/check");
  }
}

export default new AdminService();
