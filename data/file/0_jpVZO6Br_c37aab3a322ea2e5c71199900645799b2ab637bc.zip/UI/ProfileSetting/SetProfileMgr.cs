﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;
using LitJson;
using JetBrains.Annotations;
using Leguar.TotalJSON;
using Photon.Pun;
using Photon.Realtime;

public class SetProfileMgr : MonoBehaviourPunCallbacks
{
    [System.Serializable]
    public struct SButtons
    {
        public Image[] Top_Button;
        
        public Image[] Pop_SelectGender;
    }
    public SButtons Btns;

    [System.Serializable]
    public struct SProfile
    {
        public Image ProfileImg;
        public Text Gender;
        public Text NickName;
        public Text Number;
    }
    public SProfile Profile;

    public GameObject[] ProfileInfoPage;

    public Sprite[] BtnChoiceImg;

    public InputField[] Profile_InputFields;
    public InputField[] PW_InputFields;

    // PopUp
    [Header("PopUp")]
    public GameObject PopUp_SelectImg;

    public Transform[] SelectImgBox;
    public Sprite[] Spr_TopBtns;

    int Gender;
    string ImgFilePath;

    DataBaseManager DBMgr;
    public Guidance GuidPopUp;

    // Start is called before the first frame update
    void Start()
    {
        if(DBMgr == null)
        {
            DBMgr = FindObjectOfType<DataBaseManager>();
        }

        SetTextProfiles();

        SetSprite(Profile.ProfileImg, LocalPlayerInfo.Instance.ProfileImgFilePath);

        if (LocalPlayerInfo.Instance.Gender == 0)
        {
            Profile.Gender.text = "Đàn ông";
        }
        else
        {
            Profile.Gender.text = "Đàn bà";
        }

        Profile.Number.text = LocalPlayerInfo.Instance.PlayerNumber.ToString();
        Profile.NickName.text = LocalPlayerInfo.Instance.PlayerNickName;

        Gender = LocalPlayerInfo.Instance.Gender;

        SelectImgBox[Gender].gameObject.SetActive(true);

        //popup select img
        Btns.Pop_SelectGender[Gender].sprite = BtnChoiceImg[1];

        for (int i = 0; i < SelectImgBox[Gender].childCount; i++)
        {
            string fileName = "";

            fileName = "p_" + LocalPlayerInfo.Instance.Gender.ToString() + "_" + i.ToString();

            SetSprite(SelectImgBox[Gender].GetChild(i).GetComponent<Image>(), fileName);
            SelectImgBox[Gender].GetChild(i).gameObject.name = "p_" + Gender.ToString() + "_" + i.ToString();
        }

        for (int i = 0; i < SelectImgBox[Gender].childCount; i++)
        {
            if(SelectImgBox[Gender].GetChild(i).gameObject.name == LocalPlayerInfo.Instance.ProfileImgFilePath)
            {
                SelectImgBox[Gender].GetChild(i).localScale = new Vector3(1.14f, 1.16f, 1);
                break;
            }
        }
    }

    public void OnClickBtn_Back()
    {
        SceneManager.LoadScene("Lobby");
    }

    public void OnClickBtn_TopBtn(int idx)
    {
        if(idx == 0)
        {
            Btns.Top_Button[0].sprite = Spr_TopBtns[0];
            Btns.Top_Button[1].sprite = Spr_TopBtns[1];

            Btns.Top_Button[0].GetComponent<RectTransform>().sizeDelta = new Vector2(389, 112);
            Btns.Top_Button[1].GetComponent<RectTransform>().sizeDelta = new Vector2(319, 84);

            ProfileInfoPage[0].SetActive(true);
            ProfileInfoPage[1].SetActive(false);
        }
        else
        {
            Btns.Top_Button[0].sprite = Spr_TopBtns[1];
            Btns.Top_Button[1].sprite = Spr_TopBtns[0];

            Btns.Top_Button[0].GetComponent<RectTransform>().sizeDelta = new Vector2(319, 84);
            Btns.Top_Button[1].GetComponent<RectTransform>().sizeDelta = new Vector2(389, 112);

            ProfileInfoPage[0].SetActive(false);
            ProfileInfoPage[1].SetActive(true);
        }
    }

    // 팝업
    public void OnClickBtn_ProfileImg()
    {
        Gender = LocalPlayerInfo.Instance.Gender;

        SelectImgBox[Gender].gameObject.SetActive(true);

        ImgFilePath = "";

        //popup select img
        Btns.Pop_SelectGender[Gender].sprite = BtnChoiceImg[1];

        for (int i = 0; i < SelectImgBox[Gender].childCount; i++)
        {
            if (SelectImgBox[Gender].GetChild(i).gameObject.name == LocalPlayerInfo.Instance.ProfileImgFilePath)
            {
                SelectImgBox[Gender].GetChild(i).localScale = new Vector3(1.14f, 1.16f, 1);
                break;
            }
        }

        PopUp_SelectImg.SetActive(true);
    }
    public void OnClickBtn_ClickSound()
    {
        FindObjectOfType<SoundManager>().StartSound_Effect(SoundFileList.EFFECT.btn_click);
        
    }
    void SetSprite(Image img, string fileName)
    {
        img.sprite = Resources.Load<Sprite>("Sprites/Profiles/" + fileName);
    }

    public void OnClickBtn_SelectImage()
    {
        if (EventSystem.current.currentSelectedGameObject.transform.localScale == Vector3.one)
        {
            for (int i = 0; i < SelectImgBox[Gender].childCount; i++)
            {
                SelectImgBox[Gender].GetChild(i).transform.localScale = Vector3.one;
            }

            if(Gender == 0)
            {
                for (int i = 0; i < SelectImgBox[1].childCount; i++)
                {
                    SelectImgBox[1].GetChild(i).localScale = Vector3.one;
                }
            }
            else
            {
                for (int i = 0; i < SelectImgBox[0].childCount; i++)
                {
                    SelectImgBox[0].GetChild(i).localScale = Vector3.one;
                }
            }

            ImgFilePath = EventSystem.current.currentSelectedGameObject.GetComponent<Image>().sprite.name;
            EventSystem.current.currentSelectedGameObject.transform.localScale = new Vector3(1.14f, 1.16f, 1);
        }
    }

    void SetTextProfiles()
    {
        // 프로필 정보 DB 연동
        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetProfileInfo, "", "Post", PlayerPrefs.GetString("Token"), (result) => {

            if (result == "NetworkError")
            {
                return;
            }

            if (result != "Not Found")
            {
                JsonData resp = JsonMapper.ToObject(result); ;

                //Debug.LogFormat("<color=red>{0}</color>", (int)resp["result"]);

                if ((int)resp["result"] == 1)
                {
                    Profile_InputFields[0].text = (string)resp["data"]["Info"]["phone"];
                    Profile_InputFields[1].text = (string)resp["data"]["Info"]["name"];
                    Profile_InputFields[2].text = (string)resp["data"]["Info"]["bank"];
                    Profile_InputFields[3].text = (string)resp["data"]["Info"]["number"];
                }
            }
        }));
    }

    public void OnClickBtn_ChageProfile(int type)
    {
        if(type == 0) // 리셋
        {
            SetTextProfiles();
        }
        else // 확인
        {
            foreach (var item in Profile_InputFields)
            {
                if (item.text == "")
                {
                    GuidPopUp.SetText("Xin vui lòng nhập vào chỗ trống"); // 번역 : 빈칸을 입력 해 주세요 o
                    return;
                }
            }

            JSON jsonData = new JSON();
            jsonData.Add("phone", Profile_InputFields[0].text);
            jsonData.Add("name", Profile_InputFields[1].text);
            jsonData.Add("bank", Profile_InputFields[2].text);
            jsonData.Add("number", Profile_InputFields[3].text);

            // 프로필 정보 DB 연동
            StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.SetProfileInfo, jsonData.CreateString(), "Put", PlayerPrefs.GetString("Token"), (result) => {

                if (result == "NetworkError")
                {
                    return;
                }

                if (result != "Not Found")
                {
                    JsonData resp = JsonMapper.ToObject(result);

                    if ((int)resp["result"] == 1)
                    {
                        GuidPopUp.SetText("Đã hoàn thành thay đổi thông tin thành viên"); // 번역 : 회원 정보 변경 완료 o

                        if (ImgFilePath != null)
                        {
                            if (ImgFilePath.Length > 0)
                            {
                                LocalPlayerInfo.Instance.ProfileImgFilePath = ImgFilePath;
                            }
                        }
                        LocalPlayerInfo.Instance.Gender = Gender;

                        SetTextProfiles();
                    }
                }
            }));
        }
    }

    public void OnClickBtn_ChangePW(int type)
    {
        if(type == 0) // 취소
        {
            foreach (var item in PW_InputFields)
            {
                item.text = "";
            }
        }
        else // 확인
        {
            foreach (var item in PW_InputFields)
            {
                if (item.text == "")
                {
                    GuidPopUp.SetText("Xin vui lòng nhập vào chỗ trống"); // 번역 : 빈칸을 입력 해 주세요. o
                    return;
                }
            }

            if (PW_InputFields[0].text == PlayerPrefs.GetString("UserPW"))
            {
                if(PW_InputFields[1].text == PW_InputFields[2].text)
                {
                    if (PW_InputFields[0].text != PW_InputFields[1].text)
                    {
                        JSON jsonData = new JSON();
                        jsonData.Add("password", PW_InputFields[1].text);

                        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.ChangePW, jsonData.CreateString(), "Post", PlayerPrefs.GetString("Token"), (result) =>
                        {
                            JsonData resp = JsonMapper.ToObject(result);

                            if ((int)resp["result"] == 1)
                            {
                                PlayerPrefs.SetString("UserPW", PW_InputFields[1].text);

                                foreach (var item in PW_InputFields)
                                {
                                    item.text = "";
                                }

                                GuidPopUp.SetText("Mật khẩu được thay đổi"); // 번역 : 비밀번호 변경 완료  o
                            }
                        }));
                    }
                    else
                    {
                        GuidPopUp.SetText("Không thể thay đổi mật khẩu giống nhau"); // 번역 :  동일한 비밀번호로 변경할 수 없습니다. o
                    }
                }
                else
                {
                    GuidPopUp.SetText("Xin vui lòng xác nhận lại mật khẩu mới"); // 번역 : 새 비밀번호를 다시 확인 해주세요. o 
                }
            }
            else
            {
                GuidPopUp.SetText("Mật khẩu khác nhau"); // 번역 : 비밀번호가 다릅니다. o
            }
        }
    }

    public override void OnDisconnected(DisconnectCause cause)
    {
        SceneManager.LoadScene("LogIn");
    }

    public void OnClickBtn_SelectGender(int gender)
    {
        if (gender == 0)
        {
            Btns.Pop_SelectGender[0].sprite = BtnChoiceImg[1];
            Btns.Pop_SelectGender[1].sprite = BtnChoiceImg[0];
            SelectImgBox[0].gameObject.SetActive(true);
            SelectImgBox[1].gameObject.SetActive(false);
        }
        else
        {
            Btns.Pop_SelectGender[0].sprite = BtnChoiceImg[0];
            Btns.Pop_SelectGender[1].sprite = BtnChoiceImg[1];
            SelectImgBox[0].gameObject.SetActive(false);
            SelectImgBox[1].gameObject.SetActive(true);
        }

        for (int i = 0; i < SelectImgBox[gender].childCount; i++) // 이미지 있는 칸
        {
            string fileName = "";

            fileName = "p_" + gender.ToString() + "_" + i.ToString();

            SetSprite(SelectImgBox[gender].GetChild(i).GetComponent<Image>(), fileName);
        }

        Gender = gender;
    }

    public void OnClickBtn_PopUpClose(bool result)
    {
        foreach (var item in Btns.Pop_SelectGender)
        {
            item.sprite = BtnChoiceImg[0];
        }

        for (int i = 0; i < SelectImgBox.Length; i++)
        {
            for (int j = 0; j < SelectImgBox[i].childCount; j++)
            {
                SelectImgBox[i].GetChild(j).localScale = Vector3.one;
            }
        }

        if(!result)
        {
            ImgFilePath = "";
            Gender = LocalPlayerInfo.Instance.Gender;
        }
        else
        {
            if (ImgFilePath.Length != 0)
            {
                if (LocalPlayerInfo.Instance.Gender == 0)
                {
                    Profile.Gender.text = "Đàn ông";
                }
                else
                {
                    Profile.Gender.text = "Đàn bà";
                }

                SetSprite(Profile.ProfileImg, ImgFilePath);
            }
        }

        for (int i = 0; i < SelectImgBox.Length; i++)
        {
            SelectImgBox[i].gameObject.SetActive(false);
        }

        PopUp_SelectImg.SetActive(false);
    }
}
