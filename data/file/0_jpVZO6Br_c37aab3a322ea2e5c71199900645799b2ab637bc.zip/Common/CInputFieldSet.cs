﻿using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class CInputFieldSet : MonoBehaviour, IPointerClickHandler
{
    InputField IField;
    TouchScreenKeyboard Keyboard;

    private void Awake()
    {
        IField = this.GetComponent<InputField>();
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnValueChange_Prevention_Special_Cha(string text)
    {
        IField.text = Regex.Replace(IField.text, @"[^a-zA-Z0-9가-힣]", "", RegexOptions.Singleline);
    }

    public void OnValueChange_Prevention_Money(string input)
    {
        if (IField.text.Length != 0)
        {
            if (IField.text[IField.text.Length - 1] == ',')
            {
                IField.text.Remove(IField.text.Length - 1);
            }

            IField.text = Regex.Replace(IField.text, @"[^0-9,]", "", RegexOptions.Singleline);
        }
    }

    public void OnEndValue_Deposit()
    {
        if (IField.text.Length > 0 && IField.text != "0")
        {
            string formatTxt = string.Format("{0:#,###}", GetInt(IField.text));
            IField.text = formatTxt;
        }
        else if (IField.text.Length == 0)
        {
            IField.text = "0";
        }
    }

    public void OnEndValue_Withdrawal()
    {
        if (IField.text.Length > 0 && IField.text != "0")
        {
            string formatTxt = "";

            if (GetInt(IField.text) >= LocalPlayerInfo.Instance.PlayerMoney)
            {
                formatTxt = string.Format("{0:#,###}", LocalPlayerInfo.Instance.PlayerMoney);
            }
            else
            {
                formatTxt = string.Format("{0:#,###}", GetInt(IField.text));
            }
            IField.text = formatTxt;
        }
        else if (IField.text.Length == 0)
        {
            IField.text = "0";
        }
    }

    public void OnEndValue_Gift()
    {
        if (IField.text.Length > 0 && IField.text != "0")
        {
            string formatTxt = "";

            if (GetInt(IField.text) >= LocalPlayerInfo.Instance.PlayerMoney)
            {
                formatTxt = string.Format("{0:#,###}", LocalPlayerInfo.Instance.PlayerMoney);
            }
            else
            {
                formatTxt = string.Format("{0:#,###}", GetInt(IField.text));
            }
            IField.text = formatTxt;
        }
    }

    public long GetInt(string str)
    {
        long money = 0;

        if (str.Length > 0)
        {
            if (str != "0")
            {
                string[] buffer = str.Split(',');
                string buffer_money = "";
                foreach (var item in buffer)
                {
                    buffer_money += item;
                }
                money = long.Parse(buffer_money);
            }
        }
        return money;
    }

    public void OnPointerClick(PointerEventData eventData)
    {

    }
}
