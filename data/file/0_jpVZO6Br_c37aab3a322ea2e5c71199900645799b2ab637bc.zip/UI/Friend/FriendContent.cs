﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using LitJson;
using UnityEngine.EventSystems;
using Leguar.TotalJSON;

public class FriendContent : MonoBehaviour
{
    public Image ProfileIcon;
    public Text Name;
    public GameObject[] On_Offline;

    public Image AddBtn;
    public GameObject GiftBtn;

    public FriendManager Main;

    public Sprite[] Btn_Sprites;

    public int PlayerNumber;

    DataBaseManager DBMgr;

    // Start is called before the first frame update
    void Start()
    {
        if(DBMgr == null)
        {
            DBMgr = FindObjectOfType<DataBaseManager>();
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void SetFriendItem(object[] info, FriendManager main, int type)
    {
        Main = main;

        PlayerNumber = (int)(info[0]);
        Name.text = (string)info[1];
        ProfileIcon.sprite = Resources.Load<Sprite>("Sprites/InGameProfiles/" + (string)info[2]);
        On_Offline[(int)info[3]].gameObject.SetActive(true);

        AddBtn.sprite = Btn_Sprites[type];

        // on off line 여부, 선물하기 위치 조절
        if(type == 1)
        {
            //foreach (var item in On_Offline)
            //{
            //    item.transform.localPosition = new Vector3(130.0f, item.transform.localPosition.y);
            //}
            //GiftBtn.transform.localPosition = new Vector3(285.0f, GiftBtn.transform.localPosition.y);
            //GiftBtn.SetActive(true);
        }
    }

    public void ShowGiftBtn()
    {
        foreach (var item in On_Offline)
        {
            item.transform.localPosition = new Vector3(130.0f, item.transform.localPosition.y);
        }
        GiftBtn.transform.localPosition = new Vector3(285.0f, GiftBtn.transform.localPosition.y);
        //GiftBtn.SetActive(true);
    }

    public void OnClickBtn_Gift()
    {
        if(Main != null)
        {
            Main.OpenPopUp_Gift(Name.text);
        }
    }

    public void OnClickBtn_AddDeleteBtn()
    {
        int idx = 0;

        for (int i = 0; i < Btn_Sprites.Length; i++)
        {
            if(AddBtn.sprite == Btn_Sprites[i])
            {
                idx = i;
                break;
            }
        }

        if(idx == 0) // add
        {
            // 친구 리스트에 추가
            JSON jsonData = new JSON();
            jsonData.Add("friend_id", PlayerNumber.ToString());
            
            StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.AddFriend, jsonData.CreateString(), "Post", PlayerPrefs.GetString("Token"), (result) => {

                JsonData resp = JsonMapper.ToObject(result);

                if ((int)resp["result"] == 0)
                {
                    
                }
                else
                {
                    
                    Main.CreateFriendAdd(this.gameObject);
                    AddBtn.gameObject.SetActive(false);
                    Main.DeleteSearchItem(this);
                }
            }));
        }
        else // delete
        {
            JSON jsonData = new JSON();
            jsonData.Add("friend_id", PlayerNumber.ToString());

            StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.DeleteFriend, jsonData.CreateString(), "Delete", PlayerPrefs.GetString("Token"), (result) => {
                JsonData resp = JsonMapper.ToObject(result);

                if ((int)resp["result"] == 0)
                {
                    
                }
                else
                {
                    Main.DeleteFriend(this);
                }
            }));
        }
    }
    public void OnClickBtn_ClickSound()
    {
        FindObjectOfType<SoundManager>().StartSound_Effect(SoundFileList.EFFECT.btn_click);
    }
}
