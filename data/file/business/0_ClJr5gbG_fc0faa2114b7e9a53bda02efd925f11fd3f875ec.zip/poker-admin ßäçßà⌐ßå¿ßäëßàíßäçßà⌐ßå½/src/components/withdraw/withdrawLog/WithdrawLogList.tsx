import NoDataBox from "components/common/NoDataBox";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import React from "react";
import { FaSearch } from "react-icons/fa";
import { SearchWithdrawLogType } from "services/withdraw/types";
import { TWithdrawLogForm, TWithdrawLogPage } from "stores/withdraw/types";
import { Button, Input } from "styles/atom";
import WithdrawLog from "./WithdrawLog";

interface Props {
  withdrawLogListPage: TWithdrawLogPage;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
  forms: TWithdrawLogForm;
}

function withdrawLogList({ onSearch, forms, withdrawLogListPage }: Props) {
  const { search } = forms;
  const { onChange } = search;
  const { username, phone } = search.inputs as SearchWithdrawLogType;
  return (
    <>
      <SearchWrapper>
        <SearchForm onSubmit={onSearch}>
          <Input
            placeholder="ID"
            name="username"
            value={username}
            onChange={onChange}
          />
          <Input
            placeholder="Modile"
            name="phone"
            value={phone}
            onChange={onChange}
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>ID</th>
            <th>Agent</th>
            <th>Mobile</th>
            <th>amount</th>
            <th>BankAccount</th>
            <th>BankName</th>
            <th>CardNumber</th>
            <th>ApplyTime</th>
            <th>AdminName</th>
            <th>HandleTime</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {withdrawLogListPage.paging.total_page
            ? withdrawLogListPage.withdraw.map((log) => (
                <WithdrawLog key={log.orderNumber} log={log} />
              ))
            : null}
        </tbody>
      </Table>
      {withdrawLogListPage.paging.total_page ? (
        <PageNationContainer
          searchForm={forms.search}
          onSearch={onSearch}
          paging={withdrawLogListPage.paging}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
}

export default withdrawLogList;
