﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Photon.Pun;
using Photon.Realtime;

public class RoomPosition : MonoBehaviourPunCallbacks
{
    // 플레이어 프리팹 베이스
    public CPlayer PFPlayer;

    public Transform[] Arr_PlayersPos;

    // 플레이어 고유 번호 저장
    public int[] SeatPlayerPK = new int[6];
    // 플레이어 프로필 저장
    public CPlayer[] Arr_Players = new CPlayer[6];

    public CPlayer MyProfile;

    Dictionary<Player, Coroutine> CoroutineDic = new Dictionary<Player, Coroutine>();

    public bool ReConnect;
    public bool TryReConnect;

    [Header("플레이어 나간 코루틴 오브젝트")]
    public PlayerWait_Co PFWait_Co;
    public List<PlayerWait_Co> List_Wait_Co;
    Dictionary<int, PlayerWait_Co> Dic_PlayerWait = new Dictionary<int, PlayerWait_Co>();

    public Dictionary<int, long> Dic_PausePlayerBattingMoney = new Dictionary<int, long>();
    public Dictionary<Player, bool> Dic_IsLeft_Co = new Dictionary<Player, bool>();

    public List<int> List_WatchPlayers = new List<int>();

    bool IsLeave = false;

    void Start()
    {
        //PhotonNetwork.KeepAliveInBackground = 0.0f;

        PlayerPrefs.SetString("RoomName", PhotonNetwork.CurrentRoom.Name);
        PlayerPrefs.SetInt("ReflashRoom", 0);
        PlayerPrefs.SetInt("RoomSelect", int.Parse(PhotonNetwork.CurrentRoom.CustomProperties["BatMoney"].ToString()));

        PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"] = LocalPlayerInfo.Instance.PlayerMoney;

        if (PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            PhotonNetwork.CurrentRoom.PlayerTtl = 10;

            for (int i = 0; i < SeatPlayerPK.Length; i++)
            {
                if (i != 0)
                {
                    SeatPlayerPK[i] = -1;
                }
            }

            SeatPlayerPK[0] = PhotonNetwork.LocalPlayer.ActorNumber;

            // 방에 입장하면 내 자신 플레이어 프로필 오브젝트 만들기
            CreateProfile(CPlayer.PlayerType.Mine, 0, PhotonNetwork.LocalPlayer, long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()));
        }
    }

    public Player GetPlayer(int actorNum)
    {
        foreach (KeyValuePair<int, Player> item in PhotonNetwork.CurrentRoom.Players)
        {
            if (item.Value.ActorNumber == actorNum)
            {
                return item.Value;
            }
        }
        return null;
    }

    void CreateProfile(CPlayer.PlayerType type, int idx, Player playerInfo, long money)
    {
        CPlayer player = Instantiate(PFPlayer, Arr_PlayersPos[idx]);

        player.gameObject.name = "Player[" + playerInfo.NickName + "]";
        player.transform.localScale = Vector3.one;
        player.transform.localPosition = Vector3.zero;
        player.transform.localRotation = Quaternion.identity;

        player.Type = type;

        if (player.Type == CPlayer.PlayerType.Mine)
        {
            MyProfile = player;

            if (PhotonNetwork.CurrentRoom.PlayerCount == 1)
            {
                PhotonNetwork.LocalPlayer.CustomProperties["IsDealer"] = true;
                MyProfile.SetDealerImg(true);
            }
        }
        player.SetPlayerInfo(playerInfo, money);

        Arr_Players[idx] = player;
    }

    [PunRPC]
    void SendPlayerInfoToNewPlayer(Player newPlayer)
    {
        if (newPlayer != null)
        {
            if (PhotonNetwork.LocalPlayer.ActorNumber != newPlayer.ActorNumber)
            {
                photonView.RPC("ReceiveInfo_NewPlayer", newPlayer, PhotonNetwork.LocalPlayer.ActorNumber,
                                                                   long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()),
                                                                   MyProfile.CardsFileName,
                                                                   GetComponent<GameMgr>().IsPlaying,
                                                                   GetComponent<GameMgr>().TotalBattingMoney);
            }
        }
    }

    [PunRPC]
    void ReceiveInfo_NewPlayer(int actorNum, long money, string[] cardsFileName, bool isPlaying, long totalMoney)
    {
        int curIdx = 0; // 고정 값 중에 자신이 있는값

        for (int i = 0; i < SeatPlayerPK.Length; i++)
        {
            if (SeatPlayerPK[i] > 0)
            {
                if (SeatPlayerPK[i] == PhotonNetwork.LocalPlayer.ActorNumber)
                {
                    curIdx = i;
                    break;
                }
            }
        }

        CreateProfile(CPlayer.PlayerType.Mine, 0, PhotonNetwork.LocalPlayer, long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()));

        if (curIdx != 0)
        {
            for (int i = curIdx + 1; i < SeatPlayerPK.Length; i++) // 자신을 0 으로 기준잡고 SeatInfo 의 자신 자리부터 오른쪽으로 탐색.
            {
                if (SeatPlayerPK[i] > 0)
                {
                    if (SeatPlayerPK[i] == actorNum)
                    {
                        CreateProfile(CPlayer.PlayerType.Other, Mathf.Abs(curIdx - i), GetPlayer(SeatPlayerPK[i]), money);
                        break;
                    }
                }
            }
            for (int i = curIdx - 1; i >= 0; i--) // 자신을 0 으로 기준잡고 SeatInfo 의 자신 자리부터 왼쪽으로 탐색.
            {
                if (SeatPlayerPK[i] > 0)
                {
                    if (SeatPlayerPK[i] == actorNum)
                    {
                        CreateProfile(CPlayer.PlayerType.Other, Arr_PlayersPos.Length - Mathf.Abs(curIdx - i), GetPlayer(SeatPlayerPK[i]), money);
                        break;
                    }
                }
            }
        }
        else
        {
            for (int i = 1; i < SeatPlayerPK.Length; i++)
            {
                if (SeatPlayerPK[i] > 0)
                {
                    if (SeatPlayerPK[i] == actorNum)
                    {
                        CreateProfile(CPlayer.PlayerType.Other, i, GetPlayer(SeatPlayerPK[i]), money);
                        break;
                    }
                }
            }
        }

        GameMgr main = GetComponent<GameMgr>();

        if (isPlaying)
        {
            for (int i = 0; i < Arr_Players.Length; i++)
            {
                if (Arr_Players[i] != null)
                {
                    if (Arr_Players[i].Info.ActorNumber == actorNum)
                    {
                        for (int cardCount = 0; cardCount < 3; cardCount++)
                        {
                            CardInfo card = Instantiate(main.PFCard, main.CardDeckPos);
                            card.transform.localPosition = Vector3.zero;
                            card.transform.localScale = Vector3.one;

                            Arr_Players[i].SetCardPos(card, i, cardsFileName);

                            Arr_Players[i].CardsFileName[cardCount] = cardsFileName[cardCount];
                        }
                        break;
                    }
                }
            }

            main.CardDeckPos.gameObject.SetActive(false);
            main.TotalBattingMoney_Txt.text = CStringFormat.Instance.FormatToInt(totalMoney);
        }
    }

    [PunRPC]
    void SendBattingMoneyToWatchPlayer(Player watchPlayer)
    {
        if (watchPlayer.ActorNumber != PhotonNetwork.LocalPlayer.ActorNumber)
        {
            photonView.RPC("ReceiveBattingMoney_WatchPlayer", watchPlayer, PhotonNetwork.LocalPlayer.ActorNumber, MyProfile.txt_BatMoney[0].text);
        }
    }
    [PunRPC]
    void ReceiveBattingMoney_WatchPlayer(int actorNum, string batMoney)
    {
        foreach (var player in Arr_Players)
        {
            if (player != null)
            {
                if (player.Info.ActorNumber == actorNum)
                {
                    player.txt_BatMoney[1].text = batMoney;
                    return;
                }
            }
        }
    }

    [PunRPC]
    void Send_SeatPlayerPK(int[] pk)
    {
        SeatPlayerPK = pk;
    }

    // 새로운 플레이어가 방에 입장했을 때 호출.
    public override void OnPlayerEnteredRoom(Player newPlayer)
    {
        if (PhotonNetwork.IsMasterClient) // 내가 호스트면
        {
            for (int i = 0; i < SeatPlayerPK.Length; i++)
            {
                if (SeatPlayerPK[i] < 0)
                {
                    SeatPlayerPK[i] = newPlayer.ActorNumber;

                    // 방에 있는 모든 플레이어에게 SeatPK 정보 전달
                    photonView.RPC("Send_SeatPlayerPK", RpcTarget.Others, SeatPlayerPK);
                    // 새로 들어온 플레이어에게 다른 플레이어를 만들도록 전달
                    photonView.RPC("SendPlayerInfoToNewPlayer", RpcTarget.All, newPlayer);
                    break;
                }
            }

            for (int i = 0; i < Arr_Players.Length; i++)
            {
                if (Arr_Players[i] != null)
                {
                    if (GetPlayer(Arr_Players[i].Info.ActorNumber).CustomProperties["IsDealer"] != null)
                    {
                        if ((bool)GetPlayer(Arr_Players[i].Info.ActorNumber).CustomProperties["IsDealer"])
                        {
                            photonView.RPC("SetDealerPlayer", newPlayer, Arr_Players[i].Info.ActorNumber);
                        }
                    }
                }
            }

            photonView.RPC("CreateEnterPlayerProfile", RpcTarget.All, newPlayer, SeatPlayerPK);

            GameMgr main = GetComponent<GameMgr>();

            if (main.IsPlaying) // 관전 플레이어 세팅
            {
                photonView.RPC("SendBattingMoneyToWatchPlayer", RpcTarget.All, newPlayer);
                photonView.RPC("SetWatchPlayer", RpcTarget.All, newPlayer);
            }

            if (!main.IsPlaying && !main.IsAutoPlaying)
            {
                main.StartBtn.SetActive(true);
                main.StartBtn.GetComponent<Button>().interactable = true;
            }
        }

        //if ((bool)PhotonNetwork.LocalPlayer.CustomProperties["IsDealer"] && !GetComponent<GameMgr>().IsPlaying)
        //{
        //    GetComponent<GameMgr>().StartBtn.SetActive(true);
        //    GetComponent<GameMgr>().StartBtn.GetComponent<Button>().interactable = true;
        //}

        if (GetComponent<GameMgr>().IsPlaying)
        {
            photonView.RPC("SetImgWatchPlayer", RpcTarget.All);
        }
    }
    [PunRPC]
    void WatchPlayer_CreateCards(int actorNum, string[] cardsfilename)
    {
        GameMgr main = GetComponent<GameMgr>();

        for (int i = 0; i < Arr_Players.Length; i++)
        {
            if (Arr_Players[i] != null)
            {
                if (Arr_Players[i].Info.ActorNumber != PhotonNetwork.LocalPlayer.ActorNumber)
                {
                    if (Arr_Players[i].Info.ActorNumber == actorNum)
                    {
                        for (int cardCount = 0; cardCount < 3; cardCount++)
                        {
                            CardInfo card = Instantiate(main.PFCard, main.CardDeckPos);
                            card.transform.localPosition = Vector3.zero;
                            card.transform.localScale = Vector3.one;

                            Arr_Players[i].SetCardPos(card, i, cardsfilename);
                        }
                        break;
                    }
                }
            }
        }
    }

    [PunRPC]
    void SetImgWatchPlayer()
    {
        for (int i = 0; i < Arr_Players.Length; i++)
        {
            if (Arr_Players[i] != null)
            {
                if (JudgeWatchingPlayer(Arr_Players[i].Info.ActorNumber))
                {
                    Arr_Players[i].SetWatchImg(true);
                    List_WatchPlayers.Add(Arr_Players[i].Info.ActorNumber);
                    break;
                }
            }
        }
    }

    [PunRPC]
    void SetWatchPlayer(Player player)
    {
        player.CustomProperties["IsWatch"] = true;
    }

    [PunRPC]
    void SetDealerPlayer(int actorNum)
    {
        for (int i = 0; i < Arr_Players.Length; i++)
        {
            if (Arr_Players[i] != null)
            {
                if (Arr_Players[i].Info.ActorNumber == actorNum)
                {
                    Arr_Players[i].SetDealerImg(true);
                    return;
                }
            }
        }
    }

    // 새로 들어온 플레이어 프로필 생성
    [PunRPC]
    void CreateEnterPlayerProfile(Player newPlayer, int[] host_SeatInfo)
    {
        if (newPlayer == null)
        {
            return;
        }
        if (newPlayer.ActorNumber == PhotonNetwork.LocalPlayer.ActorNumber)
        {
            return;
        }

        SeatPlayerPK = host_SeatInfo;

        int newPlayerIdx = 0;
        int curPlayerIdx = 0;

        for (int i = 0; i < SeatPlayerPK.Length; i++)
        {
            if (SeatPlayerPK[i] > 0)
            {
                if (SeatPlayerPK[i] == newPlayer.ActorNumber)
                {
                    newPlayerIdx = i;
                }
                else if (SeatPlayerPK[i] == PhotonNetwork.LocalPlayer.ActorNumber)
                {
                    curPlayerIdx = i;
                }
            }
        }

        int posIdx = 0;

        if (curPlayerIdx - newPlayerIdx < 0)
        {
            posIdx = Mathf.Abs(curPlayerIdx - newPlayerIdx);
        }
        else if (curPlayerIdx - newPlayerIdx > 0)
        {
            posIdx = SeatPlayerPK.Length - Mathf.Abs(curPlayerIdx - newPlayerIdx);
        }

        CreateProfile(CPlayer.PlayerType.Other, posIdx, newPlayer, (long)newPlayer.CustomProperties["UserMoney"]);
    }

    public void OnClickBtn_LeaveRoom() // 나가기 버튼 클릭시
    {
        GameMgr main = gameObject.GetComponent<GameMgr>();

        if (main.IsMoreBtns)
        {
            main.OnClickBtn_MoreBtns();
        }

        if (!main.IsPlaying)
        {
            LeaveRoom();
        }
        else
        {
            if (main.LeaveReservation)
            {
                main.LeaveReservation = false;
            }
            else
            {
                main.LeaveReservation = true;
            }

            MyProfile.SetLeaveReservation(main.LeaveReservation);
            photonView.RPC("SetLeaveReservation", RpcTarget.Others, main.LeaveReservation, MyProfile.Info.ActorNumber);
        }
    }

    public void Android_BackBtn()
    {
        GameMgr main = gameObject.GetComponent<GameMgr>();

        if (!main.IsPlaying)
        {
            LeaveRoom();
        }
        else
        {
            if (main.LeaveReservation)
            {
                main.LeaveReservation = false;
            }
            else
            {
                main.LeaveReservation = true;
            }

            MyProfile.SetLeaveReservation(main.LeaveReservation);
            photonView.RPC("SetLeaveReservation", RpcTarget.Others, main.LeaveReservation, MyProfile.Info.ActorNumber);
        }
    }

    public override void OnPlayerLeftRoom(Player otherPlayer)
    {
        if (!Dic_IsLeft_Co.ContainsKey(otherPlayer))
        {
            Dic_IsLeft_Co.Add(otherPlayer, true);

            for (int i = 0; i < Arr_Players.Length; i++)
            {
                if (Arr_Players[i] != null)
                {
                    if (Arr_Players[i].Info.ActorNumber == otherPlayer.ActorNumber)
                    {
                        Arr_Players[i].IsLeftPlayer = true;
                    }
                }
            }
            Debug.Log("IsPlaying : " + GetComponent<GameMgr>().IsPlaying);
            if (GetComponent<GameMgr>().IsPlaying)
            {
                StartCoroutine("Co_DestroyPlayer", otherPlayer);
            }
            else
            {
                for (int i = 0; i < Arr_Players.Length; i++)
                {
                    if (Arr_Players[i] != null)
                    {
                        if (Arr_Players[i].Info.ActorNumber == otherPlayer.ActorNumber)
                        {
                            Destroy(Arr_Players[i].gameObject);
                            break;
                        }
                    }
                }

                for (int i = 0; i < SeatPlayerPK.Length; i++)
                {
                    if (SeatPlayerPK[i] == otherPlayer.ActorNumber)
                    {
                        SeatPlayerPK[i] = -1;
                    }
                }
                LeftPlayer(otherPlayer);
            }
        }
    }

    void LeftPlayer(Player otherPlayer)
    {
        GameMgr main = GetComponent<GameMgr>();

        if (PhotonNetwork.CurrentRoom.PlayerCount - GetWatchingPlayerCount() == 1) // 한명남았을때
        {
            main.StopCo_GameStart();
            main.Stop_AutoStart();
            main.StartBtn.SetActive(false);

            if (PhotonNetwork.CurrentRoom.PlayerCount <= 1)
            {
                main.IsAutoPlaying = false;
            }

            if (main.IsPlaying)
            {
                if (main.PopUp.CardExpansion.activeInHierarchy)
                {
                    main.PopUp.CardExpansion.SetActive(false);
                }

                main.Sound.StopTimerSound();
                main.JudgmentWinner();
            }
            Dic_IsLeft_Co.Remove(otherPlayer);
        }
        else if (PhotonNetwork.CurrentRoom.PlayerCount - GetWatchingPlayerCount() > 1)
        {
            if (main.IsPlaying && PhotonNetwork.IsMasterClient)
            {
                main.CallSetLeftDiePlayer(otherPlayer.ActorNumber);

                bool isWatchPlayer = false;

                for (int i = 0; i < List_WatchPlayers.Count; i++)
                {
                    if (List_WatchPlayers[i] == otherPlayer.ActorNumber)
                        isWatchPlayer = true;
                }

                if (!isWatchPlayer)
                {
                    if ((bool)otherPlayer.CustomProperties["IsDealer"])
                    {
                        PhotonNetwork.LocalPlayer.CustomProperties["IsDealer"] = true;
                    }

                    for (int i = 0; i < Arr_Players.Length; i++)
                    {
                        if (Arr_Players[i] != null)
                        {
                            if (Arr_Players[i].Info.ActorNumber == otherPlayer.ActorNumber)
                            {
                                if (!(bool)JudgeWatchingPlayer(otherPlayer.ActorNumber))
                                {
                                    if (main.IsPlayerTurns[i] && !main.IsResultWait)
                                    {
                                        if (Dic_PausePlayerBattingMoney.ContainsKey(otherPlayer.ActorNumber))
                                        {
                                            main.CallJudgmentRace(otherPlayer.ActorNumber, Dic_PausePlayerBattingMoney[otherPlayer.ActorNumber]);
                                            Debug.Log("CallJudgmentRace");
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Dic_IsLeft_Co.Remove(otherPlayer);
        }
    }

    IEnumerator Co_DestroyPlayer(Player otherPlayer)
    {
        GameMgr main = GetComponent<GameMgr>();

        LeftPlayer(otherPlayer);

        yield return new WaitForEndOfFrame();

        if (JudgeWatchingPlayer(otherPlayer.ActorNumber))
        {
            Destroy_PlayerProfile(otherPlayer);
        }
        else
        {
            WaitForSeconds wfsTime = CWFS.WFS(0.5f);

            while (true)
            {
                if (main.IsPossibilityDestroy)
                {
                    Destroy_PlayerProfile(otherPlayer);
                    break;
                }
                yield return wfsTime;
            }
        }
    }

    void Destroy_PlayerProfile(Player otherPlayer)
    {
        GameMgr main = GetComponent<GameMgr>();

        for (int i = 0; i < Arr_Players.Length; i++)
        {
            if (Arr_Players[i] != null)
            {
                if (Arr_Players[i].Info.ActorNumber == otherPlayer.ActorNumber)
                {
                    //photonView.RPC("ClearLeftPlayerCard", RpcTarget.All, otherPlayer.ActorNumber);
                    ClearLeftPlayerCard(otherPlayer.ActorNumber);
                    Destroy(Arr_Players[i].gameObject);
                    break;
                }
            }
        }

        for (int i = 0; i < SeatPlayerPK.Length; i++)
        {
            if (SeatPlayerPK[i] == otherPlayer.ActorNumber)
            {
                SeatPlayerPK[i] = -1;
            }
        }

        if (main.Dic_CheckCard.ContainsKey(otherPlayer.ActorNumber))
        {
            main.Dic_CheckCard.Remove(otherPlayer.ActorNumber);
        }
    }

    [PunRPC]
    void ClearLeftPlayerCard(int otherNum)
    {
        if(PhotonNetwork.LocalPlayer.ActorNumber != otherNum)
        {
            for (int i = 0; i < Arr_Players.Length; i++)
            {
                if(Arr_Players[i] != null)
                {
                    if(Arr_Players[i].Info.ActorNumber == otherNum)
                    {
                        Arr_Players[i].Clear();
                        break;
                    }
                }
            }
        }
    }

    [PunRPC]
    void SendDealer(int actorNum)
    {
        for (int i = 0; i < Arr_Players.Length; i++)
        {
            if (Arr_Players[i] != null)
            {
                if (Arr_Players[i].Info.ActorNumber == actorNum)
                {
                    Arr_Players[i].SetDealerImg(true);
                    break;
                }
            }
        }
    }
    [PunRPC]
    void SetDealerPlayer()
    {
        PhotonNetwork.LocalPlayer.CustomProperties["IsDealer"] = true;
    }
    [PunRPC]
    void SetLeaveReservation(bool active, int actorNum)
    {
        foreach (var item in Arr_Players)
        {
            if (item != null)
            {
                if (item.Info.ActorNumber == actorNum)
                {
                    item.SetLeaveReservation(active);
                    break;
                }
            }
        }
    }

    public override void OnDisconnected(DisconnectCause cause)
    {
        if (PhotonNetwork.CurrentRoom == null)
        {
            GetComponent<GameMgr>().Sound.StartSound_Effect(SoundFileList.EFFECT.door_out);
            GetComponent<GameMgr>().Sound.SetBGMSound(SoundFileList.BGM.MAIN);

            SceneManager.LoadScene("Lobby");
            StopAllCoroutines();
            GetComponent<GameMgr>().StopAllCoroutines();
        }

        if ((bool)PhotonNetwork.LocalPlayer.CustomProperties["IsDealer"])
        {
            for (int i = 0; i < Arr_Players.Length; i++)
            {
                if (Arr_Players[i] != null)
                {
                    if (Arr_Players[i].Info.ActorNumber == PhotonNetwork.LocalPlayer.ActorNumber)
                    {
                        if (i == Arr_Players.Length - 1)
                        {
                            GetPlayer(Arr_Players[0].Info.ActorNumber).CustomProperties["IsDealer"] = true;
                        }
                        else
                        {
                            GetPlayer(Arr_Players[i + 1].Info.ActorNumber).CustomProperties["IsDealer"] = true;
                        }
                    }
                }
            }
        }
    }

    private void OnApplicationPause(bool pause)
    {
        if (pause)
        {
            PhotonNetwork.LocalPlayer.CustomProperties["PrevTotalMoney"] = GetComponent<GameMgr>().PrevPlayerTotalBattingMoney;

            photonView.RPC("StartDisconnectDestroy", RpcTarget.Others, PhotonNetwork.LocalPlayer, GetComponent<GameMgr>().BattingMoney, GetComponent<GameMgr>().IsPossibilityDestroy);
            PhotonNetwork.SendAllOutgoingCommands();

            if (PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                foreach (KeyValuePair<int, Player> player in PhotonNetwork.CurrentRoom.Players)
                {
                    if (player.Value != PhotonNetwork.LocalPlayer)
                    {
                        photonView.RPC("SwitchMasterClient", PhotonNetwork.LocalPlayer.GetNext());
                        PhotonNetwork.SendAllOutgoingCommands();
                        break;
                    }
                }
            }
        }
        else
        {
            if (!PhotonNetwork.IsConnected)
            {
                LeaveRoom();
            }
            else
            {
                if (PhotonNetwork.CurrentRoom.PlayerCount > 1)
                {
                    Player sendPlayer = null;
                    List<Player> list_players = new List<Player>();
                    foreach (KeyValuePair<int, Player> player in PhotonNetwork.CurrentRoom.Players)
                    {
                        list_players.Add(player.Value);
                    }

                    for (int i = 0; i < list_players.Count; i++)
                    {
                        if (list_players[i].ActorNumber != PhotonNetwork.LocalPlayer.ActorNumber)
                        {
                            sendPlayer = list_players[i];
                        }
                    }
                     // 로직 재확인
                    photonView.RPC("JudgmentLeavePlayer", RpcTarget.Others, PhotonNetwork.LocalPlayer); // 내가 나간 상태인지 받아오기
                    PhotonNetwork.SendAllOutgoingCommands();
                    photonView.RPC("SendIsPlaying", RpcTarget.MasterClient, PhotonNetwork.LocalPlayer); // 현재 방의 게임 진행 여부 받아오기
                    PhotonNetwork.SendAllOutgoingCommands();
                }
                else
                {
                    LeaveRoom();
                }
            }
        }
    }
    [PunRPC]
    void SwitchMasterClient()
    {
        PhotonNetwork.SetMasterClient(PhotonNetwork.MasterClient.GetNext());
    }

    // 다른 플레이어에게서 게임이 진행 중인지 받아온다
    [PunRPC]
    void SendIsPlaying(Player player)
    {
        photonView.RPC("ReceiveIsPlaying", player, GetComponent<GameMgr>().IsPlaying);
    }

    [PunRPC]
    void ReceiveIsPlaying(bool isPlaying)
    {
        GetComponent<GameMgr>().IsPlaying = isPlaying;
    }

    [PunRPC]
    void JudgmentLeave(bool result) // pause 한 플레이어가 호출 || 나간상태 : false, 있는 상태 true
    {
        if (result)
        {
            photonView.RPC("StopDisConnectDestroy", RpcTarget.Others, PhotonNetwork.LocalPlayer);

            foreach (var item in Arr_Players)
            {
                if (item != null)
                {
                    item.SetSliderTimer(false);
                }
            }
        }
        else // 나가기
        {
            LeaveRoom();
        }
    }
    [PunRPC]
    void JudgmentLeavePlayer(Player player)
    {
        bool result = false;

        foreach (var item in Arr_Players)
        {
            if (item != null)
            {
                if (item.Info.ActorNumber == player.ActorNumber)
                {
                    result = true;
                    break;
                }
            }
        }

        if (!GetComponent<GameMgr>().IsPlaying)
        {
            result = false;
        }

        //List<CPlayer> players = new List<CPlayer>();

        //foreach (var item in Arr_Players)
        //{
        //    if (item != null)
        //    {
        //        players.Add(item);
        //    }
        //}

        if (PhotonNetwork.IsMasterClient)
        {
            photonView.RPC("JudgmentLeave", player, result);
        }
    }

    [PunRPC]
    void StopDisConnectDestroy(Player player)
    {
        if (Dic_PlayerWait.Count > 0)
        {
            PlayerWait_Co playerWait;
            if(Dic_PlayerWait.TryGetValue(player.ActorNumber, out playerWait))
            {
                playerWait.StopCo_PlayerWait();
                Dic_PlayerWait.Remove(player.ActorNumber);
            }

            //for (int i = 0; i < List_Wait_Co.Count; i++)
            //{
            //    if (List_Wait_Co[i].GetPlayer() == player)
            //    {
            //        List_Wait_Co[i].StopCo_PlayerWait();
            //        idx = i;
            //        break;
            //    }
            //}
            //List_Wait_Co.RemoveAt(idx);
        }
    }

    [PunRPC]
    void StartDisconnectDestroy(Player player, long totalBattingMoney, bool destroy)
    {
        if (Dic_PausePlayerBattingMoney.Count == 0)
        {
            Dic_PausePlayerBattingMoney.Add(player.ActorNumber, totalBattingMoney);
        }
        else
        {
            if (Dic_PausePlayerBattingMoney.ContainsKey(player.ActorNumber))
            {
                Dic_PausePlayerBattingMoney[player.ActorNumber] = totalBattingMoney;
            }
            else
            {
                Dic_PausePlayerBattingMoney.Add(player.ActorNumber, totalBattingMoney);
            }
        }

        if (player != PhotonNetwork.LocalPlayer && destroy)
        {
            PlayerWait_Co obj = Instantiate(PFWait_Co, this.transform);
            obj.StartCo_PlayerWait(player, this);

            Dic_PlayerWait.Add(player.ActorNumber, obj);
            //List_Wait_Co.Add(obj);
        }
    }

    public void OnClickBtn_Reflash()
    {
        OnClickBtn_LeaveRoom();
        PlayerPrefs.SetInt("ReflashRoom", 1);
    }

    void LeaveRoom()
    {
        if ((bool)PhotonNetwork.LocalPlayer.CustomProperties["IsDealer"])
        {
            foreach (KeyValuePair<int, Player> player in PhotonNetwork.CurrentRoom.Players)
            {
                if (player.Value != PhotonNetwork.LocalPlayer)
                {
                    photonView.RPC("SendDealer", RpcTarget.All, player.Value.ActorNumber);
                    photonView.RPC("SetDealerPlayer", player.Value, null);
                    if (PhotonNetwork.CurrentRoom.PlayerCount > 2)
                    {
                        photonView.RPC("NextDealer_AutoStart", player.Value);
                    }
                    break;
                }
            }
        }

        PhotonNetwork.LocalPlayer.CustomProperties["IsDealer"] = false;
        PhotonNetwork.LocalPlayer.CustomProperties["IsWatch"] = false;

        IsLeave = true;

        PhotonNetwork.LeaveRoom();
    }
    
    void NextDealer_AutoStart()
    {
        GetComponent<GameMgr>().AutoStart();
    }

    private void OnApplicationQuit()
    {
        IsLeave = true;

        PhotonNetwork.LeaveRoom();
    }
    public override void OnLeftRoom() // 나갔을때 처리
    {
        if (IsLeave)
        {
            GetComponent<GameMgr>().Sound.StartSound_Effect(SoundFileList.EFFECT.door_out);
            GetComponent<GameMgr>().Sound.SetBGMSound(SoundFileList.BGM.MAIN);

            SceneManager.LoadScene("Lobby");
            StopAllCoroutines();
            GetComponent<GameMgr>().StopAllCoroutines();
        }
    }

    public override void OnMasterClientSwitched(Player newMasterClient)
    {
        
        photonView.RPC("ShowGameStart", newMasterClient, null);
    }

    [PunRPC]
    void ShowGameStart()
    {
        GameMgr main = GetComponent<GameMgr>();

        if (!main.IsPlaying)
        {
            if (!main.IsAutoPlaying)
            {
                main.StartBtn.SetActive(true);
                main.StartBtn.GetComponent<Button>().interactable = true;
            }
        }
    }

    public int GetWatchingPlayerCount()
    {
        int watchingPlayer = 0;

        foreach (KeyValuePair<int, Player> player in PhotonNetwork.CurrentRoom.Players)
        {
            if ((bool)player.Value.CustomProperties["IsWatch"])
            {
                watchingPlayer++;
            }
        }

        return watchingPlayer;
    }

    public bool JudgeWatchingPlayer(int actorNum)
    {
        foreach (KeyValuePair<int, Player> player in PhotonNetwork.CurrentRoom.Players)
        {
            if (player.Value.ActorNumber == actorNum)
            {
                if ((bool)player.Value.CustomProperties["IsWatch"])
                {

                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        return false;
    }
}
