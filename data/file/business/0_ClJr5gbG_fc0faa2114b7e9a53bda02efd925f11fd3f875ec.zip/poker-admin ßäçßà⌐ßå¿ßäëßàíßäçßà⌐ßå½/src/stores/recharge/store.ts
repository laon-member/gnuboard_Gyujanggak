import { action, observable } from "mobx";
import RechargeService from "services/recharge/RechargeService";
import RootStore from "stores";
import { PagingType } from "stores/message/types";
import {
  TCancleRechRgeApply,
  TNewBankSetForm,
  TRechargeApply,
  TRechargeApplyPage,
  TRechargeBankSet,
  TRechargeBankSetPage,
  TRechargeLog,
  TRechargeLogPage,
  TSearchRechargeApply,
  TSearchRechargeBankSet,
  TSearchRechargeLog,
} from "./types";

export default class RechargeStore {
  root: RootStore;

  constructor(root: RootStore) {
    this.root = root;
  }

  @observable
  rechargeApplyPage = {
    paging: {} as PagingType,
    content: [] as TRechargeApply[],
  } as TRechargeApplyPage;

  @observable
  apply = {} as TRechargeApply;

  @observable
  rechargeLogPage = {
    paging: {} as PagingType,
    recharge: [] as TRechargeLog[],
  } as TRechargeLogPage;

  @observable
  rechargeBankSetPage = {
    paging: {} as PagingType,
    accounts: [] as TRechargeBankSet[],
  } as TRechargeBankSetPage;

  @observable
  bankSet = {} as TRechargeBankSet;

  @action
  getRechargeApplyPage = async (payload: TSearchRechargeApply) => {
    try {
      const res = await RechargeService.getRechargeApplyPage(payload);
      if (res.data.result) {
        this.rechargeApplyPage = res.data.data;
      } else {
        return alert("Field error");
      }
    } catch (error) {
      return alert("There is a problem with the server");
    }
  };

  @action
  setApply = (payload: TRechargeApply) => {
    this.apply = payload;
  };

  @action
  setBankSet = (payload: TRechargeBankSet) => {
    this.bankSet = payload;
  };

  @action
  passRechargeApply = async () => {
    return await RechargeService.passRechargeApply(this.apply);
  };

  @action
  cancleRechargeApply = async (payload: TCancleRechRgeApply) => {
    return await RechargeService.cancleRechargeApply({
      id: this.apply.id,
      message: payload.message,
    });
  };

  @action
  getRechargeLogPage = async (payload: TSearchRechargeLog) => {
    try {
      const res = await RechargeService.getRechargeLogPage(payload);
      if (res.data.result) {
        this.rechargeLogPage = res.data.data;
      } else {
        return alert("Field error");
      }
    } catch (error) {
      console.error(error);
      return alert("There is a problem with the server");
    }
  };

  @action
  getRechargeBankSet = async (payload: TSearchRechargeBankSet) => {
    try {
      const res = await RechargeService.getBankSetPage(payload);
      if (res.data.result) {
        this.rechargeBankSetPage = res.data.data;
      } else {
        return alert("Field error, Try again");
      }
    } catch (error) {
      return alert("There is a problem with the server");
    }
  };

  @action
  createBankSet = async (payload: TNewBankSetForm) => {
    return await RechargeService.createBankSet(payload);
  };

  @action
  modifyBankSet = async (payload: TRechargeBankSet) => {
    return await RechargeService.modifyBankSet(payload);
  };

  @action reserveApply = async () => {
    return await RechargeService.reserveApply(this.apply);
  };
}
