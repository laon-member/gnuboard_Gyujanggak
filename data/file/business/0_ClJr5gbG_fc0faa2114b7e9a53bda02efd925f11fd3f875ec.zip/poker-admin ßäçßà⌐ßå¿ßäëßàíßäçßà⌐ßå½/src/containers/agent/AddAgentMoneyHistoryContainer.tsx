import AddAgentMoneyHistoryList from "components/agent/addAgentMoneyHistory/AddAgentMoneyHistoryList";
import { useInputs } from "lib/hooks";
import { inject, observer } from "mobx-react";
import React, { useEffect } from "react";
import RootStore from "stores";
import {
  TAgentMoneyHistoryForms,
  TAgentMoneyHistoryPage,
  TAgentMoneyHistorySearch,
} from "stores/agent/types";

interface Props {
  agentMoneyHistoryPage: TAgentMoneyHistoryPage;
  getAgentMoneyHistoryPage: (payload: TAgentMoneyHistorySearch) => void;
}

const AddAgentMoneyHistoryContainer = ({
  agentMoneyHistoryPage,
  getAgentMoneyHistoryPage,
}: Props) => {
  const forms = {
    search: useInputs({
      username: "",
      agent_code: "",
      start_date: "",
      end_date: "",
      page: 1,
    } as TAgentMoneyHistorySearch),
  } as TAgentMoneyHistoryForms;

  useEffect(() => {
    (async () => {
      await getAgentMoneyHistoryPage(forms.search.inputs);
    })();
  }, []);

  const onSearch = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    await getAgentMoneyHistoryPage(forms.search.inputs);
  };

  return (
    <AddAgentMoneyHistoryList
      agentMoneyHistoryPage={agentMoneyHistoryPage}
      forms={forms}
      onSearch={onSearch}
    />
  );
};

export default inject(({ agentStore }: RootStore) => ({
  agentMoneyHistoryPage: agentStore.agentMoneyHistoryPage,
  getAgentMoneyHistoryPage: agentStore.getAgentMoneyHistoryPage,
}))(observer(AddAgentMoneyHistoryContainer));
