import { AxiosResponse } from "axios";
import JackpotList from "components/game/jackpotList/JackpotList";
import { EditBoxType } from "components/member/memberlist/types";
import { useInputs } from "lib/hooks";
import { inject, observer } from "mobx-react";
import React, { useEffect, useState } from "react";
import RootStore from "stores";
import {
  JackpotInfo,
  JackpotPage,
  PolicyType,
  SearchJackpotType,
  TPutPolicy,
} from "stores/jackpot/types";

interface Props {
  jackpotInfo: JackpotInfo;
  getJackpotInfo: () => void;
  getPolicyInfo: () => void;
  policyInfo: PolicyType[];
  getJackpotList: (payload: SearchJackpotType) => void;
  jackpotPage: JackpotPage;
  putPolicy: (payload: TPutPolicy) => AxiosResponse<any>;
}

const JackpotListContainer = ({
  jackpotInfo,
  getJackpotInfo,
  getPolicyInfo,
  policyInfo,
  getJackpotList,
  jackpotPage,
  putPolicy,
}: Props) => {
  useEffect(() => {
    (async () => {
      await getJackpotInfo();
      await getPolicyInfo();
      await getJackpotList(forms.search.inputs);
    })();
  }, []);
  const forms = {
    search: useInputs({
      id: "",
      start_date: "",
      end_date: "",
      page: 1,
    } as SearchJackpotType),
    policy: useInputs({
      limit_amount: "",
      level_1_consume: "",
      level_1_guarantee: "",
      level_1_headcount: "",
      level_2_consume: "",
      level_2_guarantee: "",
      level_2_headcount: "",
      level_3_consume: "",
      level_3_guarantee: "",
      level_3_headcount: "",
      level_4_consume: "",
      level_4_guarantee: "",
      level_4_headcount: "",
      level_5_consume: "",
      level_5_guarantee: "",
      level_5_headcount: "",
      level_6_consume: "",
      level_6_guarantee: "",
      level_6_headcount: "",
    } as TPutPolicy),
  };

  const onSearch = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    await getJackpotList(forms.search.inputs);
  };

  const [editToggle, setEditToggle] = useState(false);
  const onEditSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      const res = await putPolicy(forms.policy.inputs);
      if (res.data.result === 1) {
        await getPolicyInfo();
        await getJackpotInfo();
        setEditToggle(false);
      } else if (res.data.result === 0) {
        return alert("Policy field is empoy");
      }
    } catch (error) {
      return alert("There is a problem with the server");
    }
  };
  const jakpot: EditBoxType = {
    toggle: editToggle,
    onToggle: () => {
      if (editToggle) {
        forms.policy.init();
      }
      setEditToggle(!editToggle);
    },
    onSubmit: onEditSubmit,
  };
  return (
    <JackpotList
      jackpot={jakpot}
      onSearch={onSearch}
      jackpotInfo={jackpotInfo}
      policyInfo={policyInfo}
      jackpotPage={jackpotPage}
      searchForm={forms.search}
      policyForm={forms.policy}
    />
  );
};

export default inject(({ jackpotStore }: RootStore) => ({
  getJackpotInfo: jackpotStore.getJackpotInfo,
  jackpotInfo: jackpotStore.jackpotInfo,
  getPolicyInfo: jackpotStore.getPolicyInfo,
  policyInfo: jackpotStore.policyInfo,
  getJackpotList: jackpotStore.getJackpotList,
  jackpotPage: jackpotStore.jackpotPage,
  putPolicy: jackpotStore.putPolicy,
}))(observer(JackpotListContainer));
