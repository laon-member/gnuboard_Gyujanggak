﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
public class CardExpansion : MonoBehaviour
{
    public Image[] BackImgs;
    public Image FrontImg;

    bool IsClick = false;

    CPlayer CurPlayer;

    Vector2 Mouse = new Vector2();
    float Angle;

    public Text txt_Time;

    bool SecondCardShow;

    public bool CardCheckComplete;

    public GameMgr Main;

    public GameObject OpenEffect;
    public Image[] OpenImges;


    SoundManager Sound;

    public Sprite Spr_GeneType;

    public Transform TimerBG;

    Color TimerColor;

    public Sprite[] OpenText_Num;
    public GameObject[] OpenEffect_Gene; // 0 basic, 1 pair, 2 straight, 3 triple

    public GameObject OpenEffect_Coin;

    // Start is called before the first frame update
    void Start()
    {
        if(Sound == null)
        {
            Sound = FindObjectOfType<SoundManager>();

            Sound.StartTimerSound();

            TimerColor = txt_Time.color;
        }
    }

    private void OnEnable()
    {
        OpenEffect.transform.DOKill();
        OpenEffect_Coin.transform.DOKill();

        OpenEffect_Coin.transform.localScale = Vector3.zero;

        OpenEffect.transform.localRotation = Quaternion.Euler(new Vector3(0, 0, 180));
        OpenEffect_Coin.transform.localRotation = Quaternion.Euler(Vector3.zero);

        OpenEffect.SetActive(false);

        BackImgs[0].transform.DOLocalMoveY(-250, 0.25f);
        BackImgs[1].transform.DOLocalMoveY(-250, 0.25f);
        FrontImg.transform.DOLocalMoveY(-250, 0.25f).OnComplete(()=> StartCoroutine("Co_Timer"));

        CardCheckComplete = false;
    }

    private void OnDisable()
    {
        BackImgs[0].transform.localPosition = new Vector3(0, -1069, 0);
        BackImgs[1].transform.localPosition = new Vector3(0, -1069, 0);
        FrontImg.transform.localPosition = new Vector3(0, -1069, 0);

        BackImgs[0].transform.rotation = Quaternion.Euler(Vector3.zero);
        BackImgs[1].transform.rotation = Quaternion.Euler(Vector3.zero);
        FrontImg.transform.rotation = Quaternion.Euler(Vector3.zero);

        this.GetComponent<BoxCollider2D>().enabled = true;

        CardCheckComplete = true;
        Main.CompleteCardCheck();
    }

    IEnumerator Co_Timer()
    {
        txt_Time.color = TimerColor;
        int limitTime = 8;
        txt_Time.text = limitTime.ToString();

        WaitForSeconds wfsLong = CWFS.WFS(0.25f);
        WaitForSeconds wfsShort = CWFS.WFS(0.125f);

        for (int i = limitTime; i >= 0; i--)
        {
            if (i >= 3)
            {
                yield return wfsLong;
                TimerBG.transform.DOScale(1.2f, 0.25f);
                yield return wfsLong;
                TimerBG.transform.DOScale(1.0f, 0.25f);
                yield return wfsLong;
                TimerBG.transform.DOScale(1.2f, 0.25f);
                yield return wfsLong;
                TimerBG.transform.DOScale(1.0f, 0.25f);
            }
            else if (i < 3)
            {
                txt_Time.color = Color.red;
                yield return wfsShort;
                TimerBG.transform.DOScale(1.2f, 0.125f);
                yield return wfsShort;
                TimerBG.transform.DOScale(1.0f, 0.125f);
                yield return wfsShort;
                TimerBG.transform.DOScale(1.2f, 0.125f);
                yield return wfsShort;
                TimerBG.transform.DOScale(1.0f, 0.125f);
                yield return wfsShort;
                TimerBG.transform.DOScale(1.2f, 0.125f);
                yield return wfsShort;
                TimerBG.transform.DOScale(1.0f, 0.125f);
                yield return wfsShort;
                TimerBG.transform.DOScale(1.2f, 0.125f);
                yield return wfsShort;
                TimerBG.transform.DOScale(1.0f, 0.125f);
            }
            txt_Time.text = i.ToString();
        }

        // 타이머 종료시 카드 펴기
        this.transform.DOLocalMove(new Vector3(82, -150, 0), 0.3f);
        BackImgs[0].transform.DOLocalMove(new Vector3(-82, -150, 0), 0.3f);
        BackImgs[1].transform.DOLocalMove(new Vector3(0, -140, 0), 0.3f);

        this.transform.DORotate(new Vector3(0, 0, -25), 0.3f);
        BackImgs[0].transform.DORotate(new Vector3(0, 0, 25), 0.3f);
        BackImgs[1].transform.DORotate(new Vector3(0, 0, 0), 0.3f);

        yield return CWFS.WFS(0.3f);

        ReturnGame();
    }

    // Update is called once per frame
    void Update()
    {
        if (IsClick)
        {
            Mouse = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Angle = Mathf.Atan2(Mouse.y - transform.position.y, Mouse.x - transform.position.x) * Mathf.Rad2Deg;

            if(Angle >= 90)
            {
                this.transform.rotation = Quaternion.Euler(new Vector3(0, 0, 0));
            }
            else if(Angle <= 75)
            {
                this.transform.rotation = Quaternion.AngleAxis(Angle - 90, Vector3.forward);

                if (Angle <= 65)
                {
                    this.transform.rotation = Quaternion.Euler(new Vector3(0, 0, -25));

                }
                else
                {
                    BackImgs[1].transform.rotation = Quaternion.AngleAxis((Angle - 90) + 15f, Vector3.forward);
                }
            }
            else
            {
                this.transform.rotation = Quaternion.AngleAxis(Angle - 90, Vector3.forward);
            }
        }
    }

    public void SetImgInfo(string[] cards, CPlayer player)
    {
        BackImgs[0].sprite = Resources.Load<Sprite>(cards[0]);
        BackImgs[1].sprite = Resources.Load<Sprite>(cards[1]);
        FrontImg.sprite = Resources.Load<Sprite>(cards[2]);

        CurPlayer = player;
    }

    private void OnMouseDown()
    {
        IsClick = true;
    }

    private void OnMouseUp()
    {
        IsClick = false;

        this.GetComponent<BoxCollider2D>().enabled = false;

        this.transform.DOLocalMove(new Vector3(82, -150, 0), 0.3f);
        BackImgs[0].transform.DOLocalMove(new Vector3(-82, -150, 0), 0.3f);
        BackImgs[1].transform.DOLocalMove(new Vector3(0, -140, 0), 0.3f);

        this.transform.DORotate(new Vector3(0, 0, -25), 0.3f);
        BackImgs[0].transform.DORotate(new Vector3(0, 0, 25), 0.3f);
        BackImgs[1].transform.DORotate(new Vector3(0, 0, 0), 0.3f).OnComplete(()=> ReturnGame());
    }

    void ReturnGame()
    {
        StopCoroutine("Co_ReturnGame");
        StartCoroutine("Co_ReturnGame");
    }

    IEnumerator Co_ReturnGame()
    {
        this.GetComponent<BoxCollider2D>().enabled = false;

        StopCoroutine("Co_Timer");
        Sound.StartSound_Effect(SoundFileList.EFFECT.card_open);
        Sound.StopTimerSound();
        yield return CWFS.WFS(0.3f);

        for (int i = 0; i < OpenEffect_Gene.Length; i++)
        {
            OpenEffect_Gene[i].SetActive(false);
        }


        int[] result = Main.GetPlayerGeneType();

        switch ((CardGenealogy.GenealogyType)result[0])
        {
            case CardGenealogy.GenealogyType.Triple:
                {
                    OpenEffect_Gene[3].SetActive(true);
                }
                break;
            case CardGenealogy.GenealogyType.Straight:
                {
                    OpenEffect_Gene[2].SetActive(true);
                }
                break;
            case CardGenealogy.GenealogyType.Pair:
                {
                    OpenEffect_Gene[1].SetActive(true);
                }
                break;
            case CardGenealogy.GenealogyType.Basic:
                {
                    OpenEffect_Gene[0].SetActive(true);
                    OpenEffect_Gene[0].transform.GetChild(0).GetComponent<Image>().sprite = OpenText_Num[result[1]];
                }
                break;
        }

        if (OpenEffect.GetComponent<Image>().sprite != null)
        {
            OpenEffect.SetActive(true);
            OpenEffect.transform.DORotate(new Vector3(0, 0, 360 * 0.0f), 1.5f, RotateMode.FastBeyond360).OnComplete(() => ClearOpenEffect());
            OpenEffect_Coin.transform.DOScale(1.0f, 1.4f);
            OpenEffect_Coin.transform.DORotate(new Vector3(0, 0, 360 * 1.0f), 1.5f, RotateMode.FastBeyond360);
        }

        yield return CWFS.WFS(2.55f);

        CurPlayer.ShowCards();

        this.transform.parent.gameObject.SetActive(false);
    }

    void ClearOpenEffect()
    {
        if (this.gameObject.activeInHierarchy)
        {
            StartCoroutine("Co_ClearOpenEffect");
        }
    }
   
    IEnumerator Co_ClearOpenEffect()
    {
        if (this.gameObject.activeInHierarchy)
        {
            yield return CWFS.WFS(1.0f);

            OpenEffect.transform.DOKill();
            OpenEffect_Coin.transform.DOKill();

            OpenEffect_Coin.transform.localScale = Vector3.zero;

            OpenEffect.transform.localRotation = Quaternion.Euler(new Vector3(0, 0, 180));
            OpenEffect_Coin.transform.localRotation = Quaternion.Euler(Vector3.zero);


            OpenEffect.SetActive(false);
        }
    }
}
