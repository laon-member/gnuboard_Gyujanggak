import React from "react";
import { Route, NavLink } from "react-router-dom";

import { SubNavContainer, ContainerWrapper } from "pages/member/MemberPage";
import JackpotListContainer from "containers/game/JackpotListContainer";
import RoomListContainer from "containers/game/RoomListContainer";
// import RoomListContainer from "containers/game/RoomListContainer";

function GamePage() {
  return (
    <>
      <SubNavContainer>
        <li>
          <NavLink exact to="/admin/game" activeClassName="active">
            Jackpot
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/admin/game/room" activeClassName="active">
            RoomList
          </NavLink>
        </li>
      </SubNavContainer>
      <ContainerWrapper>
        <Route exact path="/admin/game" component={JackpotListContainer} />
        <Route exact path="/admin/game/room" component={RoomListContainer} />
      </ContainerWrapper>
    </>
  );
}

export default GamePage;
