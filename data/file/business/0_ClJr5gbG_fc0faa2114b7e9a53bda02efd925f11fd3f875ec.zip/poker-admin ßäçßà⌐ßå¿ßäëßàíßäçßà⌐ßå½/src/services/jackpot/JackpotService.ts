import client from "lib/client";
import { SearchJackpotType, TPutPolicy } from "stores/jackpot/types";
class JackpotService {
  public getJackpotInfo() {
    return client.get("/api/admin/jackpot/info");
  }

  public getPolicyInfo() {
    return client.get("/api/admin/jackpot/policyinfo");
  }

  public getJackpotList(payload: SearchJackpotType) {
    return client.get(
      `/api/admin/jackpot/jackpotinfo?id=${payload.id}&start_date=${payload.start_date}&end_date=${payload.end_date}&page=${payload.page - 1}`
    );
  }

  public putPolicy(payload: TPutPolicy) {
    return client.put(`/api/admin/jackpot/policy`, {
      limit_amount: payload.limit_amount,
      level_1_consume: payload.level_1_consume,
      level_1_guarantee: payload.level_1_guarantee,
      level_1_headcount: 1,
      level_2_consume: payload.level_2_consume,
      level_2_guarantee: payload.level_2_guarantee,
      level_2_headcount: 1,
      level_3_consume: payload.level_3_consume,
      level_3_guarantee: payload.level_3_guarantee,
      level_3_headcount: 3,
      level_4_consume: payload.level_4_consume,
      level_4_guarantee: payload.level_4_guarantee,
      level_4_headcount: 4,
      level_5_consume: payload.level_5_consume,
      level_5_guarantee: payload.level_5_guarantee,
      level_5_headcount: 5,
      level_6_consume: payload.level_6_consume,
      level_6_guarantee: payload.level_6_guarantee,
      level_6_headcount: 6,
    });
  }
  // public GetJackpotList(id?: string, startDate?: string, endDate?: string) {
  //   return client.get(`/api/admin/jackpot/jackpotinfo`, {
  //     params: {
  //       id,
  //       start_date: startDate,
  //       end_date: endDate,
  //     },
  //   });
  // }
  // public GetAmountOne() {
  //   return client.get(`/api/admin/jackpot/amountinfo`, {
  //     params: {},
  //   });
  // }
  // public GetPoclicyList() {
  //   return client.get(`/api/admin/jackpot/policyinfo`, {
  //     params: {},
  //   });
  // }

  // public PutPoclicyList(jackpotEditInfo: any) {
  //   const {
  //     limitValue,
  //     levelOneConsume,
  //     levelOneGuarantee,
  //     levelOneHeadCount,
  //     levelTwoConsume,
  //     levelTwoGuarantee,
  //     levelTwoHeadCount,
  //     levelThreeConsume,
  //     levelThreeGuarantee,
  //     levelThreeHeadCount,
  //     levelFourConsume,
  //     levelFourGuarantee,
  //     levelFourHeadCount,
  //     levelFiveConsume,
  //     levelFiveGuarantee,
  //     levelFiveHeadCount,
  //     levelSixConsume,
  //     levelSixGuarantee,
  //     levelSixHeadCount,
  //   } = jackpotEditInfo;
  //   return client.put(`/api/admin/jackpot/policy`, {
  //     limit_amount: limitValue,
  //     level_1_consume: levelOneConsume,
  //     level_1_guarantee: levelOneGuarantee,
  //     level_1_headcount: levelOneHeadCount,
  //     level_2_consume: levelTwoConsume,
  //     level_2_guarantee: levelTwoGuarantee,
  //     level_2_headcount: levelTwoHeadCount,
  //     level_3_consume: levelThreeConsume,
  //     level_3_guarantee: levelThreeGuarantee,
  //     level_3_headcount: levelThreeHeadCount,
  //     level_4_consume: levelFourConsume,
  //     level_4_guarantee: levelFourGuarantee,
  //     level_4_headcount: levelFourHeadCount,
  //     level_5_consume: levelFiveConsume,
  //     level_5_guarantee: levelFiveGuarantee,
  //     level_5_headcount: levelFiveHeadCount,
  //     level_6_consume: levelSixConsume,
  //     level_6_guarantee: levelSixGuarantee,
  //     level_6_headcount: levelSixHeadCount,
  //   });
  // }
}

export default new JackpotService();
