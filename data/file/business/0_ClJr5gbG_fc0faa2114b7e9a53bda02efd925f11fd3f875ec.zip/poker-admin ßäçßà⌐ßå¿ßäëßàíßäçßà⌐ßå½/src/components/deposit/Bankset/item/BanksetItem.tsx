import React from "react";
import { DepositType } from "stores/deposit/types";
import TableRowWrapper from "components/common/TableRowWrapper";
interface Props {
  data: DepositType;
  onActiveToggle: (id: number) => void;
}

function BanksetItem({ data, onActiveToggle }: Props) {
  return (
    <TableRowWrapper
      onClick={() => onActiveToggle(data.id)}
      active={data.active}
    >
      <td>{data.id}</td>
      <td>{data.bank}</td>
      <td>{data.name}</td>
      <td>{data.number}</td>
    </TableRowWrapper>
  );
}

export default BanksetItem;
