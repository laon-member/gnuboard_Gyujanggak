import AgentStatList from "components/statics/agentStat/AgentStatList";
import { useInputs } from "lib/hooks";
import { inject, observer } from "mobx-react";
import React, { useEffect } from "react";
import RootStore from "stores";
import {
  TAgentStatForms,
  TAgentStatPage,
  TAgentStatSearch,
} from "stores/statistics/types";

interface Props {
  agentPage: TAgentStatPage;
  getAgentStatPage: (payload: TAgentStatSearch) => void;
}

const AgentStatContainer = ({ agentPage, getAgentStatPage }: Props) => {
  const forms = {
    search: useInputs({
      start_date: "",
      end_date: "",
      page: 1,
    } as TAgentStatSearch),
  } as TAgentStatForms;

  useEffect(() => {
    (async () => {
      await getAgentStatPage(forms.search.inputs);
    })();
  }, []);

  const onSearch = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    console.log(forms.search.inputs);
    await getAgentStatPage(forms.search.inputs);
  };

  return (
    <AgentStatList agentPage={agentPage} forms={forms} onSearch={onSearch} />
  );
};

export default inject(({ staticStore }: RootStore) => ({
  agentPage: staticStore.agentStatPage,
  getAgentStatPage: staticStore.getAgentStatPage,
}))(observer(AgentStatContainer));
