import CancleNoteBox from "components/recharge/applyList/CancleNoteBox";
import { CancleType } from "components/recharge/applyList/types";
import React from "react";
import { TWithdrawFormType } from "services/withdraw/types";

interface Props {
  type: CancleType;
  form?: TWithdrawFormType;
}

function CancleNoteBoxContainer({ type, form }: Props) {
  return <CancleNoteBox type={type} form={form} />;
}

export default CancleNoteBoxContainer;
