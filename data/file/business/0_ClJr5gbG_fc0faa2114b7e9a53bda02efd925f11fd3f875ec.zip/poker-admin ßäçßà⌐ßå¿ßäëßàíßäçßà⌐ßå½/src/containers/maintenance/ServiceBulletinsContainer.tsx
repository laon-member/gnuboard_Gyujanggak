import React from 'react';

const serviceBulletinsContainer = () => {
  return (
    <>
      <h1>serviceBulletinsContainer</h1>
    </>
  );
}

export default serviceBulletinsContainer;