﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using LitJson;
using Leguar.TotalJSON;
using Photon.Realtime;
using Photon.Pun;

public class FriendManager : MonoBehaviourPunCallbacks
{
    public enum TYPE { SEARCH, MYFRIENDS, DEFAULT };
    public TYPE Type = TYPE.DEFAULT;

    public FriendContent PFFriend;

    public InputField SearchField;

    public GameObject[] Page;

    public Transform[] ScrollContent;

    public Image[] TopButtons;
    public Sprite[] Spr_TopBtn;

    public GameObject SearchCancle;


    public List<FriendContent> SearchList = new List<FriendContent>();
    public List<FriendContent> FriendList = new List<FriendContent>();

    DataBaseManager DBMgr;

    public Guidance Popup;

    public GameObject LobbyGirl;

    [Header("History")]
    public Transform HistoryParent;
    public JackpotContent PFGiftHistoryContent;

    List<JackpotContent> List_History = new List<JackpotContent>();

    [Header("GiftPopUp")]
    public GameObject GiftPopUp;
    public GameObject GiftPopUp_Check;
    public Text ReceivingUser;
    public InputField AmountField;

    // Start is called before the first frame update
    void Start()
    {
        if(DBMgr == null)
        {
            DBMgr = FindObjectOfType<DataBaseManager>();
        }

        CreateSearchList();
        CreateFriends();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void CreateSearchList() // 랜덤 친구 리스트 검색
    {

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetRandomUser, "", "Post", PlayerPrefs.GetString("Token"), (result) => {

            JsonData resp = JsonMapper.ToObject(result);
            
            if ((int)resp["result"] == 1)
            {
                int count = resp["data"]["list"].Count;

                for (int i = 0; i < count; i++)
                {
                    FriendContent content = Instantiate(PFFriend, ScrollContent[0]);

                    object[] info = new object[4];

                    info[0] = (int)resp["data"]["list"][i]["id"];
                    info[1] = (string)resp["data"]["list"][i]["username"];
                    if (resp["data"]["list"][i]["profile_img"] != null)
                    {
                        info[2] = (string)resp["data"]["list"][i]["profile_img"];
                    }
                    info[3] = (int)resp["data"]["list"][i]["status"];

                    content.SetFriendItem(info, this, 0);

                    SearchList.Add(content);
                }
            }
        }));
    }

    void CreateFriends() // 현재 친구 목록 조회
    {
        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetFriendList, "", "Post", PlayerPrefs.GetString("Token"), (result) => {

            JsonData resp = JsonMapper.ToObject(result);
            
            if((int)resp["result"] == 1)
            {
                int count = resp["data"]["friend"].Count;

                for (int i = 0; i < count; i++)
                {
                    FriendContent content = Instantiate(PFFriend, ScrollContent[1]);

                    object[] info = new object[4];

                    info[0] = (int)resp["data"]["friend"][i]["friend_id"];
                    info[1] = (string)resp["data"]["friend"][i]["username"];
                    if (resp["data"]["friend"][i]["profile_img"] != null)
                    {
                        info[2] = (string)resp["data"]["friend"][i]["profile_img"];
                    }

                    info[3] = (int)resp["data"]["friend"][i]["status"];
                    
                    content.SetFriendItem(info, this, 1);

                    FriendList.Add(content);
                }
            }
        }));
    }

    public void CreateFriendAdd(GameObject friend)
    {
        GameObject obj = Instantiate(friend, ScrollContent[1]);

        //obj.GetComponent<FriendContent>().ShowGiftBtn();
        obj.GetComponent<FriendContent>().AddBtn.sprite = obj.GetComponent<FriendContent>().Btn_Sprites[1];

        FriendList.Add(obj.GetComponent<FriendContent>());
    }
    
    public void DeleteSearchItem(FriendContent searchItem)
    {
        SearchList.Remove(searchItem);
        Destroy(searchItem.gameObject);
    }

    public void DeleteFriend(FriendContent friend)
    {
        foreach (var item in FriendList)
        {
            if(item == friend)
            {
                Destroy(item.gameObject);
                FriendList.Remove(item);
                break;
            }
        }
    }

    public void OnClickBtn_TopBtn(int idx)
    {
        if (idx == 0)
        {
            TopButtons[0].sprite = Spr_TopBtn[0]; // 활성

            TopButtons[1].sprite = Spr_TopBtn[1];             
            TopButtons[2].sprite = Spr_TopBtn[1]; // 비활성

            TopButtons[1].GetComponent<RectTransform>().sizeDelta = new Vector2(319, 84); // 비활성
            TopButtons[2].GetComponent<RectTransform>().sizeDelta = new Vector2(319, 84);

            // gift
            //TopButtons[0].transform.localPosition = new Vector3(56.0f, TopButtons[1].transform.localPosition.y);
            //TopButtons[1].transform.localPosition = new Vector3(410.5f, TopButtons[1].transform.localPosition.y);

            TopButtons[0].transform.localPosition = new Vector3(392.15f, TopButtons[1].transform.localPosition.y);
            TopButtons[1].transform.localPosition = new Vector3(745.0f, TopButtons[1].transform.localPosition.y);

            TopButtons[0].GetComponent<RectTransform>().sizeDelta = new Vector2(389, 112); // 활성

            Page[0].SetActive(true);
            Page[1].SetActive(false);
            Page[2].SetActive(false);

            LobbyGirl.SetActive(true);
            SearchField.gameObject.SetActive(true);

            foreach (var item in SearchList)
            {
                item.gameObject.SetActive(true);
            }
        }
        else if(idx == 1)
        {
            TopButtons[0].sprite = Spr_TopBtn[1];
            TopButtons[2].sprite = Spr_TopBtn[1]; // 비활성

            TopButtons[1].sprite = Spr_TopBtn[0]; // 활성


            TopButtons[0].GetComponent<RectTransform>().sizeDelta = new Vector2(319, 84); // 비활성
            TopButtons[2].GetComponent<RectTransform>().sizeDelta = new Vector2(319, 84);

            // gift

            //TopButtons[0].transform.localPosition = new Vector3(21.5f, TopButtons[0].transform.localPosition.y);
            //TopButtons[1].transform.localPosition = new Vector3(376.0f, TopButtons[1].transform.localPosition.y);

            TopButtons[0].transform.localPosition = new Vector3(392.15f, TopButtons[0].transform.localPosition.y);
            TopButtons[1].transform.localPosition = new Vector3(745.0f, TopButtons[1].transform.localPosition.y);

            TopButtons[1].GetComponent<RectTransform>().sizeDelta = new Vector2(389, 112); // 활성

            Page[0].SetActive(false);
            Page[2].SetActive(false);
            Page[1].SetActive(true);

            LobbyGirl.SetActive(true);
            SearchField.gameObject.SetActive(true);
        }
        else if(idx == 2)
        {
            CreateGiftHistory(); // 히스토리 생성

            TopButtons[0].sprite = Spr_TopBtn[1];// 비활성
            TopButtons[1].sprite = Spr_TopBtn[1];
            
            TopButtons[2].sprite = Spr_TopBtn[0]; // 활성

            TopButtons[0].GetComponent<RectTransform>().sizeDelta = new Vector2(319, 84); // 비활성
            TopButtons[1].GetComponent<RectTransform>().sizeDelta = new Vector2(319, 84);
            TopButtons[0].transform.localPosition = new Vector3(56.9f, TopButtons[1].transform.localPosition.y);
            TopButtons[1].transform.localPosition = new Vector3(376.0f, TopButtons[1].transform.localPosition.y);

            TopButtons[2].GetComponent<RectTransform>().sizeDelta = new Vector2(389, 112); // 활성

            Page[0].SetActive(false);
            Page[1].SetActive(false);
            Page[2].SetActive(true);

            LobbyGirl.SetActive(false);
            SearchField.gameObject.SetActive(false);
        }

        SearchField.text = "";
        SearchCancle.SetActive(false);

        Type = (TYPE)idx;
    }

    void ClearGiftHistory()
    {
        for (int i = 0; i < List_History.Count; i++)
        {
            Destroy(List_History[i].gameObject);
        }

        List_History.Clear();
    }

    void CreateGiftHistory()
    {
        ClearGiftHistory();

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetGiftHistorys, "", "Post", PlayerPrefs.GetString("Token"), (result) =>
        {
            JsonData resp = JsonMapper.ToObject(result);

            if ((int)resp["result"] == 1)
            {
                if (resp["data"].Count == 0)
                {

                }
                else if (resp["data"].Count != 0)
                {
                    for (int i = 0; i < resp["data"]["history"].Count; i++)
                    {
                        JackpotContent content = Instantiate(PFGiftHistoryContent, HistoryParent);

                        string[] info = new string[5];

                        info[0] = (i + 1).ToString();
                        info[1] = (string)resp["data"]["history"][i]["profile_img"];
                        info[2] = (string)resp["data"]["history"][i]["username"];

                        info[3] = CStringFormat.Instance.FormatToInt(long.Parse(resp["data"]["history"][i]["amount"].ToString()));

                        string date_buffer = (string)resp["data"]["history"][i]["updated_at"];
                        string date = "";

                        for (int j = 0; j < 10; j++)
                        {
                            date += date_buffer[j].ToString();
                        }

                        info[4] = date;

                        content.SetInfo(info);

                        List_History.Add(content);
                    }
                }
            }
        }));
    }

    // 선물하기 팝업
    public void OpenPopUp_Gift(string userName)
    {
        GiftPopUp.SetActive(true);
        ReceivingUser.text = '"' + userName + '"';
        AmountField.text = "";
    }

    public void OnClickBtn_GiftPopUp(bool result)
    {
        if(result) // 보내기
        {
            // DB 데이터 보내기

            // 보낼 데이터 : 유저 이름, 금액

            // 성공이면 확인 팝업 띄우기
            if (AmountField.text.Length > 0)
            {
                ReceivingUser.text = "";
                GiftPopUp.SetActive(false);

                GiftPopUp_Check.SetActive(true);
            }
        }
        else // 취소
        {
            ReceivingUser.text = "";
            GiftPopUp.SetActive(false);
            AmountField.text = "";
        }
    }

    public void OnClickBtn_CloseGiftPopUp_Check()
    {
        GiftPopUp_Check.SetActive(false);
    }

    // 친구 검색
    public override void OnDisconnected(DisconnectCause cause)
    {
        SceneManager.LoadScene("LogIn");
    }

    public void OnValueChange_Search()
    {
        if(SearchField.text.Length >= 1)
        {
            SearchCancle.SetActive(true);
        }
    }

    public void OnClickBtn_SearchCancle()
    {
        if (Type == TYPE.MYFRIENDS)
        {
            if (FriendList.Count != 0)
            {
                foreach (var item in FriendList)
                {
                    item.gameObject.SetActive(true);
                }
            }
        }
        else
        {
            if (SearchList.Count != 0)
            {
                foreach (var item in SearchList)
                {
                    item.gameObject.SetActive(true);
                }
            }
        }

        SearchField.text = "";
        SearchCancle.SetActive(false);
    }
    public void OnClickBtn_Leave()
    {
        SceneManager.LoadScene("Lobby");
    }
    public void OnClickBtn_Search()
    {
        if (SearchField.text.Length != 0)
        {
            if (Type == TYPE.SEARCH)
            {
                int searchNum = int.Parse(SearchField.text);
                bool searchResult = false;

                for (int i = 0; i < SearchList.Count; i++)
                {
                    if (SearchList[i].PlayerNumber == searchNum)
                    {
                        searchResult = true;
                        break;
                    }
                }

                if (searchResult)
                {
                    foreach (var item in SearchList)
                    {
                        if (item.PlayerNumber != searchNum)
                        {
                            item.gameObject.SetActive(false);
                        }
                    }
                }
                else
                {
                    //? 생성
                    JSON jsonData = new JSON();
                    jsonData.Add("friend_id", SearchField.text);

                    StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.CreateSearchFriend, jsonData.CreateString(), "Post", PlayerPrefs.GetString("Token"), (result) =>
                    {
                        JsonData resp = JsonMapper.ToObject(result);

                        if ((int)resp["result"] == 1)
                        {
                            if (resp["data"].Count == 0)
                            {
                                Popup.SetText("Không có người chơi tương ứng"); // 번역 : 해당하는 유저가 없습니다. o
                            }
                            else if (resp["data"].Count != 0)
                            {
                                FriendContent content = Instantiate(PFFriend, ScrollContent[0]);

                                object[] info = new object[4];

                                info[0] = int.Parse(SearchField.text);
                                info[1] = (string)resp["data"]["friend"]["username"];
                                
                                if (resp["data"]["friend"]["profile_img"] != null)
                                {
                                    info[2] = (string)resp["data"]["friend"]["profile_img"];
                                }
                                info[3] = (int)resp["data"]["friend"]["status"];

                                content.SetFriendItem(info, this, 0);

                                SearchList.Add(content);

                                foreach (var item in SearchList)
                                {
                                    if(item.PlayerNumber != searchNum)
                                    {
                                        item.gameObject.SetActive(false);
                                    }
                                }
                            }
                            else
                            {
                                Popup.SetText("Bạn bè của bạn đã đăng kí từ trước"); // 번역 : 이미 등록된 친구 입니다. o
                            }
                        }
                    }));
                }
            }
            else if (Type == TYPE.MYFRIENDS)
            {
                foreach (var item in FriendList)
                {
                    if (item.PlayerNumber != int.Parse(SearchField.text)) // 찾으면
                    {
                        item.gameObject.SetActive(false);
                    }
                }
            }
        }
    }
    public void OnClickBtn_ClickSound()
    {
        FindObjectOfType<SoundManager>().StartSound_Effect(SoundFileList.EFFECT.btn_click);
    }
}
