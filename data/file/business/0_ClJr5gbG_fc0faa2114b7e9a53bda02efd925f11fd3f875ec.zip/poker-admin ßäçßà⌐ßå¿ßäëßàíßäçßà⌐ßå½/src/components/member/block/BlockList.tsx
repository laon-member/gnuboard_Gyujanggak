import NoDataBox from "components/common/NoDataBox";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import EditBoxContainer from "containers/common/dialog/EditBoxContainer";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import React from "react";
import { FaSearch } from "react-icons/fa";
import {
  MemberAmount,
  MemberSearch,
  MemberType,
  TBlock,
  TBlockForms,
} from "stores/member/types";
import { PagingType } from "stores/message/types";
import { Button, Input } from "styles/atom";
import { ChangeBox } from "../memberlist/ChangeBox";
import { NoteType } from "../memberlist/types";
import Block from "./Block";
import NoteBox from "./NoteBox";

interface Props {
  editToggle: boolean;
  infoToggle: boolean;
  onEditToggle: () => void;
  onInfoToggle: () => void;
  onEditSubmit: (
    e: React.FormEvent<HTMLFormElement>,
    memberAmount?: MemberAmount
  ) => void;
  onInfoSubmit: (
    e: React.FormEvent<HTMLFormElement>,
    modifyMember?: MemberType
  ) => void;
  note: NoteType;
  getMember: (id: number) => void;
  getBlocks: (blockSearch: MemberSearch) => void;
  blockList: TBlock[];
  member: MemberType;
  forms: TBlockForms;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
  blockPage: PagingType;
}

const BlockList = ({
  editToggle,
  infoToggle,
  onEditToggle,
  onInfoToggle,
  onEditSubmit,
  onInfoSubmit,
  note,
  blockList,
  forms,
  getMember,
  onSearch,
  member,
  blockPage,
}: Props) => {
  const { onChange } = forms.search;

  return (
    <>
      {note.toggle && (
        <NoteBox onToggle={note.onToggle} content={member.block_note!} />
      )}
      {editToggle && (
        <EditBoxContainer
          onEditToggle={onEditToggle}
          onEditSubmit={onEditSubmit}
          member={member}
        />
      )}
      {infoToggle && (
        <ChangeBox
          onInfoToggle={onInfoToggle}
          onInfoSubmit={onInfoSubmit}
          member={member}
          form={forms.edit}
        />
      )}
      <SearchWrapper>
        <SearchForm onSubmit={onSearch}>
          <Input placeholder="ID" name="id" onChange={onChange} />
          <Input
            type="text"
            name="name"
            placeholder="NickName"
            onChange={onChange}
          />
          <Input type="date" name="start_date" onChange={onChange} />
          <Input type="date" name="end_date" onChange={onChange} />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>No.</th>
            {/* <th>Room</th> */}
            <th>ID</th>
            <th>NickName</th>
            <th>Agent</th>
            <th>Mobile</th>
            <th>Gold</th>
            <th>RegisterTime</th>
            <th>LastLogin</th>
            <th>BankAccount</th>
            <th>BankName</th>
            <th>CardNumber</th>
            <th>RechargeSum</th>
            <th>WithdrawSum</th>
            <th>Note</th>
            <th>Opt</th>
            <th>ChangeInfo</th>
          </tr>
        </thead>
        <tbody>
          {blockPage.total_page
            ? blockList.map((block) => (
                <Block
                  key={block.id}
                  block={block}
                  note={note}
                  getMember={getMember}
                  onInfoToggle={onInfoToggle}
                  onEditToggle={onEditToggle}
                />
              ))
            : null}
        </tbody>
      </Table>

      {blockPage.total_count ? (
        <PageNationContainer
          paging={blockPage}
          searchForm={forms.search}
          onSearch={onSearch}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
};

export default BlockList;
