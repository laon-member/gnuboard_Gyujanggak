import React from "react";
import { inject, observer } from "mobx-react";

import DepositStore from "stores/deposit";
import Rechargelist from "components/deposit/Rechargelist";

interface Props {
  depositStore?: DepositStore;
}

@inject("depositStore")
@observer
class RechargeListContainer extends React.Component<Props> {
  private DepositStore = this.props.depositStore! as DepositStore;

  async componentDidMount() {
    await this.DepositStore.GetRechargeList();
  }

  insert = async () => {};

  update = async () => {};

  del = async () => {};

  onSearch = async (
    id?: string,
    phone?: string,
    status?: string,
    startDate?: string,
    endDate?: string
  ) => {
    await this.DepositStore.GetRechargeList(
      id,
      phone,
      status,
      startDate,
      endDate
    );
  };

  render() {
    return (
      <Rechargelist
        depositList={this.DepositStore.DepositList}
        onSearch={this.onSearch}
      />
    );
  }
}

export default RechargeListContainer;
