import React from "react";
import styled from "styled-components";
import MainNavContainer from "containers/common/MainNavContainer";
import { Playing } from "stores/user/types";
import { DepositAndWithdrawInfo } from "stores/admin/types";
import comma from "lib/comma";

interface Props {
  onLogout: () => void;
  adminId: string;
  playing: Playing;
  role: string;
  depositWithdrawInfo: DepositAndWithdrawInfo;
}

const Header = ({
  onLogout,
  adminId,
  playing,
  role,
  depositWithdrawInfo,
}: Props) => {
  if (!depositWithdrawInfo) return <h1>loading...</h1>;
  return (
    <>
      <HeaderWrapper>
        <h1>ADMINISTRATOR</h1>

        <div className="game">
          <div className="lobbyCounter">
            <h4>{comma(playing.online)}</h4>
            <h2>Online Players</h2>
          </div>
          <div className="lobbyCounter">
            <h4>{comma(playing.lobby)}</h4>
            <h2>Lobby</h2>
          </div>
          <div className="lobbyCounter">
            <h4>{comma(playing.lv1)}</h4>
            <h2>Lv.1</h2>
          </div>
          <div className="lobbyCounter">
            <h4>{comma(playing.lv2)}</h4>
            <h2>Lv.2</h2>
          </div>
          <div className="lobbyCounter">
            <h4>{comma(playing.lv3)}</h4>
            <h2>Lv.3</h2>
          </div>
          <div className="lobbyCounter">
            <h4>{comma(playing.lv4)}</h4>
            <h2>Lv.4</h2>
          </div>
          <div className="lobbyCounter">
            <h4>{comma(playing.lv5)}</h4>
            <h2>Lv.5</h2>
          </div>
          <div className="lobbyCounter">
            <h4>{comma(playing.lv6)}</h4>
            <h2>Lv.6</h2>
          </div>
        </div>

        <div className="deposit">
          <h3>Recharge</h3>
          <h4>{comma(depositWithdrawInfo.deposit)}</h4>
          <h3>Withdraw</h3>
          <h4>{comma(depositWithdrawInfo.withdraw)}</h4>
          <h3>PlayersGoldSum</h3>
          <h4>{comma(depositWithdrawInfo.holding_amount)}</h4>
        </div>

        <div className="admin">
          <span>{adminId}</span>
          <button onClick={onLogout}>LOG OUT</button>
        </div>
      </HeaderWrapper>
      <MainNavContainer role={role} playing={playing} />
    </>
  );
};

export const HeaderWrapper = styled.header`
  background: #1c1c1f;
  height: 80px;
  padding: 1rem;
  display: flex;
  justify-content: space-between;
  align-items: center;

  * {
    color: #fff;
  }

  & > h1 {
    font-size: 1.4rem;
  }

  .game,
  .deposit,
  .admin {
    display: flex;
    align-items: center;
  }

  .game {
    height: 100%;
    width: 600px;
    display: flex;
    justify-content: space-between;

    .lobbyCounter {
      height: 100%;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      align-items: center;
      margin-right: 1rem;

      h4 {
        color: #cc7264;
        font-weight: bold;
      }
    }
  }

  .deposit {
    & > * {
      margin-right: 0.5rem;
    }
    h4 {
      color: #cc7264;
      margin-right: 2rem;
      font-weight: bold;
    }
  }

  .admin {
    height: 100%;
    display: flex;
    align-items: center;

    button {
      background: none;
      padding: 0.25rem 1rem;
      border: 1px solid #fff;
      outline: none;
      cursor: pointer;
      margin-left: 1rem;

      &:hover {
        background: #fff;
        color: #444444;
        transition: ease 0.3s;
      }
      &:active {
        transform: translateY(3px);
      }
    }
  }

  .agent {
    height: 100%;
    display: flex;
    justify-content: space-between;
  }
`;

export default Header;
