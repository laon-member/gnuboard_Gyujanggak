import AdminBox from "components/adminSet/AdminBox";
import { EditBoxType } from "components/member/memberlist/types";
import React from "react";
import { AdminType } from "stores/admin/types";

interface Props {
  _new?: EditBoxType;
  admin?: AdminType;
  edit?: EditBoxType;
}

function AdminBoxContainer({ _new, admin, edit }: Props) {
  return <AdminBox _new={_new!} admin={admin!} edit={edit!} />;
}

export default AdminBoxContainer;
