import React from "react";

import LoginContainer from "containers/login/LoginContainer";

function LoginPage() {
  return <LoginContainer />;
}

export default LoginPage;
