import { FormWrapper, RightAligned } from "components/notice/popup/Popup";
import React from "react";
import { FaSearch } from "react-icons/fa";
import { UserFormType, UserType } from "stores/message/types";
import styled from "styled-components";
import { Button, Input } from "styles/atom";
import { TextArea } from "styles/atom/TextArea";
import IdButton from "./IdButton";

interface Props {
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
  onSend: () => void;
  userList: UserType[];
  searchForm: UserFormType;
  setUser: (id: number) => void;
  user: UserType;
  initUserList: () => void;
  initUser: () => void;
}

function EditMessage({
  onSearch,
  onSend,
  userList,
  searchForm: { inputs, onChange, setInputs, init },
  setUser,
  user,
  initUserList,
  initUser,
}: Props) {
  const radioHander = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value === "1") {
      initUserList();
      initUser();
    }

    setInputs({
      ...inputs,
      [e.target.name]: e.target.value,
    });
  };

  const userHandler = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputs({
      ...inputs,
      [e.target.name]: e.target.value,
    });
  };

  const validateInputs = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (inputs.title === "" || inputs.content === "")
      return alert("Title or Content is empty");

    if (inputs.type === "0" && !user)
      return alert("user is empty please select user");
    if (user && inputs.type === "0") {
      setInputs({
        ...inputs,
        username: user.username,
      });
    }

    onSend();
  };

  const onReset = () => {
    init();
    initUserList();
    initUser();
  };
  return (
    <>
      <FormWrapper onSubmit={onSearch}>
        <div className="inputWrapper">
          <label>Type</label>
          <div className="types">
            <Input
              type="radio"
              name="type"
              value="1"
              checked={inputs.type === "1"}
              onChange={radioHander}
            />{" "}
            <span>Global</span>
            <Input
              type="radio"
              name="type"
              value="0"
              checked={inputs.type === "0"}
              onChange={radioHander}
            />{" "}
            <span>Single Mail</span>
            <Input
              placeholder="ID"
              name="username"
              value={inputs.username}
              onChange={onChange}
            />
            <Button type="submit">
              Search <FaSearch />
            </Button>
          </div>
        </div>
        {userList.length > 0 && (
          <div className="inputWrapper">
            <label> </label>
            <IdResultWrapper>
              {userList.map((user: UserType) => (
                <IdButton key={user!.id} user={user} setUser={setUser} />
              ))}
            </IdResultWrapper>
          </div>
        )}
      </FormWrapper>
      <FormWrapper onSubmit={validateInputs}>
        <div className="inputWrapper">
          <label>Receiver</label>
          <Input
            placeholder="Search user and select"
            value={inputs.type === "1" ? "All" : !user ? "" : user.username}
            onChange={userHandler}
            disabled={true}
          />
        </div>
        <div className="inputWrapper">
          <label>Title</label>
          <Input
            placeholder="Title"
            name="title"
            value={inputs.title}
            onChange={onChange}
          />
        </div>
        <div className="inputWrapper">
          <label>Content</label>
          <TextArea
            placeholder="Content"
            name="content"
            value={inputs.content}
            onChange={onChange}
          />
        </div>
        <RightAligned>
          <Button type="button" onClick={onReset}>
            RESET
          </Button>
          <Button type="submit" active>
            SEND
          </Button>
        </RightAligned>
      </FormWrapper>
    </>
  );
}

const IdResultWrapper = styled.div`
  width: 30px;
  margin-bottom: -1.5rem;
  max-height: 200px;
  overflow: scroll;
  cursor: pointer;
`;

export default EditMessage;
