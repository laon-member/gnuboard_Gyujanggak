import React from "react";

function AgentStatList() {
  return <h1>Agent stat</h1>;
}

export default AgentStatList;
