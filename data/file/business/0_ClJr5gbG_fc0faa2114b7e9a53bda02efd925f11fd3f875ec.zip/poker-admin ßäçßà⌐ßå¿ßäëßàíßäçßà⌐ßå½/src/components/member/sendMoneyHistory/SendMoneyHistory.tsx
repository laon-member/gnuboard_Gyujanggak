import { TableRowWrapper } from "components/common";
import comma from "lib/comma";
import React from "react";
import { TSMHistory } from "stores/member/types";

interface Props {
  idx: number;
  log: TSMHistory;
}

function SendMoneyHistory({ log, idx }: Props) {
  return (
    <TableRowWrapper>
      <td>{idx}</td>
      <td>{log.sender}</td>
      <td>{log.receiver}</td>
      <td>{comma(parseInt(log.amount, 10))}</td>
      <td>{log.agnet}</td>
      <td>{log.created_at}</td>
    </TableRowWrapper>
  );
}

export default SendMoneyHistory;
