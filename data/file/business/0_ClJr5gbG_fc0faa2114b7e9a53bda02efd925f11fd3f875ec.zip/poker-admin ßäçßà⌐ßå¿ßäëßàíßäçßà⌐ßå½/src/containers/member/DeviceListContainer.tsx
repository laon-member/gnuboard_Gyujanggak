
import DeviceList from 'components/member/DeviceList';
import { useObserver } from 'mobx-react';
import React from 'react';

const DeviceListContainer = () => {
  return (
    useObserver(() => <DeviceList />)
  );
}

export default DeviceListContainer;