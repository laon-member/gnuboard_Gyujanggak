import React from "react";
import styled from "styled-components";

const RollingModify = () => {
  return (
    <Wrap>
      <div className="title">
        <h2>롤링메세지 Edit</h2>
      </div>

      <div>
        <ul>
          <li>
            <p>Content</p>
            <p>
              <input type="text" />
            </p>
          </li>
          <li>
            <p>BeginTime</p>
            <p>
              <input type="text" />
            </p>
          </li>
          <li>
            <p>EndTime</p>
            <p>
              <input type="text" />
            </p>
          </li>
          <li>
            <p>Timelntv (s)</p>
            <p>
              <input type="text" />
            </p>
          </li>
          <li>
            <p>Position</p>
            <p>
              <input type="text" />
            </p>
          </li>
        </ul>
      </div>

      <div className="button">
        <button>Edit</button>
        <button>취소</button>
      </div>
    </Wrap>
  );
};
const Wrap = styled.div`
  width: 550px;

  background: #fff;

  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);

  & > .title {
    width: 100%;
    height: 68px;

    text-align: center;
    line-height: 68px;

    border-bottom: 1px solid #ddd;

    & > h2 {
      font-weight: normal;
      font-size: 18px;
      color: #333;
    }
  }

  & > div {
    width: 100%;

    & > ul {
      width: 90%;
      margin: 40px auto 40px;

      & > li {
        width: 100%;

        overflow: hidden;
        & > p {
          float: left;
        }
        & > p:nth-child(1) {
          width: 120px;
          margin-left: 60px;
          line-height: 60px;
          font-size: 14px;
          color: #333;
        }
        & > p:nth-child(2) {
          line-height: 60px;
          & > input {
            width: 260px;
            height: 30px;
            padding: 5px 12px;
            border: 1px solid #ccc;
            border-radius: 7px;
            font-size: 14px;
            color: #333;
            ::placeholder {
              color: #ccc;
            }
          }
        }
      }
      & > li:nth-child(1) {
        & > p:nth-child(1) {
          line-height: 22px;
        }
        & > p:nth-child(2) {
          & > input {
            height: 150px;
          }
        }
      }
    }
  }
  & > .button {
    width: 100%;
    height: 82px;

    text-align: center;
    line-height: 70px;

    & > button:nth-child(1) {
      width: 195px;
      height: 40px;
      background: #007fdb;
      border: none;
      color: #fff;
    }
    & > button:nth-child(2) {
      width: 195px;
      height: 40px;
      background: #ddd;
      border: none;
      color: #333;
      margin-left: 20px;
    }
  }
`;
export default RollingModify;
