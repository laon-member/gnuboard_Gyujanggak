import AgentStatListContainer from "containers/distributor/statistics/AgentStatListContainer";
import { ContainerWrapper, SubNavContainer } from "pages/member/MemberPage";
import React from "react";
import { NavLink, Route, Switch } from "react-router-dom";

function AgentStatisticsPage() {
  return (
    <>
      <SubNavContainer>
        <li>
          <NavLink exact to="/agent/statistics" activeClassName="active">
            AgentStat
          </NavLink>
        </li>
      </SubNavContainer>
      <ContainerWrapper>
        <Switch>
          <Route
            exact
            to="/agent/statistics"
            component={AgentStatListContainer}
          />
        </Switch>
      </ContainerWrapper>
    </>
  );
}

export default AgentStatisticsPage;
