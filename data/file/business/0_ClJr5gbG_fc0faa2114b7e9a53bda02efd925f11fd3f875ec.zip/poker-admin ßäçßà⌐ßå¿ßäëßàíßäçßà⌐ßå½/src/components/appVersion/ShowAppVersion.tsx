import { TableRowWrapper } from "components/common";
import Table from "components/common/Table";
import React from "react";
import styled from "styled-components";

interface Props {
  appVersion: string;
}

function ShowAppVersion({ appVersion }: Props) {
  return (
    <>
      <SizedBox />
      <Table>
        <thead>
          <tr>
            <th>DeviceType</th>
            <th>VersionNumber</th>
          </tr>
        </thead>
        <tbody>
          <TableRowWrapper>
            <td>ANDROID</td>
            <td>{appVersion}</td>
          </TableRowWrapper>
          <TableRowWrapper>
            <td>IOS</td>
            <td>{appVersion}</td>
          </TableRowWrapper>
        </tbody>
      </Table>
    </>
  );
}

const SizedBox = styled.div`
  height: 1rem;
`;

export default ShowAppVersion;
