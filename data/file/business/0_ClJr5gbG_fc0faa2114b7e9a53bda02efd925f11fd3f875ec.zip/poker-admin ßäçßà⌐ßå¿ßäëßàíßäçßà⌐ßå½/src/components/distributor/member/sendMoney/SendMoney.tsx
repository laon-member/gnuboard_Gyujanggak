import React from "react";

function SendMoney() {
  return <h1>sendmoney c</h1>;
}

export default SendMoney;
