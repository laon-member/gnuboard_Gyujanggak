import AgentNavContainer from "containers/common/AgentNavContainer";
import comma from "lib/comma";
import React from "react";
import { TAgentInfo } from "stores/agent/types";
import { TAgent } from "stores/user/types";
import { HeaderWrapper } from "./Header";

interface Props {
  agent: TAgent;
  onLogout: () => void;
  agentInfo: TAgentInfo;
}

function AgentHeader({ agent, onLogout, agentInfo }: Props) {
  if (!agentInfo) return <h1>Loading...</h1>;
  return (
    <>
      <HeaderWrapper>
        <h1>AGENT</h1>

        <div className="agent">
          <div className="deposit">
            <h3>AgentAmount</h3>
            <h4>{comma(agentInfo.amount)}</h4>
          </div>
          <div className="deposit">
            <h3>MemberSum</h3>
            <h4>{comma(agentInfo.member_sum)}</h4>
          </div>
          <div className="deposit">
            <h3>BeneRate</h3>
            <h4>{agentInfo.bene_rate}%</h4>
          </div>
          <div className="deposit">
            <h3>RemainAmount</h3>
            <h4>{comma(agentInfo.ramain_amount)}</h4>
          </div>
          <div className="deposit">
            <h3>WithdrawSum</h3>
            <h4>{comma(agentInfo.withdraw_sum)}</h4>
          </div>
        </div>

        <div className="admin">
          <span>{agent!.id}</span>
          <button onClick={onLogout}>LOG OUT</button>
        </div>
      </HeaderWrapper>
      <AgentNavContainer />
    </>
  );
}

export default AgentHeader;
