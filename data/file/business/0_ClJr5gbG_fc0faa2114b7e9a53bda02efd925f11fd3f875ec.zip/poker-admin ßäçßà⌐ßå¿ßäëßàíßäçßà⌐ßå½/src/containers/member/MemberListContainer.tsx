import React, { useEffect, useState } from "react";
import { inject, observer, useObserver } from "mobx-react";
import MemberList from "components/member/memberlist/MemberList";
import {
  MemberAmount,
  MemberSearch,
  MemberType,
  TEditMember,
  TMemberForms,
} from "stores/member/types";
import { PagingType } from "stores/message/types";
import { useInputs } from "lib/hooks";
import RootStore from "stores";
import { TAgent } from "stores/user/types";
import userStore from "stores/user";

interface Props {
  memberList?: MemberType[];
  getMemberList: (memberSearch: MemberSearch) => void;
  getMember: (id: number) => void;
  member: MemberType;
  updateMember: (modifyMember: MemberType) => void;
  updateMemberEdit: (modifyMemberAmount: MemberAmount) => void;
  memberPage: PagingType;
  agent: TAgent;
}

const MemberListContainer = ({
  memberList,
  getMemberList,
  getMember,
  updateMember,
  updateMemberEdit,
  member,
  memberPage,
}: Props) => {
  const forms = {
    search: useInputs({
      id: "",
      name: "",
      start_date: "",
      end_date: "",
      page: 1,
    } as MemberSearch),
    edit: useInputs({
      id: 0,
      bank: "",
      bankName: "",
      bankNumber: "",
      phone: "",
      password: "",
      check_password: "",
    } as TEditMember),
  } as TMemberForms;

  const [memberAmount] = useState<MemberAmount>({
    id: 0,
    amount: 0,
    block: false,
    deblock_note: "",
    finance_note: "",
    option: "",
    type: "",
  });
  const [infoToggle, setInfoToggle] = useState(false);
  const [editToggle, setEditToggle] = useState(false);

  useEffect(() => {
    getMembers(forms.search.inputs);
  }, []);

  const getMembers = (memberSearch: MemberSearch) => {
    getMemberList(memberSearch);
  };

  const onInfoToggle = () => {
    setInfoToggle(!infoToggle);
  };
  const onInfoSave = async (
    e: React.FormEvent<HTMLFormElement>,
    modifyMember?: MemberType
  ) => {
    e.preventDefault();
    await updateMember(modifyMember!);
    await setInfoToggle(false);
    await getMembers(forms.search.inputs);
  };

  const onEditToggle = () => {
    setEditToggle(!editToggle);
  };
  const onEditSave = async (
    e: React.FormEvent<HTMLFormElement>,
    modifyMemberAmount: MemberAmount
  ) => {
    e.preventDefault();
    const { amount, option } = modifyMemberAmount;
    if (amount) {
      if (option) {
        if (option !== "INCREASE" && option !== "DECREASE") {
          alert("Please select an option.");
          return;
        }
      } else {
        alert("Please select an option.");
        return;
      }
    }
    await updateMemberEdit(modifyMemberAmount);
    await setEditToggle(false);
    await getMembers(forms.search.inputs);
  };

  const onSearch = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    await getMemberList(forms.search.inputs);
  };

  return useObserver(() => (
    <MemberList
      infoToggle={infoToggle}
      onInfoToggle={onInfoToggle}
      onInfoSubmit={onInfoSave}
      editToggle={editToggle}
      onEditToggle={onEditToggle}
      onEditSubmit={onEditSave}
      memberList={memberList!}
      forms={forms}
      onSearch={onSearch}
      memberAmount={memberAmount}
      getMembers={getMembers}
      getMember={getMember}
      member={member}
      memberPage={memberPage}
    />
  ));
};

export default inject(({ memberStore }: RootStore) => ({
  memberList: memberStore.memberList,
  getMemberList: memberStore.getMemberList,
  getMember: memberStore.getMember,
  updateMember: memberStore.updateMember,
  updateMemberEdit: memberStore.updateMemberEdit,
  member: memberStore.member,
  memberPage: memberStore.memberPage,
}))(observer(MemberListContainer));
