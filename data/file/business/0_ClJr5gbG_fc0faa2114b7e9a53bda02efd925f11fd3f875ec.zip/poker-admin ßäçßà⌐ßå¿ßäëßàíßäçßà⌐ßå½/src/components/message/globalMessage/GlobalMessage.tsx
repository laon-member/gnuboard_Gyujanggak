import { TableRowWrapper } from "components/common";
import React from "react";
import { GMType } from "stores/message/types";

interface Props {
  message: GMType;
}

function GlobalMessage({ message }: Props) {
  return (
    <TableRowWrapper>
      <td>{message.id}</td>
      <td>{message.title}</td>
      <td className="overflow">{message.content}</td>
      <td>
        {message.readed_count}/{message.total_count}
      </td>
      <td>{message.created_at}</td>
    </TableRowWrapper>
  );
}

export default GlobalMessage;
