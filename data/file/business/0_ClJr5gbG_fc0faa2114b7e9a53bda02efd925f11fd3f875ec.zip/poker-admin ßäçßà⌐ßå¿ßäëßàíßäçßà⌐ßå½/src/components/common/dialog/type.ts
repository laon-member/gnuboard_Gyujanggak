export type DialogProps = {
  title: string;
  confirmText?: string;
  onToggle: () => void;
};
