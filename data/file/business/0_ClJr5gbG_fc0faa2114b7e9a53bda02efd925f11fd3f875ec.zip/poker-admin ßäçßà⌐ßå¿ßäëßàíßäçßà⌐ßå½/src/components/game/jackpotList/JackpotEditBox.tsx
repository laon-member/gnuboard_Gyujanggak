import { InputWrapper } from "components/deposit/Bankset/Bankset";
import { EditBoxType } from "components/member/memberlist/types";
import { DialogContainer } from "containers/common/dialog";
import React, { useEffect } from "react";
import { JackpotInfo, PolicyType, TPutPolicy } from "stores/jackpot/types";
import { UseInput } from "stores/notice/types";
import { Input } from "styles/atom";

interface Props {
  type: EditBoxType;
  policyForm: UseInput;
  jackpotInfo: JackpotInfo;
  policyInfo: PolicyType[];
}

function JackpotEditBox({ type, policyForm, jackpotInfo, policyInfo }: Props) {
  useEffect(() => {
    policyForm.setInputs({
      limit_amount: jackpotInfo.limit_amount.toString(),
      level_1_consume: policyInfo[0].consume.value.toString(),
      level_1_guarantee: policyInfo[0].guarantee.value.toString(),
      level_2_consume: policyInfo[1].consume.value.toString(),
      level_2_guarantee: policyInfo[1].guarantee.value.toString(),
      level_3_consume: policyInfo[2].consume.value.toString(),
      level_3_guarantee: policyInfo[2].guarantee.value.toString(),
      level_4_consume: policyInfo[3].consume.value.toString(),
      level_4_guarantee: policyInfo[3].guarantee.value.toString(),
      level_5_consume: policyInfo[4].consume.value.toString(),
      level_5_guarantee: policyInfo[4].guarantee.value.toString(),
      level_6_consume: policyInfo[5].consume.value.toString(),
      level_6_guarantee: policyInfo[5].guarantee.value.toString(),
    } as TPutPolicy);
  }, [jackpotInfo]);
  const {
    limit_amount,
    level_1_consume,
    level_1_guarantee,
    level_2_consume,
    level_2_guarantee,
    level_3_consume,
    level_3_guarantee,
    level_4_consume,
    level_4_guarantee,
    level_5_consume,
    level_5_guarantee,
    level_6_consume,
    level_6_guarantee,
  } = policyForm.inputs as TPutPolicy;
  const { onChange } = policyForm;
  return (
    <DialogContainer
      title="Jackpot Limit Box"
      confirmText="SAVE"
      onSubmit={type.onSubmit}
      onToggle={type.onToggle}
    >
      <InputWrapper>
        <label>Limit Value</label>
        <Input
          type="text"
          placeholder="Limit Value"
          name="limit_amount"
          value={limit_amount}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Lv.1 Consume</label>
        <Input
          type="text"
          placeholder="Lv.1 Consume"
          name="level_1_consume"
          value={level_1_consume}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Lv.1 Guarantee</label>
        <Input
          type="text"
          placeholder="Lv.1 Guarantee"
          name="level_1_guarantee"
          value={level_1_guarantee}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Lv.2 Consume</label>
        <Input
          type="text"
          placeholder="Lv.2 Consume"
          name="level_2_consume"
          value={level_2_consume}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Lv.2 Guarantee</label>
        <Input
          type="text"
          placeholder="Lv.2 Guarantee"
          name="level_2_guarantee"
          value={level_2_guarantee}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Lv.3 Consume</label>
        <Input
          type="text"
          placeholder="Lv.3 Consume"
          name="level_3_consume"
          value={level_3_consume}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Lv.3 Guarantee</label>
        <Input
          type="text"
          placeholder="Lv.3 Guarantee"
          name="level_3_guarantee"
          value={level_3_guarantee}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Lv.4 Consume</label>
        <Input
          type="text"
          placeholder="Lv.4 Consume"
          name="level_4_consume"
          value={level_4_consume}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Lv.4 Guarantee</label>
        <Input
          type="text"
          placeholder="Lv.4 Guarantee"
          name="level_4_guarantee"
          value={level_4_guarantee}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Lv.5 Consume</label>
        <Input
          type="text"
          placeholder="Lv.5 Consume"
          name="level_5_consume"
          value={level_5_consume}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Lv.5 Guarantee</label>
        <Input
          type="text"
          placeholder="Lv.5 Guarantee"
          name="level_5_guarantee"
          value={level_5_guarantee}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Lv.6 Consume</label>
        <Input
          type="text"
          placeholder="Lv.6 Consume"
          name="level_6_consume"
          value={level_6_consume}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Lv.6 Guarantee</label>
        <Input
          type="text"
          placeholder="Lv.6 Guarantee"
          name="level_6_guarantee"
          value={level_6_guarantee}
          onChange={onChange}
        />
      </InputWrapper>
    </DialogContainer>
  );
}

export default JackpotEditBox;
