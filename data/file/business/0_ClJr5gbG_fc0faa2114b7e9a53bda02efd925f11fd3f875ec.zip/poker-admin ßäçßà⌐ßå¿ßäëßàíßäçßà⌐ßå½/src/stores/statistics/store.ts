import { observable, computed, action } from "mobx";

import BaseStore from "stores/BaseStore";
import RootStore from "stores";

import {
  UserType,
  PremiumType,
  TAdminStat,
  TAdminStatPage,
  TAdminStatSearch,
  TAgentStat,
  TAgentStatPage,
  TAgentStatSearch,
  TAgentTotalStat,
} from "./types";
import { PagingType } from "stores/message/types";
import staticService from "services/static/staticService";

class StaticStore extends BaseStore {
  root: RootStore;

  constructor(root: RootStore) {
    super();
    this.root = root;
  }

  //수정
  @observable
  adminStatPage = {
    paging: {} as PagingType,
    notices: [] as TAdminStat[],
  } as TAdminStatPage;

  @observable
  agentStatPage = {
    paging: {} as PagingType,
    stats: [] as TAgentStat[],
    total: {} as TAgentTotalStat,
  } as TAgentStatPage;

  @action
  getAdminStatPage = async (payload: TAdminStatSearch) => {
    try {
      const res = await staticService.getAdminStatPage(payload);
      if (res.data.result) {
        this.adminStatPage = res.data.data;
      } else {
        alert("Field error");
      }
    } catch (error) {
      alert("There is a problem with the server");
    }
  };

  @action
  getAgentStatPage = async (payload: TAgentStatSearch) => {
    try {
      const res = await staticService.getAgentStatPage(payload);
      if (res.data.result) {
        this.agentStatPage = res.data.data;
      } else {
        alert("Field error");
      }
    } catch (error) {
      alert("There is a problem with the server");
    }
  };

  // 기존
  @observable
  private _isLoggedIn = false;

  @observable
  private _userType?: number;

  @observable
  private _userList: UserType[] = [];

  @observable
  private _recoList: UserType[] = [];

  @observable
  private _rewardList: UserType[] = [];

  @observable
  private _premium?: PremiumType;

  @computed
  get IsLoggedIn() {
    return this._isLoggedIn;
  }

  @computed
  get UserType() {
    return this._userType;
  }

  @computed
  get UserList() {
    return this._userList;
  }

  @computed
  get RecoList() {
    return this._recoList;
  }

  @computed
  get RewardList() {
    return this._rewardList;
  }

  @computed
  get Premium() {
    return this._premium;
  }

  @action
  public logout() {
    this._isLoggedIn = false;
    this._userType = undefined;
  }
}

export default StaticStore;
