﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using DG.Tweening;

using Photon.Pun;
using Photon.Realtime;
using JetBrains.Annotations;

public class CPlayer : MonoBehaviour
{

    // 0 = mine, 1 = other
    [Header("UI")]
    public Image[] ProfileImg;
    public Text[] txt_Money;
    public Text[] txt_BatMoney;
    public Text[] txt_Name;
    public Text[] txt_PlusBattingMoney;
    public GameObject[] Img_Dealer;

    public Sprite[] Spr_Banner; // 0 = winner, 1 = loser

    public GameObject[] Img_Fold;
    public GameObject[] Img_Allin;
    public GameObject[] Img_Watch;

    public GameObject[] LeaveReservation;

    public Image MyProfileBanner;
    public Image[] OtherProfileBanner;

    public SliderTimer Sliders; // prograss

    public Emoticon[] Emoticons;

    public Sprite[] Spr_Batting_Result;
    public Image[] Img_BattingResult;

    public Text[] Text_ResultMoney;

    public Transform[] ChipPos;

    public GameObject Chip;

    public GameObject[] BackLight;
    public bool IsLeftPlayer;
    public bool CompleteCardCheck;

    SoundManager Sound;

    [Space]
    /// <summary>
    /// 0 = left, 1 = right
    /// </summary>
    public Transform[] CardPos;
    public GameObject[] ObjType;

    public List<CardInfo> Cards = new List<CardInfo>();

    // 카드 포지션 체크
    bool[] CheckCard = new bool[3];
    // 카드 파일 이름 저장
    public string[] CardsFileName = new string[3];
    // 0 = left, 1 = right
    int CardPosDir = 0;
    
    public enum PlayerType { Mine, Other};
    public PlayerType Type;

    public List<Vector3> List_CardPos = new List<Vector3>();


    int CardIdx;

    GameMgr Main;

    [System.Serializable]
    public struct SPlayerInfo
    {
        public int ActorNumber;

        public string Name;
        public string NickName;
        public int UserNumber;
        public long Money;
        public string ProfileImgName;

        public bool IsAllin;
        public bool IsDie;
        public long BatMoney;

        public SPlayerInfo(Player player)
        {
            ActorNumber = player.ActorNumber;

            Name = player.CustomProperties["UserID"].ToString();
            NickName = player.CustomProperties["UserID"].ToString();

            UserNumber = (int)player.CustomProperties["UserNumber"];
            Money = long.Parse(player.CustomProperties["UserMoney"].ToString());
            ProfileImgName = player.CustomProperties["ProfileImageName"].ToString();

            IsAllin = false;
            IsDie = false;
            BatMoney = 0;
        }
    }
    [Header("Struct")]
    public SPlayerInfo Info;

    [Header("족보")]
    public Image CardGene_Img;
    public Sprite[] CardGene_Spr;

    // 관전 플레이어 정보 저장
    public bool IsWatch;

    public void SetPlayerInfo(Player player, long money)
    {
        if(Sound == null)
        {
            Sound = FindObjectOfType<SoundManager>();
        }

        Main = FindObjectOfType<GameMgr>();

        ObjType[(int)Type].SetActive(true);
        Info = new SPlayerInfo(player);

        ProfileImg[(int)Type].sprite = Resources.Load<Sprite>("Sprites/InGameProfiles/" + Info.ProfileImgName);
        txt_Name[(int)Type].text = Info.Name;
        txt_Money[(int)Type].text = CStringFormat.Instance.FormatToInt(Info.Money);
    }

    public void SetCardPos(CardInfo card, int pos, string[] fileNames)
    {
        if (CardsFileName[0] == null)
        {
            for (int i = 0; i < 3; i++)
            {
                CardsFileName[i] = fileNames[i];
            }
        }

        if (pos >= 3)
        {
            CardPosDir = 1;
        }
        else
        {
            CardPosDir = 0;
        }

        for (int i = 0; i < CheckCard.Length; i++)
        {
            if(!CheckCard[i])
            {
                CardIdx = i;
                CheckCard[i] = true;

                break;
            }
        }

        if(Type == PlayerType.Mine)
        {
            card.transform.SetParent(CardPos[(int)Type].GetChild(0).GetChild(2 - CardIdx));

            card.transform.DORotate(new Vector3(0, 0, 180), 0.5f,RotateMode.FastBeyond360).SetRelative();
            
            card.transform.DOLocalMove(Vector3.zero, 0.5f).OnComplete(()=> card.StopRot());

            string[] result = CardsFileName[CardIdx].Split('/');

            int pattern = int.Parse(result[0]);
            int num = int.Parse(result[1]);

            card.SetCardInfo(pattern, num, true, false);

            for (int i = 0; i < CardPos[(int)Type].childCount - 1; i++)
            {
                List_CardPos.Add(CardPos[(int)Type].GetChild(i).transform.localPosition);
            }
        }
        else
        {
            card.transform.SetParent(CardPos[(int)Type].GetChild(CardPosDir).GetChild(2 - CardIdx));

            card.transform.DORotate(new Vector3(0, 0, 360), 0.5f, RotateMode.FastBeyond360).SetRelative();

            card.transform.DOLocalMove(Vector3.zero, 0.5f).OnComplete(() => card.StopRot());

            for (int i = 0; i < CardPos[(int)Type].GetChild(CardPosDir).childCount - 1; i++)
            {
                List_CardPos.Add(CardPos[(int)Type].GetChild(CardPosDir).GetChild(i).transform.localPosition);
            }
        }

        Cards.Add(card);
    }
    public void StartCo_Expansion()
    {
        if (PhotonNetwork.CurrentRoom.PlayerCount > 1)
        {
            StartCoroutine("Co_CardExpansion");
        }
    }

    public IEnumerator Co_CardExpansion()
    {
        yield return CWFS.WFS(0.5f);

        string[] result = CardsFileName[CardIdx].Split('/');

        int pattern = int.Parse(result[0]);
        int num = int.Parse(result[1]);

        //Cards[CardIdx].SetCardInfo(pattern, num, true);
        Cards[CardIdx].FlipCard();
        
        for (int i = 0; i < CardPos.Length; i++)
        {
            CardPos[i].gameObject.SetActive(false);
        }

        Main.PopUp.CardExpansion.SetActive(true);

        string[] cardsName = new string[3];

        for (int i = 0; i < cardsName.Length; i++)
        {
            if (2 - i >= 0)
            {
                if (Cards[2 - i] != null)
                {
                    cardsName[i] = Cards[2 - i].CardFileName;
                }
            }
        }

        CardExpansion expan = FindObjectOfType<CardExpansion>();
        expan.SetImgInfo(cardsName, this);

        this.GetComponent<CardGenealogy>().SetGenealogy(CardsFileName);
    }

    public void ShowCards()
    {
        for (int i = 0; i < CardPos.Length; i++)
        {
            CardPos[i].gameObject.SetActive(true);
            Cards[i].FlipCard();
        }

        int cardGene_SprIdx = 0;

        if(this.GetComponent<CardGenealogy>().GeneType == CardGenealogy.GenealogyType.Pair)
        {
            cardGene_SprIdx = 10;
        }
        else if(this.GetComponent<CardGenealogy>().GeneType == CardGenealogy.GenealogyType.Straight)
        {
            cardGene_SprIdx = 11;
        }
        else if(this.GetComponent<CardGenealogy>().GeneType == CardGenealogy.GenealogyType.Triple)
        {
            cardGene_SprIdx = 12;
        }
        else
        {
            cardGene_SprIdx = this.GetComponent<CardGenealogy>().SumCardNumber;
        }


        CardGene_Img.sprite = CardGene_Spr[cardGene_SprIdx];
        CardGene_Img.gameObject.SetActive(true);

        Main.CreateAllPlayerCoin();
    }

    public void OpenCard(bool open)
    {
        StartCoroutine("Co_OpenCard", open);
    }

    IEnumerator Co_OpenCard(bool open)
    {
        this.GetComponent<CardGenealogy>().SetGenealogy(CardsFileName);
        
        if (open)
        {
            if (Type == PlayerType.Mine)
            {
                CardPos[(int)Type].GetChild(0).DOLocalMoveX(CardPos[(int)Type].GetChild(2).localPosition.x, 0.2f);
                yield return CWFS.WFS(0.1f);
                CardPos[(int)Type].GetChild(1).DOLocalMoveX(CardPos[(int)Type].GetChild(2).localPosition.x, 0.2f);
                yield return CWFS.WFS(0.2f);
                CardPos[(int)Type].GetChild(0).DOLocalMoveX(List_CardPos[0].x, 0.2f);
                CardPos[(int)Type].GetChild(1).DOLocalMoveX(List_CardPos[1].x, 0.2f);
            }
            else
            {
                CardPos[(int)Type].GetChild(CardPosDir).GetChild(0).DOLocalMoveX(CardPos[(int)Type].GetChild(CardPosDir).GetChild(2).localPosition.x, 0.2f);
                yield return CWFS.WFS(0.1f);
                CardPos[(int)Type].GetChild(CardPosDir).GetChild(1).DOLocalMoveX(CardPos[(int)Type].GetChild(CardPosDir).GetChild(2).localPosition.x, 0.2f);
                yield return CWFS.WFS(0.2f);
                CardPos[(int)Type].GetChild(CardPosDir).GetChild(0).DOLocalMoveX(List_CardPos[0].x, 0.2f);
                CardPos[(int)Type].GetChild(CardPosDir).GetChild(1).DOLocalMoveX(List_CardPos[1].x, 0.2f);
            }
        }

        yield return CWFS.WFS(0.05f);

        WaitForSeconds wfsTime = CWFS.WFS(0.1f);
        for (int i = 0; i < Cards.Count; i++)
        {
            string[] result = CardsFileName[i].Split('/');

            int pattern = int.Parse(result[0]);
            int num = int.Parse(result[1]);

            if (Type != PlayerType.Mine)
            {
                Cards[i].SetCardInfo(pattern, num, true, open);
            }
            else
            {
                Cards[i].SetCardInfo(pattern, num, false, open);
            }
            yield return wfsTime;
        }
    }

    public void Clear()
    {
        for (int i = 0; i < CheckCard.Length; i++)
        {
            CheckCard[i] = false;
        }

        CardIdx = 0;

        for (int i = 0; i < Cards.Count; i++)
        {
            Main.ClearCard(Cards[i]);
        }

        txt_BatMoney[(int)Type].text = "0";
        Info.BatMoney = 0;
        this.GetComponent<CardGenealogy>().Clear();
        CalculationCard.Instance.ClearLists();
        Cards.Clear();

        CardGene_Img.gameObject.SetActive(false);

        if (MyProfileBanner.gameObject.activeInHierarchy)
            MyProfileBanner.gameObject.SetActive(false);

        for (int i = 0; i < OtherProfileBanner.Length; i++)
        {
            if(OtherProfileBanner[i].gameObject.activeInHierarchy)
            {
                OtherProfileBanner[i].gameObject.SetActive(false);
            }
        }

        ProfileImg[(int)Type].color = Color.white;
        Img_Fold[(int)Type].SetActive(false);
        Info.IsDie = false;
        Img_Allin[(int)Type].SetActive(false);
        Info.IsAllin = false;
    }

    public void SetDieImg()
    {
        ProfileImg[(int)Type].color = Color.gray;

        Img_Fold[(int)Type].SetActive(true);
        Info.IsDie = true;
    }
    public void ReceiveMoneyTxt(long money)
    {
        txt_Money[(int)Type].text = CStringFormat.Instance.FormatToInt(Info.Money + money);
        Info.Money -= money;
    }
    public void SetBanner(int type) // 0 win, 1 lose
    {
        if (Type == PlayerType.Mine)
        {
            MyProfileBanner.gameObject.SetActive(true);
            MyProfileBanner.sprite = Spr_Banner[type];
        }
        else
        {
            OtherProfileBanner[CardPosDir].gameObject.SetActive(true);
            OtherProfileBanner[CardPosDir].sprite = Spr_Banner[type];
        }
    }

    public Transform GetChipEndPoint()
    {
        return ChipPos[(int)Type];
    }

    public void ShowResultMoney(long money)
    {
        Text_ResultMoney[(int)Type].text = CStringFormat.Instance.FormatToInt(money);

        Text_ResultMoney[(int)Type].text = "+" + Text_ResultMoney[(int)Type].text;

        Text_ResultMoney[(int)Type].gameObject.SetActive(true);
        Text_ResultMoney[(int)Type].transform.DOLocalMoveY(130.0f, 2.5f);
        Text_ResultMoney[(int)Type].transform.DOScale(1.25f, 2.5f);
        Color color = Text_ResultMoney[(int)Type].color;
        color.a = 0;
        Text_ResultMoney[(int)Type].DOColor(color, 5.0f).OnComplete(() => ClearResultMoney());
    }

    void ClearResultMoney()
    {
        Color color = Text_ResultMoney[(int)Type].color;
        color.a = 1.0f;
        Text_ResultMoney[(int)Type].color = color;

        Text_ResultMoney[(int)Type].transform.localScale = Vector3.one;
        Text_ResultMoney[(int)Type].transform.localPosition = Vector3.zero;
        Text_ResultMoney[(int)Type].text = "";
        Text_ResultMoney[(int)Type].gameObject.SetActive(false);
    }

    public void ShowBackLight()
    {
        BackLight[(int)Type].SetActive(true);

        BackLight[(int)Type].transform.DOScale(1.25f, 1.0f);
        BackLight[(int)Type].transform.DORotate(new Vector3(0, 0, 360 * 1.5f), 3.0f, RotateMode.FastBeyond360).OnComplete(()=>ClearBackLight());
    }

    void ClearBackLight()
    {
        BackLight[(int)Type].transform.localScale = Vector3.one;
        BackLight[(int)Type].transform.DORotate(Vector3.one, 0.01f);
        BackLight[(int)Type].SetActive(false);
    }

    public void SetGenealogy(string[] filename)
    {
        if (this.GetComponent<CardGenealogy>().GeneType == CardGenealogy.GenealogyType.Default)
        {
            this.GetComponent<CardGenealogy>().SetGenealogy(filename);
        }
    }

    public void SetDealerImg(bool result)
    {
        Img_Dealer[(int)Type].SetActive(result);
    }

    public void SetBattingMoneyText(long money)
    {
        txt_BatMoney[(int)Type].text = CStringFormat.Instance.FormatToInt(Info.BatMoney + money);
        Info.BatMoney += money;

        if (Info.Money > money)
        {
            txt_Money[(int)Type].text = CStringFormat.Instance.FormatToInt(Info.Money - money);
            Info.Money -= money;
        }
        else
        {
            txt_Money[(int)Type].text = "0";
            Info.Money = 0;
        }
    }

    public long GetBattingMoney()
    {
        long money = 0;

        money = Info.BatMoney;
        
        return money;
    }

    //public int GetIntMoney(string str)
    //{
    //    int money = 0;

    //    if (str.Length > 0)
    //    {
    //        if (str != "0")
    //        {
    //            string[] buffer = str.Split(',');
    //            string buffer_money = "";
    //            foreach (var item in buffer)
    //            {
    //                buffer_money += item;
    //            }
    //            money = int.Parse(buffer_money);
    //        }
    //    }
    //    return money;
    //}

    public void ShowEmoticon(string fileName, float[] info)
    {
        Emoticons[(int)Type].StartEmoticon(fileName, info);
    }
    
    public void SetLeaveReservation(bool active)
    {
        LeaveReservation[(int)Type].SetActive(active);
    }

    public void ActiveAllIn()
    {
        Info.IsAllin = true;
        Img_Allin[(int)Type].SetActive(true);
    }

    public void SetSliderTimer(bool active, bool type = true)
    {
        // type == true : 배팅 타이머
        if (active)
        {
            if (type)
            {
                Sliders.StartBattingTimer();
            }
            else
            {
                Sliders.StartCardTimer();
            }
        }

        Sliders.gameObject.SetActive(active); // prograss
    }

    public void SetWatchImg(bool active)
    {
        if(active)
        {
            Img_Watch[(int)Type].SetActive(true);
            ProfileImg[(int)Type].color = Color.gray;

            IsWatch = active;
        }
        else
        {
            Img_Watch[(int)Type].SetActive(false);
            ProfileImg[(int)Type].color = Color.white;

            IsWatch = active;
        }
    }

    // Set batting result img
    /// <summary>
    /// 0 = call, 1 = check, 2 = half, 3 = full, 4 = die
    /// </summary>
    /// <param name="idx"></param>
    public void SetBattingResultImg(int idx)
    {
        int type = (int)Type;
        Img_BattingResult[type].sprite = Spr_Batting_Result[idx];

        StartCoroutine("Co_BattingResult");
    }

    IEnumerator Co_BattingResult()
    {
        int type = (int)Type;

        Color color = Img_BattingResult[type].color;
        color.a = 0;
        Img_BattingResult[type].color = color;
        color.a = 1;
        Img_BattingResult[type].transform.localPosition = Vector3.zero;

        Img_BattingResult[type].gameObject.SetActive(true);

        Img_BattingResult[type].DOColor(color, 0.5f);
        Img_BattingResult[type].transform.DOLocalMoveY(110, 0.5f);

        yield return CWFS.WFS(1.0f);

        color.a = 0;
        Img_BattingResult[type].DOColor(color, 0.3f).OnComplete(()=>Img_BattingResult[type].gameObject.SetActive(false));
    }
}
