import React from 'react';

const ShowServerVersionContainer = () => {
  return (
    <>
      <h1>showServiceVersionContainer</h1>
    </>
  );
}

export default ShowServerVersionContainer;