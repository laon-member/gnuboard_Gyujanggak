import React from "react";
import { inject, observer } from "mobx-react";
import { withRouter, RouteComponentProps } from "react-router";
import { withCookies, ReactCookieProps } from "react-cookie";

import Login from "components/login";
import userStore from "stores/user";

interface Props extends RouteComponentProps, ReactCookieProps {
  userStore?: userStore;
}

@inject("userStore")
@observer
class LoginContainer extends React.Component<Props> {
  private userStore = this.props.userStore! as userStore;

  onLogin = async (id: string, password: string) => {
    if (id === "") return alert("Please enter your administrator ID");
    if (password === "")
      return alert("Please enter your administrator password");
    try {
      await this.userStore.login(id, password);
      this.props.history.push("/admin/member");
    } catch (error) {
      console.error(error);
      throw error;
    }
  };

  onAgentLogin = async (id: string, password: string) => {
    if (id === "") return alert("Please enter your agent ID");
    if (password === "") return alert("Please enter your agent password");

    try {
      await this.userStore.agentLogin({ id, password });
      this.props.history.push("/agent/member");
    } catch (error) {
      console.log(error);
      alert("There is a problem with the server");
    }
  };

  render() {
    return (
      <Login
        onLogin={this.onLogin}
        onAgentLogin={this.onAgentLogin}
        loginError={this.userStore.isLoggedInError}
      />
    );
  }
}

export default withCookies(withRouter(LoginContainer));
