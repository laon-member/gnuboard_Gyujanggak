import client from "lib/client";

class DepositService {
  public LoginAPI(data: FormData) {
    return client.post(`/api/admin/admin-login`, data);
  }

  public GetDepositListAPI() {
    return client.get(`/api/admin/deposit/applyinfo`, {
      params: {},
    });
  }

  public removeDepositList(id: number[]) {
    return client.delete(`/api/admin/deposit/my-account/${id.join(",")}`);
  }

  public PutUpdateApprovalAPI(id: number) {
    return client.put(`/api/admin/deposit/approval`, { id: id });
  }
  public PutupdateRejectAPI(id: number) {
    return client.put(`/api/admin/deposit/reject`, { id: id });
  }
  public GetRechargeListAPI(
    id?: string,
    phone?: string,
    status?: string,
    startDate?: string,
    endDate?: string
  ) {
    return client.get(`/api/admin/deposit/rechargeinfo`, {
      params: {
        id,
        phone,
        status,
        start_date: startDate,
        end_date: endDate,
      },
    });
  }
  public GetRanksetListAPI(name?: string, account?: string) {
    return client.get(`/api/admin/deposit/my-account`, {
      params: {
        name,
        account,
      },
    });
  }
  public PostAccountAPI(
    addBankName: string,
    addAccountHolder: string,
    addAccountNumber: string
  ) {
    return client.post(`/api/admin/deposit/new-account`, {
      bank: addBankName,
      name: addAccountHolder,
      number: addAccountNumber,
    });
  }
  public GetSearchListAPI(
    type?: string,
    inputValue?: string,
    dateType?: string
  ) {
    return client.get(`/api/admin/deposit/search`, {
      params: {
        type,
        inputValue,
        dateType,
      },
    });
  }
}
export default new DepositService();
