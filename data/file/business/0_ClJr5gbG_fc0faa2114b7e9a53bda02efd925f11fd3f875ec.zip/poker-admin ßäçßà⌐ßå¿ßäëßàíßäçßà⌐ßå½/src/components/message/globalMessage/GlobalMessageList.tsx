import NoDataBox from "components/common/NoDataBox";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import React from "react";
import { FaSearch } from "react-icons/fa";
import { GM, GMFormType, SearchGMType } from "stores/message/types";
import { Button, Input } from "styles/atom";
import GlobalMessage from "./GlobalMessage";

interface Props {
  GMList: GM;
  searchForm: GMFormType;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
}

function GlobalMessageList({
  GMList,
  searchForm: { inputs, onChange },
  onSearch,
}: Props) {
  const { start_date, end_date } = inputs as SearchGMType;
  return (
    <>
      <SearchWrapper>
        <SearchForm className="search" onSubmit={onSearch}>
          <Input
            type="date"
            name="start_date"
            value={start_date}
            onChange={onChange}
            className="date"
          />
          <Input
            type="date"
            name="end_date"
            value={end_date}
            onChange={onChange}
            className="date"
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>Sender</th>
            <th>Title</th>
            <th>Content</th>
            <th>ReadingState</th>
            <th>SendingTime</th>
          </tr>
        </thead>
        <tbody>
          {GMList.paging.total_page
            ? GMList.messages.map((message) => (
                <GlobalMessage key={message.id} message={message} />
              ))
            : null}
        </tbody>
      </Table>
      {GMList.paging.total_page ? (
        <PageNationContainer
          onPageNation={() => null}
          paging={GMList.paging}
          searchForm={{ inputs, onChange }}
          onSearch={onSearch}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
}

export default GlobalMessageList;
