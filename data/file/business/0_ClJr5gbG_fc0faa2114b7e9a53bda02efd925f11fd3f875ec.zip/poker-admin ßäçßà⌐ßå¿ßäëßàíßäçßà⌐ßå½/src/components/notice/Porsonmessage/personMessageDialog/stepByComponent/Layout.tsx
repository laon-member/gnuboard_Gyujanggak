import React, { useState } from "react";
import Dialog from "components/common/dialog/Dialog";
import FormRouter from "./FormRouter";

type LayoutProps = {
  onCreateToggle: () => void;
};

const Layout = ({ onCreateToggle }: LayoutProps) => {
  const [step, setStep] = useState(1);
  const onIncrease = () => {
    setStep(step + 1);
  };
  return (
    <Dialog title="SEND MESSAGE">
      <FormRouter
        step={step}
        onIncrease={onIncrease}
        onCreateToggle={onCreateToggle}
      />
    </Dialog>
  );
};

export default Layout;
