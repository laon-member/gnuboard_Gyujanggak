import React from "react";
import useInputs from "lib/hooks/useInputs";
import { inject, observer } from "mobx-react";
import SelectUser from "./SelectUser";
import { searchedUserType } from "stores/notice/types";
import styled from "styled-components";
import { Button, Input, Select } from "styles/atom";
import Table from "components/common/Table";
import { ButtonGroup } from "containers/common/dialog/DialogContainer";

type SelectUserListProps = {
  userList: searchedUserType[];
  sendUserList: searchedUserType[];
  onIncrease: () => void;
  onCreateToggle: () => void;
  onSearch: (type: string, value: string) => void;
  onAddUser: (user: searchedUserType) => void;
  onRemoveUser: (id: number) => void;
  onSelectAllUser: () => void;
  onInit: () => void;
};

const SelectUserList = ({
  userList,
  onIncrease,
  onCreateToggle,
  onSearch,
  onAddUser,
  onRemoveUser,
  sendUserList,
  onSelectAllUser,
  onInit,
}: SelectUserListProps) => {
  const { inputs, onChange, init } = useInputs({
    type: "all",
    value: "",
  });
  const { type, value } = inputs;

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onSearch(type, value);
    init();
  };

  const Init = () => {
    onCreateToggle();
    onInit();
  };

  console.dir(userList);
  return (
    <SelectUserListWrapper>
      <SelectedUserList>
        {sendUserList.map((user) => (
          <StyledSelectedUser onClick={() => onRemoveUser(user.id)}>
            {user.username} X
          </StyledSelectedUser>
        ))}
      </SelectedUserList>
      <FormWrapper onSubmit={onSubmit}>
        <Select name="type" value={type} onChange={onChange}>
          <option value="all">All</option>
          <option value="id">ID</option>
          <option value="userName">User name</option>
          <option value="phone">Phone</option>
        </Select>
        <Input
          name="value"
          value={value}
          onChange={onChange}
          placeholder="type value"
        />
        <Button type="submit">SEARCH</Button>
      </FormWrapper>
      <UserPositioner>
        <Table>
          <thead>
            <tr>
              <td>ID</td>
              <td>USER NAME</td>
              <td>PHONE</td>
              <td>
                <span onClick={onSelectAllUser}>ADD ALL</span>
              </td>
            </tr>
          </thead>
          <tbody>
            {userList &&
              userList.map((user) => (
                <SelectUser key={user.id} user={user} onAddUser={onAddUser} />
              ))}
          </tbody>
        </Table>
      </UserPositioner>
      <ButtonGroup>
        <Button half secondary onClick={Init}>
          CANCLE
        </Button>
        <Button half onClick={onIncrease}>
          NEXT
        </Button>
      </ButtonGroup>
    </SelectUserListWrapper>
  );
};

const SelectUserListWrapper = styled.div`
  padding: 1rem;
  span {
    cursor: pointer;
  }
  & > * {
    margin-top: 1rem;
  }
  & > p {
    font-size: 0.75rem;
  }
`;

const FormWrapper = styled.form`
  display: flex;

  & > select {
    flex: 1;
  }
  & > input {
    flex: 2;
    margin: 0 1rem;
  }
  & > button {
    flex: 1;
  }
`;

const SelectedUserList = styled.div`
  max-height: 300px;
  overflow: scroll;
`;

export const StyledSelectedUser = styled.div`
  display: inline-block;
  padding: 0.125rem 0.5rem;
  word-break: keep-all;
  cursor: pointer;

  background: #007fdb;
  border-radius: 1rem;
  color: #fff;

  & + & {
    margin: 0.25rem 0.25rem;
  }
`;

const UserPositioner = styled.div`
  border: 1px solid #ddd;
  border-radius: 5px;
  max-height: 30vh;
  overflow: scroll;
`;

export default inject("noticeStore")(observer(SelectUserList));
