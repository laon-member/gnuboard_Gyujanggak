﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using Photon.Pun;
using Photon.Realtime;
using System;

public class Guidance_Logout : MonoBehaviourPunCallbacks
{
    public GameObject ActiveObject;
    public Text Content;

    SoundManager Sound;

    DataBaseManager DBMgr;

    // Start is called before the first frame update
    void Start()
    {
        if(Sound == null)
        {
            Sound = FindObjectOfType<SoundManager>();
            DBMgr = FindObjectOfType<DataBaseManager>();
        }
    }

    public void SetText(string str)
    {
        if (Content.text.Length > 0)
        {
            Content.text = "";
        }

        ActiveObject.SetActive(true);
        Content.text = str;
    }


    public void OnClickBtn_Logout()
    {
        Sound.StartSound_Effect(SoundFileList.EFFECT.btn_click);

        StopCoroutine("RepeatNotic");
        Destroy(GameObject.FindObjectOfType<JackPot>().transform.parent.parent.gameObject);

        PlayerPrefs.SetInt("AutoLogin", 0);

        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.Logout, "", "Post", PlayerPrefs.GetString("Token"), (result) =>
        {
            DBMgr.StopSendLogined();
        }));

        ActiveObject.SetActive(false);
        PhotonNetwork.Disconnect();
    }
}
