import comma from "lib/comma";
import React from "react";
import { FaAndroid, FaApple } from "react-icons/fa";
import { TMember } from "stores/distributor/member/types";
import { TableRowWrapper } from "../../../../components/common";

interface Props {
  idx: number;
  member: TMember;
}

function Member({ idx, member }: Props) {
  return (
    <TableRowWrapper>
      <td>{idx}</td>
      <td>{member.id}</td>
      <td>{!member.status ? "Offline" : member.location}</td>
      <td>{member.username}</td>
      <td className="blue">
        {member.platform === "IOS" ? (
          <FaApple color="silver" />
        ) : (
          <FaAndroid color="green" />
        )}
        <br />
        {member.name}
      </td>
      <td>{member.agent}</td>
      <td>{member.phone}</td>
      <td>{comma(member.amount)}</td>
      <td>{member.created_at}</td>
      <td>{member.last_login}</td>
      <td>{member.bankName}</td>
      <td>{member.bank}</td>
      <td>{member.bankNumber}</td>
    </TableRowWrapper>
  );
}

export default Member;
