import styled, { css } from "styled-components";

type WrapperType = {
  active?: boolean | undefined;
};

export const TableRowWrapper = styled.tr<WrapperType>`
  background-color: #fff;

  .icon {
    color: #70c7bf;
    cursor: pointer;
  }

  ${(props) =>
    props.active &&
    css`
      background: #ddd;
    `}
`;

export default TableRowWrapper;
