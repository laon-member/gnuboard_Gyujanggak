﻿using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChaAnimation : MonoBehaviour
{
    public Transform Arm;

    int RotDir = 1;
    public float RotSpeed = 0.01f;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    private void Update()
    {
        //Arm.rotation = Quaternion.Euler(new Vector3(0, 0, Arm.rotation.z + (RotDir * 0.001f) * Time.deltaTime));
        Arm.transform.Rotate(Vector3.forward, RotSpeed * RotDir);

        if (Arm.rotation.z >= 0.1f)
        {
            RotDir = -1;
        }
        else if (Arm.rotation.z <= 0.0f)
        {
            RotDir = 1;
        }

    }

    //IEnumerator Co_ChaAni()
    //{
    //    while (true)
    //    {
    //        Arm.DORotate(Quaternion.Euler(0, 0, 0.1f), 0.5f);
    //        yield return CWFS.WFS(0.5f);

    //    }
    //}

}
