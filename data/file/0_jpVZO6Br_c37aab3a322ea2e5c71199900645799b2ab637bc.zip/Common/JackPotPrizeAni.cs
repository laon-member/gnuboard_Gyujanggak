﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class JackPotPrizeAni : MonoBehaviour
{
    public Text UserName;
    public Text Price;

    public RectTransform TextBG;

    public Button ClickZone;

    // Start is called before the first frame update
    void Start()
    {
        TextBG.sizeDelta = new Vector2((30 * UserName.text.Length) + (Price.text.Length * 30) + 40, TextBG.sizeDelta.y);
        
        StartCoroutine("Co_BtnActive");
    }

    public void SetUserName(string name)
    {
        UserName.text = name;
    }

    public void SetPrizeMoney(string money)
    {
        Price.text = money + " 당첨";
    }

    IEnumerator Co_BtnActive()
    {
        yield return CWFS.WFS(1.25f);
        ClickZone.gameObject.SetActive(true);

        yield return CWFS.WFS(6.0f);

        Destroy(this.gameObject);
    }

    public void OnClickBtn_Destroy()
    {
        StopCoroutine("Co_BtnActive");

        Destroy(this.gameObject);
    }
}
