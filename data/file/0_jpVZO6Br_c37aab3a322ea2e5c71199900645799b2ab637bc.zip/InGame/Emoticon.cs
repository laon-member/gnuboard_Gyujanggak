﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class Emoticon : MonoBehaviour
{
    public Image Img;

    public List<Sprite> Sprites = new List<Sprite>();

    [HideInInspector]
    int RepeatCount = 4;

    string FileName;

    private void OnDisable()
    {
        Sprites.Clear();
        
        this.transform.localScale = Vector2.zero;
    }

    public void StartEmoticon(string fileName, float[] info)
    {
        StopCoroutine("StartAnimation");

        if(Sprites.Count != 0)
        {
            Sprites.Clear();
        }

        int count = (int)info[0];

        FileName = fileName;

        for (int i = 0; i < count; i++)
        {
            Sprites.Add(Resources.Load<Sprite>("Sprites/Emoticons/" + FileName + "_" + i.ToString()));
        }

        this.gameObject.SetActive(true);

        StopCoroutine("StartAnimation");
        StartCoroutine("StartAnimation");
    }

    IEnumerator StartAnimation()
    {
        this.transform.DOScale(Vector3.one, 0.4f);

        WaitForSeconds wfsTime = CWFS.WFS(0.07f);

        for (int j = 0; j < RepeatCount; j++)
        {
            for (int i = 0; i < Sprites.Count; i++)
            {
                Img.sprite = Sprites[i];
                yield return wfsTime;
            }
        }
        yield return CWFS.WFS(0.3f);

        this.transform.DOScale(Vector3.zero, 0.4f).OnComplete(()=> this.gameObject.SetActive(false));
    }


}
