﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using UnityEditor;

public class LoadingAnimation : MonoBehaviour
{
    public Sprite[] Spr_Patterns;
    public Sprite[] Spr_Texts;

    public Image Pattern;
    public Image Text;

    bool IsAni;

    private void OnEnable()
    {
        IsAni = true;

        StartCoroutine("StartAnimation_Pattern");
        StartCoroutine("StartAnimation_Text");
    }

    private void OnDisable()
    {
        IsAni = false;
    }

    IEnumerator StartAnimation_Pattern()
    {
        int i = 1;

        WaitForSeconds wfsTime = CWFS.WFS(0.125f);

        while (IsAni)
        {
            Pattern.sprite = Spr_Patterns[i - 1];

            if(i >= Spr_Patterns.Length)
            {
                i = 1;
            }
            else
            {
                i++;
            }
            yield return wfsTime;
        }
    }

    IEnumerator StartAnimation_Text()
    {
        int i = 1;

        WaitForSeconds wfsTime = CWFS.WFS(0.5f);

        while (IsAni)
        {
            Text.sprite = Spr_Texts[i - 1];

            if (i >= Spr_Texts.Length)
            {
                i = 1;
            }
            else
            {
                i++;
            }
            yield return wfsTime;
        }
    }
}
