import React from "react";
import styled from "styled-components";
// import ParticlesBg from "particles-bg";

import UserIcon from "assets/icons/loginuser.png";
import PWIcon from "assets/icons/loginpw.png";
import useInputs from "lib/hooks/useInputs";
import { inject, observer } from "mobx-react";

interface Props {
  onLogin: (id: string, password: string) => void;
  onAgentLogin: (id: string, password: string) => void;
  loginError: boolean;
}

function Login({ onLogin, loginError, onAgentLogin }: Props) {
  const { inputs, onChange } = useInputs({
    id: "",
    password: "",
  });
  const { id, password } = inputs;
  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onLogin(id, password);
  };

  const agentLogin = () => {
    onAgentLogin(id, password);
  };

  return (
    <Wrap>
      <LoginWrap className="login-wrap">
        <div>LIENG GAME MANAGER</div>
        <form onSubmit={onSubmit}>
          <h1>LOGIN</h1>
          <input
            name="id"
            value={id}
            onChange={onChange}
            className="user"
            placeholder="ID"
            autoComplete="off"
          />
          <input
            name="password"
            type="password"
            value={password}
            onChange={onChange}
            className="pw"
            placeholder="PASSWORD"
            autoComplete="off"
          />
          {loginError && <Invalid>Can't not find admin account</Invalid>}
          <button type="submit">ADMIN LOGIN</button>
          <button type="button" onClick={agentLogin}>
            AGENT LOGIN
          </button>

          <p>If you forgot ID / PASSWORD. Contact to general manager.</p>
        </form>
      </LoginWrap>
    </Wrap>
  );
}

export const Invalid = styled.div`
  color: red;
  font-weight: bold;
`;

const Wrap = styled.div`
  width: 100vw;
  height: 100vh;
  /* background: #00bbcc; */
  background: #eeeeee;

  position: absolute;
  z-index: -1;
`;

const LoginWrap = styled.div`
  width: 960px;
  height: 660px;

  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);

  display: flex;

  background: white;

  border-radius: 20px;

  & > div {
    width: 100%;
    height: 100%;
    /* display: flex; */
    background: #555;

    display: flex;
    justify-content: center;
    align-items: center;

    color: white;

    font-size: 48px;
    font-weight: bold;

    border-radius: 20px 0px 0px 20px;

    padding: 30px;
  }

  & > form {
    width: 100%;
    height: 100%;

    display: flex;
    flex-direction: column;
    justify-content: center;

    padding: 30px;

    & > p {
      display: flex;
      justify-content: center;

      font-size: 14px;
      color: #888888;

      margin-top: 72px;
    }

    & > h1 {
      font-size: 36px;
      font-weight: bold;

      color: #888888;
    }

    & > input {
      width: 100%;
      height: 50px;
      background: white;

      border-radius: 0px;
      border: none;

      font-size: 14px;
      color: #444444;

      padding: 0 36px;

      margin-bottom: 36px;

      border-bottom: 2px solid #dddddd;

      :focus {
        border-bottom: 2px solid ${({ theme }) => theme.colors.primary_color};
      }
    }

    & > .user {
      background: url(${UserIcon});
      background-position: left;
      background-repeat: no-repeat;
      background-size: 20px 20px;
    }

    & > .pw {
      background: url(${PWIcon});
      background-position: left;
      background-repeat: no-repeat;
      background-size: 21px;
    }

    & > button {
      width: 100%;
      height: 60px;
      background: #555;

      font-size: 18px;
      font-weight: bold;
      color: white;
      margin-top: 50px;
      border-radius: 5px;
      border: none;
    }
  }
`;

export default inject("userStore")(observer(Login));
