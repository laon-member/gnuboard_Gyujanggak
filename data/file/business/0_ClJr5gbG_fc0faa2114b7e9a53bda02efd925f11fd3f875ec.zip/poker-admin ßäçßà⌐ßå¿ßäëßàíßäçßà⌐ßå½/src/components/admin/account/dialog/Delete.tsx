import React from "react";
import { DialogContainer } from "containers/common/dialog";

interface Props {
  title: string;
  onToggle: (id: string) => void;
  activeAdminList: number[];
}

const Delete = ({ title, onToggle, activeAdminList }: Props) => {
  const onSave = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
  };
  return (
    <DialogContainer
      title={title}
      confirmText="DELETE"
      onToggle={() => onToggle("delete")}
      onSubmit={onSave}
    >
      <p>Are you sure you want to delete {activeAdminList.length} account?</p>
    </DialogContainer>
  );
};

export default Delete;
