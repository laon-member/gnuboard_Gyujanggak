import React from "react";
import { inject, observer } from "mobx-react";

import WithdrawApplylist from "components/withdraw/WithdrawApplylist";

import WithdrawStore from "stores/withdraw";

interface Props {
  withdrawStore?: WithdrawStore;
}

@inject("withdrawStore")
@observer
class WithdrawApplyListContainer extends React.Component<Props> {
  private WithdrawStore = this.props.withdrawStore! as WithdrawStore;

  async componentDidMount() {
    await this.WithdrawStore.GetWithdrawList();
  }

  updateComplete = async (id: number) => {
    await this.WithdrawStore.PutWithdrawComplete(id);
    if (this.WithdrawStore.success["PUT_WITHDRAW_COMPLETE"]) {
      await this.WithdrawStore.GetWithdrawList();
    }
  };

  updateReject = async (id: number) => {
    await this.WithdrawStore.PutWithdrawReject(id);
    if (this.WithdrawStore.success["PUT_WITHDRAW_REJECT"]) {
      await this.WithdrawStore.GetWithdrawList();
    }
  };

  onActiveToggle = async (id: number) => {
    await this.WithdrawStore.onActive(id);
  };

  onSearch = async (
    id?: string,
    phone?: string,
    startDate?: string,
    endDate?: string
  ) => {
    await this.WithdrawStore.GetWithdrawList(id, phone, startDate, endDate);
  };

  render() {
    return (
      <WithdrawApplylist
        withdraw={this.WithdrawStore.Withdraw!}
        withdrawList={this.WithdrawStore.WithdrawList}
        updateComplete={this.updateComplete}
        updateReject={this.updateReject}
        onSearch={this.onSearch}
        onActiveToggle={this.onActiveToggle}
      />
    );
  }
}

export default WithdrawApplyListContainer;
