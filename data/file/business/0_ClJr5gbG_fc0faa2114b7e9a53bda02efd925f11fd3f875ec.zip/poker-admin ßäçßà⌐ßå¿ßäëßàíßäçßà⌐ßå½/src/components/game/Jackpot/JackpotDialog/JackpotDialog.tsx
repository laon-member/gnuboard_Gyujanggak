import React from "react";
import useInputs from "lib/hooks/useInputs";
import { DialogContainer } from "containers/common/dialog";
import { Input } from "styles/atom";
import { InputWrapper } from "components/deposit/Bankset/Bankset";

interface Props {
  title: string;
  onToggle: () => void;
  editPolicyList: (jackpotEditInfo: any) => void;
}

const JackpotDialog = ({ title, onToggle, editPolicyList }: Props) => {
  const { inputs, setInputs, init } = useInputs({
    limitValue: "",
    levelOneConsume: "",
    levelOneGuarantee: "",
    levelOneHeadCount: 1,
    levelTwoConsume: "",
    levelTwoGuarantee: "",
    levelTwoHeadCount: 2,
    levelThreeConsume: "",
    levelThreeGuarantee: "",
    levelThreeHeadCount: 3,
    levelFourConsume: "",
    levelFourGuarantee: "",
    levelFourHeadCount: 4,
    levelFiveConsume: "",
    levelFiveGuarantee: "",
    levelFiveHeadCount: 5,
    levelSixConsume: "",
    levelSixGuarantee: "",
    levelSixHeadCount: 6,
  });
  const {
    limitValue,
    levelOneConsume,
    levelOneGuarantee,
    levelTwoConsume,
    levelTwoGuarantee,
    levelThreeConsume,
    levelThreeGuarantee,
    levelFourConsume,
    levelFourGuarantee,
    levelFiveConsume,
    levelFiveGuarantee,
    levelSixConsume,
    levelSixGuarantee,
  } = inputs;

  const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setInputs({
      ...inputs,
      [name]: parseInt(value, 10),
    });
  };

  const onSave = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (
      limitValue === "" ||
      levelOneGuarantee === "" ||
      levelOneConsume === "" ||
      levelTwoConsume === "" ||
      levelTwoGuarantee === "" ||
      levelThreeConsume === "" ||
      levelThreeGuarantee === "" ||
      levelFourConsume === "" ||
      levelFourGuarantee === "" ||
      levelFiveConsume === "" ||
      levelFiveGuarantee === "" ||
      levelSixConsume === "" ||
      levelSixGuarantee === ""
    )
      return alert("Don't empty input");
    editPolicyList(inputs);
    init();
    onToggle();
  };
  return (
    <>
      <DialogContainer title={title} onToggle={onToggle} onSubmit={onSave}>
        <InputWrapper>
          <label>Limit value</label>
          <Input
            type="number"
            name="limitValue"
            value={limitValue}
            onChange={onChange}
          />
        </InputWrapper>
        <InputWrapper>
          <label>Lv.1 Consume</label>
          <Input
            type="number"
            name="levelOneConsume"
            value={levelOneConsume}
            onChange={onChange}
          />
        </InputWrapper>
        <InputWrapper>
          <label>Lv.1 Consume</label>
          <Input
            type="number"
            name="levelOneGuarantee"
            value={levelOneGuarantee}
            onChange={onChange}
          />
        </InputWrapper>
        <InputWrapper>
          <label>Lv.2 Consume</label>
          <Input
            type="number"
            name="levelTwoConsume"
            value={levelTwoConsume}
            onChange={onChange}
          />
        </InputWrapper>
        <InputWrapper>
          <label>Lv.2 Guarantee</label>
          <Input
            type="number"
            name="levelTwoGuarantee"
            value={levelTwoGuarantee}
            onChange={onChange}
          />
        </InputWrapper>
        <InputWrapper>
          <label>Lv.3 Consume</label>
          <Input
            type="number"
            name="levelThreeConsume"
            value={levelThreeConsume}
            onChange={onChange}
          />
        </InputWrapper>
        <InputWrapper>
          <label>Lv.3 Guarantee</label>
          <Input
            type="number"
            name="levelThreeGuarantee"
            value={levelThreeGuarantee}
            onChange={onChange}
          />
        </InputWrapper>
        <InputWrapper>
          <label>Lv.4 Consume</label>
          <Input
            type="number"
            name="levelFourConsume"
            value={levelFourConsume}
            onChange={onChange}
          />
        </InputWrapper>
        <InputWrapper>
          <label>Lv.4 Guarantee</label>
          <Input
            type="number"
            name="levelFourGuarantee"
            value={levelFourGuarantee}
            onChange={onChange}
          />
        </InputWrapper>
        <InputWrapper>
          <label>Lv.5 Consume</label>
          <Input
            type="number"
            name="levelFiveConsume"
            value={levelFiveConsume}
            onChange={onChange}
          />
        </InputWrapper>
        <InputWrapper>
          <label>Lv.5 Guarantee</label>
          <Input
            type="number"
            name="levelFiveGuarantee"
            value={levelFiveGuarantee}
            onChange={onChange}
          />
        </InputWrapper>
        <InputWrapper>
          <label>Lv.6 Consume</label>
          <Input
            type="number"
            name="levelSixConsume"
            value={levelSixConsume}
            onChange={onChange}
          />
        </InputWrapper>
        <InputWrapper>
          <label>Lv.6 Guarantee</label>
          <Input
            type="number"
            name="levelSixGuarantee"
            value={levelSixGuarantee}
            onChange={onChange}
          />
        </InputWrapper>
      </DialogContainer>
    </>
  );
};

export default JackpotDialog;
