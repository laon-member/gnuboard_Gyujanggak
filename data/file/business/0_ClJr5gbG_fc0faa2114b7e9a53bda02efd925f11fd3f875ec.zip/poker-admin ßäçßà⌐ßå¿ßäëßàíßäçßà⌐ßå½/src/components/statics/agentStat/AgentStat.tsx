import { TableRowWrapper } from "components/common";
import comma from "lib/comma";
import React from "react";
import { TAgentStat } from "stores/statistics/types";

interface Props {
  agentStat: TAgentStat;
}

function AgentStat({ agentStat }: Props) {
  return (
    <TableRowWrapper>
      <td>{agentStat.username}</td>
      <td>{agentStat.date}</td>
      <td>{comma(agentStat.member_number)}</td>
      <td>{comma(agentStat.remain_amount)}</td>
      <td>{comma(agentStat.total_poundage)}</td>
      <td>{comma(agentStat.agent_withdraw)}</td>
    </TableRowWrapper>
  );
}

export default AgentStat;
