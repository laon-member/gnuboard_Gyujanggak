import { PagingType } from "stores/message/types";

export type NoticeType = {
  id: number;
  title: string;
  content: string;
  userName: string;
  name: string;
  is_read: number;
  created_at: Date;
  updated_at?: Date;
  active?: boolean;
};

export type Account = {
  id: string;
  dl: number;
  cp: number;
  created_at: Date;
  updated_at?: Date;
};

export type PremiumType = {
  idx: number;
  updated_at: Date;
  content: string;
};

export type searchedUserType = {
  id: number;
  username: string;
  phone: string;
};

export type PopUpFormType = {
  title: string;
  content: string;
};

export type UseInput = {
  inputs: any;
  onChange: (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => void;
  setInputs: React.Dispatch<any>;
  init: () => void;
};

export type RollingSearchType = {
  content: string;
  start_date: string;
  end_date: string;
  position: string;
  page: number;
};

export type AddRollingType = {
  content: string;
  start_date: string;
  end_date: string;
  duration: string;
  position: string;
  validateInterval: boolean;
};

export type RollingType = {
  id: number;
  duration: string;
  start_date: string;
  end_date: string;
  position: string;
  content: string;
  username: string;
  active?: boolean;
};

export type RollingPage = {
  paging: PagingType;
  notices: RollingType[];
};

export type TPopUp = {
  id: number;
  title: string;
  content: string;
  created_at: string;
};
