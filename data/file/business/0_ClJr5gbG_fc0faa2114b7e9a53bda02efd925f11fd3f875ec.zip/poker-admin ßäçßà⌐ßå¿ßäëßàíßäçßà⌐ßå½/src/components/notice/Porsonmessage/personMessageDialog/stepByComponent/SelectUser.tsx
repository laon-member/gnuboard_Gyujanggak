import React from "react";
import styled from "styled-components";
import { searchedUserType } from "stores/notice/types";
import TableRowWrapper from "components/common/TableRowWrapper";

interface Props {
  user: searchedUserType;
  onAddUser: (user: searchedUserType) => void;
}

const SelectUser = ({ user, onAddUser }: Props) => {
  const { id, username, phone } = user;
  return (
    <>
      <TableRowWrapper>
        <td>{id}</td>
        <td>{username}</td>
        <td>{phone}</td>
        <td>
          <span onClick={() => onAddUser(user)}>ADD</span>
        </td>
      </TableRowWrapper>
    </>
  );
};

export const UserWrapper = styled.tbody`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 1rem 0 0;
  margin: 0.5rem 0;

  span {
    cursor: pointer;
    background: #ccc;
    padding: 0.25rem;
    border-radius: 10px;
    font: 12px/14px sans-serif;
  }
`;

export default SelectUser;
