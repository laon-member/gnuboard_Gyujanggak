import axios from "axios";

export default axios.create({
  baseURL: `${process.env.REACT_APP_API_BASE}`,

  headers: {
    Authorization: localStorage.getItem("userInfo") ? `Bearer ${JSON.parse(localStorage.getItem("userInfo")!)["access_token"]
      }` : null,

  },
});
