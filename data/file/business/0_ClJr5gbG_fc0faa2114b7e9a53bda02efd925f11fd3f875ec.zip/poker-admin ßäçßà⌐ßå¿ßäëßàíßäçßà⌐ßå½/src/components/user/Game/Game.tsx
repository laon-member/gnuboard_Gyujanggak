import React from "react";
import styled from "styled-components";
import Calendar from "assets/icons/calendar.png";
import SearchIcon from "assets/icons/search.png";
import Online from "assets/icons/online.png";
import Heart from "assets/icons/heart.png";
import Dia from "assets/icons/dia.png";
import Table from "components/common/Table";

const Game = () => {
  return (
    <Wrap>
      <div className="search">
        <input type="text" placeholder="ID" className="id" />
        <input type="text" placeholder="Nickname" className="nickname" />
        <input type="text" className="date" />
        <span> ~ </span>
        <input type="text" className="date" />
        <button>
          <img src={SearchIcon} alt="search" />
        </button>
      </div>

      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>Round</th>
            <th>ID</th>
            <th>Nick name</th>
            <th>방</th>
            <th>승패</th>
            <th>카드</th>
            <th>기본배팅</th>
            <th>배팅금액</th>
            <th>게임 전 Holding amount</th>
            <th>승 / 패 금액</th>
            <th>현재 Holding amount</th>
            <th>게임시간</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>200</td>
            <td>1122</td>
            <td>홍길동</td>
            <td>
              길동이 <img src={Online} alt="online" />
            </td>
            <td>Lv.1</td>

            <td>승</td>
            <td>
              <span>
                <img src={Heart} alt="card" />
              </span>
              <span>2</span>
              <span>
                <img src={Dia} alt="card" />
              </span>
              <span>4</span>
            </td>
            <td>20,000</td>
            <td>20,000</td>
            <td>40,000</td>
            <td>10.000</td>
            <td>10.000</td>
            <td>2020.02.02 02:02</td>
          </tr>
        </tbody>
      </Table>
    </Wrap>
  );
};
const Wrap = styled.div`
  width: 100%;
  padding: 0 1rem;
  & > .membermenu {
    width: 100%;
    margin-top: 40px;

    border-bottom: 2px solid #555;
    & > ul {
      overflow: hidden;
      & > li {
        & > a {
          width: 150px;
          float: left;

          cursor: pointer;

          padding: 15px 0;
          border-radius: 7px 7px 0 0;

          text-align: center;
          font-size: 14px;
          color: #333;
        }
      }
      & > li > a.active {
        background: #555;
        color: #fff;
      }
    }
  }

  & > .search {
    width: 100%;
    padding: 20px 0;
    & > .id {
      width: 200px;
      height: 35px;
      background: #ffffff;
      border: 1px solid #cccccc;

      border-radius: 7px;

      padding-left: 12px;

      ::placeholder {
        color: #ccc;
        font-size: 12px;
      }
    }

    & > .nickname {
      width: 200px;
      height: 35px;
      background: #ffffff;
      border: 1px solid #cccccc;

      border-radius: 7px;

      padding-left: 12px;
      margin-left: 20px;

      ::placeholder {
        color: #ccc;
        font-size: 12px;
      }
    }

    & > .date {
      width: 200px;
      height: 35px;
      background: #ffffff;
      border: 1px solid #cccccc;

      border-radius: 7px;

      padding: 0 12px;
      margin-left: 20px;
      margin-right: 20px;
      background: url(${Calendar}) no-repeat;
      background-position: 95% 50%;

      ::placeholder {
        color: #ccc;
        font-size: 12px;
      }
    }

    & > span {
      color: #333;
    }

    & > button {
      width: 70px;
      height: 35px;

      background: #555555;
      border-radius: 5px;

      border: none;
      vertical-align: top;
    }
  }
`;
export default Game;
