import { observable, flow, computed, action } from "mobx";

import BaseStore from "stores/BaseStore";
import RootStore from "stores";

import {
  NoticeType,
  PopUpFormType,
  RollingType,
  RollingSearchType,
  searchedUserType,
  RollingPage,
  AddRollingType,
  TPopUp,
} from "./types";
import NoticeService from "services/notice/NoticeService";
import { PagingType } from "stores/message/types";

class NoticeStore extends BaseStore {
  root: RootStore;

  constructor(root: RootStore) {
    super();
    this.root = root;
  }

  // 추가기능
  @observable
  rollingPage: RollingPage = {
    paging: {} as PagingType,
    notices: [] as RollingType[],
  };

  @observable
  popUp = {} as TPopUp;

  @observable
  rolling = {} as RollingType;

  @action
  createPopUp = async (inputs: PopUpFormType) => {
    return await NoticeService.createPopUp(inputs);
  };

  @action
  getRollingList = async (payload: RollingSearchType) => {
    try {
      const res = await NoticeService.getRollingList(payload);
      if (res.status === 200) {
        this.rollingPage = res.data.data;
      }
    } catch (error) {
      throw error;
    }
  };

  @action
  addRolling = async (payload: AddRollingType) => {
    return await NoticeService.addRolling(payload);
  };

  @action
  deleteRollingToggle = (id: number) => {
    this.rollingPage.notices = this.rollingPage.notices.map((rolling) =>
      id === rolling.id ? { ...rolling, active: !rolling.active } : rolling
    );
  };

  @action
  deleteAllRollingToggle = () => {
    const isActive = this.rollingPage.notices.filter((notice) => notice.active);
    if (isActive.length === 0) {
      this.rollingPage.notices = this.rollingPage.notices.map((notice) => ({
        ...notice,
        active: true,
      }));
    } else {
      this.rollingPage.notices = this.rollingPage.notices.map((notice) => ({
        ...notice,
        active: false,
      }));
    }
  };

  @action setRolling = (payload: RollingType) => {
    this.rolling = payload;
  };

  @computed
  get getDeleteRollingList() {
    return this.rollingPage.notices.filter((rolling) => rolling.active);
  }

  @action
  deleteRolling = async (payload: RollingType[]) => {
    const list = payload.map((rolling) => rolling.id);
    return await NoticeService.RemoveRollingList(list);
  };

  @action
  getPopUp = async () => {
    try {
      const res = await NoticeService.getPopUp();
      if (res.data.result) {
        this.popUp = res.data.data.notice;
      } else {
        alert("There is a problem with the server");
      }
    } catch (error) {
      alert("There is a problem with the server");
    }
  };

  // 기존 스토어
  @observable
  private _isLoggedIn = false;

  @observable
  private _userType?: number;

  @observable
  private _notice?: NoticeType;

  @observable
  private _noticeList: NoticeType[] = [];

  @observable
  private _searchedUserList: searchedUserType[] = [];

  @observable
  private userListOfPersonMessage: searchedUserType[] = [];

  @computed
  get NoticeList() {
    return this._noticeList;
  }
  @computed
  get Notice() {
    return this._notice;
  }

  @computed
  get IsLoggedIn() {
    return this._isLoggedIn;
  }

  @computed
  get searchedUserList() {
    return this._searchedUserList;
  }

  @computed
  get activeUsers() {
    const users = this._noticeList.filter((user) => user.active);
    return users.map((user) => user.id);
  }

  @computed
  get GetUserListToPersonMessage() {
    return this.userListOfPersonMessage;
  }

  @action
  public logout() {
    this._isLoggedIn = false;
    this._userType = undefined;
  }

  @action
  public activeToggle(id: number) {
    this._noticeList = this._noticeList.map((user) =>
      user.id === id ? { ...user, active: !user.active } : user
    );
  }

  @action
  public addUserListToPersonMessage(user: searchedUserType) {
    if (this.userListOfPersonMessage.find((v) => v.id === user.id))
      return alert("This is the added user");
    this.userListOfPersonMessage.push(user);
  }
  @action
  public removeUserListToPersonMessage(id: number) {
    this.userListOfPersonMessage = this.userListOfPersonMessage.filter(
      (user) => user.id !== id
    );
  }
  @action
  public initUserListToPersonMessage() {
    this.userListOfPersonMessage = [];
    this._searchedUserList = [];
  }
  @action
  public selectAllUserListToPersonMessage() {
    this.userListOfPersonMessage = this.searchedUserList;
  }

  GetPeronmsgList = flow(function* (
    this: NoticeStore,
    nickname?: string,
    date?: string
  ) {
    this._init("GET_PERONMSG_LIST");

    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ notice: NoticeType[] }>;
      } = yield NoticeService.GetPeronmsgListAPI(nickname, date);
      const { notice } = res.data;
      this._noticeList = notice;
      this._success["GET_PERONMSG_LIST"] = true;
    } catch (e) {
      console.error(e);
      this._failure["GET_PERONMSG_LIST"] = [true, e];
    } finally {
      this._pending["GET_PERONMSG_LIST"] = false;
    }
  });

  PostPersonMessage = flow(function* (
    this: NoticeStore,
    title: string,
    content: string,
    list: number[]
  ) {
    try {
      const data = yield NoticeService.PostPersonMessage(title, content, list);
      console.dir(data);
    } catch (error) {
      throw error;
    }
  });

  RemovePersonList = flow(function* (this: NoticeStore, list: number[]) {
    try {
      yield NoticeService.RemovePersonList(list);
    } catch (error) {
      throw error;
    }
  });

  PostNewRolling = flow(function* (
    this: NoticeStore,
    adminName: string,
    content: string
  ) {
    this._init("POST_NEW_ROLLING");

    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ notice: NoticeType }>;
      } = yield NoticeService.PostNewRollingAPI(adminName, content);
      const { notice } = res.data;
      this._notice = notice;
      this._success["POST_NEW_ROLLING"] = true;
    } catch (e) {
      this._failure["POST_NEW_ROLLING"] = [true, e];
    } finally {
      this._pending["POST_NEW_ROLLING"] = false;
    }
  });

  GetRollingList = flow(function* (
    this: NoticeStore,
    content?: string,
    startDate?: string,
    endDate?: string
  ) {
    this._init("GET_ROLLING_LIST");

    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ notice: NoticeType[] }>;
      } = yield NoticeService.GetRollingListAPI(content, startDate, endDate);
      const { notice } = res.data;
      this._noticeList = notice;
      this._success["GET_ROLLING_LIST"] = true;
    } catch (e) {
      this._failure["GET_ROLLING_LIST"] = [true, e];
    } finally {
      this._pending["GET_ROLLING_LIST"] = false;
    }
  });

  GetPopupList = flow(function* (
    this: NoticeStore,
    title?: string,
    date?: string
  ) {
    this._init("GET_POPUP_LIST");

    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ notice: NoticeType[] }>;
      } = yield NoticeService.GetPopupListAPI(title, date);
      const { notice } = res.data;
      this._noticeList = notice;
      this._success["GET_POPUP_LIST"] = true;
    } catch (e) {
      this._failure["GET_POPUP_LIST"] = [true, e];
    } finally {
      this._pending["GET_POPUP_LIST"] = false;
    }
  });

  RemovePopupList = flow(function* (this: NoticeStore, list: number[]) {
    try {
      yield NoticeService.RemovePopupList(list);
    } catch (error) {
      throw error;
    }
  });

  PostNewPopup = flow(function* (
    this: NoticeStore,
    adminName: string,
    title: string,
    content: string
  ) {
    this._init("POST_NEW_POPUP");

    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ notice: NoticeType }>;
      } = yield NoticeService.PostNewPopupAPI(adminName, title, content);
      const { notice } = res.data;
      this._notice = notice;
      this._success["POST_NEW_POPUP"] = true;
    } catch (e) {
      this._failure["POST_NEW_POPUP"] = [true, e];
    } finally {
      this._pending["POST_NEW_POPUP"] = false;
    }
  });

  SearchUserAtRollingMessage = flow(function* (
    this: NoticeStore,
    content: string,
    startDate: string,
    endDate: string
  ) {
    yield NoticeService.GetRollingListAPI(content, startDate, endDate);
  });

  SearchUserAtPersonMessage = flow(function* (
    this: NoticeStore,
    type: string,
    value: string
  ) {
    this._init("GET_SEARCH_USER");

    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ users: searchedUserType[] }>;
      } = yield NoticeService.SearchUserAtPersonMessage(type, value);
      const { users } = res.data;
      this._searchedUserList = users;
    } catch (error) {
      console.error(error);
      throw error;
    }
  });
}

export default NoticeStore;
