﻿using System.Collections;
using UnityEngine;
using UnityEngine.Networking;

using System;
using System.Text;

using Photon.Realtime;
using Photon.Pun;

public class DataBaseManager : MonoBehaviourPunCallbacks
{

    private void Start()
    {
        DontDestroyOnLoad(this.gameObject);
    }

    public IEnumerator Post(string url, string data, string type, string token, Action<string> onResponse)
    {
        var req = new UnityWebRequest(url, type);

        if (data.Length > 0)
        {
            byte[] body = Encoding.UTF8.GetBytes(data);

            req.uploadHandler = new UploadHandlerRaw(body);
        }
        req.downloadHandler = new DownloadHandlerBuffer();

        req.SetRequestHeader("Authorization", "Bearer " + token); // 토큰 보낼 때
        req.SetRequestHeader("Content-Type", "application/json");
        

        yield return req.SendWebRequest();

        if(req.isNetworkError)
        {
            onResponse("NetworkError");
        }
        else
        {
            onResponse(req.downloadHandler.text);
        }
    }

    public void StartSendLogined()
    {
        StopSendLogined();
        StartCoroutine("SendLogined");
    }

    IEnumerator SendLogined()
    {
        WaitForSeconds wfsTime = CWFS.WFS(9.0f);

        while (true)
        {
            StartCoroutine(Post(DataBaseLinkList.Instance.SendIsLogined, "", "Post", PlayerPrefs.GetString("Token"), (result) =>
            {
            }));
            yield return wfsTime;
        }
    }

    public void StopSendLogined()
    {
        StopCoroutine("SendLogined");
    }

    public void OnApplicationPause(bool pause)
    {
        if(pause == true)
        {
            StopCoroutine("SendLogined");
        }
        else
        {
            StartSendLogined();
        }
    }

    public override void OnDisconnected(DisconnectCause cause)
    {
        StartCoroutine(Post(DataBaseLinkList.Instance.Logout, "", "Post", PlayerPrefs.GetString("Token"), (result) =>
        {
            StopSendLogined();
        }));
    }
}
