import { TableRowWrapper } from "components/common";
import comma from "lib/comma";
import React from "react";
import { TAgentMoneyHistory } from "stores/agent/types";

interface Props {
  log: TAgentMoneyHistory;
  idx: number;
}

function AddAgentMoneyHistory({ log, idx }: Props) {
  return (
    <TableRowWrapper>
      <td>{idx}</td>
      <td>{log.admin_account}</td>
      <td>{log.agent_account}</td>
      <td>{log.agent_code}</td>
      <td>{comma(parseInt(log.amount, 10))}</td>
      <td>{log.created_at}</td>
    </TableRowWrapper>
  );
}

export default AddAgentMoneyHistory;
