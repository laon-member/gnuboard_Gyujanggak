import { Switch } from "@material-ui/core";
import { InputWrapper } from "components/deposit/Bankset/Bankset";
import { RadioWrapper } from "components/member/memberlist/EditBox";
import { DialogContainer } from "containers/common/dialog";
import { useInputs } from "lib/hooks";
import React from "react";
import { UseInput } from "stores/notice/types";
import {
  TNewBankSet,
  TNewBankSetForm,
  TRechargeBankSet,
} from "stores/recharge/types";
import { Input } from "styles/atom";

interface Props {
  type: TNewBankSet;
  form: UseInput;
  bankSet: TRechargeBankSet;
}

function BankBox({ type, form, bankSet }: Props) {
  const {
    bank_account,
    bank_number,
    bank_name,
    is_active,
  } = form.inputs as TNewBankSetForm;
  const { onChange, setInputs } = form;

  const modi = {
    bankset: useInputs(bankSet),
  };

  const onEditSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    type.onSubmit(modi.bankset.inputs);
  };

  return bankSet ? (
    <DialogContainer
      title="Edit Bank Box"
      confirmText="SAVE"
      onToggle={type.onToggle}
      onSubmit={onEditSubmit}
    >
      <InputWrapper>
        <label>BankName</label>
        <Input
          placeholder="BankName"
          name="bank_name"
          value={modi.bankset.inputs.bank_name}
          onChange={modi.bankset.onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>BankAccount</label>
        <Input
          placeholder="BankAccount"
          name="bank_account"
          value={modi.bankset.inputs.bank_account}
          onChange={modi.bankset.onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>BankCardNumber</label>
        <Input
          placeholder="BankCardNumber"
          name="bank_number"
          value={modi.bankset.inputs.bank_number}
          onChange={modi.bankset.onChange}
        />
      </InputWrapper>
      <RadioWrapper>
        <label>ShowBank</label>
        <div style={{ width: 100 }}>
          <Switch
            color="primary"
            defaultChecked={modi.bankset.inputs.is_active === 1}
            checked={modi.bankset.inputs.is_active === 1}
            value={modi.bankset.inputs.is_active}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              modi.bankset.setInputs({
                ...modi.bankset.inputs,
                is_active: e.target.checked ? 1 : 0,
              });
            }}
          />
        </div>
      </RadioWrapper>
    </DialogContainer>
  ) : (
    <DialogContainer
      title="Bank Box"
      confirmText="SAVE"
      onToggle={type.onToggle}
      onSubmit={type.onSubmit}
    >
      <InputWrapper>
        <label>BankName</label>
        <Input
          placeholder="BankName"
          name="bank_name"
          value={bank_name}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>BankAccount</label>
        <Input
          placeholder="BankAccount"
          name="bank_account"
          value={bank_account}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>BankCardNumber</label>
        <Input
          placeholder="BankCardNumber"
          name="bank_number"
          value={bank_number}
          onChange={onChange}
        />
      </InputWrapper>
      <RadioWrapper>
        <label>ShowBank</label>
        <div style={{ width: 100 }}>
          <Switch
            color="primary"
            value={is_active}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
              setInputs({
                ...form.inputs,
                is_active: e.target.checked ? 1 : 0,
              })
            }
          />
        </div>
      </RadioWrapper>
    </DialogContainer>
  );
}

export default BankBox;
