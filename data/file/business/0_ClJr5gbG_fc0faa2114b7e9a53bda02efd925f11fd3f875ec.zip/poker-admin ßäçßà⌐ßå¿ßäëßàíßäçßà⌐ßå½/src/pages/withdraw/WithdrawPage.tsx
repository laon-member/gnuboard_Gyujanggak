import React from "react";
import { Route, NavLink, Switch } from "react-router-dom";

import { SubNavContainer, ContainerWrapper } from "pages/member/MemberPage";
import ApplyListContainer from "containers/withdraw/ApplyListContainer";
import WithDrawLogContainer from "containers/withdraw/WithDrawLogContainer";

function WithdrawPage() {
  return (
    <>
      <SubNavContainer>
        <li>
          <NavLink exact to="/admin/withdraw" activeClassName="active">
            ApplyList
          </NavLink>
        </li>
        <li>
          <NavLink to="/admin/withdraw/log" activeClassName="active">
            WithdrawLog
          </NavLink>
        </li>
      </SubNavContainer>
      <ContainerWrapper>
        <Switch>
          <Route exact path="/admin/withdraw" component={ApplyListContainer} />
          <Route path="/admin/withdraw/log" component={WithDrawLogContainer} />
        </Switch>
      </ContainerWrapper>
    </>
  );
}

export default WithdrawPage;
