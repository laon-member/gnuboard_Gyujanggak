import React from "react";

import { Route, NavLink, Switch } from "react-router-dom";
import styled from "styled-components";
import FinanceLogContainer from "containers/member/FinanceLogContainer";
import GameLogContainer from "containers/member/GameLogContainer";
import MemberListContainer from "containers/member/MemberListContainer";
import BlockListContainer from "containers/member/BlockListContainer";
import SendMoneyHistoryContainer from "containers/member/SendMoneyHistoryContainer";
import RechargeLogContainer from "containers/recharge/RechargeLogContainer";

function MemberPage() {
  return (
    <>
      <SubNavContainer>
        <li>
          <NavLink exact to="/admin/member" activeClassName="active">
            MemberList
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/admin/member/block" activeClassName="active">
            BlockList
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/admin/member/finance" activeClassName="active">
            FinanceLog
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/admin/member/game" activeClassName="active">
            GameLog
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/admin/member/money" activeClassName="active">
            SendMoneyHistory
          </NavLink>
        </li>
      </SubNavContainer>
      <ContainerWrapper>
        <Switch>
          <Route exact path="/admin/member" component={MemberListContainer} />
          <Route
            exact
            path="/admin/member/block"
            component={BlockListContainer}
          />
          <Route
            exact
            path="/admin/member/finance"
            component={FinanceLogContainer}
          />
          <Route exact path="/admin/member/game" component={GameLogContainer} />
          <Route
            exact
            path="/admin/member/recharge"
            component={RechargeLogContainer}
          />
          <Route
            exact
            path="/admin/member/withdraw"
            component={GameLogContainer}
          />
          <Route
            exact
            path="/admin/member/sendMoney"
            component={GameLogContainer}
          />
          <Route
            exact
            path="/admin/member/money"
            component={SendMoneyHistoryContainer}
          />
        </Switch>
      </ContainerWrapper>
    </>
  );
}

export const SubNavContainer = styled.ul`
  display: flex;
  margin: 1rem 1rem 0 1rem;
  padding: 9px 0;
  border-bottom: 3px solid #3ab598;

  a {
    padding: 0.5rem 2rem;
    margin-right: 1rem;
    border-radius: 5px 5px 0 0;
    background-color: #f4f4f4;
  }

  .active {
    background: #3ab598;
    color: #fff;
  }
`;

export const ContainerWrapper = styled.article`
  padding: 0 1rem 1rem 1rem;
`;

export default MemberPage;
