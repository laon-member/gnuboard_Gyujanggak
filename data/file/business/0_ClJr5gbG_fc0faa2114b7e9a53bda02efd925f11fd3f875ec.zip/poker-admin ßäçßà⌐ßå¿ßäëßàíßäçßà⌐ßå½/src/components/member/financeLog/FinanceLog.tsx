import { TableRowWrapper } from "components/common/TableRowWrapper";
import comma from "lib/comma";
import React from "react";
import { FaBook } from "react-icons/fa";
import { NoteType } from "../memberlist/types";

interface Props {
  note: NoteType;
  log: any;
}

function FinanceLog({ log, note }: Props) {
  return (
    <TableRowWrapper>
      <td>{log.id}</td>
      <td>{log.username}</td>
      <td>{log.type}</td>
      <td>{comma(log.amount)}</td>
      <td>{log.adminName}</td>
      <td>{log.handleTime}</td>
      <td className="icon" onClick={() => note.onToggle(log.id!)}>
        <FaBook />
      </td>
    </TableRowWrapper>
  );
}

export default FinanceLog;
