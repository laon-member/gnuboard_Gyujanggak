import client from "lib/client";
import { TMemberListSearch } from "stores/distributor/member/types";

class AgentMemberService {
  public getMemberListPage = (payload: TMemberListSearch) => {
    return client.get(
      `/api/admin/users/me?username=${payload.username}&nickname=${payload.nickname
      }&date_type=${payload.date_type}&start_date=${payload.start_date
      }&end_date=${payload.end_date}&page=${payload.page - 1}`
    );
  };
}

export default new AgentMemberService();