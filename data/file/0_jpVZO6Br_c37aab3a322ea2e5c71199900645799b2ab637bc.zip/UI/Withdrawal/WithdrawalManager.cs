﻿using DG.Tweening;
using Photon.Realtime;
using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using LitJson;
using Leguar.TotalJSON;

public class WithdrawalManager : MonoBehaviourPunCallbacks
{
    // TopButton
    public Image Btn_Charge;
    public Image Btn_History;

    public Sprite[] Spr_TopBtn;
    
    public GameObject[] Pages;

    int BtnState = 0;

    public GameObject PopUp_Guidance;

    public Text Txt_TotalMoney;

    public GameObject PFContent;
    public Transform ContentParent;

    public InputField Input_ChargeAmount;

    public GameObject X_Btn;

    DataBaseManager DBMgr;

    List<WithdrawalContent> List_Contents = new List<WithdrawalContent>();

    public Guidance NoticGuidance;

    public Button ChargeBtn;

    // Start is called before the first frame update
    void Start()
    {
        if(DBMgr == null)
        {
            DBMgr = FindObjectOfType<DataBaseManager>();
        }

        SetTotalMoney();
    }

    private void Update()
    {
        if (Input_ChargeAmount != null)
        {
            if (Input_ChargeAmount.text != "0" && Input_ChargeAmount.text.Length > 0)
            {
                if (!X_Btn.activeInHierarchy)
                {
                    X_Btn.SetActive(true);
                }
            }
            else
            {
                if (X_Btn.activeInHierarchy)
                {
                    X_Btn.SetActive(false);
                }
            }
        }
    }

    public void OnClickBtn_X_Btn()
    {
        Input_ChargeAmount.text = "0";
    }

    void SetTotalMoney()
    {
        if (long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()) == 0)
        {
            Txt_TotalMoney.text = "0";
            Input_ChargeAmount.interactable = false;
        }
        else
        {
            Txt_TotalMoney.text = string.Format("{0:#,###}", long.Parse(PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"].ToString()));
        }
    }

    void CreateHistoryContent()
    {
        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetWithdrawHistory, "", "Post", PlayerPrefs.GetString("Token"), (result) => {

            JsonData resp = JsonMapper.ToObject(result);

            if ((int)resp["result"] == 1)
            {
                int count = resp["data"]["withdraw"].Count;

                for (int i = 0; i < count; i++)
                {
                    WithdrawalContent content = GameObject.Instantiate(PFContent, ContentParent).GetComponent<WithdrawalContent>();

                    // DB에서 정보 받아서 세팅
                    string[] info = new string[6];
                    info[0] = (i + 1).ToString();
                    info[1] = LocalPlayerInfo.Instance.PlayerAccount;
                    //info[2] = (string)resp["data"]["withdraw"][i]["number"];

                    info[3] = CStringFormat.Instance.FormatToInt(long.Parse(resp["data"]["withdraw"][i]["amount"].ToString()));

                    string date_buffer = (string)resp["data"]["withdraw"][i]["created_at"];
                    string date = "";

                    for (int j = 0; j < 10; j++)
                    {
                        date += date_buffer[j].ToString();
                    }

                    info[4] = date;

                    string status = "";
                    if ((int)resp["data"]["withdraw"][i]["status"] == 0 || (int)resp["data"]["withdraw"][i]["status"] == 5)
                    {
                        status = "Chờ rút tiền"; // 번역 : 출금 대기 o
                    }
                    else if ((int)resp["data"]["withdraw"][i]["status"] == 1)
                    {
                        status = "Hoàn thành rút tiền"; // 번역 : 출금 완료 o
                    }
                    else if ((int)resp["data"]["withdraw"][i]["status"] == 2)
                    {
                        status = "Hủy rút tiền"; // 번역 : 출금 취소  o 
                    }
                    info[5] = status;

                    content.SetTexts(info);
                    List_Contents.Add(content);
                }
            }
        }));
    }
    void ClearHistory()
    {
        for (int i = 0; i < ContentParent.childCount; i++)
        {
            Destroy(ContentParent.GetChild(i).gameObject);
        }

        List_Contents.Clear();
    }
    public void OnClickBtn_ClickSound()
    {
        FindObjectOfType<SoundManager>().StartSound_Effect(SoundFileList.EFFECT.btn_click);
    }
    public void OnClickBtn_Leave()
    {
        SceneManager.LoadScene("Lobby");
    }

    /// <summary>
    /// 0 = charge, 1 = history
    /// </summary>
    /// <param name="type"></param>
    public void OnClickBtn_TopBtn(int type)
    {
        if (type == 0 && BtnState == 1)
        {
            BtnState = type;

            Btn_Charge.sprite = Spr_TopBtn[0];
            Btn_History.sprite = Spr_TopBtn[1];

            Btn_Charge.GetComponent<RectTransform>().sizeDelta = new Vector2(389, 112);
            Btn_History.GetComponent<RectTransform>().sizeDelta = new Vector2(319, 84);

            Pages[0].SetActive(true);
            Pages[1].SetActive(false);

            ClearHistory();

            StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetUserInfo, "", "POST", PlayerPrefs.GetString("Token"), resp => {

                JsonData data = JsonMapper.ToObject(resp);

                PhotonNetwork.LocalPlayer.CustomProperties["UserMoney"] = long.Parse(data["data"]["user"]["amount"].ToString());

                SetTotalMoney();

            }));
        }
        else if (type == 1 && BtnState == 0)
        {
            BtnState = type;

            Btn_Charge.sprite = Spr_TopBtn[1];
            Btn_History.sprite = Spr_TopBtn[0];

            Btn_Charge.GetComponent<RectTransform>().sizeDelta = new Vector2(319, 84);
            Btn_History.GetComponent<RectTransform>().sizeDelta = new Vector2(389, 112);

            Pages[0].SetActive(false);
            Pages[1].SetActive(true);

            CreateHistoryContent();
        }
    }

    public void OnClickBtn_Moneys(int money)
    {
        if (Txt_TotalMoney.text == "0")
        {
            Input_ChargeAmount.text = "0";
        }
        else
        {
            if (GetIntMoney(Input_ChargeAmount.text) + money >= GetIntMoney(Txt_TotalMoney.text))
            {
                Input_ChargeAmount.text = Txt_TotalMoney.text;
            }
            else
            {
                Input_ChargeAmount.text = (long.Parse(Input_ChargeAmount.text) + money).ToString();
            }
        }

        if(money == -10000)
        {
            Input_ChargeAmount.text = string.Format("{0:#,###}", GetIntMoney(Txt_TotalMoney.text));
        }
    }

    long GetIntMoney(string str)
    {
        long money = 0;

        if (str.Length > 0)
        {
            if (str != "0")
            {
                string[] buffer = str.Split(',');
                string buffer_money = "";
                foreach (var item in buffer)
                {
                    buffer_money += item;
                }
                money = long.Parse(buffer_money);
            }
        }
        return money;
    }

    public override void OnDisconnected(DisconnectCause cause)
    {
        SceneManager.LoadScene("LogIn");
    }

    public void OnClickBtn_Withdrawal()
    {
        if (GetIntMoney(Txt_TotalMoney.text) > 0 && Txt_TotalMoney.text.Length > 0)
        {
            if (Input_ChargeAmount.text != "0")
            {
                if (Input_ChargeAmount.text.Length > 0)
                {
                    PopUp_Guidance.SetActive(true);
                }
            }
        }
    }

    public void OnClickBtn_WithdrawalOK(bool result)
    {
        if (result)
        {
            // 출금
            JSON jsonData = new JSON();
            jsonData.Add("amount", GetIntMoney(Input_ChargeAmount.text).ToString());
            jsonData.Add("status", "0");

            StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.AddWithdraw, jsonData.CreateString(), "Post", PlayerPrefs.GetString("Token"), (coresult) =>
            {
                JsonData resp = JsonMapper.ToObject(coresult);

                //Debug.LogFormat("<color=red>{0}</color>", (int)resp["result"]);

                if ((int)resp["result"] == 1)
                {
                    NoticGuidance.SetText("Hoàn thành đăng kí"); // 번역 : 출금 신청 완료 o

                    Txt_TotalMoney.text = string.Format("{0:#,###}", ((GetIntMoney(Txt_TotalMoney.text) - GetIntMoney(Input_ChargeAmount.text))));
                    Input_ChargeAmount.text = "0";

                    if(GetIntMoney(Txt_TotalMoney.text) == 0 || Txt_TotalMoney.text.Length == 0)
                    {
                        Txt_TotalMoney.text = "0";
                        Input_ChargeAmount.interactable = false;
                    }
                }
            }));
        }
        else
        {
            // 취소
        }

        PopUp_Guidance.SetActive(false);
    }
}
