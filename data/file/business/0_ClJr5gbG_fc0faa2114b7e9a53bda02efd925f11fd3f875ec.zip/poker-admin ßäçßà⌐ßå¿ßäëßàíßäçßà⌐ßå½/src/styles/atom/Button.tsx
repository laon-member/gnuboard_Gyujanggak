import styled, { css } from "styled-components";

type Props = {
  secondary?: boolean;
  half?: boolean;
  full?: boolean;
  big?: boolean;
  small?: boolean;
  active?: boolean;
  bgColor?: string;
  color?: string;
};

const Button = styled.button<Props>`
  padding: 0.75rem 1rem;
  background: #f0f0f0;
  background-color: ${(props) => props.bgColor};
  font-size: 1rem;
  border-radius: 5px;
  color: #000;
  color: ${(props) => props.color};
  border: none;
  cursor: pointer;

  &:active {
    transition: ease 0.3s;
    transform: translateY(3px);
  }

  ${(props) =>
    props.half &&
    css`
      width: 50%;
    `}

  ${(props) =>
    props.secondary &&
    css`
      background: none;
      border: 1px solid #555;
      color: #555;
    `}

  ${(props) =>
    props.active &&
    css`
      background-color: #eb7567;
      color: #fff;
    `}
`;

export default Button;
