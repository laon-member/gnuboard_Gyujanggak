import { TableRowWrapper } from "components/common";
import comma from "lib/comma";
import React from "react";
import { JackpotType } from "stores/jackpot/types";

interface Props {
  jackpot: JackpotType;
}

function Jackpot({ jackpot }: Props) {
  return (
    <TableRowWrapper>
      <td>{jackpot.id}</td>
      <td>{jackpot.username}</td>
      <td>{comma(jackpot.amount)}</td>
      <td>{jackpot.created_at}</td>
      <td>{jackpot.admin_name}</td>
      <td className="blue">Guarantee</td>
    </TableRowWrapper>
  );
}

export default Jackpot;
