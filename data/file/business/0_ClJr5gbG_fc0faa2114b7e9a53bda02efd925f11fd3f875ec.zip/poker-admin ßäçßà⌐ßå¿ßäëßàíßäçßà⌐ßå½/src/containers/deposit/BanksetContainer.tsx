import React from "react";
import { inject, observer } from "mobx-react";

import DepositStore from "stores/deposit";
import Bankset from "components/deposit/Bankset";
import { RouteComponentProps, withRouter } from "react-router-dom";

interface Props extends RouteComponentProps {
  depositStore?: DepositStore;
}

@inject("depositStore")
@observer
class BanksetContainer extends React.Component<Props> {
  private DepositStore = this.props.depositStore! as DepositStore;

  async componentDidMount() {
    await this.DepositStore.GetRanksetList();
  }

  onCreateBankSet = async (
    addBankName: string,
    addAccountHolder: string,
    addAccountNumber: string
  ) => {
    try {
      await this.DepositStore.PostAccount(
        addBankName,
        addAccountHolder,
        addAccountNumber
      );
      alert("success to saved");
      this.props.history.go(0);
    } catch (error) {
      throw error;
    }
  };

  onSearch = async (name?: string, account?: string) => {
    await this.DepositStore.GetRanksetList(name, account);
  };

  onActiveToggle = async (id: number) => {
    await this.DepositStore.onActiveToggle(id);
  };

  onRemoveDeposit = async (id: number[]) => {
    try {
      await this.DepositStore.RemoveDepositList(id);
      alert("Success to removed");
      this.props.history.go(0);
    } catch (error) {
      alert("something is wrong try again");
    }
  };

  render() {
    return (
      <Bankset
        deposit={this.DepositStore.Deposit!}
        depositList={this.DepositStore.DepositList}
        onCreateBankSet={this.onCreateBankSet}
        onSearch={this.onSearch}
        onActiveToggle={this.onActiveToggle}
        activeDepositList={this.DepositStore.ActiveDepositList}
        onRemoveDeposit={this.onRemoveDeposit}
      />
    );
  }
}

export default withRouter(BanksetContainer);
