import React from "react";
import styled from "styled-components";

const ApplyRdject = () => {
  return (
    <Wrap>
      <div className="title">
        <h2>NO</h2>
      </div>

      <div className="amount">
        <div>
          <div>
            <p>ID</p>
            <p>홍길동</p>
          </div>
          <div>
            <p>Amount</p>
            <p>90,000</p>
          </div>
        </div>

        <textarea placeholder="NO사유를 입력해주세요."></textarea>
      </div>

      <div className="button">
        <button>확인</button>
        <button>취소</button>
      </div>
    </Wrap>
  );
};

const Wrap = styled.div`
  width: 550px;
  height: 400px;

  background: #fff;

  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);

  & > .title {
    width: 100%;
    height: 68px;

    text-align: center;
    line-height: 68px;

    border-bottom: 1px solid #ddd;

    & > h2 {
      font-weight: normal;
      font-size: 18px;
      color: #333;
    }
  }

  & > .amount {
    width: 100%;
    height: 249px;

    text-align: center;

    padding-top: 40px;
    & > div {
      width: 310px;
      margin: 0 auto 20px;
      overflow: hidden;
      & > div {
        width: 155px;
        float: left;
        overflow: hidden;
        & > p {
          float: left;
        }
        & > p:nth-child(1) {
          font-size: 13px;
          color: #333;
          text-align: left;
        }

        & > p:nth-child(2) {
          font-size: 13px;
          color: #333;
          text-align: right;
          margin-left: 20px;
        }
      }
      & > div:nth-child(1) {
        width: 100px;
      }
    }

    & > .charge {
      width: 100%;
      text-align: cneter;

      margin-top: 52px;

      & > span {
        font-size: 14px;
        color: #888;
      }
    }

    & > textarea {
      width: 310px;
      height: 149px;
      resize: none;
      background: #ffffff;
      border: 1px solid #cccccc;

      border-radius: 7px;
      padding: 8px 12px;

      ::placeholder {
        color: #cccccc;
        font-size: 12px;
      }
    }
  }

  & > .button {
    width: 100%;
    height: 82px;

    text-align: center;
    line-height: 70px;

    & > button:nth-child(1) {
      width: 195px;
      height: 40px;
      background: #007fdb;
      border: none;
      color: #fff;
    }
    & > button:nth-child(2) {
      width: 195px;
      height: 40px;
      background: #ddd;
      border: none;
      color: #333;
      margin-left: 20px;
    }
  }
`;

export default ApplyRdject;
