import { AxiosResponse } from "axios";
import AgentList from "components/agent/agentList/AgentList";
import { useInputs } from "lib/hooks";
import { inject, observer } from "mobx-react";
import React, { useEffect, useState } from "react";
import RootStore from "stores";
import {
  CreateBoxType,
  EditBoxType,
  TAgent,
  TAgentCreate,
  TAgentEdit,
  TAgentListPage,
  TAgentListPageForms,
  TAgentListPageSearch,
} from "stores/agent/types";

interface Props {
  getAgentListPage: (paylaod: TAgentListPageSearch) => void;
  agentListPage: TAgentListPage;
  addAgent: (payload: TAgentCreate) => AxiosResponse;
  setAgent: (payload?: TAgent) => void;
  agent?: TAgent;
  editAgent: (payload: TAgentEdit) => AxiosResponse;
}

const AgentListContainer = ({
  getAgentListPage,
  agentListPage,
  addAgent,
  setAgent,
  agent,
  editAgent,
}: Props) => {
  const [toggle, setToggle] = useState({
    create: false,
    edit: false,
  });

  const forms = {
    search: useInputs({
      username: "",
      agent_code: "",
      start_date: "",
      end_date: "",
      page: 1,
    } as TAgentListPageSearch),
    create: useInputs({
      username: "",
      mobile: "",
      password: "",
      passwordCheck: "",
      agent_code: "",
      bank_account: "",
      bank_name: "",
      card_number: "",
      bene_rate: "",
      add_money: "",
    } as TAgentCreate),
    edit: useInputs({
      operation: "",
      add_money: "",
      password: "",
      passwordCheck: "",
    } as TAgentEdit),
  } as TAgentListPageForms;

  useEffect(() => {
    (async () => {
      await getAgentListPage(forms.search.inputs);
    })();
  }, []);

  const onSearch = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    await getAgentListPage(forms.search.inputs);
  };

  const create = {
    toggle: toggle.create,
    onToggle: () => {
      forms.create.init();
      setToggle({ ...toggle, create: !toggle.create });
    },
    onSubmit: async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();

      for (const key in forms.create.inputs) {
        if (Object.prototype.hasOwnProperty.call(forms.create.inputs, key)) {
          const element = forms.create.inputs[key];
          if (element === "") return alert(`${key} is empty`);
        }
      }

      try {
        const res = await addAgent(forms.create.inputs);
        if (res.data.result) {
          forms.create.init();
          forms.search.init();
          await getAgentListPage(forms.search.inputs);
          setToggle({ ...toggle, create: false });
        } else {
          alert("This is a registered agent");
        }
      } catch (error) {
        return alert("There is a problem with the server");
      }
    },
  } as CreateBoxType;

  const edit = {
    toggle: toggle.edit,
    onToggle: (payload: TAgent) => {
      if (toggle.edit) setAgent();
      else {
        setAgent(payload);
        forms.edit.init();
      }

      setToggle({
        ...toggle,
        edit: !toggle.edit,
      });
    },
    onSubmit: async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();

      try {
        const res = await editAgent(forms.edit.inputs);
        console.log(res.data);
        if (res.data.result) {
          forms.edit.init();
          forms.search.init();
          await getAgentListPage(forms.search.inputs);
          setToggle({ ...toggle, edit: false });
        } else {
          alert("Faild to edit agent");
        }
      } catch (error) {
        alert("There is a problem with the server");
      }
    },
  } as EditBoxType;

  return (
    <AgentList
      agentListPage={agentListPage}
      forms={forms}
      onSearch={onSearch}
      create={create}
      edit={edit}
      agent={agent}
    />
  );
};

export default inject(({ agentStore }: RootStore) => ({
  getAgentListPage: agentStore.getAgentListPage,
  agentListPage: agentStore.agentListPage,
  addAgent: agentStore.addAgent,
  setAgent: agentStore.setAgent,
  agent: agentStore.agent,
  editAgent: agentStore.editAgent,
}))(observer(AgentListContainer));
