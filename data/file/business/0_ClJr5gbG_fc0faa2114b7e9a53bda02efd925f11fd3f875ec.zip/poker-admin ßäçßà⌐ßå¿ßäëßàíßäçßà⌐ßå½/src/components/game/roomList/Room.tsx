import { TableRowWrapper } from "components/common";
import React from "react";
import { FaBug } from "react-icons/fa";
import { TRoom, TRoomDelete } from "services/game/types";

interface Props {
  room: TRoom;
  _delete: TRoomDelete;
}

function Room({ room, _delete }: Props) {
  return (
    <TableRowWrapper>
      <td>{room.room_id}</td>
      <td>{room.room_type}</td>
      <td>{room.username}</td>
      <td>{room.name}</td>
      <td className="icon" onClick={() => _delete.onToggle(room)}>
        <FaBug />
      </td>
    </TableRowWrapper>
  );
}

export default Room;
