﻿using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;

public class CStringFormat
{
    private static CStringFormat instance = null;

    private CStringFormat() { }

    public static CStringFormat Instance
    {
        get
        {
            if (instance == null)
            {
                instance = new CStringFormat();
            }
            return instance;
        }
    }

    public string FormatToInt(long num)
    {
        string str = "";

        str = string.Format("{0:#,###}", num);

        if (str.Length >= 13)
        {
            List<char> cha = new List<char>();

            foreach (var s in str)
            {
                cha.Add(s);
            }

            char[] c;

            //if (cha[cha.Count - 1 - 2] != '0')
            //{
            //    c = new char[3];
            //    c[0] = '.';
            //    c[1] = cha[cha.Count - 1 - 2];
            //    c[2] = 'K';
            //}
            //else
            //{
            c = new char[1];
            c[0] = 'K';
            //}

            for (int i = 0; i < 4; i++)
            {
                cha.RemoveAt(cha.Count - 1);
            }
            for (int i = 0; i < c.Length; i++)
            {
                cha.Add(c[i]);
            }

            str = "";

            for (int i = 0; i < cha.Count; i++)
            {
                str += cha[i];
            }
        }

        return str;
    }
}
