-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: poker_game
-- ------------------------------------------------------
-- Server version	10.1.44-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_charge_account`
--

DROP TABLE IF EXISTS `tbl_charge_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_charge_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank` varchar(100) NOT NULL,
  `number` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_charge_account`
--

LOCK TABLES `tbl_charge_account` WRITE;
/*!40000 ALTER TABLE `tbl_charge_account` DISABLE KEYS */;
INSERT INTO `tbl_charge_account` (`id`, `bank`, `number`, `created_at`, `updated_at`) VALUES (1,'정민경','1102020','2020-06-27 15:18:50',NULL),(2,'정민경','1102020','2020-06-27 21:11:38',NULL),(3,'nk','11032323','2020-07-01 11:27:25',NULL),(10,'샤랴랼','1100222','2020-07-01 11:28:30',NULL),(11,'신한','11000200','2020-07-22 06:20:54',NULL);
/*!40000 ALTER TABLE `tbl_charge_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_deposit_history`
--

DROP TABLE IF EXISTS `tbl_deposit_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_deposit_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_deposit_history`
--

LOCK TABLES `tbl_deposit_history` WRITE;
/*!40000 ALTER TABLE `tbl_deposit_history` DISABLE KEYS */;
INSERT INTO `tbl_deposit_history` (`id`, `user_id`, `account_id`, `amount`, `status`, `created_at`, `updated_at`) VALUES (10,1,1,1,1,'2020-06-27 18:02:24',NULL),(11,1,223,2,1,'2020-06-27 18:02:40',NULL),(12,2,33,23,1,'2020-06-27 18:02:47',NULL),(13,3,4,1,1,'2020-06-27 18:02:48',NULL),(14,4,4,23,2,'2020-06-27 18:02:49',NULL),(15,11,4,45,2,'2020-06-27 18:02:51',NULL),(16,12,4,344545,0,'2020-06-27 18:02:51',NULL),(17,13,5,12323,0,'2020-06-27 18:02:52',NULL),(18,14,6,454,0,'2020-06-27 18:02:52',NULL),(19,10,6,35,0,'2020-06-27 18:02:52',NULL),(20,2,7,45,0,'2020-06-27 18:02:52',NULL),(21,2,8,4,0,'2020-06-27 18:02:53',NULL),(22,2,9,54,0,'2020-06-27 18:02:53',NULL),(23,2,9,5,0,'2020-06-27 18:58:01',NULL),(24,2,10,45,0,'2020-06-27 18:58:18',NULL),(25,2,11,4,0,'2020-06-27 18:58:20',NULL),(26,3,23,7,0,'2020-06-27 20:36:41',NULL),(27,3,34,86655,0,'2020-06-27 20:36:42',NULL),(28,3,56,9,0,'2020-06-27 20:36:42',NULL),(29,3,9,12323,0,'2020-06-27 20:36:43',NULL),(30,3,1,12323,0,'2020-06-27 21:01:28',NULL),(31,3,1,12323,0,'2020-06-27 21:01:29',NULL),(32,3,1,12323,0,'2020-06-27 21:01:30',NULL),(33,3,1,12323,0,'2020-06-27 21:01:30',NULL),(34,3,2,12323,0,'2020-06-27 21:09:42',NULL),(35,3,2,12323,0,'2020-06-27 21:09:42',NULL),(36,3,2,12323,0,'2020-06-27 21:09:42',NULL),(37,3,2,12323,0,'2020-06-27 21:09:43',NULL),(38,3,2,12323,0,'2020-06-27 21:09:43',NULL),(39,3,2,12323,0,'2020-06-27 21:09:43',NULL),(40,3,2,12323,0,'2020-06-27 21:09:43',NULL),(41,3,2,12323,0,'2020-06-27 21:09:43',NULL),(42,3,2,12323,0,'2020-06-27 21:09:44',NULL),(43,3,2,12323,0,'2020-06-27 21:09:44',NULL),(44,2,12332,12323,1,'2020-06-27 21:11:11',NULL),(45,10,2,12323,2,'2020-06-27 21:22:54',NULL),(46,10,2,12323,1,'2020-06-27 21:27:11',NULL),(47,10,2,12323,1,'2020-06-27 21:27:12',NULL),(48,10,2,12323,1,'2020-06-27 21:27:12',NULL),(49,10,2,12323,1,'2020-06-27 21:27:12',NULL),(50,10,2,12323,1,'2020-06-27 21:27:13',NULL),(51,10,2,12323,1,'2020-06-27 21:27:13',NULL),(52,10,2,12323,1,'2020-06-27 21:27:13',NULL),(53,10,2,12323,1,'2020-06-27 21:27:13',NULL),(54,2,2,12323,1,'2020-06-28 01:24:32',NULL),(55,3,3,12323,1,'2020-06-28 02:01:50',NULL),(56,3,3,12323,1,'2020-06-28 02:01:50',NULL),(57,3,3,12323,1,'2020-06-28 02:01:51',NULL),(58,3,3,12323,1,'2020-06-28 02:01:51',NULL),(59,3,3,12323,1,'2020-06-28 02:01:52',NULL),(60,10,10,12323,1,'2020-06-28 02:02:02',NULL),(61,10,10,12323,1,'2020-06-28 02:02:05',NULL),(62,15,10,12323,1,'2020-06-28 02:16:00',NULL),(63,2,10,12323,1,'2020-07-01 16:19:00',NULL),(64,10,10,12323,1,'2020-07-02 11:31:43',NULL),(65,2,10,12323,1,'2020-07-14 16:15:22',NULL),(66,60,3,3400000,1,'2020-07-16 14:34:56',NULL),(67,60,3,3400000,0,'2020-07-16 14:34:58',NULL),(68,60,3,3400000,0,'2020-07-16 14:35:05',NULL),(69,60,10,1633000,0,'2020-07-16 14:37:26',NULL),(70,60,3,541326321,2,'2020-07-16 14:38:18',NULL),(71,60,1,2000,2,'2020-07-16 15:33:26',NULL),(72,1,1,2000,2,'2020-07-16 15:33:36',NULL),(73,60,3,60000,0,'2020-07-24 15:28:01',NULL),(74,60,0,60000,0,'2020-07-24 15:35:55',NULL),(75,78,11,166000,0,'2020-07-24 16:16:15',NULL),(76,78,0,300000,0,'2020-07-24 18:06:30',NULL),(77,89,0,66000,0,'2020-07-24 18:28:44',NULL),(78,79,0,33,0,'2020-07-27 15:05:38',NULL),(79,79,10,33,0,'2020-07-27 15:08:05',NULL),(80,79,0,333,0,'2020-07-27 15:09:04',NULL),(81,79,2,333,0,'2020-07-27 15:09:21',NULL),(82,79,1,663,0,'2020-07-27 15:10:41',NULL),(83,79,1,6666666,0,'2020-07-27 15:10:48',NULL),(84,84,0,26000,0,'2020-07-27 15:40:47',NULL);
/*!40000 ALTER TABLE `tbl_deposit_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_jackpot`
--

DROP TABLE IF EXISTS `tbl_jackpot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_jackpot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` int(11) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_jackpot`
--

LOCK TABLES `tbl_jackpot` WRITE;
/*!40000 ALTER TABLE `tbl_jackpot` DISABLE KEYS */;
INSERT INTO `tbl_jackpot` (`id`, `amount`, `created_at`, `updated_at`) VALUES (1,115454,'2020-07-02 15:29:09','2020-07-28 15:05:10');
/*!40000 ALTER TABLE `tbl_jackpot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_jackpot_log`
--

DROP TABLE IF EXISTS `tbl_jackpot_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_jackpot_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` int(11) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_jackpot_log`
--

LOCK TABLES `tbl_jackpot_log` WRITE;
/*!40000 ALTER TABLE `tbl_jackpot_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_jackpot_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_jackpot_user_wait`
--

DROP TABLE IF EXISTS `tbl_jackpot_user_wait`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_jackpot_user_wait` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `tbl_jackpot_user_wait_tbl_user_id_fk` (`user_id`),
  CONSTRAINT `tbl_jackpot_user_wait_tbl_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_jackpot_user_wait`
--

LOCK TABLES `tbl_jackpot_user_wait` WRITE;
/*!40000 ALTER TABLE `tbl_jackpot_user_wait` DISABLE KEYS */;
INSERT INTO `tbl_jackpot_user_wait` (`id`, `user_id`, `amount`, `status`, `created_at`, `updated_at`) VALUES (2,10,30000,1,'2020-07-06 20:19:26','2020-07-19 02:34:19'),(3,10,100000,1,'2020-07-06 18:19:26','2020-07-19 02:34:19'),(4,2,30000,0,'2020-07-06 22:19:26',NULL),(5,10,44440000,1,'2020-07-06 17:19:26','2020-07-19 02:34:19'),(6,10,80000,1,'2020-07-06 19:19:26','2020-07-19 02:34:19'),(7,2,30000,0,'2020-07-06 22:19:26',NULL),(8,60,80000,1,'2020-07-06 22:19:26','2020-07-24 13:52:09'),(9,2,100000,0,'2020-07-06 22:19:26',NULL),(10,2,200000,0,'2020-07-06 22:19:26',NULL),(11,2,30000,0,'2020-07-06 22:19:26',NULL),(12,2,80000,0,'2020-07-06 22:19:26',NULL),(13,2,100000,0,'2020-07-06 22:19:26',NULL),(14,2,30000,0,'2020-07-06 22:19:26',NULL),(15,2,80000,0,'2020-07-06 22:19:26',NULL),(16,2,200000,0,'2020-07-06 22:19:26',NULL),(17,2,300000,0,'2020-07-06 22:19:26',NULL),(18,2,30000,0,'2020-07-07 10:40:34',NULL),(19,1,50000,0,'2020-07-07 10:40:34',NULL),(20,2,30000,0,'2020-07-07 10:40:35',NULL),(21,1,50000,0,'2020-07-07 10:40:35',NULL),(22,2,300000,0,'2020-07-07 10:40:35',NULL),(23,2,30000,0,'2020-07-07 10:40:35',NULL),(24,1,50000,0,'2020-07-07 10:40:35',NULL),(25,2,200000,0,'2020-07-07 10:40:35',NULL),(26,2,80000,0,'2020-07-07 10:40:50',NULL),(27,2,200000,0,'2020-07-07 10:40:50',NULL),(28,2,100000,0,'2020-07-07 11:04:44',NULL),(29,2,200000,0,'2020-07-07 11:04:44',NULL),(30,89,300000,1,'2020-07-07 11:04:44','2020-07-24 18:33:56'),(31,2,30000,0,'2020-07-07 11:04:44',NULL),(32,1,50000,0,'2020-07-07 11:04:44',NULL),(33,2,100000,0,'2020-07-07 11:04:44',NULL),(34,2,30000,0,'2020-07-07 11:04:44',NULL),(35,1,50000,0,'2020-07-07 11:04:44',NULL),(36,2,80000,0,'2020-07-07 11:04:44',NULL),(37,2,100000,0,'2020-07-07 11:04:44',NULL),(38,2,200000,0,'2020-07-07 11:04:44',NULL),(39,2,30000,0,'2020-07-07 11:04:45',NULL),(40,2,300000,0,'2020-07-07 11:04:45',NULL),(41,2,30000,0,'2020-07-07 11:04:45',NULL),(42,1,50000,0,'2020-07-07 11:04:45',NULL),(43,2,300000,0,'2020-07-07 11:04:45',NULL),(44,2,30000,0,'2020-07-07 11:05:08',NULL),(45,1,50000,0,'2020-07-07 11:05:08',NULL),(46,2,200000,0,'2020-07-07 11:05:08',NULL),(47,2,300000,0,'2020-07-07 11:05:08',NULL),(48,78,30000,1,'2020-07-07 11:05:09','2020-07-24 16:23:16'),(49,2,80000,0,'2020-07-07 11:05:09',NULL),(50,2,200000,0,'2020-07-07 11:05:09',NULL),(51,2,300000,0,'2020-07-07 11:05:09',NULL),(52,1,50000,0,'2020-07-07 11:05:09',NULL),(53,2,80000,0,'2020-07-07 11:05:09',NULL),(54,2,100000,0,'2020-07-07 11:05:09',NULL),(55,2,30000,0,'2020-07-07 11:05:09',NULL),(56,2,100000,0,'2020-07-07 11:05:09',NULL),(57,2,200000,0,'2020-07-07 11:05:09',NULL),(58,2,300000,0,'2020-07-07 11:05:09',NULL),(59,2,80000,0,'2020-07-07 11:05:09',NULL),(60,2,300000,0,'2020-07-07 11:05:09',NULL),(61,2,30000,0,'2020-07-07 11:05:09',NULL),(62,2,300000,0,'2020-07-07 11:05:09',NULL),(63,2,80000,0,'2020-07-07 11:05:10',NULL),(64,2,300000,0,'2020-07-07 11:05:10',NULL),(65,1,50000,0,'2020-07-07 11:05:10',NULL),(66,2,100000,0,'2020-07-07 11:05:10',NULL),(67,2,200000,0,'2020-07-07 11:05:10',NULL),(68,2,300000,0,'2020-07-07 11:05:10',NULL),(69,2,100000,0,'2020-07-07 11:05:10',NULL),(70,2,300000,0,'2020-07-07 11:05:10',NULL),(71,2,30000,0,'2020-07-08 09:35:00',NULL),(72,2,80000,0,'2020-07-08 09:35:00',NULL),(73,2,100000,0,'2020-07-08 09:35:00',NULL),(74,2,200000,0,'2020-07-08 09:35:00',NULL),(75,2,100000,0,'2020-07-08 09:35:01',NULL),(76,60,200000,1,'2020-07-08 09:35:01','2020-07-24 04:56:22'),(77,2,300000,0,'2020-07-08 09:35:01',NULL),(78,1,50000,0,'2020-07-08 09:50:05',NULL),(79,2,100000,0,'2020-07-08 09:50:05',NULL),(80,2,300000,0,'2020-07-08 09:50:05',NULL),(81,2,30000,0,'2020-07-08 09:51:45',NULL),(82,2,200000,0,'2020-07-08 09:51:45',NULL),(83,2,80000,0,'2020-07-08 09:51:46',NULL),(84,2,200000,0,'2020-07-08 09:51:46',NULL),(85,2,30000,0,'2020-07-08 09:51:46',NULL),(86,1,50000,0,'2020-07-08 09:51:46',NULL),(87,2,80000,0,'2020-07-08 09:51:46',NULL),(88,2,100000,0,'2020-07-08 09:51:46',NULL),(89,2,200000,0,'2020-07-08 09:51:46',NULL),(90,2,30000,0,'2020-07-08 09:51:46',NULL),(91,2,200000,0,'2020-07-08 09:51:46',NULL),(92,2,300000,0,'2020-07-08 09:51:46',NULL),(93,2,30000,0,'2020-07-08 09:54:03',NULL),(94,2,80000,0,'2020-07-08 09:54:03',NULL),(95,2,300000,0,'2020-07-08 09:54:03',NULL),(96,2,30000,0,'2020-07-08 10:04:50',NULL),(97,2,80000,0,'2020-07-08 10:04:50',NULL),(98,2,30000,0,'2020-07-08 10:04:50',NULL),(99,1,50000,0,'2020-07-08 10:04:50',NULL),(100,2,80000,0,'2020-07-08 10:04:50',NULL),(101,2,100000,0,'2020-07-08 10:04:50',NULL);
/*!40000 ALTER TABLE `tbl_jackpot_user_wait` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_mail`
--

DROP TABLE IF EXISTS `tbl_mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `type` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `tbl_mail_tbl_user_id_fk` (`admin_id`),
  CONSTRAINT `tbl_mail_tbl_user_id_fk` FOREIGN KEY (`admin_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_mail`
--

LOCK TABLES `tbl_mail` WRITE;
/*!40000 ALTER TABLE `tbl_mail` DISABLE KEYS */;
INSERT INTO `tbl_mail` (`id`, `admin_id`, `title`, `content`, `type`, `created_at`, `updated_at`) VALUES (1,1,'공지','안녕하세요 즐겁게 게임하세요',0,'2020-06-29 12:00:45','2020-07-24 05:06:50'),(2,2,'메일','안녕하세요',0,'2020-06-29 12:09:45',NULL),(3,2,'메일','안녕하세요',0,'2020-06-29 17:36:52',NULL),(4,2,'메일','안녕하세요',0,'2020-06-29 17:36:55',NULL),(5,2,'메일','안녕하세요',0,'2020-06-29 17:36:55',NULL),(6,2,'메일','안녕하세요',0,'2020-06-29 17:36:55',NULL),(7,2,'메일','안녕하세요',0,'2020-07-16 19:55:33',NULL),(8,2,'메일','안녕하세요',0,'2020-07-16 19:55:33',NULL),(9,1,'메일','안녕하세요',0,'2020-07-16 19:55:33',NULL),(10,1,'메일','안녕하세요',0,'2020-07-16 19:55:33','2020-07-23 18:00:59'),(11,2,'메일 제목 : 공지','ㅇㄹ맨랴머댄ㅇ랴ㅓㅐㅑㅁㄴ어래ㅑㅁ더ㅐㅓㅐㄴㅇ러',0,'2020-07-23 14:23:37','2020-07-23 18:00:59');
/*!40000 ALTER TABLE `tbl_mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_mail_history`
--

DROP TABLE IF EXISTS `tbl_mail_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mail_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `mail_id` int(11) NOT NULL,
  `is_read` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_mail_history_tbl_user_id_fk` (`user_id`),
  KEY `tbl_mail_history_tbl_mail_id_fk` (`mail_id`),
  CONSTRAINT `tbl_mail_history_tbl_mail_id_fk` FOREIGN KEY (`mail_id`) REFERENCES `tbl_mail` (`id`),
  CONSTRAINT `tbl_mail_history_tbl_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_mail_history`
--

LOCK TABLES `tbl_mail_history` WRITE;
/*!40000 ALTER TABLE `tbl_mail_history` DISABLE KEYS */;
INSERT INTO `tbl_mail_history` (`id`, `user_id`, `mail_id`, `is_read`, `created_at`, `updated_at`) VALUES (32,60,1,1,'2020-07-18 12:00:57',NULL),(33,60,2,1,'2020-07-18 12:00:57',NULL),(34,60,3,0,'2020-07-18 12:00:57',NULL),(35,60,4,0,'2020-07-18 12:00:57',NULL),(36,60,5,0,'2020-07-18 12:00:57',NULL),(37,60,6,0,'2020-07-18 12:00:57',NULL),(39,60,8,0,'2020-07-18 12:00:57',NULL),(40,1,9,0,'2020-07-18 12:00:57',NULL),(41,10,10,0,'2020-07-18 12:00:57',NULL),(42,10,1,0,'2020-07-23 13:58:08','2020-07-23 13:58:09');
/*!40000 ALTER TABLE `tbl_mail_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_notice`
--

DROP TABLE IF EXISTS `tbl_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `type` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_notice`
--

LOCK TABLES `tbl_notice` WRITE;
/*!40000 ALTER TABLE `tbl_notice` DISABLE KEYS */;
INSERT INTO `tbl_notice` (`id`, `title`, `content`, `type`, `created_at`, `updated_at`) VALUES (1,'NOTICE','I can hear you but I won\'t\r\nSome look for trouble while others don\'t\r\nThere\'s a thousand reasons I should go about my day\r\nAnd ignore your whispers which I wish would go away, oh\r\nWhoa\r\nYou\'re not a voice, you\'re just a ringing in my ear\r\nAnd if I heard you, which I don\'t, I\'m spoken for I fear\r\nEveryone I\'ve ever loved is here within these walls\r\nI\'m sorry, secret siren, but I\'m blocking out your calls\r\nI\'ve had my adventure, I don\'t need something new\r\nI\'m afraid of what I\'m risking if I follow you\r\nInto the unknown\r\nInto the unknown\r\nInto the unknown\r\n(Oh)\r\n(Oh)\r\nWhat do you want? \'Cause you\'ve been keeping me awake\r\nAre you here to distract me so I make a big mistake?\r\nOr are you someone out there who\'s a little bit like me?\r\nWho knows deep down I\'m not where I\'m meant to be?\r\nEvery day\'s a little harder as I feel my power grow\r\nDon\'t you know there\'s part of me that longs to go\r\nInto the unknown\r\nInto the unknown\r\nInto the unknown\r\n(Oh)\r\n(Oh)\r\nWhoa\r\nAre you out there?\r\nDo you know me?\r\nCan you feel me?\r\nCan you show me?\r\noh\r\n(Ah) oh\r\n(Ah) oh\r\n(Ah) oh\r\n(Ah) oh\r\n(Ah) oh\r\nWhere are you going? Don\'t leave me alone\r\nHow do I follow you\r\nInto the unknown?',0,'2020-07-16 18:57:08','2020-07-24 14:53:09'),(2,'롤링','I can hear you but I won\'t Some look for trouble while others don\'t There\'s a thousand reasons I should go about my day And ignore your whispers which I wish would go away, oh Whoa You\'re not a voice, you\'re just a ringing in my ear And if I heard you, which I don\'t, I\'m spoken for I fear Everyone I\'ve ever loved is here within these walls I\'m sorry, secret siren, but I\'m blocking out your calls I\'ve had my adventure, I don\'t need something new I\'m afraid of what I\'m risking if I follow you Into the unknown Into the unknown Into the unknown (Oh) (Oh) What do you want? \'Cause you\'ve been keeping me awakeAre you here to distract me so I make a big mistake? Or are you someone out there who\'s a little bit like me? Who knows deep down I\'m not where I\'m meant to be? Every day\'s a little harder as I feel my power grow Don\'t you know there\'s part of me that longs to go Into the unknown Into the unknown Into the unknown (Oh) (Oh) Whoa Are you out there? Do you know me? Can you feel me? Can you show me?',1,'2020-07-16 18:57:08','2020-07-24 18:19:26'),(3,'잿팟','잿팟당첨자입니다',2,'2020-07-16 18:57:08',NULL);
/*!40000 ALTER TABLE `tbl_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `amount` int(10) unsigned NOT NULL DEFAULT '0',
  `profile_img` varchar(255) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `gender` tinyint(1) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_user_phone_uindex` (`phone`),
  UNIQUE KEY `tbl_user_username_uindex` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_user`
--

LOCK TABLES `tbl_user` WRITE;
/*!40000 ALTER TABLE `tbl_user` DISABLE KEYS */;
INSERT INTO `tbl_user` (`id`, `username`, `password`, `amount`, `profile_img`, `name`, `phone`, `gender`, `status`, `created_at`, `updated_at`) VALUES (1,'정민경','4444',100,'P_0_0','mk','010222222',0,1,'2020-06-26 22:29:51','2020-07-22 14:22:06'),(2,'test1','$2b$10$Yr.Nc8akQJWjuGf7qQi7kuwExp4bEP1C/9mhwh2oFNoF1Difvm1N6',0,'P_0_0','aa','01012341234',0,0,'2020-06-26 22:46:32','2020-07-24 05:33:20'),(10,'test2','$2b$10$Uz.iURes9mV.TumhVwf1s.G0yEC2SCJR3/6pjsSH58vfIxXIrhGki',0,'P_0_0','bb','010341234',0,0,'2020-06-27 09:12:51','2020-07-24 05:33:20'),(11,'test3','$2b$10$fhUGY/Ed/cgC0TjxPROm/.LqhzNkYAmzO86nnQt7IlCui1xsZLUYW',0,'P_0_0','cc','0103414',0,0,'2020-06-27 09:14:18','2020-07-24 05:33:20'),(12,'test4','$2b$10$rAXqe8m5Un1qAlNY4hcMgeGTlYgY3INwOA0Q4Ry0EB7D/iToJcreu',0,'P_0_0','dd','010323',0,0,'2020-06-27 09:14:35','2020-07-24 05:33:20'),(13,'test5','$2b$10$KaJzqKAgq0vpo3pFwQbe4uE0LlzJ./yPeTGLVsm7ahCbIOH0jmeFa',0,'P_0_0','ee','010d3',0,0,'2020-06-27 09:28:57','2020-07-24 05:33:20'),(14,'test6','$2b$10$ZzcqkcmqhLRYzddKcxRp1OLyyD4HLpaizRI3tfT/XvemrvyrMYbge',0,'P_0_0','ff','010221',0,0,'2020-06-27 09:30:23','2020-07-24 05:33:20'),(15,'test7','$2b$10$BN77zaZncWGqxY2n4lUUOuJ85qUIrKLodaJ5upalOHVm65ku8cIq6',0,'P_0_0','gg','010w1',0,0,'2020-06-27 09:31:45','2020-07-24 05:33:20'),(16,'test9','$2b$10$ueBxM4fSwrlLUGIZSACadOyS8SRV5WtOQdYQseIQJ6.vGMwpOroVu',0,'P_0_0','hh','01011111',0,0,'2020-06-27 09:32:47','2020-07-24 05:33:20'),(17,'test10','$2b$10$d7J4UVpajsBCAziWHr59XeYfRshopjqQBwGFu4U3RnNjjrQbXwui2',0,'P_0_0','ii','01044411',0,0,'2020-06-27 09:36:47','2020-07-24 05:33:20'),(18,'test11','$2b$10$lOAJNx7zmKT/S8pnio.Y8e0JFhUB5dAHBQgyAVk2n2RiKYuUeVPxO',0,'P_0_0','jj','01044553',0,0,'2020-06-27 09:54:57','2020-07-24 05:33:20'),(19,'test12','$2b$10$ZAqfOknhnLjUp0W3.V19/ODkENoxFKyKA6ke5bSotXU6NMdkmz43.',0,'P_0_0','kk','01044533',0,0,'2020-06-27 09:55:34','2020-07-24 05:33:20'),(20,'test13','$2b$10$.PSf2aZfP6V62dolgGIogOPUzWG10RuRQdm0B/HKvtgKhILqTMB1q',0,'P_0_0','ll','010445ttt',0,0,'2020-06-27 09:55:51','2020-07-24 05:33:20'),(21,'test14','$2b$10$OebuIGOJzuMwhMSR0Ej6UuzU7aQbJDGbj/y4OgfWcxgTSeZvRTAHq',0,'P_0_0','mm','01042222',0,0,'2020-06-27 09:56:20','2020-07-24 05:33:20'),(22,'test15','$2b$10$M7ec1qkacJr/O9B9RfOb.O3DjrOlbpsnmyQprUgzu16QIwHqgtXTe',0,'P_0_0','nn','01055',0,0,'2020-06-27 10:54:14','2020-07-24 05:33:20'),(23,'test16','$2b$10$4MOSMPB.ZBCtIe8cW9fUQuxRvdfhvFhh/FBUk8/SFCPZcr6Xap6jO',0,'P_0_0','oo','010551111',0,0,'2020-06-27 10:56:11','2020-07-24 05:33:20'),(24,'test17','$2b$10$2KY71mn0SSI3.p67oUxHgurExuREucgS/1a8hp5H8GYfvJXmQ.Wnu',0,'P_0_0','pp','010511111',0,0,'2020-06-27 10:57:05','2020-07-24 05:33:20'),(25,'test18','$2b$10$PMf6RtojLe8Ybgux0NfVsuJO/zblFXDIZfIQ8vG/H/RL44y79PxO.',0,'P_0_0','qq','01051444',0,0,'2020-06-27 10:58:47','2020-07-24 05:33:20'),(26,'test19','$2b$10$.y2hawwesyJhsHddFE6nJuyPdsKdNSccFq0GdDlj6kibu.oxJ8cyS',0,'P_0_0','rr','010514ㅉㅈㄸ',0,0,'2020-06-27 10:59:02','2020-07-24 05:33:20'),(27,'test20','4444',0,'P_0_0','ss','01010',0,0,'2020-06-27 11:07:31','2020-07-24 05:33:20'),(28,'test21','$2b$10$B0I5zYSHJhOfVzT21bupnOEmbXExvaZjTNxmgLMO/ZpcdmjMFS2yS',0,'P_0_0','tt','01014444',0,0,'2020-06-27 11:09:48','2020-07-24 05:33:20'),(29,'test22','$2b$10$ScnrbPI/d/IFIASn0B2F3OcixuqHp1dBWsdGX4ji/dNF4w3gdF4ZG',0,'P_0_0','uu','0105555',0,0,'2020-06-27 11:32:35','2020-07-24 05:33:20'),(30,'test23','$2b$10$ak/B5EYMU2I/Wo/12JdX.eal.ori/Q9aWL9AWPc32b3rNJsRi/wGO',0,'P_0_0','vv','010666',0,0,'2020-06-27 11:34:40','2020-07-24 05:33:20'),(43,'te','4444',0,'P_0_0','ww','010141',0,0,'2020-07-03 11:08:56','2020-07-24 05:33:20'),(45,'te11','$2b$10$6AGaKUhlvocvXiMQwTOtkunP2aAD/1DfXukDz9/oX08zBShzS8okm',0,'P_0_0','xx','0102226',0,0,'2020-07-03 11:09:30','2020-07-24 05:33:20'),(46,'min0701','',0,'P_0_0','yy','0105542',0,0,'2020-07-03 11:33:10','2020-07-24 05:33:20'),(47,'gggg','$2b$10$kxZ8Wy.3boN2nVGkLHCV3Ojy1NmQeeuVdAKa12OT7B0iyvzLvKvMm',0,'p_0_4','zz','0107700',0,0,'2020-07-13 11:23:47','2020-07-24 05:33:20'),(57,'min071','$2b$10$YnmzwDNTKdr5nxTqzSmOPemgY/ydYFFd26za8OhmDeyIn541HTpTS',0,'P_0_0','ab','01055423',0,0,'2020-07-13 12:05:18','2020-07-24 05:33:20'),(58,'g3g3g3','$2b$10$elaP2eCGMUDo3TP8BjSaBOgTPTRg1j1p01zOvqsz2evnNQ6NVPNmK',0,'p_0_0','ac','01077',0,0,'2020-07-13 22:15:16','2020-07-24 05:33:20'),(59,'gggg22','$2b$10$kA8dh0RjyOhRSQEtJfIBCuNxRY6y0yKRMIwQuseIs0BB7waRVHdDq',1053050,'p_0_3','ad','01011',0,0,'2020-07-23 14:04:00','2020-07-24 13:52:20'),(60,'gg333','$2b$10$r0LwCQxEwj9BMrZ0CbDgNegl.gJMo1tp5nfkWEUeJKutrRVtiUtDW',0,'p_0_9','ae','11111111',0,0,'2020-07-23 14:07:09','2020-07-24 17:37:25'),(61,'alalalalalal','$2b$10$W68H7FGT.XgaLVXLhoUX8er3nNfX7yFcNgISV1vw/vnqB/4bV8sCK',0,'p_0_4','af','22222222',0,0,'2020-07-23 14:35:29','2020-07-24 05:33:26'),(77,'qwerty','$2b$10$lyNtuGLvzWAySeIKs/SjZ.jgFvKTJTkBPMX5H/VOnBNMW8AmCWpOK',0,'p_1_11','이이이기기','555555555',1,0,'2020-07-23 16:40:57','2020-07-24 05:33:29'),(78,'laontest1','$2b$10$loXNv/2SrX5gV/kyJ.bg1erMjcB2OadI/NAPPvMK6M4QzDfJq4cqq',0,'p_1_11','라온','01099',1,0,'2020-07-24 16:15:48','2020-07-24 17:39:28'),(79,'laontest2','$2b$10$drH.8tT2vBsqPFhY03lMZ..hEUTagVSv.P3dMA4NuedD8EhqQISyS',558962,'p_0_2','라온2','01088',0,0,'2020-07-24 16:41:23','2020-07-28 15:05:38'),(80,'laontest3','$2b$10$A/7wl2R6V0Q5qbAklRzFeOJbeU1kBu0WS86iXyTv0ymQ4HYSwG.B.',980000,'p_0_6','라온3','01098',0,0,'2020-07-24 16:42:17','2020-07-28 15:05:20'),(81,'laontest4','$2b$10$2kcpljo715AwgF0MTLI2T..yaOwy37jCNusOD2F72upqQTI9Mwj0e',998045,'p_0_0','라온4','010889',0,0,'2020-07-24 16:42:53','2020-07-24 16:44:00'),(82,'asdasjdaskdjawkd','$2b$10$J4Y.xxikHQgiUCEG2A7xAOddnUS.rDVRfwiiM/FyqoKgIT5qrp2Fy',0,'P_0_0','이이이이','0107712',0,0,'2020-07-24 16:59:04',NULL),(83,'sajdwajdawjd','$2b$10$ZWqzAPqhqkx3aMQ/V6V57ubCF8/2m1C3Mx2Jw9VRB7u3VPNjlJha6',0,'P_0_0','이이이이','01077112',0,0,'2020-07-24 17:42:07',NULL),(84,'kiea1','$2b$10$TZJozvLe6ESB1N4gmDJEwOmSIcVzi4UK9lvJQKqcATDMK5hpoXgOm',1000000,'p_0_0','1','kiea1',0,0,'2020-07-24 18:19:36','2020-07-24 18:25:48'),(85,'kiea2','$2b$10$xMG8c2DiFpSo2HoAzuz2KO583btUGuYbdQ5PRok3iZnrtkYKA0Vie',1000000,'p_0_0','1','kiea2',0,0,'2020-07-24 18:21:24','2020-07-24 18:25:50'),(86,'kiea3','$2b$10$InVEQyMhl69lm4ty3dnm5..nEQ2Gjk9lmeVll5AkSho.q/QNYugvu',1000000,'p_0_0','1','kiea3',0,0,'2020-07-24 18:22:45','2020-07-24 18:25:54'),(87,'kiea4','$2b$10$H9TE7l3.RmawN5UIttM3M.Fq1O.CLA4Ccjrs.XL.oCcRw7XfYRo0G',1000000,'p_0_0','1','kiea4',0,0,'2020-07-24 18:24:24','2020-07-24 18:26:00'),(88,'kiea5','$2b$10$E.FDq6VGdwmwpq702QU7xuZp5bUkRZh2WITMT2uCwiDm63DsmIxoe',964000,'p_0_0','1','kiea5',0,0,'2020-07-24 18:25:02','2020-07-28 12:40:55'),(89,'test0705','$2b$10$0CXEEb0c/rBwfhIL4WdTheik3HFFQFwx4ak/Pfp6H3id2Rj4vQ6T6',734000,'p_0_0','test','00011111111',0,0,'2020-07-24 18:27:02','2020-07-24 18:35:35'),(90,'11','$2b$10$YgRE8xuBU8pbBiQeg9fcheCbsWjqA7tjSLPOSPPbi5i0zf75Y4d1u',0,'p_0_0','d','d',0,0,'2020-07-24 19:29:37',NULL);
/*!40000 ALTER TABLE `tbl_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_user_account`
--

DROP TABLE IF EXISTS `tbl_user_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_user_account` (
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `bank` varchar(100) NOT NULL,
  KEY `tbl_user_account_tbl_user_id_fk` (`user_id`),
  CONSTRAINT `tbl_user_account_tbl_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_user_account`
--

LOCK TABLES `tbl_user_account` WRITE;
/*!40000 ALTER TABLE `tbl_user_account` DISABLE KEYS */;
INSERT INTO `tbl_user_account` (`user_id`, `name`, `number`, `created_at`, `updated_at`, `bank`) VALUES (1,'샤샤샬13111','01111221111','2020-06-27 09:24:35',NULL,'나라사랑111'),(27,'민두이','0111122','2020-06-27 11:07:31',NULL,'나라사랑'),(30,'정민구','01111','2020-06-27 11:34:40',NULL,'기업'),(43,'힘드11','0111122','2020-07-03 11:08:56',NULL,'나라헷'),(45,'화잍팅','01111','2020-07-03 11:09:30',NULL,'기업'),(46,'힘들오','01111','2020-07-03 11:33:10',NULL,'기업111'),(47,'정민구','01111','2020-07-13 11:23:47',NULL,'기업'),(57,'정민구','01111','2020-07-13 12:05:18',NULL,'기업'),(58,'이기','01111','2020-07-13 22:15:16',NULL,'기업'),(1,'샤샤샬13111','01111221111','2020-07-17 23:50:13',NULL,'나라사랑111'),(12,'RKRK','110','2020-07-19 17:04:19',NULL,'민경은행'),(13,'데헷','220','2020-07-19 17:05:22',NULL,'ㅁ민경은행2'),(14,'ㅎ힘들다','331','2020-07-19 17:05:22',NULL,'정은행3'),(1,'샤샤샬13111','01111221111','2020-07-21 17:29:41',NULL,'나라사랑111'),(59,'이이','110110111','2020-07-23 14:04:00',NULL,'기기'),(60,'이기','11011111jdhdhdhdhhdudhdhdhhdhfhfhhffhdhdhgdhshhsh$7374664747757474+_?(_)_)&','2020-07-23 14:07:09',NULL,'기업'),(61,'이이이이이이','1212121212','2020-07-23 14:35:29',NULL,'기ㅏ기기기기기'),(77,'이이이기기','010010045','2020-07-23 16:40:57',NULL,'종종종종종'),(78,'라온','110010110','2020-07-24 16:15:48',NULL,'기업'),(79,'라온2','110110110','2020-07-24 16:41:23',NULL,'기업'),(80,'라온3','11055222','2020-07-24 16:42:17',NULL,'기업'),(81,'라온4','1548856','2020-07-24 16:42:53',NULL,'기업'),(82,'정민경','11020202','2020-07-24 16:59:04',NULL,'신한'),(83,'정민경','11020202','2020-07-24 17:42:07',NULL,'신한'),(84,'1','1','2020-07-24 18:19:36',NULL,'1'),(85,'1','1','2020-07-24 18:21:24',NULL,'1'),(86,'1','1','2020-07-24 18:22:45',NULL,'1'),(87,'1','1','2020-07-24 18:24:24',NULL,'1'),(88,'1','1','2020-07-24 18:25:02',NULL,'1'),(89,'test','0000','2020-07-24 18:27:02',NULL,'test'),(90,'d','d','2020-07-24 19:29:37',NULL,'s');
/*!40000 ALTER TABLE `tbl_user_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_user_friend`
--

DROP TABLE IF EXISTS `tbl_user_friend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_user_friend` (
  `user_id` int(11) NOT NULL,
  `friend_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`friend_id`),
  KEY `tbl_user_friend_tbl_user_id_fk` (`user_id`),
  KEY `tbl_user_friend_tbl_user_id_fk_2` (`friend_id`),
  CONSTRAINT `tbl_user_friend_tbl_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id`),
  CONSTRAINT `tbl_user_friend_tbl_user_id_fk_2` FOREIGN KEY (`friend_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_user_friend`
--

LOCK TABLES `tbl_user_friend` WRITE;
/*!40000 ALTER TABLE `tbl_user_friend` DISABLE KEYS */;
INSERT INTO `tbl_user_friend` (`user_id`, `friend_id`, `created_at`, `updated_at`) VALUES (1,2,'2020-07-01 16:41:07','2020-07-23 17:12:54'),(2,11,'2020-07-01 16:40:23',NULL),(2,17,'2020-07-01 21:21:51',NULL),(58,18,'2020-07-16 10:49:37',NULL),(60,1,'2020-07-24 01:04:05',NULL),(60,10,'2020-07-24 16:10:23',NULL),(60,15,'2020-07-24 16:10:23',NULL),(60,17,'2020-07-24 01:04:09',NULL),(60,30,'2020-07-24 05:09:43',NULL),(60,61,'2020-07-24 04:47:56',NULL),(60,77,'2020-07-24 01:04:04',NULL),(78,60,'2020-07-24 16:19:10',NULL),(79,43,'2020-07-27 16:13:03',NULL),(84,11,'2020-07-27 15:35:23',NULL),(84,25,'2020-07-27 15:35:20',NULL),(84,80,'2020-07-27 15:35:17',NULL);
/*!40000 ALTER TABLE `tbl_user_friend` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_user_game_history`
--

DROP TABLE IF EXISTS `tbl_user_game_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_user_game_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `tbl_user_game_history_tbl_user_id_fk` (`user_id`),
  CONSTRAINT `tbl_user_game_history_tbl_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_user_game_history`
--

LOCK TABLES `tbl_user_game_history` WRITE;
/*!40000 ALTER TABLE `tbl_user_game_history` DISABLE KEYS */;
INSERT INTO `tbl_user_game_history` (`id`, `user_id`, `level`, `price`, `created_at`, `updated_at`) VALUES (34,2,1,30,'2020-07-03 16:06:06','2020-07-06 20:58:50'),(37,1,2,20,'2020-07-03 16:28:26','2020-07-06 20:58:50'),(42,2,3,-40,'2020-07-03 17:14:00','2020-07-06 21:57:05'),(44,2,4,10,'2020-07-03 17:14:03','2020-07-06 20:58:50'),(47,2,5,25,'2020-07-03 17:14:06','2020-07-08 09:48:43'),(50,2,6,25,'2020-07-03 17:14:12','2020-07-06 21:54:34'),(57,10,6,-400000,'2020-07-19 02:42:05',NULL),(58,10,6,-400000,'2020-07-19 03:03:51',NULL),(59,10,6,-400000,'2020-07-19 03:03:52',NULL),(60,10,6,-400000,'2020-07-19 03:06:11',NULL),(61,10,6,-400000,'2020-07-19 03:06:12',NULL),(62,10,6,-400000,'2020-07-19 03:13:52',NULL),(63,10,6,-400000,'2020-07-19 03:13:53',NULL),(64,10,6,-400000,'2020-07-19 03:14:17',NULL),(65,10,6,-400000,'2020-07-19 03:14:17',NULL),(66,10,6,-400000,'2020-07-19 03:14:18',NULL),(67,10,6,-400000,'2020-07-19 03:14:18',NULL),(68,10,6,-400000,'2020-07-19 03:16:11',NULL),(69,60,1,-150000,'2020-07-23 16:47:55',NULL),(70,59,1,135000,'2020-07-23 16:47:55',NULL),(71,60,6,-100,'2020-07-23 16:49:27',NULL),(72,60,6,-100,'2020-07-23 16:49:46',NULL),(73,60,1,45000,'2020-07-23 17:14:13',NULL),(74,59,1,-50000,'2020-07-23 17:14:13',NULL),(75,60,1,-10000,'2020-07-23 17:14:45',NULL),(76,59,1,9000,'2020-07-23 17:14:45',NULL),(77,60,1,9000,'2020-07-23 17:15:20',NULL),(78,59,1,-10000,'2020-07-23 17:15:20',NULL),(79,60,1,-30000,'2020-07-23 17:15:51',NULL),(80,59,1,27000,'2020-07-23 17:15:51',NULL),(81,60,1,-30000,'2020-07-23 17:18:34',NULL),(82,59,1,27000,'2020-07-23 17:18:34',NULL),(83,60,1,-30000,'2020-07-23 17:18:56',NULL),(84,59,1,27000,'2020-07-23 17:18:56',NULL),(85,60,1,-30000,'2020-07-23 17:19:43',NULL),(86,60,1,-30000,'2020-07-23 17:19:56',NULL),(87,60,1,-30000,'2020-07-23 17:19:56',NULL),(88,60,1,-100,'2020-07-23 17:25:27',NULL),(89,60,6,-100,'2020-07-23 17:25:45',NULL),(90,60,6,-100,'2020-07-23 17:25:52',NULL),(91,60,4,-100,'2020-07-23 17:26:10',NULL),(92,60,4,-100,'2020-07-23 17:58:58',NULL),(93,60,1,45000,'2020-07-23 20:51:33',NULL),(94,59,1,-50000,'2020-07-23 20:51:33',NULL),(95,60,1,-50000,'2020-07-23 20:51:57',NULL),(96,59,1,45000,'2020-07-23 20:51:57',NULL),(97,60,1,-150000,'2020-07-23 20:52:21',NULL),(98,59,1,135000,'2020-07-23 20:52:21',NULL),(99,60,1,-150000,'2020-07-23 20:52:50',NULL),(100,59,1,135000,'2020-07-23 20:52:50',NULL),(101,60,4,-3000,'2020-07-23 20:53:28',NULL),(102,60,1,-50000,'2020-07-23 20:56:05',NULL),(103,59,1,45000,'2020-07-23 20:56:05',NULL),(104,60,1,-110000,'2020-07-23 20:56:36',NULL),(105,59,1,99000,'2020-07-23 20:56:36',NULL),(106,60,1,-147500,'2020-07-23 20:57:00',NULL),(107,59,1,132750,'2020-07-23 20:57:00',NULL),(108,60,1,-30000,'2020-07-23 20:59:23',NULL),(109,59,1,27000,'2020-07-23 20:59:23',NULL),(110,60,1,18000,'2020-07-23 21:50:50',NULL),(111,59,1,-20000,'2020-07-23 21:50:50',NULL),(112,60,1,43200,'2020-07-23 21:51:22',NULL),(113,59,1,-48000,'2020-07-23 21:51:22',NULL),(114,60,1,-10000,'2020-07-23 21:51:57',NULL),(115,59,1,9000,'2020-07-23 21:51:57',NULL),(116,60,1,9000,'2020-07-23 21:52:32',NULL),(117,59,1,-10000,'2020-07-23 21:52:32',NULL),(118,59,1,-30000,'2020-07-23 21:53:10',NULL),(119,60,1,27000,'2020-07-23 21:53:10',NULL),(120,59,1,-58650,'2020-07-23 21:53:38',NULL),(121,60,1,51300,'2020-07-23 21:53:38',NULL),(122,60,1,-147500,'2020-07-23 21:55:44',NULL),(123,59,1,132750,'2020-07-23 21:55:45',NULL),(124,60,1,7500,'2020-07-23 22:11:48',NULL),(125,59,1,-10000,'2020-07-23 22:11:48',NULL),(126,60,1,-70000,'2020-07-23 22:17:06',NULL),(127,59,1,63000,'2020-07-23 22:17:06',NULL),(128,60,1,-40000,'2020-07-23 22:17:38',NULL),(129,59,1,36000,'2020-07-23 22:17:38',NULL),(130,60,1,36000,'2020-07-23 22:18:26',NULL),(131,59,1,-40000,'2020-07-23 22:18:26',NULL),(132,60,1,-70000,'2020-07-24 00:51:01',NULL),(133,59,1,63000,'2020-07-24 00:51:01',NULL),(134,60,1,-70000,'2020-07-24 00:52:21',NULL),(135,59,1,63000,'2020-07-24 00:52:21',NULL),(136,60,1,-30000,'2020-07-24 00:57:09',NULL),(137,59,1,27000,'2020-07-24 00:57:09',NULL),(138,60,1,9000,'2020-07-24 00:57:47',NULL),(139,59,1,-10000,'2020-07-24 00:57:47',NULL),(140,60,4,-3000,'2020-07-24 01:13:26',NULL),(141,60,4,-3000,'2020-07-24 01:19:47',NULL),(142,60,1,7500,'2020-07-24 01:33:09',NULL),(143,59,1,-10000,'2020-07-24 01:33:09',NULL),(144,60,1,121950,'2020-07-24 01:33:40',NULL),(145,59,1,-135500,'2020-07-24 01:33:40',NULL),(146,60,1,231705,'2020-07-24 01:34:10',NULL),(147,59,1,-308110,'2020-07-24 01:34:10',NULL),(148,60,1,-65000,'2020-07-24 01:34:36',NULL),(149,59,1,58500,'2020-07-24 01:34:36',NULL),(150,60,1,-10000,'2020-07-24 13:42:47',NULL),(151,59,1,9000,'2020-07-24 13:42:47',NULL),(152,60,1,-10000,'2020-07-24 13:44:28',NULL),(153,59,1,9000,'2020-07-24 13:44:28',NULL),(154,60,1,-10000,'2020-07-24 13:45:12',NULL),(155,59,1,8000,'2020-07-24 13:45:12',NULL),(156,60,1,-10000,'2020-07-24 13:48:35',NULL),(157,59,1,9000,'2020-07-24 13:48:35',NULL),(158,60,1,-10000,'2020-07-24 13:49:40',NULL),(159,59,1,9000,'2020-07-24 13:49:40',NULL),(160,60,1,-10000,'2020-07-24 13:50:04',NULL),(161,59,1,9000,'2020-07-24 13:50:04',NULL),(162,60,1,-10000,'2020-07-24 13:52:09',NULL),(163,59,1,9000,'2020-07-24 13:52:09',NULL),(164,60,1,45000,'2020-07-24 16:22:39',NULL),(165,78,1,-50000,'2020-07-24 16:22:39',NULL),(166,60,1,126000,'2020-07-24 16:23:16',NULL),(167,78,1,-140000,'2020-07-24 16:23:16',NULL),(168,60,1,27000,'2020-07-24 16:23:46',NULL),(169,78,1,-30000,'2020-07-24 16:23:46',NULL),(170,60,1,-90000,'2020-07-24 16:24:16',NULL),(171,78,1,81000,'2020-07-24 16:24:16',NULL),(172,78,1,-50000,'2020-07-24 16:31:31',NULL),(173,60,1,45000,'2020-07-24 16:31:31',NULL),(174,78,1,27000,'2020-07-24 16:31:58',NULL),(175,60,1,-30000,'2020-07-24 16:31:58',NULL),(176,78,1,7500,'2020-07-24 16:32:24',NULL),(177,60,1,-10000,'2020-07-24 16:32:24',NULL),(178,78,1,-291371,'2020-07-24 16:32:56',NULL),(179,60,1,244040,'2020-07-24 16:32:56',NULL),(180,78,1,27000,'2020-07-24 16:33:22',NULL),(181,60,1,-30000,'2020-07-24 16:33:22',NULL),(182,89,1,-10000,'2020-07-24 18:30:44',NULL),(183,79,1,9000,'2020-07-24 18:30:44',NULL),(184,89,1,9000,'2020-07-24 18:31:15',NULL),(185,79,1,-10000,'2020-07-24 18:31:15',NULL),(186,79,1,36000,'2020-07-24 18:31:50',NULL),(187,89,1,-40000,'2020-07-24 18:31:50',NULL),(188,79,1,8000,'2020-07-24 18:32:20',NULL),(189,89,1,-10000,'2020-07-24 18:32:20',NULL),(190,79,1,63000,'2020-07-24 18:32:56',NULL),(191,89,1,-70000,'2020-07-24 18:32:57',NULL),(192,79,1,-10000,'2020-07-24 18:33:25',NULL),(193,89,1,9000,'2020-07-24 18:33:25',NULL),(194,79,1,9000,'2020-07-24 18:33:56',NULL),(195,89,1,-10000,'2020-07-24 18:33:56',NULL),(196,79,1,-30000,'2020-07-24 18:34:30',NULL),(197,89,1,27000,'2020-07-24 18:34:30',NULL),(198,79,1,411559,'2020-07-24 18:35:24',NULL),(199,89,1,-460000,'2020-07-24 18:35:24',NULL),(200,79,3,90000,'2020-07-28 13:46:16',NULL),(201,80,3,-100000,'2020-07-28 13:46:16',NULL),(202,79,3,-50000,'2020-07-28 13:46:50',NULL),(203,80,3,45000,'2020-07-28 13:46:50',NULL),(204,79,3,-100000,'2020-07-28 14:58:15',NULL),(205,80,3,90000,'2020-07-28 14:58:15',NULL),(206,79,3,-50000,'2020-07-28 15:04:34',NULL),(207,80,3,45000,'2020-07-28 15:04:34',NULL),(208,79,3,45000,'2020-07-28 15:05:09',NULL),(209,80,3,-50000,'2020-07-28 15:05:09',NULL);
/*!40000 ALTER TABLE `tbl_user_game_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_withdraw_history`
--

DROP TABLE IF EXISTS `tbl_withdraw_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_withdraw_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_withdraw_history`
--

LOCK TABLES `tbl_withdraw_history` WRITE;
/*!40000 ALTER TABLE `tbl_withdraw_history` DISABLE KEYS */;
INSERT INTO `tbl_withdraw_history` (`id`, `user_id`, `account_id`, `amount`, `status`, `created_at`, `updated_at`) VALUES (1,1,2,1100,2,'2020-06-28 03:23:17',NULL),(2,2,4,110,1,'2020-06-28 03:41:31',NULL),(3,2,4,110,0,'2020-06-28 03:41:33',NULL),(4,2,4,110,0,'2020-06-28 03:41:34',NULL),(5,2,4,110,0,'2020-06-28 03:41:55',NULL),(6,2,4,110,0,'2020-06-28 03:41:56',NULL),(7,3,4,110,0,'2020-06-28 03:42:02',NULL),(8,4,4,110,0,'2020-06-28 03:42:07',NULL),(9,4,4,110,0,'2020-06-28 03:42:45',NULL),(10,5,10,110,1,'2020-07-01 11:28:55',NULL),(11,2,2,110,0,'2020-07-01 16:22:01',NULL),(12,2,2,110,0,'2020-07-01 16:23:10',NULL),(13,2,2,110,0,'2020-07-01 16:23:14',NULL),(14,2,2,110,0,'2020-07-01 16:23:34',NULL),(15,2,2,110,0,'2020-07-01 16:23:35',NULL),(16,2,2,110,0,'2020-07-01 16:24:59',NULL),(17,10,2,110,0,'2020-07-02 11:31:46',NULL),(18,47,2,110,1,'2020-07-13 19:11:33',NULL),(19,2,2,110,1,'2020-07-14 16:15:26',NULL),(20,10,1,200000,0,'2020-07-16 14:47:20',NULL),(21,10,2,110,0,'2020-07-16 16:57:14',NULL),(22,10,2,110,0,'2020-07-16 16:57:14',NULL),(23,10,2,110,0,'2020-07-16 16:59:08',NULL),(24,10,2,110,0,'2020-07-16 17:01:18',NULL),(25,10,2,110,0,'2020-07-16 17:01:19',NULL),(26,10,2,110,0,'2020-07-16 17:03:25',NULL),(27,10,2,110,0,'2020-07-16 17:06:36',NULL),(28,10,2,110,0,'2020-07-16 17:08:23',NULL),(29,10,2,110,0,'2020-07-16 17:08:24',NULL),(30,10,2,110,0,'2020-07-16 17:08:24',NULL),(31,10,2,110,0,'2020-07-16 17:08:34',NULL),(32,10,2,110,0,'2020-07-16 17:09:15',NULL),(33,10,2,110,0,'2020-07-16 17:11:28',NULL),(34,10,2,110,0,'2020-07-16 17:17:06',NULL),(35,10,2,110,0,'2020-07-16 17:18:23',NULL),(36,10,2,110,0,'2020-07-16 17:19:04',NULL),(37,10,2,110,0,'2020-07-16 17:19:18',NULL),(38,10,2,110,0,'2020-07-16 17:19:34',NULL),(39,10,2,110,0,'2020-07-16 17:19:57',NULL),(40,10,2,110,0,'2020-07-16 17:21:11',NULL),(41,10,2,110,0,'2020-07-16 17:22:03',NULL),(42,10,2,110,0,'2020-07-16 17:22:11',NULL),(43,10,2,110,0,'2020-07-16 17:22:31',NULL),(44,10,2,110,0,'2020-07-16 17:23:12',NULL),(45,10,2,110,0,'2020-07-16 17:24:51',NULL),(46,10,2,110,0,'2020-07-16 17:26:58',NULL),(47,10,2,110,1,'2020-07-16 17:32:53',NULL),(48,10,2,110,0,'2020-07-16 17:33:24',NULL),(49,10,2,110,0,'2020-07-16 17:33:44',NULL),(50,10,2,110,0,'2020-07-16 17:34:12',NULL),(51,60,2,110,1,'2020-07-16 17:34:13',NULL),(52,60,2,110,0,'2020-07-16 17:34:13',NULL),(53,60,2,110,0,'2020-07-16 17:34:13',NULL),(54,60,2,110,0,'2020-07-16 17:34:13',NULL),(55,60,2,110,0,'2020-07-16 17:34:34',NULL),(56,60,2,110,0,'2020-07-16 17:34:53',NULL),(57,60,1,170000,0,'2020-07-24 15:28:23',NULL),(58,60,1,200000,0,'2020-07-24 15:28:44',NULL),(59,60,1,150000,0,'2020-07-24 15:31:36',NULL),(60,60,1,150000,0,'2020-07-24 15:33:13',NULL),(61,60,1,100000,0,'2020-07-24 15:34:05',NULL),(62,60,1,20000,0,'2020-07-24 15:35:14',NULL),(63,60,1,1000,0,'2020-07-24 15:35:44',NULL),(64,60,1,15000,0,'2020-07-24 15:35:49',NULL),(65,78,1,200000,0,'2020-07-24 16:24:31',NULL),(66,78,1,0,0,'2020-07-24 17:24:54',NULL),(67,60,1,485195,0,'2020-07-24 17:37:25',NULL),(68,60,1,0,0,'2020-07-24 17:37:38',NULL),(69,60,1,0,0,'2020-07-24 17:37:41',NULL),(70,60,1,0,0,'2020-07-24 17:37:43',NULL),(71,78,1,411129,0,'2020-07-24 17:39:28',NULL),(72,78,1,0,0,'2020-07-24 17:53:59',NULL),(73,78,1,0,0,'2020-07-24 17:54:08',NULL),(74,78,1,0,0,'2020-07-24 17:54:09',NULL),(75,78,1,0,0,'2020-07-24 17:55:09',NULL),(76,78,1,0,0,'2020-07-24 17:55:16',NULL),(77,89,1,1000,0,'2020-07-24 18:28:52',NULL),(78,79,1,66444,0,'2020-07-27 15:11:50',NULL),(79,88,1,36000,0,'2020-07-28 12:40:55',NULL);
/*!40000 ALTER TABLE `tbl_withdraw_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-28 16:34:28
