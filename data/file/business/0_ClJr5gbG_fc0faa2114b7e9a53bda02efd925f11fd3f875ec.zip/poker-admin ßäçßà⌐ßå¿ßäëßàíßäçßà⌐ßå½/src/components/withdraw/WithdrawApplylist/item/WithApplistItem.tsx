import React from "react";
import { WithdrawTypeBackup } from "stores/withdraw/types";
import TableRowWrapper from "components/common/TableRowWrapper";
import comma from "lib/comma";
import { OptionWrapper } from "components/admin/account/edit/EditRow";
import { Button } from "styles/atom";
interface Props {
  data: WithdrawTypeBackup;
  updateComplete: (id: number) => void;
  updateReject: (id: number) => void;
  onActiveToggle: (id: number) => void;
}

function WithApplistItem({ data, updateComplete, updateReject }: Props) {
  const complete = (id: number) => {
    alert("Accepted to request.");
    updateComplete(id);
  };
  const cancel = (id: number) => {
    alert("Declined to request.");
    updateReject(id);
  };
  return (
    <TableRowWrapper>
      <td>{data.id}</td>
      <td>{data.username}</td>
      <td>{data.phone}</td>
      <td>{data.bank}</td>
      <td>{data.name}</td>
      <td>{data.number}</td>
      <td>{comma(data.amount)}</td>
      <td>{data.created_at.toString().slice(0, 16).replace("T", " ")}</td>
      <td>
        <OptionWrapper>
          <Button onClick={() => complete(data.id)}>OK</Button>
          <Button secondary onClick={() => cancel(data.id)}>
            NO
          </Button>
        </OptionWrapper>
      </td>
    </TableRowWrapper>
  );
}

export default WithApplistItem;
