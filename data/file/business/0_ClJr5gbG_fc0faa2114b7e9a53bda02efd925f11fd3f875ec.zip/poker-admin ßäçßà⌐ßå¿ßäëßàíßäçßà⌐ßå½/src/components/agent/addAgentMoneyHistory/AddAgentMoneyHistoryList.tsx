import NoDataBox from "components/common/NoDataBox";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import React from "react";
import { FaSearch } from "react-icons/fa";
import {
  TAgentMoneyHistoryForms,
  TAgentMoneyHistoryPage,
  TAgentMoneyHistorySearch,
} from "stores/agent/types";
import { Button, Input } from "styles/atom";
import AddAgentMoneyHistory from "./AddAgentMoneyHistory";

interface Props {
  agentMoneyHistoryPage: TAgentMoneyHistoryPage;
  forms: TAgentMoneyHistoryForms;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
}

function AddAgentMoneyHistoryList({
  agentMoneyHistoryPage,
  forms,
  onSearch,
}: Props) {
  const { search } = forms;
  const { onChange } = forms.search;
  const {
    username,
    agent_code,
    start_date,
    end_date,
  } = search.inputs as TAgentMoneyHistorySearch;
  return (
    <>
      <SearchWrapper>
        <SearchForm onSubmit={onSearch}>
          <Input
            placeholder="Agent Account"
            name="username"
            value={username}
            onChange={onChange}
          />
          <Input
            placeholder="Agent Code"
            name="agent_code"
            value={agent_code}
            onChange={onChange}
          />
          <Input
            type="date"
            name="start_date"
            value={start_date}
            onChange={onChange}
          />
          <Input
            type="date"
            name="end_date"
            value={end_date}
            onChange={onChange}
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>AdminAccount</th>
            <th>AgentAccount</th>
            <th>AgentCode</th>
            <th>AddMoney</th>
            <th>Time</th>
          </tr>
        </thead>
        <tbody>
          {agentMoneyHistoryPage.paging.total_page
            ? agentMoneyHistoryPage.list.map((log, idx) => (
                <AddAgentMoneyHistory
                  key={idx}
                  log={log}
                  idx={
                    idx +
                    1 +
                    (agentMoneyHistoryPage.paging.current_page - 1) * 30
                  }
                />
              ))
            : null}
        </tbody>
      </Table>
      {agentMoneyHistoryPage.paging.total_page ? (
        <PageNationContainer
          paging={agentMoneyHistoryPage.paging}
          searchForm={forms.search}
          onSearch={onSearch}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
}

export default AddAgentMoneyHistoryList;
