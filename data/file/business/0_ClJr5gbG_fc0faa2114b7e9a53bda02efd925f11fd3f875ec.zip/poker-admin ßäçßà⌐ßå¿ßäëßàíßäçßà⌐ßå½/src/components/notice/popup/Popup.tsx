import React, { useEffect } from "react";
import { TPopUp, UseInput } from "stores/notice/types";
import { Button, Input } from "styles/atom";
import { TextArea } from "styles/atom/TextArea";
import styled from "styles/theme-components";

interface Props {
  onSend: (e: React.FormEvent<HTMLFormElement>) => void;
  sendForm: UseInput;
  popUp: TPopUp;
}

function Popup({
  onSend,
  sendForm: { inputs, onChange, setInputs },
  popUp,
}: Props) {
  useEffect(() => {
    setInputs({
      ...popUp,
    });
  }, [popUp]);
  return (
    <FormWrapper onSubmit={onSend}>
      <div className="inputWrapper">
        <label>Title</label>
        <Input
          placeholder="Title"
          name="title"
          value={inputs.title}
          onChange={onChange}
        />
      </div>
      <div className="inputWrapper">
        <label>Content</label>
        <TextArea
          placeholder="Content"
          name="content"
          value={inputs.content}
          onChange={onChange}
        />
      </div>
      <RightAligned>
        <Button type="submit" active>
          SAVE
        </Button>
      </RightAligned>
    </FormWrapper>
  );
}

export const FormWrapper = styled.form`
  min-width: 1080px;
  width: 50%;
  margin: 0 auto;
  padding: 1rem 0;

  button {
    display: inline-block;
  }

  .types {
    display: flex;
    align-items: center;

    button {
      margin-left: 1rem;
    }
  }

  span {
    margin-top: 0.5rem;
    margin-right: 1rem;
  }

  .inputWrapper {
    display: flex;
    margin-bottom: 1rem;

    label {
      flex: 2;
      padding: 1rem;
      text-align: right;
    }
    & > *:not(label) {
      flex: 8;
    }
    textarea {
      height: 400px;
    }
  }
`;

export const RightAligned = styled.div`
  display: flex;
  justify-content: flex-end;

  button + button {
    margin-left: 1rem;
  }
`;

export default Popup;
