import React from "react";
import styled from "styled-components";
import { PolicyTypeBackUp } from "stores/jackpot/types";
import comma from "lib/comma";
interface Props {
  data: PolicyTypeBackUp;
}

function PocliyItem({ data }: Props) {
  return (
    <Wrap>
      <td>Lv.{data.level && data.level.value}</td>
      <td>{data.consume && comma(parseInt(data.consume.value, 10))}</td>
      <td>{data.guarantee && comma(parseInt(data.guarantee.value, 10))}</td>
    </Wrap>
  );
}

const Wrap = styled.tr`
  width: 100%;
  height: 50px;
`;

export default PocliyItem;
