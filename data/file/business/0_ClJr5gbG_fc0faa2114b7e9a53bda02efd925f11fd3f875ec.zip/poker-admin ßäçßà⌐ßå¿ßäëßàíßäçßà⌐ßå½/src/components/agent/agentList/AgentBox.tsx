import { InputWrapper } from "components/deposit/Bankset/Bankset";
import { Invalid } from "components/login/Login";
import { DialogContainer } from "containers/common/dialog";
import React, { useState } from "react";
import { CreateBoxType, TAgentCreate } from "stores/agent/types";
import { UseInput } from "stores/notice/types";
import { Input } from "styles/atom";

interface Props {
  create: CreateBoxType;
  createForm: UseInput;
}

function AgentBox({ create, createForm }: Props) {
  const {
    username,
    mobile,
    password,
    passwordCheck,
    agent_code,
    bank_account,
    bank_name,
    card_number,
    bene_rate,
    add_money,
  } = createForm!.inputs as TAgentCreate;
  const { onChange } = createForm!;
  const [passwordConfirm, setPasswordConfirm] = useState(false);

  const passwordCheckHandler = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPasswordConfirm(password !== e.target.value);
    createForm!.setInputs({
      ...createForm!.inputs,
      passwordCheck: e.target.value,
    });
  };
  return (
    <DialogContainer
      title="Agent Box"
      confirmText="SAVE"
      onToggle={create!.onToggle}
      onSubmit={create!.onSubmit}
    >
      <InputWrapper>
        <label>ID</label>
        <Input
          placeholder="ID"
          name="username"
          value={username}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Password</label>
        <Input
          type="password"
          placeholder="Password"
          name="password"
          value={password}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>PasswordCheck</label>
        <Input
          type="password"
          placeholder="passwordCheck"
          value={passwordCheck}
          onChange={(e) => passwordCheckHandler(e)}
        />
      </InputWrapper>
      {passwordConfirm && (
        <InputWrapper>
          <label></label>
          <Invalid>The password is different.</Invalid>
        </InputWrapper>
      )}
      <InputWrapper>
        <label>Mobile</label>
        <Input
          placeholder="Mobile"
          name="mobile"
          value={mobile}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>AgentCode</label>
        <Input
          placeholder="AgentCode"
          name="agent_code"
          value={agent_code}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>BankAccount</label>
        <Input
          placeholder="BankAccount"
          name="bank_account"
          value={bank_account}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>BankName</label>
        <Input
          placeholder="BankName"
          name="bank_name"
          value={bank_name}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>CardNumber</label>
        <Input
          placeholder="CardNumber"
          name="card_number"
          value={card_number}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>BeneRate</label>
        <Input
          type="number"
          placeholder="BeneRate"
          name="bene_rate"
          value={bene_rate}
          onChange={onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label>AddMoney</label>
        <Input
          type="number"
          placeholder="AddMoney"
          name="add_money"
          value={add_money}
          onChange={onChange}
        />
      </InputWrapper>
    </DialogContainer>
  );
}

export default AgentBox;
