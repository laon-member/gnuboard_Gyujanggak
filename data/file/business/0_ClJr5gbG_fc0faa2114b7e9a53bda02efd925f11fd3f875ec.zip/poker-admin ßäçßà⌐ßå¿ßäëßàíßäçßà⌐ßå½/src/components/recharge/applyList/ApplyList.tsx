import NoDataBox from "components/common/NoDataBox";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import { Invalid } from "components/login/Login";
import CancleNoteBoxContainer from "containers/common/dialog/CancleNoteBoxContainer";
import WarningBoxContainer from "containers/common/dialog/WarningBoxContainer";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import React from "react";
import { FaSearch } from "react-icons/fa";
import {
  TRechargeApplyPage,
  TRechargeForms,
  TSearchRechargeApply,
  WarningBoxType,
} from "stores/recharge/types";
import { Button, Input } from "styles/atom";
import Apply from "./Apply";
import { CancleType } from "./types";

interface Props {
  ok: WarningBoxType;
  reserve: WarningBoxType;
  cancle: CancleType;
  rechargeApplyPage: TRechargeApplyPage;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
  forms: TRechargeForms;
}

function ApplyList({
  ok,
  reserve,
  cancle,
  rechargeApplyPage,
  onSearch,
  forms,
}: Props) {
  const { search } = forms;
  const { onChange } = search;
  const { username, phone } = search.inputs as TSearchRechargeApply;
  return (
    <>
      {ok.toggle && (
        <WarningBoxContainer
          content="Sure to  pass the recharge record?"
          type={ok}
        />
      )}
      {reserve.toggle && (
        <WarningBoxContainer
          content="Sure to reserve the recharge record?"
          type={reserve}
        />
      )}
      {cancle.toggle && (
        <CancleNoteBoxContainer type={cancle} form={forms.cancle} />
      )}
      <SearchWrapper>
        <SearchForm onSubmit={onSearch}>
          <Input
            type="text"
            placeholder="ID"
            name="username"
            value={username}
            onChange={onChange}
          />
          <Input
            placeholder="Modile"
            name="phone"
            value={phone}
            onChange={onChange}
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>ID</th>
            <th>Agent</th>
            <th>Mobile</th>
            <th>BankAccount</th>
            <th>BankName</th>
            <th>CardNumber</th>
            <th>ApplyTime</th>
            <th>AcceptBank</th>
            <th>AcceptCardNumber</th>
            <th>Amount</th>
            <th>Opt</th>
          </tr>
        </thead>
        <tbody>
          {rechargeApplyPage.paging.total_page
            ? rechargeApplyPage.content.map((apply) => (
                <Apply
                  key={apply.id}
                  apply={apply}
                  ok={ok}
                  reserve={reserve}
                  cancle={cancle}
                />
              ))
            : null}
        </tbody>
      </Table>
      {rechargeApplyPage.paging.total_page ? (
        <PageNationContainer
          paging={rechargeApplyPage.paging}
          onSearch={onSearch}
          searchForm={forms.search}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
}

export default ApplyList;
