import React from "react";
import { NoticeType } from "stores/notice/types";
import TableRowWrapper from "components/common/TableRowWrapper";
interface Props {
  data: NoticeType;
  onActiveToggle: (id: number) => void;
}

function PorsonmsgItem({ data, onActiveToggle }: Props) {
  return (
    <TableRowWrapper
      onClick={() => onActiveToggle(data.id)}
      active={data.active}
    >
      <td>{data.id}</td>
      <td>{data.userName}</td>
      <td>{data.name}</td>
      <td>{data.content}</td>
      <td>{data.is_read}</td>
      <td>{data.created_at.toString().slice(0, 16).replace("T", " ")}</td>
    </TableRowWrapper>
  );
}

export default PorsonmsgItem;
