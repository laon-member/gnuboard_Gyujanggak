import React from "react";
import styled from "styles/theme-components";

function NoDataBox() {
  return <Wrapper>NO DATA</Wrapper>;
}

const Wrapper = styled.div`
  width: 500px;
  height: 350px;
  color: #666666;
  font-size: 3rem;
  border-radius: 10px;
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 0 auto;
`;

export default NoDataBox;
