import NoDataBox from "components/common/NoDataBox";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import React from "react";
import { FaSearch } from "react-icons/fa";
import {
  TGameLogForms,
  TGameLogPage,
  TGameLogSearch,
} from "stores/member/types";
import { Button, Input } from "styles/atom";
import GameLog from "./GameLog";

interface Props {
  gameLogPage: TGameLogPage;
  forms: TGameLogForms;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
}

const GameLogList = ({ gameLogPage, forms, onSearch }: Props) => {
  const { search } = forms;
  const { onChange } = search;
  const {
    username,
    nickname,
    round,
    start_date,
    end_date,
  } = search.inputs as TGameLogSearch;

  return (
    <>
      <SearchWrapper>
        <SearchForm onSubmit={onSearch}>
          <Input
            placeholder="ID"
            name="username"
            value={username}
            onChange={onChange}
          />
          <Input
            placeholder="NickName"
            name="nickname"
            value={nickname}
            onChange={onChange}
          />
          <Input
            placeholder="Round"
            name="round"
            value={round}
            onChange={onChange}
          />
          <Input
            type="date"
            name="start_date"
            value={start_date}
            onChange={onChange}
          />
          <Input
            type="date"
            name="end_date"
            value={end_date}
            onChange={onChange}
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>ID</th>
            <th>NickName</th>
            <th>RoomType</th>
            <th>BetAmount</th>
            <th>Mode</th>
            <th>MyCard (1, 2, 3)</th>
            <th>GameTime</th>
            <th>BaseAmount</th>
            <th>ResultAmount</th>
            <th>Round</th>
          </tr>
        </thead>
        <tbody>
          {gameLogPage.paging.total_page
            ? gameLogPage.logs.map((gameLog) => (
                <GameLog key={gameLog.id} gameLog={gameLog} />
              ))
            : null}
        </tbody>
      </Table>
      {gameLogPage.paging.total_page ? (
        <PageNationContainer
          searchForm={forms.search}
          onSearch={onSearch}
          paging={gameLogPage.paging}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
};

export default GameLogList;
