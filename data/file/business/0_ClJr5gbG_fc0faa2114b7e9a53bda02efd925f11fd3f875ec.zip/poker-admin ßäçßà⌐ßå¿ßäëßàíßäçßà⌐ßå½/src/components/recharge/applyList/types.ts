import { TWithdrawFormType } from "services/withdraw/types";

export type CancleType = {
  toggle: boolean;
  onToggle: (payload?: any) => void;
  onSubmit: (e: React.FormEvent<HTMLFormElement>) => void;
  form?: TWithdrawFormType;
};
