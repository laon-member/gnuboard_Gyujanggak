import client from "lib/client";
import {
  AddRollingType,
  PopUpFormType,
  RollingSearchType,
} from "stores/notice/types";

class NoticeService {
  public addPopUp() {
    return client.post(`/api/admin/notice/createpopup`);
  }
  public GetPopupListAPI(title?: string, date?: string) {
    return client.get(`/api/admin/notice/popupinfo`, {
      params: {
        title,
        date,
      },
    });
  }
  public PostNewPopupAPI(adminName: string, title: string, content: string) {
    return client.post(`/api/admin/notice/createpopup`, {
      admin_name: adminName,
      title,
      content,
    });
  }

  public RemovePopupList(list: number[]) {
    return client.delete(`/api/admin/notice/popup/${list.join(",")}`);
  }

  public GetRollingListAPI(
    content?: string,
    startDate?: string,
    endDate?: string
  ) {
    return client.get(`/api/admin/notice/rollinginfo`, {
      params: {
        content,
        start_date: startDate,
        end_date: endDate,
      },
    });
  }

  public PostNewRollingAPI(adminName: string, content: string) {
    return client.post(`/api/admin/notice/createrolling`, {
      content,
    });
  }
  public GetPeronmsgListAPI(nickname?: string, date?: string) {
    return client.get(`/api/admin/notice/selectmessage`, {
      params: {
        nickname,
        date,
      },
    });
  }

  public RemovePersonList(list: number[]) {
    return client.delete(`/api/admin/notice/message/${list.join(",")}`);
  }

  public PostPersonMessage(title: string, content: string, list: number[]) {
    return client.post("/api/admin/notice/message", {
      title,
      content,
      idx: list,
    });
  }

  public SearchUserAtPersonMessage(type: string, value: string) {
    return client.get(
      `/api/admin/notice/message/users?type=${type}&value=${value}`
    );
  }

  // 추가기능
  public createPopUp = async (payload: PopUpFormType) => {
    return client.post(`/api/admin/notice/createpopup`, {
      title: payload.title,
      content: payload.content,
    });
  };

  public getRollingList = async (payload: RollingSearchType) => {
    return client.get(
      `/api/admin/notice/rollinginfo?content=${payload.content}&start_date=${payload.start_date
      }&end_date=${payload.end_date}&position=${payload.position}&page=${payload.page - 1
      }`
    );
  };

  public addRolling = async (payload: AddRollingType) => {
    return client.post(`/api/admin/notice/createrolling`, {
      title: "",
      content: payload.content,
      start_date: payload.start_date,
      end_date: payload.end_date,
      duration: parseInt(payload.duration, 10),
      position: payload.position,
    });
  };

  public RemoveRollingList(list: number[]) {
    return client.delete(`/api/admin/notice/rolling/${list.join(",")}`);
  }

  public getPopUp() {
    return client.get(`/api/admin/notice/popupinfo?title&date`);
  }
}

export default new NoticeService();
