import WithdrawList from "components/distributor/member/withdraw/WithdrawList";
import React from "react";

function WithdrawListContainer() {
  return <WithdrawList />;
}

export default WithdrawListContainer;
