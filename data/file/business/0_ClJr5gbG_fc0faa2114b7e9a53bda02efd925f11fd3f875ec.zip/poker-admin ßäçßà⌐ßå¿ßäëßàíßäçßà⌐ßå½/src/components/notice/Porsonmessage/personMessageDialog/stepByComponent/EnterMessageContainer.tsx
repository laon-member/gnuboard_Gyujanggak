import React from "react";
import { observer, inject } from "mobx-react";
import NoticeStore from "stores/notice";
import { RouteComponentProps, withRouter } from "react-router-dom";
import { ReactCookieProps, withCookies } from "react-cookie";
import EnterMessageUserList from "./EnterMessageUserList";

interface Props extends RouteComponentProps, ReactCookieProps {
  noticeStore?: NoticeStore;
  onCreateToggle: () => void;
}

@inject("noticeStore")
@observer
class EnterMessageContainer extends React.Component<Props> {
  private NoticeStore = this.props.noticeStore! as NoticeStore;

  onSearch = async (type: string, value: string) => {
    await this.NoticeStore.SearchUserAtPersonMessage(type, value);
  };

  onCreatePersonMessage = async (
    title: string,
    content: string,
    list: number[]
  ) => {
    try {
      await this.NoticeStore.PostPersonMessage(title, content, list);
      this.props.history.go(0);
    } catch (e) {
      console.error(e);
    }
  };

  render() {
    return (
      <EnterMessageUserList
        onCreateToggle={this.props.onCreateToggle}
        userList={this.NoticeStore.GetUserListToPersonMessage}
        onCreatePersonMessage={this.onCreatePersonMessage}
      />
    );
  }
}
export default withCookies(withRouter(EnterMessageContainer));
