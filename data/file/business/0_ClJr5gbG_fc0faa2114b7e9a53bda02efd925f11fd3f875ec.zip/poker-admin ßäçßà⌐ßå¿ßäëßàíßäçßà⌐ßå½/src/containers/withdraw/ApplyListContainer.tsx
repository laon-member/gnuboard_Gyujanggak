import { AxiosResponse } from "axios";
import { CancleType } from "components/recharge/applyList/types";
import ApplyList from "components/withdraw/apply/ApplyList";
import { useInputs } from "lib/hooks";
import { inject, observer } from "mobx-react";
import React, { useEffect, useState } from "react";
import {
  CancleWithdrawApplyType,
  PassWithdrawApplyType,
  SearchWithdrawApplyType,
} from "services/withdraw/types";
import RootStore from "stores";
import { WarningBoxType } from "stores/recharge/types";
import { TWithdrawApplyPage, WithdrawApplyType } from "stores/withdraw/types";

interface Props {
  getWithdrawApplyListPage: (payload: SearchWithdrawApplyType) => void;
  withdrawApplyListPage: TWithdrawApplyPage;
  passWithdrawApply: (paylaod: PassWithdrawApplyType) => AxiosResponse;
  setApply: (payload: WithdrawApplyType) => void;
  apply: WithdrawApplyType;
  cancleWithdrawApply: (message: string) => AxiosResponse;
  reserveApply: () => AxiosResponse;
}

const ApplyListContainer = ({
  getWithdrawApplyListPage,
  withdrawApplyListPage,
  passWithdrawApply,
  setApply,
  apply,
  cancleWithdrawApply,
  reserveApply,
}: Props) => {
  const forms = {
    search: useInputs({
      id: "",
      phone: "",
      page: 1,
    } as SearchWithdrawApplyType),
    cancle: useInputs({
      message: "",
    } as CancleWithdrawApplyType),
  };

  useEffect(() => {
    (async () => {
      await getWithdrawApplyListPage(forms.search.inputs);
    })();
  }, []);

  const onSearch = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    await getWithdrawApplyListPage(forms.search.inputs);
  };

  const [okToggle, setOkToggle] = useState(false);
  const onOkSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      const res = await passWithdrawApply(apply);
      if (res.data.result === 1) {
        setOkToggle(false);
        forms.search.init();
        return await getWithdrawApplyListPage(forms.search.inputs);
      } else {
        return alert("Faild to pass the withdraw apply");
      }
    } catch (error) {
      console.error(error);
      return alert("There is a problem with the server");
    }
  };
  const ok: WarningBoxType = {
    toggle: okToggle,
    onToggle: (payload: WithdrawApplyType) => {
      if (!okToggle) setApply(payload);
      setOkToggle(!okToggle);
    },
    onSubmit: onOkSubmit,
  };

  const [reserveToggle, setReserveToggle] = useState(false);
  const onReserveSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    try {
      await reserveApply();
    } catch (error) {
      return alert("There is a problem with the server");
    } finally {
      await getWithdrawApplyListPage(forms.search.inputs);
      setReserveToggle(false);
    }
  };
  const reserve: WarningBoxType = {
    toggle: reserveToggle,
    onToggle: (payload: WithdrawApplyType) => {
      if (!reserveToggle) setApply(payload);
      setReserveToggle(!reserveToggle);
    },
    onSubmit: onReserveSubmit,
  };

  const [cancleToggle, setCancleToggle] = useState(false);
  const onCancleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      await cancleWithdrawApply(forms.cancle.inputs);
    } catch (error) {
      return alert("There is a problem with the server");
    } finally {
      setCancleToggle(false);
      forms.search.init();
      await getWithdrawApplyListPage(forms.search.inputs);
    }
  };
  const cancle: CancleType = {
    toggle: cancleToggle,
    onToggle: (payload: WithdrawApplyType) => {
      if (!cancleToggle) setApply(payload);
      setCancleToggle(!cancleToggle);
    },
    onSubmit: onCancleSubmit,
    form: forms.cancle,
  };

  return (
    <ApplyList
      onSearch={onSearch}
      ok={ok}
      reserve={reserve}
      cancle={cancle}
      withdrawApplyListPage={withdrawApplyListPage}
      forms={forms}
    />
  );
};

export default inject(({ withdrawStore }: RootStore) => ({
  getWithdrawApplyListPage: withdrawStore.getWithdrawApplyListPage,
  withdrawApplyListPage: withdrawStore.withdrawApplyListPage,
  passWithdrawApply: withdrawStore.passWithdrawApply,
  setApply: withdrawStore.setApply,
  apply: withdrawStore.apply,
  cancleWithdrawApply: withdrawStore.cancleWithdrawApply,
  reserveApply: withdrawStore.reserveApply,
}))(observer(ApplyListContainer));
