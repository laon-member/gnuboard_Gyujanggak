import React from "react";
import { NavLink } from "react-router-dom";
import styled from "styles/theme-components";

const AgentNavContainer = () => {
  return (
    <>
      <StyledMainNav>
        <li>
          <NavLink to="/agent/member" activeClassName="active">
            MEMBER
          </NavLink>
        </li>
        <li>
          <NavLink to="/agent/statistics" activeClassName="active">
            STATICS
          </NavLink>
        </li>
      </StyledMainNav>
    </>
  );
};

const StyledMainNav = styled.ul`
  /* background: tomato; */
  display: flex;
  background-color: #383a3f;

  li {
    position: relative;
  }

  div {
    position: absolute;
    top: 0.5rem;
    right: 0.5rem;
    background-color: red;
    font-size: 0.75rem;
    border-radius: 3px;
    color: #fff;
    padding: 3px;
  }

  a {
    box-sizing: border-box;
    display: inline-block;
    padding: 1rem 2rem;
    background-color: #383a3f;
    border-right: 1px solid #696a6c;
    color: #eeefee;
  }
  .active {
    border-top: 2px solid #d96864;
  }
`;

export default AgentNavContainer;
