import React from "react";
import PopupContainer from "containers/notice/PopupContainer";
import { Route, Switch, NavLink } from "react-router-dom";
import { SubNavContainer, ContainerWrapper } from "pages/member/MemberPage";
import RollingListContainer from "containers/notice/rolling/RollingListContainer";

function NoticePage() {
  return (
    <>
      <SubNavContainer>
        <li>
          <NavLink exact to="/admin/notice" activeClassName="active">
            Rolling
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/admin/notice/popup" activeClassName="active">
            PopUp
          </NavLink>
        </li>
      </SubNavContainer>
      <ContainerWrapper>
        <Switch>
          <Route exact path="/admin/notice" component={RollingListContainer} />
          <Route exact path="/admin/notice/popup" component={PopupContainer} />
        </Switch>
      </ContainerWrapper>
    </>
  );
}

export default NoticePage;
