import styled from "styled-components";

const Select = styled.select`
  height: 2.5rem;
  border-radius: 7px;
  border: 1px solid #ccc;
  font-size: 1rem;
  padding: 0.5rem 1rem;
`;

export default Select;
