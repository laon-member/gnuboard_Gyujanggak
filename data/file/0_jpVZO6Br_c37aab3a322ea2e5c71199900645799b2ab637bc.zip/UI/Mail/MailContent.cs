﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MailContent : MonoBehaviour
{
    public Sprite[] Spr_Mail;

    public Image Icon;
    public Text Title;
    public Text Sender;
    public Text Day;
    public Text Time;
    public GameObject NewTxt;

    bool IsOpen;
    bool IsNew;

    public MailDetail Detail;
    MailManager Main;

    string DetailContent;

    public int ID;

    private void Start()
    {
        
    }

    public void SetObj_Detail(MailDetail obj, MailManager main, string detailContents)
    {
        Detail = obj;
        Main = main;

        DetailContent = detailContents;
    }

    public void SetMailInfo(string[] info, bool isNew, int id)
    {
        IsOpen = isNew;
        IsNew = isNew;
        ID = id;


        if(IsOpen)
        {
            Icon.sprite = Spr_Mail[0];
        }
        else
        {
            Icon.sprite = Spr_Mail[1];
        }

        if(IsNew)
        {
            NewTxt.SetActive(true);
        }
        else
        {
            NewTxt.SetActive(false);
        }

        Title.text = info[0];
        Sender.text = info[1];
        Day.text = info[2];
        Time.text = info[3];
    }

    public void OnClickBtn_Detail()
    {
        Detail.gameObject.SetActive(true);
        Detail.MailObj = this.gameObject;

        IsOpen = true;
        
        Icon.sprite = Spr_Mail[1];
        NewTxt.SetActive(false);

        // DB에서 메일 정보받아서 세팅
        string[] info = new string[6];

        info[0] = Title.text;
        info[1] = Sender.text;
        info[2] = Day.text;
        info[3] = Time.text;
        info[4] = DetailContent;

        Detail.SetDetail(info, ID);

        if (IsNew)
        {
            Main.SumNewMailNumber(1);
            IsNew = false;
        }

        Main.ReadMail(ID);
    }

    public void OnClickBtn_ClickSound()
    {
        FindObjectOfType<SoundManager>().StartSound_Effect(SoundFileList.EFFECT.btn_click);
    }
}
