import React from "react";
import { DepositType } from "stores/deposit/types";
import TableRowWrapper from "components/common/TableRowWrapper";
interface Props {
  data: DepositType;
}

function RechargelistItem({ data }: Props) {
  const getStatus = () => {
    if (data.status === 1) {
      return "Success";
    } else if (data.status === 2) {
      return "Cancle";
    }
  };
  return (
    <TableRowWrapper>
      <td>{data.id}</td>
      <td>{data.userName}</td>
      <td>{data.phone}</td>
      <td>{data.bank}</td>
      <td>{data.name}</td>
      <td>{data.number}</td>
      <td>{data.amount}</td>
      <td>
        {data.created_at &&
          data.created_at.toString().slice(0, 16).replace("T", " ")}
      </td>
      <td>
        {data.check_at &&
          data.check_at.toString().slice(0, 16).replace("T", " ")}
      </td>
      <td>{getStatus()}</td>
    </TableRowWrapper>
  );
}

export default RechargelistItem;
