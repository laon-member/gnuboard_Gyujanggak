import React from "react";
import styled from "styles/theme-components";

type SelectBoxProps = {
  props: any;
  children: any;
};

const SelectBox = ({ children, props }: SelectBoxProps) => {
  return <StyledSelectBox {...props}>{children}</StyledSelectBox>;
};

const StyledSelectBox = styled.select`
  padding: 20px 0;
  option {
    width: 200px;
    height: 35px;
    background: #ffffff;
    border: 1px solid #cccccc;

    border-radius: 7px;

    padding-left: 12px;

    ::placeholder {
      color: #ccc;
      font-size: 12px;
    }
  }
`;

export default SelectBox;
