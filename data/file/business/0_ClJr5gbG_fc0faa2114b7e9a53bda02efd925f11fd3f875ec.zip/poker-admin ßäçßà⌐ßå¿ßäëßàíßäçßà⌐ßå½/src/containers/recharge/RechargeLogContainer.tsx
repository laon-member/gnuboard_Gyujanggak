import RechargeLogList from "components/recharge/rechargeLog/RechargeLogList";
import { useInputs } from "lib/hooks";
import { inject, observer } from "mobx-react";
import React, { useEffect } from "react";
import RootStore from "stores";
import {
  TRechargeForms,
  TRechargeLogPage,
  TSearchRechargeLog,
} from "stores/recharge/types";

interface Props {
  rechargeLogPage: TRechargeLogPage;
  getRechargeLogPage: (paylaod: TSearchRechargeLog) => void;
}

const RechargeLogContainer = ({
  rechargeLogPage,
  getRechargeLogPage,
}: Props) => {
  const forms = {
    search: useInputs({
      username: "",
      phone: "",
      page: 1,
    } as TSearchRechargeLog),
  } as TRechargeForms;

  useEffect(() => {
    (async () => {
      await getRechargeLogPage(forms.search.inputs);
    })();
  }, []);

  const onSearch = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    await getRechargeLogPage(forms.search.inputs);
  };

  return (
    <RechargeLogList
      rechargeLogPage={rechargeLogPage}
      onSearch={onSearch}
      forms={forms}
    />
  );
};

export default inject(({ rechargeStore }: RootStore) => ({
  rechargeLogPage: rechargeStore.rechargeLogPage,
  getRechargeLogPage: rechargeStore.getRechargeLogPage,
}))(observer(RechargeLogContainer));
