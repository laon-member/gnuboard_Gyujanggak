import { Switch } from "@material-ui/core";
import { InputWrapper } from "components/deposit/Bankset/Bankset";
import { DialogContainer } from "containers/common/dialog";
import { BlockType } from "containers/common/dialog/EditBoxContainer";
import { useInputs } from "lib/hooks";
import React from "react";
import { MemberAmount, MemberType } from "stores/member/types";
import styled from "styled-components";
import { Input } from "styles/atom";
import { TextArea } from "styles/atom/TextArea";

interface Props {
  onToggle: () => void;
  onSubmit: (
    e: React.FormEvent<HTMLFormElement>,
    memberAmount: MemberAmount
  ) => void;
  block: BlockType;
  member?: MemberType;
  memberAmount?: MemberAmount;
}

export function EditBox({ onToggle, onSubmit, member }: Props) {
  const { inputs, onChange, setInputs } = useInputs({
    id: member!.id,
    amount: 0,
    option: "",
    finance_note: "",
    block: member!.blocked === 1,
    deblock_note: "",
  });

  return (
    <DialogContainer
      title="Edit Box"
      confirmText="SAVE"
      onToggle={onToggle}
      onSubmit={(e) => onSubmit(e, inputs)}
    >
      <InputWrapper>
        <label>ID</label>
        <Input
          type="text"
          placeholder="ID"
          name="id"
          disabled
          value={member!.username}
        />
      </InputWrapper>
      <InputWrapper>
        <label>Amount</label>
        <Input
          type="text"
          placeholder="Amount"
          name="amount"
          onChange={onChange}
        />
      </InputWrapper>
      <RadioWrapper>
        <label>Type</label>
        <div>
          <input
            type="radio"
            name="type"
            defaultChecked={true}
            onChange={onChange}
            value="gold"
          />{" "}
          Gold
        </div>
      </RadioWrapper>
      <RadioWrapper>
        <label>Operation</label>
        <div>
          <input
            type="radio"
            name="option"
            onChange={onChange}
            value="INCREASE"
          />{" "}
          Increase
          <input
            type="radio"
            name="option"
            onChange={onChange}
            value="DECREASE"
          />{" "}
          Decrease
        </div>
      </RadioWrapper>
      <TextAreaWrapper>
        <label>Finance Note</label>
        <TextArea name="finance_note" onChange={onChange} />
      </TextAreaWrapper>
      <RadioWrapper>
        <label>Block</label>
        <div style={{ width: 100 }}>
          <Switch
            color="primary"
            checked={inputs.block}
            value={inputs.block}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              setInputs({
                ...inputs,
                block: e.target.checked,
              });
            }}
          />
        </div>
      </RadioWrapper>
      {inputs.block && (
        <>
          <TextAreaWrapper>
            <label>Block Note</label>
            <TextArea onChange={onChange} name="deblock_note" />
          </TextAreaWrapper>
        </>
      )}
    </DialogContainer>
  );
}

export const TextAreaWrapper = styled(InputWrapper)`
  align-items: flex-start;
  textarea {
    height: 150px;
  }
`;

export const RadioWrapper = styled(InputWrapper)`
  & > *:not(label) {
    flex: 3.5;
  }
`;

export default EditBox;
