import client from "lib/client";
import { TAdminStatSearch, TAgentStatSearch } from "stores/statistics/types";

class StaticService {
  public getAdminStatPage = async (payload: TAdminStatSearch) => {
    return await client.get(
      `/api/admin/stats?start_date=${payload.start_date}&end_date=${payload.end_date
      }&page=${payload.page - 1}`
    );
  };

  public getAgentStatPage = async (payload: TAgentStatSearch) => {
    return await client.get(
      `/api/admin/stats/agent?start_date=${payload.start_date}&end_date=${payload.end_date}&page=${payload.page - 1}`
    );
  };
}

export default new StaticService();
