import NoDataBox from "components/common/NoDataBox";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import React from "react";
import { FaSearch } from "react-icons/fa";
import { PM, PMFormTYpe, SearchPMType } from "stores/message/types";
import { Button, Input } from "styles/atom";
import PersonMessage from "./PersonMessage";

interface Props {
  PMList: PM;
  searchForm: PMFormTYpe;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
}

function PersonMessageList({
  PMList,
  searchForm: { inputs, onChange },
  onSearch,
}: Props) {
  const { username, start_date, end_date } = inputs as SearchPMType;
  return (
    <>
      <SearchWrapper>
        <SearchForm className="search" onSubmit={onSearch}>
          <Input
            placeholder="ID"
            name="username"
            value={username}
            onChange={onChange}
          />
          <Input
            type="date"
            name="start_date"
            value={start_date}
            onChange={onChange}
            className="date"
          />
          <Input
            type="date"
            name="end_date"
            value={end_date}
            onChange={onChange}
            className="date"
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>UserNumber</th>
            <th>ID</th>
            <th>Sender</th>
            <th>ReadingState</th>
            <th>SendingTime</th>
          </tr>
        </thead>
        <tbody>
          {PMList.paging.total_page
            ? PMList.messages.map((message) => (
                <PersonMessage key={message.id} message={message} />
              ))
            : null}
        </tbody>
      </Table>
      {PMList.paging.total_page ? (
        <PageNationContainer
          onPageNation={() => null}
          paging={PMList.paging}
          searchForm={{ inputs, onChange }}
          onSearch={onSearch}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
}

export default PersonMessageList;
