import NoDataBox from "components/common/NoDataBox";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import { Invalid } from "components/login/Login";
import { CancleType } from "components/recharge/applyList/types";
import { WarningBoxContainer } from "containers/common/dialog";
import CancleNoteBoxContainer from "containers/common/dialog/CancleNoteBoxContainer";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import React from "react";
import { FaSearch } from "react-icons/fa";
import {
  SearchWithdrawApplyType,
  TWithdrawFormType,
} from "services/withdraw/types";
import { WarningBoxType } from "stores/recharge/types";
import { TWithdrawApplyPage } from "stores/withdraw/types";
import { Button, Input } from "styles/atom";
import Apply from "./Apply";

interface Props {
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
  ok: WarningBoxType;
  reserve: WarningBoxType;
  cancle: CancleType;
  withdrawApplyListPage: TWithdrawApplyPage;
  forms: { search: TWithdrawFormType; cancle: TWithdrawFormType };
}

function ApplyList({
  onSearch,
  ok,
  reserve,
  cancle,
  withdrawApplyListPage,
  forms,
}: Props) {
  const { id, phone } = forms.search.inputs as SearchWithdrawApplyType;
  return (
    <>
      {ok.toggle && (
        <WarningBoxContainer
          content="Sure to  pass the withdraw record?"
          type={ok}
        />
      )}
      {reserve.toggle && (
        <WarningBoxContainer
          content="Sure to reserve the withdraw record?"
          type={reserve}
        />
      )}
      {cancle.toggle && (
        <CancleNoteBoxContainer type={cancle} form={forms.cancle} />
      )}
      <SearchWrapper>
        <SearchForm onSubmit={onSearch}>
          <Input
            type="text"
            placeholder="ID"
            name="id"
            value={id}
            onChange={forms.search.onChange}
          />
          <Input
            placeholder="Mobile"
            name="phone"
            value={phone}
            onChange={forms.search.onChange}
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>ID</th>
            <th>Agent</th>
            <th>Mobile</th>
            <th>BankAccount</th>
            <th>BankName</th>
            <th>CardNumber</th>
            <th>ApplyTime</th>
            <th>Amount</th>
            <th>Opt</th>
          </tr>
        </thead>
        <tbody>
          {withdrawApplyListPage.paging.total_page
            ? withdrawApplyListPage.withdraw.map((apply) => (
                <Apply
                  key={apply.id}
                  apply={apply}
                  ok={ok}
                  reserve={reserve}
                  cancle={cancle}
                />
              ))
            : null}
        </tbody>
      </Table>
      {withdrawApplyListPage.paging.total_page ? (
        <PageNationContainer
          paging={withdrawApplyListPage.paging}
          searchForm={forms.search}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
}

export default ApplyList;
