﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Guidance : MonoBehaviour
{
    public Text Txt_Content;

    SoundManager Sound;

    // Start is called before the first frame update
    void Start()
    {
        if (Sound == null)
        {
            Sound = FindObjectOfType<SoundManager>();
        }
    }

    public void OnDisable()
    {
        if (Txt_Content != null)
        {
            Txt_Content.text = "";
        }
    }

    public void SetText(string str)
    {
        if (Txt_Content.text.Length > 0)
        {
            Txt_Content.text = "";
        }

        this.gameObject.SetActive(true);
        Txt_Content.text = str;
    }

    //public void AddEventDelegate(UnityAction action)
    //{
    //    Button btn = this.GetComponentInChildren<Button>();
    //    btn.onClick.AddListener(action);
    //}

    public void OnClickBtn_OK()
    {
        Sound.StartSound_Effect(SoundFileList.EFFECT.btn_click);

        Txt_Content.text = "";
        this.gameObject.SetActive(false);
    }

    public void OnClickBtn_Quit()
    {
        Application.Quit();
    }

    public void OnClickBtn_Quit_Cancel()
    {
        this.gameObject.SetActive(false);
    }
}
