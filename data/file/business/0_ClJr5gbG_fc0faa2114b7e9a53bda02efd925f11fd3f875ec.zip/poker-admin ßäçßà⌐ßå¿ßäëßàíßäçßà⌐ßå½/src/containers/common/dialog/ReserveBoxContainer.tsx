import React from "react";

function ReserveBoxContainer() {
  return <h1>dfd</h1>;
}

export default ReserveBoxContainer;
