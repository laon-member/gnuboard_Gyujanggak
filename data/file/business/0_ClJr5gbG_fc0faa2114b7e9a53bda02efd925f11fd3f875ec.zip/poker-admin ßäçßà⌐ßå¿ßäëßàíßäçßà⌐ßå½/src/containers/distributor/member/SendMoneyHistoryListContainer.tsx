import SendMoneyHistoryList from "components/distributor/member/sendMoneyHistory/SendMoneyHistoryList";
import React from "react";

function SendMoneyHistoryListContainer() {
  return <SendMoneyHistoryList />;
}

export default SendMoneyHistoryListContainer;
