export type NoteType = {
  id?: number;
  toggle: boolean;
  onToggle: (id?: number) => void;
};

export type EditBoxType = {
  toggle: boolean;
  onToggle: (payload?: any) => void;
  onSubmit: ({}: any) => void;
  check?: any;
};
