export type SearchWithdrawLogType = {
  username: string;
  phone: string;
  orderNumber: string;
  page: number;
};

export type SearchWithdrawApplyType = {
  id: string;
  phone: string;
  page: number;
};

export type CancleWithdrawApplyType = {
  id: number;
  message: string;
};

export type PassWithdrawApplyType = {
  id: number;
};

export type TWithdrawFormType = {
  inputs:
  | SearchWithdrawApplyType
  | CancleWithdrawApplyType
  | SearchWithdrawLogType;
  onChange: (e: any) => void;
  setInputs?: React.Dispatch<any>;
  init?: () => void;
};
