import { action, observable } from "mobx";
import agentService from "services/agent/agentService";
import RootStore from "stores";
import { PagingType } from "stores/message/types";
import {
  TAgent,
  TAgentCreate,
  TAgentEdit,
  TAgentInfo,
  TAgentListPage,
  TAgentListPageSearch,
  TAgentMoneyHistory,
  TAgentMoneyHistoryPage,
  TAgentMoneyHistorySearch,
} from "./types";

export default class AgentStore {
  root: RootStore;

  constructor(root: RootStore) {
    this.root = root;
  }

  @observable
  agentListPage = {
    paging: {} as PagingType,
    list: [] as TAgent[],
  } as TAgentListPage;

  @observable
  agent?: TAgent;

  @observable
  agentMoneyHistoryPage = {
    paging: {} as PagingType,
    list: [] as TAgentMoneyHistory[],
  } as TAgentMoneyHistoryPage;

  @observable
  agentInfo?: TAgentInfo;

  @action
  getAgentListPage = async (payload: TAgentListPageSearch) => {
    try {
      const res = await agentService.getAgentListPage(payload);
      if (res.data.result) {
        this.agentListPage = res.data.data;
      } else {
        alert("Field Error");
      }
    } catch (error) {
      alert("There is a problem with the server");
    }
  };

  @action
  addAgent = async (payload: TAgentCreate) => {
    return await agentService.addAgent(payload);
  };

  @action
  setAgent = async (payload?: TAgent) => {
    if (payload) {
      this.agent = payload;
    } else {
      this.agent = undefined;
    }
    console.log(this.agent);
  };

  @action
  editAgent = async (payload: TAgentEdit) => {
    return await agentService.editAgent(payload);
  };

  @action
  getAgentMoneyHistoryPage = async (payload: TAgentMoneyHistorySearch) => {
    try {
      const res = await agentService.getAgentMoneyHistoryPage(payload);
      if (res.data.result) {
        this.agentMoneyHistoryPage = res.data.data;
      } else {
        alert("Field error");
      }
    } catch (error) {
      alert("There is a problem with the server");
    }
  };

  @action
  getAgentInfo = async () => {
    try {
      const res = await agentService.getAgentInfo();
      if (res.data.result) {
        this.agentInfo = res.data.data;
      } else {
        alert("There is no barrier token");
      }
    } catch (error) {
      alert("There is a problem with the server");
    }
  };
}
