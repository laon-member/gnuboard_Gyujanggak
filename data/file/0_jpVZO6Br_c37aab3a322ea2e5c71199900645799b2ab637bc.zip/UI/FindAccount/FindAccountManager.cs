﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;
using LitJson;
using UnityEngine.Networking;
using Leguar.TotalJSON;

public class FindAccountManager : MonoBehaviour
{
    public Image[] Top_Button;
    public Sprite[] Spr_TopBtns;

    public GameObject[] Page;

    public InputField[] ID_Fields;
    public InputField[] PW_Fields;

    public Guidance PopUp;

    public GameObject PopUp_NewPassword;

    public InputField[] Input_NewPassword;

    int PageIdx = 0;

    DataBaseManager DBMgr;

    // Start is called before the first frame update
    void Start()
    {
        if(DBMgr == null)
        {
            DBMgr = FindObjectOfType<DataBaseManager>();
        }
    }

    public void OnClickBtn_Back()
    {
        SceneManager.LoadScene("LogIn");
    }
    public void OnClickBtn_ClickSound()
    {
        FindObjectOfType<SoundManager>().StartSound_Effect(SoundFileList.EFFECT.btn_click);   
    }
    public void OnClickBtn_TopBtn(int idx)
    {
        PageIdx = idx;

        if (idx == 0)
        {
            Top_Button[0].sprite = Spr_TopBtns[0];
            Top_Button[1].sprite = Spr_TopBtns[1];

            Top_Button[0].GetComponent<RectTransform>().sizeDelta = new Vector2(389, 112);
            Top_Button[1].GetComponent<RectTransform>().sizeDelta = new Vector2(319, 84);

            Page[0].SetActive(true);
            Page[1].SetActive(false);
        }
        else
        {
            Top_Button[0].sprite = Spr_TopBtns[1];
            Top_Button[1].sprite = Spr_TopBtns[0];

            Top_Button[0].GetComponent<RectTransform>().sizeDelta = new Vector2(319, 84);
            Top_Button[1].GetComponent<RectTransform>().sizeDelta = new Vector2(389, 112);

            Page[0].SetActive(false);
            Page[1].SetActive(true);
        }
    }

    void SetSprite(Image img, string fileName)
    {
        img.sprite = Resources.Load<Sprite>("Sprites/Profiles/" + fileName);
    }

    public void OnClickBtn_OK()
    {
        bool empty = false;

        // 빈칸 체크
        if (PageIdx == 0)
        {
            int idx = 0;
            for (int i = 0; i < ID_Fields.Length; i++)
            {
                if(ID_Fields[i].text.Length <= 0)
                {
                    empty = true;
                    idx = i;
                    break;
                }
            }
            if(empty)
            {
                PopUp.SetText(ID_Fields[idx].transform.parent.GetComponent<Text>().text + "를(을) 입력해주세요");
            }
        }
        else
        {
            int idx = 0;
            for (int i = 0; i < PW_Fields.Length; i++)
            {
                if (PW_Fields[i].text.Length <= 0)
                {
                    empty = true;
                    idx = i;
                    break;
                }
            }
            if (empty)
            {
                PopUp.SetText(PW_Fields[idx].transform.parent.GetComponent<Text>().text + "를(을) 입력해주세요");
            }
        }

        // DB 스캔해서 일치하는 정보가 있나 없나
        // PopUp 띄우기
        if (PageIdx == 0) // ID
        {
            FindID();
        }
        else // PW
        {
            // 일치된 정보가 있으면
            FindPW();
        }
    }

    void FindID()
    {
        JSON jsonData = new JSON();
        jsonData.Add("phone", ID_Fields[0].text);
        jsonData.Add("account_name", ID_Fields[1].text);
        
        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.FindID, jsonData.CreateString(), UnityWebRequest.kHttpVerbPOST, "", (result) =>
        {
            if (result == "NetworkError" || result == "Not Found")
            {
                PopUp.SetText("Không thể kết nối mạng"); // 번역 : 네트워크 연결 실패 o
                return;
            }

            JsonData responeseResult = JsonMapper.ToObject(result);

            Debug.LogFormat("<color=red>{0}</color>", (int)responeseResult["result"]);

            if ((int)responeseResult["result"] == 0)
            {   
                PopUp.SetText("Không có người chơi tương ứng"); // 번역 : 해당하는 유저가 없습니다. o
            }
            else
            {
                PopUp.SetText("ID : " + (string)responeseResult["data"]["user"]["username"]); // 번역 o
            }
        }));
    }

    void FindPW()
    {
        JSON jsonData = new JSON();
        jsonData.Add("username", PW_Fields[0].text);
        jsonData.Add("phone", PW_Fields[1].text);
        jsonData.Add("name", PW_Fields[2].text);
        
        StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.FindPW, jsonData.CreateString(), "Post", "", (result) =>
        {
            if (result == "NetworkError" || result == "Not Found")
            {
                PopUp.SetText("Không thể kết nối mạng"); // 번역 : 네트워크 연결 실패 o
                return;
            }

            JsonData responeseResult = JsonMapper.ToObject(result);

            Debug.LogFormat("<color=red>{0}</color>", (int)responeseResult["result"]);

            if ((int)responeseResult["result"] == 0)
            {
                PopUp.SetText("Xin vui lòng nhập vào chỗ trống"); // 번역 : 빈칸을 입력해주세요. o
            }
            else
            {
                PopUp_NewPassword.SetActive(true);
            }
        }));
    }

    public void OnClickBtn_PopUp_OK()
    {
        PopUp.gameObject.SetActive(false);
    }

    public void OnClickBtn_PopUp_PasswordCheck()
    {
        if(Input_NewPassword[0].text == Input_NewPassword[1].text)
        {
            JSON jsonData = new JSON();
            jsonData.Add("username", PW_Fields[0].text);
            jsonData.Add("password", Input_NewPassword[0].text);
            
            foreach (var item in PW_Fields)
            {
                item.text = "";
            }

            StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.FindNewPW, jsonData.CreateString(), "Post", "", (result) =>
            {
                if (result == "NetworkError" || result == "Not Found")
                {
                    PopUp.SetText("Không thể kết nối mạng"); // 번역 : 네트워크 오류 o
                    return;
                }

                JsonData resp = JsonMapper.ToObject(result);

                Debug.LogFormat("<color=red>{0}</color>", (int)resp["result"]);

                if((int)resp["result"] == 1)
                {
                    PopUp.SetText("Mật khẩu được thay đổi"); // 번역 : 비밀번호 변경 완료 o
                    PopUp_NewPassword.SetActive(false);
                }
                else
                {
                    PopUp.SetText("Xin vui lòng nhập vào chỗ trống"); // 번역 : 빈칸을 입력해 주세요. o
                }
            }));


            Input_NewPassword[0].text = "";
            Input_NewPassword[1].text = "";
        }
        else
        {
            PopUp.SetText("Xin vui lòng xác nhận lại mật khẩu "); // 번역 : 비밀번호를 다시 확인해 주세요. o

            Input_NewPassword[0].text = "";
            Input_NewPassword[1].text = "";
        }

        PopUp.gameObject.SetActive(true);
    }

    public void OnClickBtn_Cancel()
    {
        PopUp_NewPassword.SetActive(false);

        Input_NewPassword[0].text = "";
        Input_NewPassword[1].text = "";
    }

    public void OnClickBtn_Reset()
    {
        for (int i = 0; i < Page[PageIdx].transform.childCount; i++)
        {
            Page[PageIdx].transform.GetChild(i).GetChild(0).GetComponent<InputField>().text = "";
        }
    }
}
