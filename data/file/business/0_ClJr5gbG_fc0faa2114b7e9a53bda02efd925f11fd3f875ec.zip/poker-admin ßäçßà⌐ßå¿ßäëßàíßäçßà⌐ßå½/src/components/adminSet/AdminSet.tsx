import { TableRowWrapper } from "components/common";
import React from "react";
import { AdminType } from "stores/admin/types";
import { WarningBoxType } from "stores/recharge/types";
import { Button } from "styles/atom";

interface Props {
  adminSet: AdminType;
  edit: WarningBoxType;
  _delete: WarningBoxType;
  setAdmin: (id: string) => void;
}

function AdminSet({ adminSet, edit, _delete, setAdmin }: Props) {
  const onEditToggle = () => {
    edit.onToggle();
    setAdmin(adminSet.id);
  };

  const onDeleteToggle = () => {
    _delete.onToggle();
    setAdmin(adminSet.id);
  };
  return (
    <TableRowWrapper>
      <td>{adminSet.id}</td>
      <td>{adminSet.username}</td>
      <td>{adminSet.created_at}</td>
      <td>{adminSet.updated_at === null ? "" : adminSet.updated_at}</td>
      <td>
        <Button bgColor="#FFC124" color="#fff" onClick={onEditToggle}>
          EDIT
        </Button>
      </td>
      <td>
        <Button bgColor="#E44849" color="#fff" onClick={onDeleteToggle}>
          DELETE
        </Button>
      </td>
    </TableRowWrapper>
  );
}

export default AdminSet;
