import styled from "styled-components";

export const TextArea = styled.textarea`
  border-radius: 7px;
  border: 1px solid #ccc;
  font-size: 1rem;
  padding: 0.5rem 1rem;
`;
