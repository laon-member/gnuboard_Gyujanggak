﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class MailDetail : MonoBehaviour
{
    public Text Title;
    public Text Sender;
    public TextMeshProUGUI Day;
    public Text Time;
    public Text Content;


    public MailManager Main;

    public GameObject MailObj;

    int ID = 0;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    /// <summary>
    /// 0 = title, 1 = sender, 2 = day, 3 = time, 4 = content
    /// </summary>
    /// <param name="info"></param>
    public void SetDetail(string[] info, int id)
    {
        Title.text = info[0];
        Sender.text = info[1];
        Day.text = info[2];
        Time.text = info[3];
        Content.text = info[4];
        ID = id;
    }

    public void OnClickBtn_Delete()
    {
        Main.RemoveContentList(MailObj);

        Main.DeleteMail(ID);

        this.gameObject.SetActive(false);

        Destroy(MailObj.gameObject);
    }

    public void OnClickBtn_PopUPClose()
    {
        this.gameObject.SetActive(false);
    }

    public void SetTitle(string title)
    {
        Title.text = title;
    }
    public void SetContent(string content)
    {
        Content.text = content;
    }
}
