﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class SoundManager : MonoBehaviour
{
    public AudioSource BGM;

    public AudioSource PFEffect;

    public AudioClip[] EffectSounds;
    public AudioClip[] BGMSounds;

    List<AudioSource> EffectList = new List<AudioSource>();
    public float[] Volumes;

    public AudioSource TimerSound;

    //public AudioClip[] LobbyBGM;

    // GetString :: BGM, GameSound :: 0 play

    private void Awake()
    {
        DontDestroyOnLoad(this.gameObject);

        if (PlayerPrefs.GetString("BGM") == "0")
        {
            BGM.clip = BGMSounds[(int)SoundFileList.BGM.MAIN];
            BGM.Play();
        }
    }

    public void SetBGMSound(SoundFileList.BGM bgm)
    {
        //if ((int)bgm == 0)
        //{
        //    BGM.clip = LobbyBGM[Random.Range(0, 3)];
        //}
        //else
        //{
        //BGM.clip = BGMSounds[(int)bgm];
        //}

        BGM.clip = BGMSounds[(int)bgm];

        if (PlayerPrefs.GetString("BGM") == "0")
        {
            BGM.Play();
        }
    }

    public void StartSound_Effect(SoundFileList.EFFECT effect_sound)
    {
        if(PlayerPrefs.GetString("GameSound") == "1")
        {
            return;
        }

        AudioSource effect = Instantiate(PFEffect, this.transform);

        effect.clip = EffectSounds[(int)effect_sound];
        effect.volume = Volumes[(int)effect_sound];

        effect.Play();

        EffectList.Add(effect);

        StartCoroutine(DestroyEffectSound(effect));
    }

    IEnumerator DestroyEffectSound(AudioSource effect)
    {
        yield return CWFS.WFS(effect.clip.length);
        Destroy(effect.gameObject);
    }

    public void StartTimerSound()
    {
        if(PlayerPrefs.GetString("GameSound") == "1")
        {
            return;
        }

        AudioSource effect = Instantiate(PFEffect, this.transform);

        effect.clip = EffectSounds[(int)SoundFileList.EFFECT.card_timer];

        effect.Play();

        TimerSound = effect;
    }

    public void StopTimerSound()
    {
        if (TimerSound != null)
        {
            Destroy(TimerSound.gameObject);
        }
    }
}
