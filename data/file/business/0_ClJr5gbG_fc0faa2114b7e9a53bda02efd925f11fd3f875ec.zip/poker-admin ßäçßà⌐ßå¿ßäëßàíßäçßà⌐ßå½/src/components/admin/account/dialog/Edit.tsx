import React, { FormEvent, useState } from "react";
import { DialogContainer } from "containers/common/dialog";
import { Input } from "styles/atom";
import { useInputs } from "lib/hooks";

interface Props {
  title: string;
  onToggle: (id: string) => void;
  onEditAccout: (id: string, password: string) => void;
  // adminId: string;
}

const Edit = ({
  title,
  onToggle,
  // adminId,
  onEditAccout,
}: Props) => {
  const { inputs, onChange, init } = useInputs({
    id: "",
    password: "",
    passwordCheck: "",
  });
  const { id, password, passwordCheck } = inputs;
  const [isSamePassword, setIsSamePassword] = useState(true);

  const onSave = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (password === "") return alert("please enter password");
    if (password !== passwordCheck) return setIsSamePassword(false);
    onEditAccout(id, password);
    init();
    setIsSamePassword(true);
  };

  return (
    <DialogContainer
      title={title}
      confirmText="EDIT"
      onToggle={() => onToggle("edit")}
      onSubmit={onSave}
    >
      <div>
        <label>ID</label>
        <Input
          name="id"
          value={id}
          onChange={onChange}
          placeholder="Enter id"
        />
        <label>Password</label>
        <Input
          type="password"
          name="password"
          value={password}
          onChange={onChange}
          placeholder="Enter your new password"
        />
        <label>Password check</label>
        <Input
          type="password"
          name="passwordCheck"
          value={passwordCheck}
          onChange={onChange}
          placeholder="again enter your new password"
        />
      </div>
      {!isSamePassword && <label>The password isn't same</label>}
    </DialogContainer>
  );
};

export default Edit;
