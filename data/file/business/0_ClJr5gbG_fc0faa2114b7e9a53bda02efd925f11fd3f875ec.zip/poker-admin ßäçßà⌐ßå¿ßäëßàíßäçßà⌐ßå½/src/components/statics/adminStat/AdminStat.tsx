import { TableRowWrapper } from "components/common";
import comma from "lib/comma";
import React from "react";
import { TAdminStat } from "stores/statistics/types";

interface Props {
  adminStat: TAdminStat;
}

function AdminStat({ adminStat }: Props) {
  const {
    day,
    member_recharge,
    player_gold_sum,
    member_withdraw,
    admin_decrease,
    admin_increase,
    total_poundage,
    new_member,
    agent_poundage,
  } = adminStat;
  return (
    <TableRowWrapper>
      <td>{day}</td>
      <td>{member_recharge ? comma(member_recharge) : 0}</td>
      <td>{player_gold_sum ? comma(player_gold_sum) : 0}</td>
      <td>{member_withdraw ? comma(member_withdraw) : 0}</td>
      <td>{admin_increase ? comma(admin_increase) : 0}</td>
      <td>{admin_decrease ? comma(admin_decrease) : 0}</td>
      <td>{total_poundage ? comma(total_poundage) : 0}</td>
      <td>{agent_poundage ? comma(agent_poundage) : 0}</td>
      <td>
        {total_poundage && agent_poundage
          ? comma(total_poundage - agent_poundage)
          : 0}
      </td>
      <td>{new_member ? comma(new_member) : 0}</td>
    </TableRowWrapper>
  );
}

export default AdminStat;
