import React from "react";
import { useInputs } from "lib/hooks";
import styled from "styled-components";
import { searchedUserType } from "stores/notice/types";
import { StyledSelectedUser } from "./SelectUserList";
import { Button } from "styles/atom";
import { ButtonGroup } from "containers/common/dialog/DialogContainer";

type EnterMessageUserListProps = {
  onCreateToggle: () => void;
  userList: searchedUserType[];
  onCreatePersonMessage: (
    title: string,
    content: string,
    list: number[]
  ) => void;
};

const EnterMessageUserList = ({
  onCreateToggle,
  userList,
  onCreatePersonMessage,
}: EnterMessageUserListProps) => {
  const { inputs, onChange, init } = useInputs({
    title: "",
    content: "",
  });
  const { title, content } = inputs;

  const onSendMessage = () => {
    // eslint-disable-next-line no-restricted-globals
    const isSend = confirm("Are you sure send messages?");
    if (isSend) {
      const list = userList.map((user) => user.id);
      onCreatePersonMessage(title, content, list);
      init();
      onCreateToggle();
    }
  };
  return (
    <Wrapper>
      <UserContainer>
        {userList.map((user) => (
          <UserWrapper key={user.id}>
            <StyledSelectedUser>{user.username}</StyledSelectedUser>
          </UserWrapper>
        ))}
      </UserContainer>

      <Form>
        <input
          name="title"
          value={title}
          onChange={onChange}
          placeholder="type the title"
        />
        <textarea
          name="content"
          value={content}
          onChange={onChange}
          placeholder="type your message"
        />
      </Form>
      <ButtonGroup>
        <Button secondary half onClick={onCreateToggle}>
          CANCLE
        </Button>
        <Button half onClick={onSendMessage}>
          SEND
        </Button>
      </ButtonGroup>
    </Wrapper>
  );
};

const Wrapper = styled.div`
  padding: 1rem;
`;

const UserContainer = styled.div`
  padding-bottom: 1rem;
  max-height: 150px;
  overflow: scroll;
`;

const UserWrapper = styled.div`
  display: inline-block;

  & + & {
    margin-left: 0.5rem;
    margin-bottom: 0.5rem;
  }
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;

  * {
    margin-top: 1rem;
    padding: 0.5rem 1rem;
    font-size: 1rem;
    width: 100%;
  }
  textarea {
    height: 6rem;
    width: 100%;
  }
`;

export default EnterMessageUserList;
