import { TPutPolicy } from "stores/jackpot/types";

export type SearchPMType = {
  username: string;
  start_date: string;
  end_date: string;
  sender: string;
  page: number;
};

export type SearchGMType = {
  start_date: string;
  end_date: string;
  page: number;
};

export type PMType = {
  id: string;
  user_id: number;
  username: string;
  title: string;
  content: string;
  is_read: string;
  sender: string;
  created_at: string;
};

export type GMType = {
  id: number;
  title: string;
  content: string;
  created_at: string;
  updated_at?: string;
  sender: string;
  total_count: number;
  readed_count: number;
};

export type PagingType = {
  current_page: number;
  total_page: number;
  total_count: number;
};

export type PM = {
  paging: PagingType;
  messages: PMType[];
};

export type GM = {
  paging: PagingType;
  messages: GMType[];
};

export type GMFormType = {
  inputs: SearchGMType | any;
  onChange: (e: any) => void;
};

export type PMFormTYpe = {
  inputs: SearchPMType;
  onChange: (e: any) => void;
};

export type SearchUserType = {
  title: string;
  content: string;
  type: string;
  username: string;
};

export type UserFormType = {
  inputs: SearchUserType;
  onChange: (e: any) => void;
  setInputs: any,
  init: any;
};

export type UserType = {
  id: number;
  username: string;
  phone: string;
};
