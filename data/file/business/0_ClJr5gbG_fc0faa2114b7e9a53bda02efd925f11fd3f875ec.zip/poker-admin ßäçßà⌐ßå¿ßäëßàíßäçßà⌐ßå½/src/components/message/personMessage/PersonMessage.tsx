import { TableRowWrapper } from "components/common";
import React from "react";
import { PMType } from "stores/message/types";

interface Props {
  message: PMType;
}

function PersonMessage({ message }: Props) {
  return (
    <TableRowWrapper>
      <td>{message.user_id}</td>
      <td>{message.username}</td>
      <td>{message.sender}</td>
      <td>{message.is_read === "false" ? "unread" : "read"}</td>
      <td>{message.created_at}</td>
    </TableRowWrapper>
  );
}

export default PersonMessage;
