import React from "react";

import { Route, NavLink, Switch } from "react-router-dom";
import { ContainerWrapper, SubNavContainer } from "pages/member/MemberPage";
import AdminStatContainer from "containers/statics/AdminStatContainer";
import AgentStatContainer from "containers/statics/AgentStatContainer";
// import AgentStatContainer from "containers/statics/AgentStatContainer";

function MemberPage() {
  return (
    <>
      <SubNavContainer>
        <li>
          <NavLink exact to="/admin/statistics" activeClassName="active">
            AdminStat
          </NavLink>
        </li>
        <li>
          <NavLink exact to="/admin/statistics/agent" activeClassName="active">
            AgentStat
          </NavLink>
        </li>
      </SubNavContainer>
      <ContainerWrapper>
        <Switch>
          <Route
            exact
            path="/admin/statistics"
            component={AdminStatContainer}
          />
          <Route
            exact
            path="/admin/statistics/agent"
            component={AgentStatContainer}
          />
        </Switch>
      </ContainerWrapper>
    </>
  );
}

export default MemberPage;
