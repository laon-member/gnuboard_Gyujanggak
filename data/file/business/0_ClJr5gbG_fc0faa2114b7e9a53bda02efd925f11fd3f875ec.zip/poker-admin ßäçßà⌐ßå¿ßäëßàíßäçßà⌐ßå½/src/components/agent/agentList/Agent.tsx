import { TableRowWrapper } from "components/common";
import comma from "lib/comma";
import React from "react";
import { FaPen } from "react-icons/fa";
import { EditBoxType, TAgent } from "stores/agent/types";
import { PagingType } from "stores/message/types";

interface Props {
  idx: number;
  agent: TAgent;
  paging: PagingType;
  edit: EditBoxType;
}

function Agent({ idx, agent, paging, edit }: Props) {
  return (
    <TableRowWrapper>
      <td>{idx + 1 + (paging.current_page - 1) * 30}</td>
      <td>{agent.username}</td>
      <td>{agent.agent_code}</td>
      <td>{agent.mobile}</td>
      <td>{agent.bene_rate}</td>
      <td>{agent.bank_account}</td>
      <td>{agent.bank_name}</td>
      <td>{agent.card_number}</td>
      <td>{agent.created_at}</td>
      <td>{comma(agent.member_sum)}</td>
      <td>{comma(agent.agent_amount)}</td>
      <td>{comma(agent.remain_amount)}</td>
      <td>{comma(agent.withdraw_sum)}</td>
      <td className="icon" onClick={() => edit.onToggle(agent)}>
        <FaPen />
      </td>
    </TableRowWrapper>
  );
}

export default Agent;
