﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DataBaseLinkList
{
    private static DataBaseLinkList instance = null;

    private DataBaseLinkList() { }

    public static DataBaseLinkList Instance
    {
        get
        {
            if (instance == null)
            {
                instance = new DataBaseLinkList();
            }
            return instance;
        }
    }

    //static string BaseIP = "http://127.0.0.1:8080/poker_api/api/";

    // 테스트 서버
    //static string BaseIP = "http://sean.oig.kr:4040/poker_api/api/";

    // 실서버
    //static string BaseIP = "http://kiea.shop/poker_api/api/";

    //static string BaseIP = "http://192.168.100.214:4040/poker_api/api/";

    //test server
    static string BaseIP = "http://192.168.100.216:4040/poker_api/api/";
    //static string BaseIP = "http://192.168.100.200:4040/poker_api/api/";

    // game
    public string SendCardInfo = BaseIP + "games/log/user/card/";
    public string SendRoomBattingMoney = BaseIP + "games/log/user/";
    public string SendRoomLevel = BaseIP + "games/log/room";
    public string SendBattingMoney = BaseIP + "games/log/user/bet/";
    public string SendRoom_End = BaseIP + "games/log/room/finish/";
    public string SendUser_End = BaseIP + "games/log/user/finish/";

    //policy :: 보류
    public string GetNotics = BaseIP + "policy/notice";
    public string GetGameVersion = BaseIP + "version/check";


    // auth
    public string FindPW = BaseIP + "auth/numbercheck"; //
    public string Login = BaseIP + "auth/login"; //
    public string SingUp = BaseIP + "auth/signup"; //
    public string FindID = BaseIP + "auth/findid"; //
    public string FindNewPW = BaseIP + "auth/findPw";//
    public string Logout = BaseIP + "auth/logout";//

    // User
    public string GetProfileInfo = BaseIP + "users/me/profileinfo"; //
    public string SetProfileInfo = BaseIP + "users/me/profile"; //
    public string SendPlayerCount = BaseIP + "users/plays";

    public string SendMyLocation = BaseIP + "users/location";

    public string UserNumberCheck = BaseIP + "users/numbercheck"; //
    public string GetUserInfo = BaseIP + "users/info"; //
    public string ChangePW = BaseIP + "users/newfindpw"; //

    public string SendIsLogined = BaseIP + "users/login/check";
    
    // Bank
    public string GetCompanyAccount = BaseIP + "bank/chargeinfo";
    public string AddDeposit = BaseIP + "bank/createdeposit";
    public string GetDepositHistory = BaseIP + "bank/selectdeposit";
    public string AddWithdraw = BaseIP + "bank/createWithdraw";
    public string GetWithdrawHistory = BaseIP + "bank/selectwithdraw";

    // Friend
    public string GetRandomUser = BaseIP + "friend/randomFriend";
    public string AddFriend = BaseIP + "friend/createfriend";
    public string GetFriendList = BaseIP + "friend/selectfriend";
    public string DeleteFriend = BaseIP + "friend/deletefriend";
    public string CreateSearchFriend = BaseIP + "friend/onefriend";
    public string GetGiftHistorys = BaseIP + "jackpot/history"; // api 만들어 지면 수정

    // Mail
    public string GetMailList = BaseIP + "mail/selectmail";
    public string DeleteAllMail = BaseIP + "mail/delmailone";
    public string ReadMail = BaseIP + "mail/isreadmail";
    public string DeleteMail = BaseIP + "mail/del";

    // Jackpot
    public string GetJackpotMoney = BaseIP + "jackpot/account";
    public string EndHistory = BaseIP + "jackpot/endhistory";
    public string GetRaffle = BaseIP + "jackpot/raffle";
    public string JackPotPlus = BaseIP + "jackpot/jackpotplus";

    public string SetUserMoney = BaseIP + "jackpot/amount";
    public string AddJackpotLog = BaseIP + "jackpot/log";
    //public string SendRoomLevel = BaseIP + "jackpot/users/log";
    public string GetJackpotHistory = BaseIP + "jackpot/history";


}
