import NoDataBox from "components/common/NoDataBox";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import { WarningBoxContainer } from "containers/common/dialog";
import PageNationContainer from "containers/common/pageNation/PageNationContainer";
import React from "react";
import { FaSearch } from "react-icons/fa";
import {
  TRoomDelete,
  TRoomListForms,
  TRoomListPage,
  TRoomListSearch,
} from "services/game/types";
import { Button, Input, Select } from "styles/atom";
import Room from "./Room";

interface Props {
  roomListPage: TRoomListPage;
  forms: TRoomListForms;
  _delete: TRoomDelete;
  onSearch: (e: React.FormEvent<HTMLFormElement>) => void;
}

function RoomList({ roomListPage, forms, onSearch, _delete }: Props) {
  const { search } = forms;
  const { onChange } = search;
  const { room_type, username, nickname } = search.inputs as TRoomListSearch;
  return (
    <>
      {_delete.toggle && (
        <WarningBoxContainer
          content={`This will kickk everyone out of the room, Do you want to continue?`}
          type={_delete}
        />
      )}
      <SearchWrapper>
        <SearchForm onSubmit={onSearch}>
          <Select name="room_type" value={room_type} onChange={onChange}>
            <option value="" disabled selected>
              Room Type
            </option>
            <option value="ALL">ALL</option>
            <option value="1">Lv. 1</option>
            <option value="2">Lv. 2</option>
            <option value="3">Lv. 3</option>
            <option value="4">Lv. 4</option>
            <option value="5">Lv. 5</option>
            <option value="6">Lv. 6</option>
          </Select>
          <Input
            placeholder="ID"
            name="username"
            value={username}
            onChange={onChange}
          />
          <Input
            placeholder="Nickname"
            name="nickname"
            value={nickname}
            onChange={onChange}
          />
          <Button type="submit">
            Search <FaSearch />
          </Button>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>RoomID</th>
            <th>ToomType</th>
            <th>UserId</th>
            <th>NickName</th>
            <th>Close</th>
          </tr>
        </thead>
        <tbody>
          {roomListPage.paging.total_page
            ? roomListPage.list.map((room, idx) => (
                <Room key={idx} room={room} _delete={_delete} />
              ))
            : null}
        </tbody>
      </Table>
      {roomListPage.paging.total_page ? (
        <PageNationContainer
          paging={roomListPage.paging}
          onSearch={onSearch}
          searchForm={forms.search}
        />
      ) : (
        <NoDataBox />
      )}
    </>
  );
}

export default RoomList;
