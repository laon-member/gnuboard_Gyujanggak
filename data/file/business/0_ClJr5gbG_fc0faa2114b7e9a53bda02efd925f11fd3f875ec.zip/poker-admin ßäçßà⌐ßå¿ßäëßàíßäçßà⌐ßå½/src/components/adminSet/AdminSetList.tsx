import Table from "components/common/Table";
import { SearchWrapper } from "components/deposit/Bankset/Bankset";
import { EditBoxType } from "components/member/memberlist/types";
import AdminBoxContainer from "containers/adminSet/AdminBoxContainer";
import { WarningBoxContainer } from "containers/common/dialog";
import React from "react";
import { FaPlus } from "react-icons/fa";
import { AdminType } from "stores/admin/types";
import { WarningBoxType } from "stores/recharge/types";
import { Button } from "styles/atom";
import AdminSet from "./AdminSet";

interface Props {
  _new: EditBoxType;
  edit: EditBoxType;
  _delete: WarningBoxType;
  adminList: AdminType[];
  admin: AdminType;
  setAdmin: (id: string) => void;
}

const AdminSetList = ({
  _new,
  edit,
  _delete,
  adminList,
  admin,
  setAdmin,
}: Props) => {
  return (
    <>
      {_new.toggle && <AdminBoxContainer _new={_new} />}
      {edit.toggle && <AdminBoxContainer edit={edit} admin={admin} />}
      {_delete.toggle && (
        <WarningBoxContainer
          content="Sure to delete the admin?"
          type={_delete}
        />
      )}
      <SearchWrapper>
        <Button onClick={_new.onToggle}>
          New <FaPlus />
        </Button>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>ID</th>
            <th>RegisterTime</th>
            <th>ChangeTime</th>
            <th>Opt</th>
            <th>Opt</th>
          </tr>
        </thead>
        <tbody>
          {adminList.map((admin) => (
            <AdminSet
              key={admin.id}
              adminSet={admin}
              edit={edit}
              _delete={_delete}
              setAdmin={setAdmin}
            />
          ))}
        </tbody>
      </Table>
    </>
  );
};

export default AdminSetList;
