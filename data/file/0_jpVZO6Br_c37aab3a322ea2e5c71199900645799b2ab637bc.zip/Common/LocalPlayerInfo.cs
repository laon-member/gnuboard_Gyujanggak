﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LocalPlayerInfo
{
    private static LocalPlayerInfo instance = null;

    private LocalPlayerInfo() { }

    public static LocalPlayerInfo Instance
    {
        get
        {
            if(instance == null)
            {
                instance = new LocalPlayerInfo();
            }
            return instance;
        }
    }


    public string PlayerName;
    public string PlayerNickName;

    public string PlayerAccount;

    public int PlayerNumber;

    public long PlayerMoney;

    public string ProfileImgFilePath;

    public string NoticMessage;

    public float Commission;

    public string RollingNotic;
    public string PopUpNotic;
    public string JackpotNotic;

    public bool SetProfile;
    public bool ShowPopUpNotice;

    public bool QuitWait;

    public bool InRoom;

    public bool IsLogined;

    public bool SendPlayerCount;

    public float Agent_Commission;

    public int RoomLevel;
    /// <summary>
    /// 0 = 남자, 1 = 여자
    /// </summary>
    public int Gender;

    public void SetInfo(ExitGames.Client.Photon.Hashtable info)
    {
        PlayerName = (string)info["UserID"];
        PlayerNickName = (string)info["UserNickName"];

        PlayerNumber = (int)info["UserNumber"];
        PlayerMoney = (long)info["UserMoney"];

        Gender = (int)info["UserGender"];

        ProfileImgFilePath = (string)info["ProfileImageName"];
    }

    public ExitGames.Client.Photon.Hashtable GetInfo()
    {
        string[] cards = new string[3] { "", "", "" };

        ExitGames.Client.Photon.Hashtable hash = new ExitGames.Client.Photon.Hashtable()
            {
                {"UserID", PlayerName },
                {"UserNickName", PlayerNickName },
                {"UserNumber", PlayerNumber },
                {"UserMoney",PlayerMoney },
                {"UserGender", Gender },
                {"ProfileImageName", ProfileImgFilePath },
                {"IsDie", false },
                {"IsDealer", false },
                {"IsWatch", false }
            };

        return hash;
    }
}
