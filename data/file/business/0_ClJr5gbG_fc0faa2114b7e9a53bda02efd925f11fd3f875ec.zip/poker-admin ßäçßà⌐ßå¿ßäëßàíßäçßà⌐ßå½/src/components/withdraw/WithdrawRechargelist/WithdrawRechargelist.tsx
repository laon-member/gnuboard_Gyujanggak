/* eslint-disable no-restricted-globals */
import React from "react";
import SearchIcon from "assets/icons/search.png";
import { WithdrawTypeBackup } from "stores/withdraw/types";
import WithRechargelistItem from "./item";
import useInputs from "lib/hooks/useInputs";
import Table from "components/common/Table";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";
import { Input, Select, Button } from "styles/atom";

interface Props {
  withdrawList: WithdrawTypeBackup[];
  onSearch: (
    id?: string,
    phone?: string,
    status?: string,
    startDate?: string,
    endDate?: string
  ) => void;
  onActiveToggle: (id: number) => void;
}

function Rechargelist({ withdrawList, onSearch, onActiveToggle }: Props) {
  const { inputs, onChange } = useInputs({
    id: "",
    phone: "",
    status: "",
    startDate: "",
    endDate: "",
  });
  const { id, phone, status, startDate, endDate } = inputs;

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onSearch(id, phone, status, startDate, endDate);
  };

  return (
    <>
      <SearchWrapper>
        <SearchForm className="search" onSubmit={onSubmit}>
          <Input
            value={id}
            onChange={onChange}
            name="id"
            placeholder="ID"
            className="id"
          />
          <Input
            value={phone}
            onChange={onChange}
            name="phone"
            placeholder="phone number"
            className="phone"
          />
          <Select
            name="status"
            value={status}
            onChange={onChange}
            style={{ color: "#ccc" }}
          >
            <option>Status</option>
            <option value="1">Success</option>
            <option value="2">Cancle</option>
          </Select>
          <Input
            type="date"
            name="startDate"
            value={startDate}
            onChange={onChange}
            className="date"
          />
          <span> ~ </span>
          <Input
            type="date"
            name="endDate"
            value={endDate}
            onChange={onChange}
            className="date"
          />

          <Button type="submit">
            <img src={SearchIcon} alt="검색" />
          </Button>
          <SearchWrapper></SearchWrapper>
        </SearchForm>
      </SearchWrapper>
      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>ID</th>
            <th>Phone number</th>
            <th>Bank name</th>
            <th>Account Holder</th>
            <th>Account number</th>
            <th>deposit ammount</th>
            <th>Application time</th>
            <th>processed time</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {withdrawList.map((data, idx) => (
            <WithRechargelistItem
              key={idx}
              data={data}
              onActiveToggle={onActiveToggle}
            />
          ))}
        </tbody>
      </Table>
    </>
  );
}

export default Rechargelist;
