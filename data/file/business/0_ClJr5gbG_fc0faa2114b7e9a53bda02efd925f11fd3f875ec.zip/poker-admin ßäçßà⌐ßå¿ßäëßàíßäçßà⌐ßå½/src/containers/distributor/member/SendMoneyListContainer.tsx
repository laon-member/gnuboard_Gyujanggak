import SendMoney from "components/distributor/member/sendMoney/SendMoney";
import React from "react";

function SendMoneyListContainer() {
  return <SendMoney />;
}

export default SendMoneyListContainer;
