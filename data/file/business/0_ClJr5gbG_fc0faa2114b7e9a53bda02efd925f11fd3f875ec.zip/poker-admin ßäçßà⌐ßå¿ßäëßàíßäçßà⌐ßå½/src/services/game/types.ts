import { AxiosResponse } from "axios";
import { PagingType } from "stores/message/types";
import { UseInput } from "stores/notice/types";

export interface TRoom {
  room_id: number;
  room_type: number;
  name: string;
  username: string;
}

export interface TRoomListPage {
  paging: PagingType;
  list: TRoom[];
}

export interface TRoomListSearch {
  room_type: string;
  username: string;
  nickname: string;
  page: number;
}

export interface TRoomDelete {
  toggle: boolean;
  onToggle: (payload: TRoom) => void;
  onSubmit: () => AxiosResponse;
}

export interface TRoomListForms {
  search: UseInput;
  delete: TRoomDelete;
}
