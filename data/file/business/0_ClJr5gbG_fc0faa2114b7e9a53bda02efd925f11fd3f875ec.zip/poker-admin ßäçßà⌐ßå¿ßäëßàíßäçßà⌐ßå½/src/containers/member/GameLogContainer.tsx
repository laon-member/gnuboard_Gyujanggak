import GameLogList from "components/member/gameLog/GameLogList";
import { useInputs } from "lib/hooks";
import { inject, observer, useObserver } from "mobx-react";
import React, { useEffect } from "react";
import RootStore from "stores";
import {
  TGameLogForms,
  TGameLogPage,
  TGameLogSearch,
} from "stores/member/types";

interface Props {
  getGameLogPage: (payload: TGameLogSearch) => void;
  gameLogPage: TGameLogPage;
}

const GameLogContainer = ({ getGameLogPage, gameLogPage }: Props) => {
  console.log("game log conainer");
  const forms = {
    search: useInputs({
      username: "",
      nickname: "",
      round: "",
      start_date: "",
      end_date: "",
      page: 1,
    } as TGameLogSearch),
  } as TGameLogForms;

  useEffect(() => {
    (async () => {
      await getGameLogPage(forms.search.inputs);
    })();
  }, []);

  const onSearch = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    await getGameLogPage(forms.search.inputs);
  };

  return useObserver(() => (
    <GameLogList gameLogPage={gameLogPage} forms={forms} onSearch={onSearch} />
  ));
};

export default inject(({ memberStore }: RootStore) => ({
  getGameLogPage: memberStore.getGameLogPage,
  gameLogPage: memberStore.gameLogPage,
}))(observer(GameLogContainer));
