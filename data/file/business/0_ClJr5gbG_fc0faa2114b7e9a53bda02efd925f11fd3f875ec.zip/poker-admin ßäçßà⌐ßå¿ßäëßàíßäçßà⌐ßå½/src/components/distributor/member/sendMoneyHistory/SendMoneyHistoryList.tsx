import React from "react";

function SendMoneyHistoryList() {
  return <h1>sendmoney history c</h1>;
}

export default SendMoneyHistoryList;
