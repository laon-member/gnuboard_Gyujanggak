import React from "react";
import comma from "lib/comma";
import TableRowWrapper from "components/common/TableRowWrapper";

interface Props {
  jackdata: any;
}

function JackpotItem({ jackdata }: Props) {
  return (
    <TableRowWrapper>
      <td>{jackdata.id}</td>
      <td>{jackdata.username}</td>
      <td>{comma(jackdata.amount)}</td>
      <td>
        {jackdata.created_at &&
          jackdata.created_at.toString().slice(0, 16).replace("T", " ")}
      </td>
    </TableRowWrapper>
  );
}

export default JackpotItem;
