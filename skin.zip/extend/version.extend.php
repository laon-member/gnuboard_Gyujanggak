<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

define('G5_JS_VER',  '191202');
define('G5_CSS_VER', '191202');
?>