import AgentStatList from "components/distributor/statistics/agentStat/AgentStatList";
import React from "react";

function AgentStatListContainer() {
  return <AgentStatList />;
}

export default AgentStatListContainer;
