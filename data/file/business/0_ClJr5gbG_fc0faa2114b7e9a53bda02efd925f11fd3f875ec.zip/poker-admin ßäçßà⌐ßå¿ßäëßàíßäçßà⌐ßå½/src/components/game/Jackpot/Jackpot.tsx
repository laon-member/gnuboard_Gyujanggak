import React, { useState } from "react";
import styled from "styled-components";
import SearchIcon from "assets/icons/search.png";
import {
  JackpotType,
  PolicyTypeBackUp,
  JackpotInfo,
} from "stores/jackpot/types";
import JackpotItem from "./item";
import PocliyItem from "./stack";
import JackpotDialog from "./JackpotDialog";
import useInputs from "lib/hooks/useInputs";
import Table from "components/common/Table";
import { Button, Input } from "styles/atom";
import comma from "lib/comma";
import { SearchForm, SearchWrapper } from "components/deposit/Bankset/Bankset";

interface Props {
  jackpotList: JackpotType[];
  policyList: PolicyTypeBackUp[];
  jackpot: JackpotType;
  amount: number;
  onSearch: (id?: string, startDate?: string, endDate?: string) => void;
  editPolicyList: (jackpotEditInfo: any) => void;
  jackpotInfo: JackpotInfo;
}

function Jackpot({
  jackpotList,
  policyList,
  onSearch,
  editPolicyList,
  jackpotInfo,
}: Props) {
  const { inputs, onChange } = useInputs({
    id: "",
    startDate: "",
    endDate: "",
  });
  const { id, startDate, endDate } = inputs;

  const [toggle, setToggle] = useState(false);

  const onToggle = () => {
    setToggle(!toggle);
  };

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onSearch(id, startDate, endDate);
  };
  if (!jackpotInfo) return <h1>loading...</h1>;
  return (
    <>
      <>
        <JackpotTitle>
          <Button onClick={onToggle}>Edit</Button>
          <div>
            <h3>Jackpot Amount : </h3>
            <span>
              {!jackpotInfo.jackpot_amount
                ? "0"
                : comma(jackpotInfo!.jackpot_amount)}
            </span>
          </div>
          <div>
            <h3>Today send : </h3>
            <span>
              {!jackpotInfo.today_send ? "0" : comma(jackpotInfo!.today_send)}
            </span>
          </div>
          <div>
            <h3>Limit : </h3>
            <span>
              {!jackpotInfo.limit_amount
                ? "0"
                : comma(jackpotInfo!.limit_amount)}
            </span>
          </div>
        </JackpotTitle>
        {toggle && (
          <JackpotDialog
            title="Jackpot Limit Box"
            onToggle={onToggle}
            editPolicyList={editPolicyList}
          />
        )}
        <JackpotInfoTable>
          <thead>
            <tr>
              <th>ROOM TYPE</th>
              <th>CONSUME</th>
              <th>GUARANTEE</th>
            </tr>
          </thead>
          <tbody>
            {policyList.map((data, index) => (
              <PocliyItem key={index} data={data} />
            ))}
          </tbody>
        </JackpotInfoTable>
        <SearchWrapper>
          <SearchForm onSubmit={onSubmit} className="search">
            <Input
              name="id"
              value={id}
              onChange={onChange}
              placeholder="ID"
              className="id"
            />
            <Input
              type="date"
              name="startDate"
              value={startDate}
              onChange={onChange}
              className="date"
            />
            <span> ~ </span>
            <Input
              type="date"
              name="endDate"
              value={endDate}
              onChange={onChange}
              className="date"
            />
            <Button type="submit">
              <img src={SearchIcon} alt="search" />
            </Button>
          </SearchForm>
        </SearchWrapper>
        <Table>
          <thead>
            <tr>
              <th>No.</th>
              <th>Winner</th>
              <th>Amount</th>
              <th>WinTime</th>
            </tr>
          </thead>
          <tbody>
            {jackpotList.map((jackdata, idx) => (
              <JackpotItem jackdata={jackdata} key={jackdata.id} />
            ))}
          </tbody>
        </Table>
      </>
    </>
  );
}

const JackpotInfoTable = styled.table`
  border-collapse: separate;

  & th,
  td {
    width: 200px;
  }

  & th {
    background: #555;
    color: #fff;
    padding: 0.825rem 0;
  }

  & td {
    background: #c4c4c4;
  }
`;

const JackpotTitle = styled.div`
  display: flex;
  align-items: center;
  padding: 1rem 0;
  font-size: 1.5rem;

  div {
    display: flex;
    align-items: center;
  }
  div + div {
    margin-left: 1rem;
  }

  h3 {
    font-size: 1rem;
    font-weight: bold;
    display: inline-block;
  }
  span {
    color: #007fdb;
  }

  h3 + span {
    margin-left: 1rem;
  }

  button {
    margin-right: 1rem;
  }
`;

export default Jackpot;
