import React from "react";
import { NavLink } from "react-router-dom";
import { Playing } from "stores/user/types";
import styled from "styles/theme-components";

interface Props {
  role: string;
  playing?: Playing;
}

const MainNavContainer = ({ role, playing }: Props) => {
  return (
    <>
      <StyledMainNav>
        <li>
          <NavLink to="/admin/member" activeClassName="active">
            MEMBER
          </NavLink>
        </li>
        <li>
          <NavLink to="/admin/statistics" activeClassName="active">
            STATISTICS
          </NavLink>
        </li>
        <li>
          <NavLink to="/admin/recharge" activeClassName="active">
            RECHARGE
          </NavLink>
          {playing!.deposit_count ? <div>{playing!.deposit_count}</div> : ""}
        </li>
        <li>
          <NavLink to="/admin/withdraw" activeClassName="active">
            WITHDRAW
          </NavLink>
          {playing!.withdraw_count ? <div>{playing!.withdraw_count}</div> : ""}
        </li>

        <li>
          <NavLink to="/admin/agent" activeClassName="active">
            AGENT
          </NavLink>
        </li>
        <li>
          <NavLink to="/admin/game" activeClassName="active">
            GAME
          </NavLink>
        </li>
        <li>
          <NavLink to="/admin/notice" activeClassName="active">
            NOTICE
          </NavLink>
        </li>
        <li>
          <NavLink to="/admin/message" activeClassName="active">
            MESSAGE
          </NavLink>
        </li>
        {role === "SUPER_ADMIN" && (
          <li>
            <NavLink to="/admin/maintenance" activeClassName="active">
              MAINTENANCE
            </NavLink>
          </li>
        )}
      </StyledMainNav>
    </>
  );
};

const StyledMainNav = styled.ul`
  /* background: tomato; */
  display: flex;
  background-color: #383a3f;

  li {
    position: relative;
  }

  div {
    position: absolute;
    top: 0.5rem;
    right: 0.5rem;
    background-color: red;
    font-size: 0.75rem;
    border-radius: 3px;
    color: #fff;
    padding: 3px;
  }

  a {
    box-sizing: border-box;
    display: inline-block;
    padding: 1rem 2rem;
    background-color: #383a3f;
    border-right: 1px solid #696a6c;
    color: #eeefee;
  }
  .active {
    border-top: 2px solid #d96864;
  }
`;

export default MainNavContainer;
