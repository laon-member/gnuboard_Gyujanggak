import { InputWrapper } from "components/deposit/Bankset/Bankset";
import { Invalid } from "components/login/Login";
import {
  RadioWrapper,
  TextAreaWrapper,
} from "components/member/memberlist/EditBox";
import { EditBoxType } from "components/member/memberlist/types";
import { DialogContainer } from "containers/common/dialog";
import { formatDate } from "lib/util";
import React, { useEffect } from "react";
import { AddRollingType, RollingType, UseInput } from "stores/notice/types";
import { Input } from "styles/atom";
import { TextArea } from "styles/atom/TextArea";

interface Props {
  rolling?: RollingType;
  _new?: EditBoxType;
  edit?: EditBoxType;
  form?: UseInput;
}

function RollNoticeBox({ rolling, _new, edit, form }: Props) {
  useEffect(() => {
    form?.setInputs({
      ...rolling,
    });
  }, []);

  const {
    content,
    start_date,
    end_date,
    duration,
    validateInterval,
  } = form?.inputs as AddRollingType;

  return rolling ? (
    <DialogContainer
      title="Edit Roll Notice"
      confirmText="SAVE"
      onToggle={edit!.onToggle}
      onSubmit={edit!.onSubmit}
    >
      <InputWrapper>
        <label>RollingPeriod</label>
        <Input
          type="date"
          name="start_date"
          value={formatDate(rolling.start_date)}
          onChange={form?.onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label></label>
        <Input
          type="date"
          name="end_date"
          value={formatDate(rolling.end_date)}
          onChange={form?.onChange}
        />
      </InputWrapper>
      <RadioWrapper>
        <label>Display Position</label>
        <div>
          <input
            type="radio"
            name="position"
            defaultChecked={rolling.position === "ALL"}
            value="ALL"
            onChange={form?.onChange}
          />{" "}
          <span>ALL</span>
          <input
            type="radio"
            name="position"
            defaultChecked={rolling.position === "HALL"}
            value="HALL"
            onChange={form?.onChange}
          />{" "}
          <span>HALL</span>
          <input
            type="radio"
            name="position"
            defaultChecked={rolling.position === "GAME"}
            value="GAME"
            onChange={form?.onChange}
          />{" "}
          <span>GAME</span>
        </div>
      </RadioWrapper>
      <InputWrapper>
        <label>TimeInterval(s)</label>
        <Input
          placeholder="TimeInterval(s)"
          name="duration"
          value={duration}
          onChange={form?.onChange}
        />
      </InputWrapper>
      {validateInterval && (
        <InputWrapper>
          <label></label>
          <Invalid>Please enter in units of 100</Invalid>
        </InputWrapper>
      )}
      <TextAreaWrapper>
        <label>Content</label>
        <TextArea name="content" value={content} onChange={form?.onChange} />
      </TextAreaWrapper>
    </DialogContainer>
  ) : (
    <DialogContainer
      title="Roll Notice"
      confirmText="SAVE"
      onToggle={_new!.onToggle}
      onSubmit={_new!.onSubmit}
    >
      <InputWrapper>
        <label>RollingPeriod</label>
        <Input
          type="date"
          name="start_date"
          value={start_date}
          onChange={form?.onChange}
        />
      </InputWrapper>
      <InputWrapper>
        <label></label>
        <Input
          type="date"
          name="end_date"
          value={end_date}
          onChange={form?.onChange}
        />
      </InputWrapper>
      <RadioWrapper>
        <label>Display Position</label>
        <div>
          <input
            type="radio"
            name="position"
            value="ALL"
            onChange={form?.onChange}
          />{" "}
          <span>ALL</span>
          <input
            type="radio"
            name="position"
            value="HALL"
            onChange={form?.onChange}
          />{" "}
          <span>HALL</span>
          <input
            type="radio"
            name="position"
            value="GAME"
            onChange={form?.onChange}
          />{" "}
          <span>GAME</span>
        </div>
      </RadioWrapper>
      <InputWrapper>
        <label>TimeInterval(s)</label>
        <Input
          type="number"
          placeholder="TimeInterval(s)"
          name="duration"
          value={duration}
          onChange={form?.onChange}
        />
      </InputWrapper>
      {validateInterval && (
        <InputWrapper>
          <label></label>
          <Invalid>Please enter in units of 100</Invalid>
        </InputWrapper>
      )}
      <TextAreaWrapper>
        <label>Content</label>
        <TextArea name="content" value={content} onChange={form?.onChange} />
      </TextAreaWrapper>
    </DialogContainer>
  );
}

export default RollNoticeBox;
