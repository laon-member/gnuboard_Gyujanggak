import { PagingType } from "stores/message/types";
import { UseInput } from "stores/notice/types";

export type User = {
  id: number;
  username: string;
  name: string;
  phone: string;
  birth: Date;
  sex: string;
  created_at: Date;
  updated_at?: Date;
};

export type Account = {
  id: string;
  dl: number;
  cp: number;
  created_at: Date;
  updated_at?: Date;
};

export type UserType = {
  idx: number;
  id: string;
  name: string;
  phone: string;
  birthDay: string;
  type: number;
  point: number;
  pushRecoCode?: string;
  recoCode: string;
  recoPerson: number;
  recoPrice: number;
  gender: number;
  signDate: string;
  dl: number;
};

export type PremiumType = {
  idx: number;
  updated_at: Date;
  content: string;
};

// 수정

export type TAdminStatSearch = {
  start_date: string;
  end_date: string;
  page: number;
};

export type TAdminStat = {
  day: string;
  member_recharge?: any;
  player_gold_sum: number;
  member_withdraw?: any;
  admin_increase?: any;
  admin_decrease?: any;
  total_poundage?: any;
  agent_poundage: number;
  new_member: number;
};

export type TAdminStatPage = {
  paging: PagingType;
  notices: TAdminStat[];
};

export type TAdminStatForms = {
  search: UseInput;
};

export type TAgentStat = {
  agent_id: number;
  date: string;
  username: string;
  member_number: number;
  remain_amount: number;
  total_poundage: number;
  agent_withdraw: number;
};

export interface TAgentTotalStat {
  date: string;
  member_number: number;
  ramain_amount: number;
  total_poundage: number;
  agent_withdraw?: any;
}

export type TAgentStatPage = {
  paging: PagingType;
  stats: TAgentStat[];
  total: TAgentTotalStat;
};

export type TAgentStatSearch = {
  start_date: string;
  end_date: string;
  page: number;
};

export type TAgentStatForms = {
  search: UseInput;
};
