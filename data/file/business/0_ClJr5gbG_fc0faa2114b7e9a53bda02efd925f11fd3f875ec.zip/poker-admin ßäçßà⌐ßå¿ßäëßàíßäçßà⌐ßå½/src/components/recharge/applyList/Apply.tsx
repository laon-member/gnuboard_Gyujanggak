import { TableRowWrapper } from "components/common";
import comma from "lib/comma";
import React from "react";
import { TRechargeApply, WarningBoxType } from "stores/recharge/types";
import styled from "styled-components";
import { Button } from "styles/atom";
import { CancleType } from "./types";

interface Props {
  apply: TRechargeApply;
  ok: WarningBoxType;
  reserve: WarningBoxType;
  cancle: CancleType;
}

function Apply({ apply, ok, reserve, cancle }: Props) {
  return (
    <TableRowWrapper>
      <td>{apply.id}</td>
      <td>{apply.username}</td>
      <td>{apply.agent}</td>
      <td>{apply.phone}</td>
      <td>{apply.bankAccount}</td>
      <td>{apply.bankName}</td>
      <td>{apply.bankNumber}</td>
      <td>{apply.applyTime}</td>
      <td>{apply.acceptBank}</td>
      <td>{apply.accepyBankNumber}</td>
      <td>{comma(apply.amount)}</td>
      <OptButtonsWrapper>
        <Button
          bgColor="#70C44D"
          color="white"
          onClick={apply.status === 5 ? () => ok.onToggle(apply) : undefined}
        >
          OK
        </Button>
        {apply.status === 5 ? (
          <Button bgColor="gary" color="black" disabled>
            RESERVED
          </Button>
        ) : (
          <Button
            bgColor="#FFC124"
            color="white"
            onClick={() => reserve.onToggle(apply)}
          >
            RESERVE
          </Button>
        )}
        <Button
          bgColor="#E44849"
          color="white"
          onClick={
            apply.status === 5 ? () => cancle.onToggle(apply) : undefined
          }
        >
          CANCEL
        </Button>
      </OptButtonsWrapper>
    </TableRowWrapper>
  );
}

export const OptButtonsWrapper = styled.td`
  button + button {
    margin-left: 1rem;
  }
`;

export default Apply;
