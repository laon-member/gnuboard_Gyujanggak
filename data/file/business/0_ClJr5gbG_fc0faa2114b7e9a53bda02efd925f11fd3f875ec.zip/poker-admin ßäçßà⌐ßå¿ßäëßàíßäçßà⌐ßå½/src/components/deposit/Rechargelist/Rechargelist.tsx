/* eslint-disable no-restricted-globals */
import React from "react";
import SearchIcon from "assets/icons/search.png";
import { DepositType } from "stores/deposit/types";
import RechargelistItem from "../Rechargelist/item/RechargelistItem";
import useInputs from "lib/hooks/useInputs";
import Table from "components/common/Table";
import { Input, Select, Button } from "styles/atom";
import { SearchWrapper, SearchForm } from "../Bankset/Bankset";
interface Props {
  depositList: DepositType[];
  onSearch: (
    id?: string,
    phone?: string,
    status?: string,
    startDate?: string,
    endDate?: string
  ) => void;
}

function Rechargelist({ depositList, onSearch }: Props) {
  const { inputs, onChange } = useInputs({
    id: "",
    phone: "",
    status: "",
    startDate: "",
    endDate: "",
  });
  const { id, phone, status, startDate, endDate } = inputs;

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onSearch(id, phone, status, startDate, endDate);
  };

  return (
    <>
      <SearchWrapper>
        <SearchForm onSubmit={onSubmit} className="search">
          <Input
            name="id"
            placeholder="ID"
            className="id"
            value={id}
            onChange={onChange}
          />
          <Input
            name="phone"
            placeholder="phone"
            className="mobile"
            value={phone}
            onChange={onChange}
          />
          <Select
            name="status"
            value={status}
            onChange={onChange}
            style={{ color: "#ccc" }}
          >
            <option>Status</option>
            <option value="1">Success</option>
            <option value="2">Cancle</option>
          </Select>
          <Input
            name="startDate"
            type="date"
            className="date"
            value={startDate}
            onChange={onChange}
          />
          <span> ~ </span>
          <Input
            name="endDate"
            type="date"
            className="date"
            value={endDate}
            onChange={onChange}
          />

          <Button>
            <img src={SearchIcon} alt="검색" />
          </Button>
        </SearchForm>
      </SearchWrapper>

      <Table>
        <thead>
          <tr>
            <th>No.</th>
            <th>ID</th>
            <th>Phone number</th>
            <th>Bank name</th>
            <th>Account Holder</th>
            <th>Account number</th>
            <th>입금금액</th>
            <th>Application time</th>
            <th>처리시간</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {depositList.map((data, idx) => (
            <RechargelistItem key={idx} data={data} />
          ))}
        </tbody>
      </Table>
    </>
  );
}

export default Rechargelist;
