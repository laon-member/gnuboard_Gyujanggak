import React from "react";
import { inject, observer } from "mobx-react";

import WithdrawRechargelist from "components/withdraw/WithdrawRechargelist";

import WithdrawStore from "stores/withdraw";

interface Props {
  withdrawStore?: WithdrawStore;
}

@inject("withdrawStore")
@observer
class WithdrawRechargeListContainer extends React.Component<Props> {
  private WithdrawStore = this.props.withdrawStore! as WithdrawStore;

  async componentDidMount() {
    await this.WithdrawStore.GetWithRechargeList();
  }

  onSearch = async (
    id?: string,
    phone?: string,
    status?: string,
    startDate?: string,
    endDate?: string
  ) => {
    await this.WithdrawStore.GetWithRechargeList(
      id,
      phone,
      status,
      startDate,
      endDate
    );
  };

  onActiveToggle = async (id: number) => {
    await this.WithdrawStore.onActive(id);
  };

  render() {
    return (
      <WithdrawRechargelist
        withdrawList={this.WithdrawStore.WithdrawList}
        onSearch={this.onSearch}
        onActiveToggle={this.onActiveToggle}
      />
    );
  }
}

export default WithdrawRechargeListContainer;
