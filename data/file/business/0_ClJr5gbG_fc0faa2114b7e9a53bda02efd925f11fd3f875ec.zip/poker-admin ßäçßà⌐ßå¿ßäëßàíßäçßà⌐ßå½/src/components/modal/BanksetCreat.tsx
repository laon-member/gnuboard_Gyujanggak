import React, { useState, useCallback, useEffect } from "react";
import styled from "styled-components";
import { DepositType } from "stores/deposit/types";
interface Props extends DepositType {
  // setModal: (e: any) => void;
  // insert: (user_id: number, bank: string, name: string, number: string) => void;
  insert: (bank: string, number: string) => void;
}
function BanksetCreat({ insert }: Props) {
  const [bank, setBankName] = useState<string>("");
  const [number, setBankNumber] = useState<string>("");

  // const insertAccount = useCallback(
  //   (e: any) => {
  //     e.preventDefault();
  //     // insert(user_id, bank, name, number);
  //     insert(bank, name, number);
  //     console.log('콘솔', user_id, bank, name, number);
  //   },
  //   [insert]
  // );

  const insertAccount1 = (e: any) => {
    e.preventDefault();
    insert(bank, number);
  };
  // const insertAccount = () => {
  //   insert(user_id, bank, name, number);
  //   console.log(user_id, bank, name, number);
  // };
  const onChangeName = useCallback((e: any) => {
    e.preventDefault();
    const { value } = e.target;
    setBankName(value);
  }, []);
  const onChangeNumber = useCallback((e: any) => {
    e.preventDefault();
    const { value } = e.target;
    setBankNumber(value);
  }, []);
  return (
    <Wrap>
      <div className="title">
        <h2>추가하기</h2>
      </div>

      <div className="bank">
        <ul>
          {/* <li>
            <p>유저이이디</p>
            <p>
              <input type='text' value={user_id} onChange={onChangeId} />
            </p>
          </li> */}
          <li>
            <p>Bank name</p>
            <p>
              <input type="text" value={bank} onChange={onChangeName} />
            </p>
          </li>
          {/* <li>
            <p>
Account Holder</p>
            <p>
              <input type='text' value={name} onChange={onChangeHolder} />
            </p>
          </li> */}
          <li>
            <p>Account number</p>
            <p>
              <input type="text" value={number} onChange={onChangeNumber} />
            </p>
          </li>
        </ul>
      </div>

      <div className="button">
        <button onClick={insertAccount1}>확인</button>
        <button>취소</button>
      </div>
    </Wrap>
  );
}

const Wrap = styled.div`
  width: 550px;
  height: 400px;

  background: #fff;

  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);

  & > .title {
    width: 100%;
    height: 68px;

    text-align: center;
    line-height: 68px;

    border-bottom: 1px solid #ddd;

    & > h2 {
      font-weight: normal;
      font-size: 18px;
      color: #333;
    }
  }

  & > .radiobutton {
    width: 410px;
    margin: 40px auto 0;
    & > input {
      margin-right: 4px;
    }
    & > span {
      font-size: 14px;
      color: #333;
    }
    & > span:nth-child(2) {
      margin-right: 20px;
    }
  }
  & > .button {
    width: 100%;
    height: 82px;

    text-align: center;
    line-height: 70px;

    & > button:nth-child(1) {
      width: 195px;
      height: 40px;
      background: #007fdb;
      border: none;
      color: #fff;
    }
    & > button:nth-child(2) {
      width: 195px;
      height: 40px;
      background: #ddd;
      border: none;
      color: #333;
      margin-left: 20px;
    }
  }
  & > .bank {
    width: 410px;

    margin: 20px auto;

    & > ul {
      & > li {
        width: 100%;
        height: 60px;
        overflow: hidden;
        & > p {
          float: left;
        }
        & > p:nth-child(1) {
          width: 120px;

          line-height: 60px;
          font-size: 14px;
          color: #333;
        }
        & > p:nth-child(2) {
          line-height: 60px;
          & > input {
            width: 260px;
            height: 30px;
            padding: 5px 12px;
            border: 1px solid #ccc;
            border-radius: 7px;
            font-size: 14px;
            color: #333;
          }
        }
      }
      & > li:nth-child(1) {
        & > p {
          & > input {
            ::placeholder {
              color: #999;
            }
          }
        }
      }
      & > li:nth-child(2) {
        & > p {
          & > input {
            ::placeholder {
              color: #999;
            }
          }
        }
      }
    }
  }
`;

export default BanksetCreat;
