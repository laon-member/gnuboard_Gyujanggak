import GlobalMessageList from "components/message/globalMessage/GlobalMessageList";
import { useInputs } from "lib/hooks";
import { inject, observer } from "mobx-react";
import React, { useEffect } from "react";
import { GM, SearchGMType } from "stores/message/types";

interface Props {
  GMList: GM;
  getGMList: (payload: SearchGMType) => void;
}

const GlobalMessageListContainer = ({ GMList, getGMList }: Props) => {
  const { inputs, onChange } = useInputs({
    start_date: "",
    end_date: "",
    page: 1,
  } as SearchGMType);

  useEffect(() => {
    getGMList(inputs);
  }, []);

  const onSearch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    getGMList(inputs);
  };
  return (
    <GlobalMessageList
      GMList={GMList}
      searchForm={{ inputs, onChange }}
      onSearch={onSearch}
    />
  );
};

export default inject(({ messageStore }) => ({
  GMList: messageStore.GMList,
  getGMList: messageStore.getGMList,
}))(observer(GlobalMessageListContainer));
