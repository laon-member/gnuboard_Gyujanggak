import EditBox from "components/member/memberlist/EditBox";
import { useObserver } from "mobx-react";
import React, { useState } from "react";
import { MemberAmount, MemberType } from "stores/member/types";

interface Props {
  onEditToggle: () => void;
  onEditSubmit: (
    e: React.FormEvent<HTMLFormElement>,
    memberAmount: MemberAmount
  ) => void;
  member?: MemberType;
  memberAmount?: MemberAmount;
}

export type BlockType = {
  toggle: boolean;
  onToggle: () => void;
};

function EditBoxContainer({
  onEditSubmit,
  onEditToggle,
  member,
  memberAmount,
}: Props) {
  const [blockToggle, setBlockToggle] = useState(false);
  const block: BlockType = {
    toggle: blockToggle,
    onToggle: () => setBlockToggle(!blockToggle),
  };
  return useObserver(() => (
    <EditBox
      onToggle={onEditToggle}
      onSubmit={onEditSubmit}
      block={block}
      member={member}
      memberAmount={memberAmount}
    />
  ));
}

export default EditBoxContainer;
