import userStore from "./user";
import StaticStore from "./statistics";
import DepositStore from "./deposit";
import WithdrawStore from "./withdraw";
import JackpotStore from "./jackpot";
import NoticeStore from "./notice";
import AdminStore from "./admin";
import MemberStore from "./member/store";
import MessageStore from "./message/store";
import RechargeStore from "./recharge/store";
import AgentStore from "./agent/store";
import GameStore from "./game/store";
import AgentMemberStore from "./distributor/member/agentMemberStore";
class RootStore {
  member: MemberStore;
  messageStore: MessageStore;
  rechargeStore: RechargeStore;
  memberStore: MemberStore;
  userStore: userStore;
  staticStore: StaticStore;
  depositStore: DepositStore;
  withdrawStore: WithdrawStore;
  agentStore: AgentStore;
  jackpotStore: JackpotStore;
  gameStore: GameStore;
  noticeStore: NoticeStore;
  adminStore: AdminStore;
  agentMemberStore: AgentMemberStore;
  constructor() {
    this.member = new MemberStore(this);
    this.messageStore = new MessageStore(this);
    this.memberStore = new MemberStore(this);
    this.userStore = new userStore(this);
    this.staticStore = new StaticStore(this);
    this.depositStore = new DepositStore(this);
    this.rechargeStore = new RechargeStore(this);
    this.withdrawStore = new WithdrawStore(this);
    this.agentStore = new AgentStore(this);
    this.jackpotStore = new JackpotStore(this);
    this.gameStore = new GameStore(this);
    this.noticeStore = new NoticeStore(this);
    this.adminStore = new AdminStore(this);
    this.agentMemberStore = new AgentMemberStore(this);
  }
}
export default RootStore;
