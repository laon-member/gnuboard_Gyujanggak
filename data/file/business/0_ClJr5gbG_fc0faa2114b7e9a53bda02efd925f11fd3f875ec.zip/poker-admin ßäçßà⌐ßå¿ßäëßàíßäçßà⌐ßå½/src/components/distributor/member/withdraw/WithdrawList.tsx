import React from "react";

function WithdrawList() {
  return <h1>withdraw list c</h1>;
}

export default WithdrawList;
