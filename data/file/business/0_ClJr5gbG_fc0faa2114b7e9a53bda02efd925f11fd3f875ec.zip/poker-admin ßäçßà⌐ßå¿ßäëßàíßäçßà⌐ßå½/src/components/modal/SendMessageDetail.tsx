import React from "react";
import styled from "styled-components";

const SendMessageDetail = () => {
  return (
    <Wrap>
      <div className="title">
        <h2>Send Message</h2>
      </div>

      <div>
        <div className="usernumber">
          <span>888888 x</span>
          <span>888888 x</span>
          <span>888888 x</span>
        </div>
        <ul>
          <li>
            <input type="text" placeholder="Tittle" />
          </li>

          <li>
            <textarea placeholder="Content"></textarea>
          </li>
        </ul>
      </div>

      <div className="button">
        <button>보내기</button>
        <button>취소</button>
      </div>
    </Wrap>
  );
};
const Wrap = styled.div`
  width: 550px;

  background: #fff;

  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);

  & > .title {
    width: 100%;
    height: 68px;

    text-align: center;
    line-height: 68px;

    border-bottom: 1px solid #ddd;

    & > h2 {
      font-weight: normal;
      font-size: 18px;
      color: #333;
    }
  }

  & > div {
    width: 100%;
    & > .usernumber {
      width: 361px;
      margin: 15px auto 30px;
      & > span {
        font-size: 12px;

        color: #007fdb;

        margin-right: 10px;
      }
    }

    & > ul {
      width: 376px;
      margin: 20px auto 30px;

      & > li {
        width: 361px;
        margin: 0 auto;

        overflow: hidden;
      }
      & > li:nth-child(1) {
        width: 361px;
        height: 30px;

        padding-left: 12px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 7px;

        & > input {
          border: none;
          width: 100%;

          ::placeholder {
            color: #ccc;
          }
        }
      }

      & > li:nth-child(2) {
        & > textarea {
          width: 361px;
          height: 158px;
          resize: none;
          padding: 4px 12px;

          background: #ffffff;
          border: 1px solid #ccc;

          border-radius: 7px;
          ::placeholder {
            color: #ccc;
          }
        }
      }
    }
  }
  & > .button {
    width: 100%;
    height: 82px;

    text-align: center;
    line-height: 70px;

    & > button:nth-child(1) {
      width: 195px;
      height: 40px;
      background: #007fdb;
      border: none;
      color: #fff;
    }
    & > button:nth-child(2) {
      width: 195px;
      height: 40px;
      background: #ddd;
      border: none;
      color: #333;
      margin-left: 20px;
    }
  }
`;
export default SendMessageDetail;
