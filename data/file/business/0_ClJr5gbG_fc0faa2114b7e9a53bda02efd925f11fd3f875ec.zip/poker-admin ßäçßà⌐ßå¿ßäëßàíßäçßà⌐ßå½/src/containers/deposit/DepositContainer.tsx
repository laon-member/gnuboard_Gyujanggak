import React from "react";
import { inject, observer } from "mobx-react";

import DepositStore from "stores/deposit";
import Applylist from "components/deposit/Applylist";

interface Props {
  depositStore?: DepositStore;
}

@inject("depositStore")
@observer
class DepositContainer extends React.Component<Props> {
  private DepositStore = this.props.depositStore! as DepositStore;

  async componentDidMount() {
    await this.DepositStore.GetDepositList();
  }
  updateApproval = async (id: number) => {
    await this.DepositStore.PutUpdateApproval(id);
    if (this.DepositStore.success["PUT_UPDATE_APPROVAL"]) {
      await this.DepositStore.GetDepositList();
    }
  };
  updateReject = async (id: number) => {
    await this.DepositStore.PutupdateReject(id);
    if (this.DepositStore.success["PUT_UPDATE_REJECT"]) {
      await this.DepositStore.GetDepositList();
    }
  };
  search = async (searchs: string, searchType: string, date: string) => {
    await this.DepositStore.GetSearchList(searchs, searchType, date);
  };

  onActiveToggle = async (id: number) => {
    await this.DepositStore.onActiveToggle(id);
  };

  render() {
    return (
      <Applylist
        depositList={this.DepositStore.DepositList}
        deposit={this.DepositStore.Deposit!}
        updateApproval={this.updateApproval}
        updateReject={this.updateReject}
        search={this.search}
        onActiveToggle={this.onActiveToggle}
      />
    );
  }
}

export default DepositContainer;
