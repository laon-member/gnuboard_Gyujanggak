import client from "lib/client";
import { TRoom, TRoomListSearch } from "./types";

class GameService {
  public getRoomListPage = async (payload: TRoomListSearch) => {
    return await client.get(
      `/api/admin/jackpot/game/room?room_type=${payload.room_type}&username=${payload.username
      }&nickname=${payload.nickname}&page=${payload.page - 1}`
    );
  };

  public deleteRoom = async (payload: TRoom) => {
    return await client.post(`/api/admin/jackpot/game/room/${payload.room_id}`);
  };
}

export default new GameService();
