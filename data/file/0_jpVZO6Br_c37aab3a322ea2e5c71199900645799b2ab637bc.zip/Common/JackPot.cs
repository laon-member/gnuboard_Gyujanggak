﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using System.Xml.Schema;
using UnityEngine.SceneManagement;
using LitJson;

public class JackPot : MonoBehaviour
{
    public Transform[] Numbers;
    public GameObject[] Commas;
    
    string JackPotMoney = "0";

    public float ReflashTime = 3.0f;

    string[] TargetNumbers;

    DataBaseManager DBMgr;

    private void Awake()
    {
        if(DBMgr == null)
        {
            DBMgr = FindObjectOfType<DataBaseManager>();
        }
        StartCoroutine("Co_RandomMoneyPlus");
    }

    IEnumerator Co_RandomMoneyPlus()
    {
        WaitForSeconds wfsTime = CWFS.WFS(ReflashTime);

        while (true)
        {
            StartCoroutine(DBMgr.Post(DataBaseLinkList.Instance.GetJackpotMoney, "", "Post", PlayerPrefs.GetString("Token"), (result) => {
                
                JsonData resp = JsonMapper.ToObject(result);

                if((int)resp["result"] == 1)
                {
                    int money = (int)resp["data"]["account"][0]["amount"];

                    JackPotMoney = money.ToString();

                    RollNumbers();
                }
            }));

            yield return wfsTime;
        }
    }

    void RollNumbers()
    {
        SetCommas();
        StartCoroutine("SplitJackPotMoney");
    }

    IEnumerator SplitJackPotMoney()
    {
        float length = JackPotMoney.Length;
        float waitTime = 1.0f / length;
        
        TargetNumbers = new string[JackPotMoney.Length];

        for (int i = 0; i < JackPotMoney.Length; i++)
        {
            TargetNumbers[i] = JackPotMoney[i].ToString();
        }

        int targetNum = 0;
        int idx = 0;

        WaitForSeconds wfsTime = CWFS.WFS(waitTime);

        for (int i = JackPotMoney.Length - 1; i >= 0; i--)
        {
            targetNum = int.Parse(TargetNumbers[idx]);

            StartCoroutine(SpinNumber(i, targetNum));
            idx++;
            yield return wfsTime;
        }
    }

    IEnumerator SpinNumber(int idx, int targetNum)
    {
        JackPotNumber moveNum = Numbers[idx].GetComponent<JackPotNumber>();

        moveNum.StartSpinNumber(targetNum);
        
        yield return CWFS.WFS(1.0f);

        moveNum.StopSpinNumber();
    }

    void SetCommas()
    {
        int idx = 0;

        if (JackPotMoney.Length > 3)
        {
            idx++;
            if (JackPotMoney.Length > 6)
            {
                idx++;
                if (JackPotMoney.Length > 9)
                {
                    idx++;
                }
            }
        }

        for (int i = 0; i < Commas.Length; i++)
        {
            if (i <= idx - 1)
            {
                Commas[i].SetActive(true);
            }
            else
            {
                Commas[i].SetActive(false);
            }
        }

        for (int i = 0; i < Numbers.Length; i++)
        {
            if (i <= JackPotMoney.Length - 1)
            {
                Numbers[i].gameObject.SetActive(true);
            }
            else
            {
                Numbers[i].gameObject.SetActive(false);
            }
        }
    }

    public void SetBtnActive(bool result)
    {
        GetComponent<Button>().enabled = result;
    }

    public void OnClickBtn_Jackpot()
    {
        FindObjectOfType<SoundManager>().StartSound_Effect(SoundFileList.EFFECT.btn_click);

        SceneManager.LoadScene("JackpotHistory");
    }
    
}
