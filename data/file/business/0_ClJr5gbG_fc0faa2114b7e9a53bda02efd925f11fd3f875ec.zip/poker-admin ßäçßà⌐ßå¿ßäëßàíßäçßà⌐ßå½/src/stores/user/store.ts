import { observable, flow, computed, action } from "mobx";

import BaseStore from "stores/BaseStore";
import RootStore from "stores";

import { UserType, Playing, Admin, TAgent, TAgentLogin } from "./types";
import UserService from "services/user/UserService";
import client from "lib/client";

class userStore extends BaseStore {
  root: RootStore;

  constructor(root: RootStore) {
    super();
    this.root = root;
  }

  @observable
  private _admin?: Admin;

  @observable
  private _adminId = "";

  @observable
  isLoggedInError = false;

  @observable
  private _isLoggedIn = false;

  @observable
  private _playing?: Playing;

  @observable
  private _userType?: number;
  //user 하나만 가져오는거 만들기 20200715
  @observable
  private _user?: UserType;

  @observable
  private _userList: UserType[] = [];

  @observable
  private _recoList: UserType[] = [];

  @observable
  private _rewardList: UserType[] = [];

  @observable
  agent!: TAgent;

  @computed
  get User() {
    return this._user;
  }
  @computed
  get IsLoggedIn() {
    return this._isLoggedIn;
  }

  @computed
  get adminId() {
    return this._adminId;
  }

  @computed
  get admin() {
    return this._admin;
  }

  @computed
  get UserType() {
    return this._userType;
  }

  @computed
  get UserList() {
    return this._userList;
  }

  @computed
  get RecoList() {
    return this._recoList;
  }

  @computed
  get RewardList() {
    return this._rewardList;
  }

  @computed
  get getPlaying() {
    return this._playing;
  }

  @action
  public setAdminId(id: string) {
    return (this._adminId = id);
  }

  @action setAdmin(id: string, role: string) {
    return (this._admin = {
      id,
      role,
    });
  }

  @action setAgent(id: string, role: string) {
    this.agent = { id, role }
  }

  @action
  userInit = () => {
    this._admin = null;
    this.agent = null;
  };

  @action
  public Active(id: number) {
    this._userList = this._userList.map((user) =>
      user.id === id ? { ...user, active: !user.active } : user
    );
  }

  @action
  public logout() {
    this._isLoggedIn = false;
    this._userType = undefined;
  }

  @action
  public setPlaying = (playing: any) => {
    this._playing = playing;
  };

  login = flow(function* (this: userStore, id: string, password: string) {
    try {
      const res = yield UserService.LoginAPI(id, password);
      this._admin = {
        id: res.data.data.id,
        role: res.data.data.role,
      };
      localStorage.setItem(
        "userInfo",
        JSON.stringify({
          id: res.data.data.id,
          role: res.data.data.role,
          access_token: res.data.data.access_token,
        })
      );

      client.defaults.headers[
        "Authorization"
      ] = `Bearer ${res.data.data.access_token}`;

      this.isLoggedInError = false;
    } catch (e) {
      this.isLoggedInError = true;
      throw e;
    } finally {
      this._pending["LOGIN"] = false;
    }
  });

  @action
  agentLogin = async (payload: TAgentLogin) => {
    try {
      const res = await UserService.agentLogin(payload);
      console.log(res);
      if (res.data.result) {
        this.agent = res.data.data;

        localStorage.setItem(
          "userInfo",
          JSON.stringify({
            id: res.data.data.id,
            role: res.data.data.role,
            access_token: res.data.data.access_token,
          })
        );

        client.defaults.headers[
          "Authorization"
        ] = `Bearer ${res.data.data.access_token}`;
      } else {
        return (this.isLoggedInError = true);
      }
    } catch (error) {
      throw error;
    }
  };

  @action
  playing = async () => {
    const res = await UserService.playingInfo();
    this.setPlaying(res.data.data.players);
  };

  GetOneUser = flow(function* (this: userStore, id: number) {
    this._init("GET_ONE_USER");
    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ user: UserType }>;
      } = yield UserService.GetOneUserAPI(id);
      const { user } = res.data;
      this._user = user;
      this._success["GET_ONE_USER"] = true;
    } catch (e) {
      this._failure["GET_ONE_USER"] = [true, e];
    } finally {
      this._pending["GET_ONE_USER"] = false;
    }
  });

  GetSearchUserList = flow(function* (
    this: userStore,
    type?: string,
    inputValue?: string,
    dateType?: string
  ) {
    this._init("GET_SEARCH_USER_LIST");
    try {
      const {
        data: res,
      }: {
        data: ApiResult<{ search: UserType[] }>;
      } = yield UserService.GetSearchUserListAPI(type, inputValue, dateType);
      const { search } = res.data;
      this._userList = search;

      this._success["GET_SEARCH_USER_LIST"] = true;
    } catch (e) {
      this._failure["GET_SEARCH_USER_LIST"] = [true, e];
      throw e;
    } finally {
      this._pending["GET_SEARCH_USER_LIST"] = false;
    }
  });

  PutUserPoint = flow(function* (this: userStore, idx: number, point: number) {
    this._init("PUT_USER_POINT");

    try {
      yield UserService.PutUserPointAPI(idx, point);

      this._success["PUT_USER_POINT"] = true;
    } catch (e) {
      this._failure["PUT_USER_POINT"] = [true, e];
    } finally {
      this._pending["PUT_USER_POINT"] = false;
    }
  });

  PutUserLevel = flow(function* (this: userStore, idx: number, type: number) {
    this._init("PUT_USER_LEVEL");

    try {
      yield UserService.PutUserLevelAPI(idx, type);

      this._success["PUT_USER_LEVEL"] = true;
    } catch (e) {
      this._failure["PUT_USER_LEVEL"] = [true, e];
    } finally {
      this._pending["PUT_USER_LEVEL"] = false;
    }
  });

  PutReco = flow(function* (
    this: userStore,
    idx: number,
    id: string,
    recoCode: string
  ) {
    this._init("PUT_RECO");
    try {
      yield UserService.PutRecoAPI(idx, id, recoCode);

      this._success["PUT_RECO"] = true;
    } catch (e) {
      this._failure["PUT_RECO"] = [true, e];
    } finally {
      this._pending["PUT_RECO"] = false;
    }
  });

  GetRecoList = flow(function* (this: userStore) {
    this._init("GET_RECO_LIST");

    try {
      const {
        data: res,
      }: {
        data: ApiResult<UserType[]>;
      } = yield UserService.GetRecoNoneAPI();

      this._recoList = res.data;

      this._success["GET_RECO_LIST"] = true;
    } catch (e) {
      this._failure["GET_RECO_LIST"] = [true, e];
    } finally {
      this._pending["GET_RECO_LIST"] = false;
    }
  });

  GetRewardList = flow(function* (this: userStore, idx: number) {
    this._init("GET_REWARD_LIST");

    try {
      const {
        data: res,
      }: {
        data: ApiResult<UserType[]>;
      } = yield UserService.GetRewardUser(idx);

      this._rewardList = res.data;

      this._success["GET_REWARD_LIST"] = true;
    } catch (e) {
      this._failure["GET_REWARD_LIST"] = [true, e];
    } finally {
      this._pending["GET_REWARD_LIST"] = false;
    }
  });

  PutPremium = flow(function* (this: userStore, idx: number, content: string) {
    this._init("PUT_PREMIUM");

    try {
      yield UserService.PostPremium(idx, content);

      this._success["PUT_PREMIUM"] = true;
    } catch (e) {
      this._failure["PUT_PREMIUM"] = [true, e];
    } finally {
      this._pending["PUT_PREMIUM"] = false;
    }
  });
}

export default userStore;
